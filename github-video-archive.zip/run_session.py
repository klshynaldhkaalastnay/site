"""Run one website session, PreserveTube metadata, Companion, and its HTTPS tunnel."""

import json
import os
from pathlib import Path
import re
import secrets
import signal
import sqlite3
import subprocess
import sys
import threading
import time
from urllib.request import urlopen

ROOT = Path(__file__).resolve().parent
stopping = threading.Event()


def command(*args, **kwargs):
    return subprocess.run(args, check=True, **kwargs)


def prepare_repository():
    repository = os.environ.get("ARCHIVE_REPOSITORY", "").strip()
    if not re.fullmatch(r"[A-Za-z0-9_-]+/[A-Za-z0-9_.-]+", repository):
        raise ValueError("ARCHIVE_REPOSITORY must be an owner/repo name.")
    if repository.lower() == os.environ["GITHUB_REPOSITORY"].lower():
        raise ValueError("Choose a separate repository for ARCHIVE_REPOSITORY.")
    if not os.environ.get("GH_TOKEN", "").strip():
        raise ValueError("Set GH_PAT to a token with Contents read/write access to the archive repository.")
    metadata = json.loads(command("gh", "api", f"repos/{repository}", capture_output=True, text=True).stdout)
    if metadata["private"]:
        raise ValueError("The archive repository must be public so visitors can play its media.")
    branch = metadata["default_branch"]
    directory = Path(os.environ["RUNNER_TEMP"]) / "archive-repository"
    command("gh", "auth", "setup-git", "--hostname", "github.com")
    command("git", "clone", "--depth=1", "--filter=blob:none", "--no-checkout", f"https://github.com/{repository}.git", str(directory))
    command("git", "-C", str(directory), "sparse-checkout", "set", "--cone", "catalog")
    command("git", "-C", str(directory), "checkout", branch)
    return repository, branch, directory


def stop_process(process, timeout=60):
    if process is None or process.poll() is not None:
        return
    try:
        try:
            os.killpg(process.pid, signal.SIGTERM)
        except ProcessLookupError:
            pass
        process.wait(timeout=timeout)
    except subprocess.TimeoutExpired:
        os.killpg(process.pid, signal.SIGKILL)
        process.wait(timeout=10)


def wait_ready(url, process, seconds=180):
    for _ in range(seconds):
        if stopping.is_set() or process.poll() is not None:
            break
        try:
            with urlopen(url, timeout=2) as response:
                if response.status == 200:
                    return
        except OSError:
            pass
        stopping.wait(1)
    raise RuntimeError(f"The service at {url} did not become ready.")


def record_url(url):
    print(f"Website address: {url}", flush=True)
    summary = os.environ.get("GITHUB_STEP_SUMMARY")
    if summary:
        with open(summary, "a", encoding="utf-8") as output:
            output.write(f"## Video Archive\n\n[Open the website]({url})\n\nThe server runs in this workflow session.\n")


def main():
    for signum in (signal.SIGINT, signal.SIGTERM):
        signal.signal(signum, lambda *_: stopping.set())
    repository, branch, directory = prepare_repository()
    data = ROOT / "data"
    data.mkdir(mode=0o700, exist_ok=True)
    receipt = data / "clean-stop"
    receipt.unlink(missing_ok=True)
    server = metadata = companion = tunnel = None
    reason = "startup-failed"
    ok = False
    try:
        internal_key = secrets.token_hex(8)
        if os.environ.get("GITHUB_ACTIONS") == "true":
            print(f"::add-mask::{internal_key}", flush=True)
        dependency_env = dict(os.environ)
        for name in ("GH_TOKEN", "GITHUB_TOKEN", "SITE_ARCHIVE_KEY", "TUNNEL_TOKEN"):
            dependency_env.pop(name, None)
        companion_env = dict(dependency_env, SERVER_SECRET_KEY=internal_key, HOST="127.0.0.1", PORT="8282", CACHE_ENABLED="false")
        companion = subprocess.Popen([os.environ["COMPANION_BINARY"]], cwd=os.environ["RUNNER_TEMP"],
                                     env=companion_env, start_new_session=True)
        wait_ready("http://127.0.0.1:8282/healthz", companion)
        metadata_env = dict(dependency_env, COMPANION_SECRET_KEY=internal_key)
        metadata = subprocess.Popen(["bun", "run", "index.ts"], cwd=os.environ["METADATA_DIRECTORY"],
                                    env=metadata_env, start_new_session=True)
        wait_ready("http://127.0.0.1:8008/readyz", metadata)
        env = dict(os.environ, ARCHIVE_REPOSITORY=repository, ARCHIVE_BRANCH=branch, ARCHIVE_DIRECTORY=str(directory),
                   SITE_DATA_DIRECTORY=str(data))
        env.pop("TUNNEL_TOKEN", None)
        server = subprocess.Popen([sys.executable, "-u", str(ROOT / "site_server.py")], env=env, start_new_session=True)
        port = int(os.environ.get("SITE_PORT", "8080"))
        wait_ready(f"http://127.0.0.1:{port}/healthz", server)

        token = os.environ.get("TUNNEL_TOKEN", "").strip()
        site_url = os.environ.get("SITE_URL", "").strip().rstrip("/")
        if token and not re.fullmatch(r"https://[A-Za-z0-9.-]+", site_url):
            raise ValueError("Set SITE_URL to the HTTPS origin configured on your named Cloudflare Tunnel.")
        tunnel_command = [os.environ["CLOUDFLARED"], "tunnel", "--no-autoupdate", "--protocol", "http2"]
        tunnel_command.extend(["run"] if token else ["--url", f"http://127.0.0.1:{port}"])
        tunnel = subprocess.Popen(tunnel_command, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True,
                                  bufsize=1, start_new_session=True)
        connected = threading.Event()
        address = {"url": site_url if token else ""}

        def read_tunnel():
            for line in tunnel.stdout:
                print(line.rstrip(), flush=True)
                found = re.search(r"https://[a-z0-9-]+\.trycloudflare\.com", line)
                if found and not token:
                    address["url"] = found.group()
                if "Registered tunnel connection" in line:
                    connected.set()

        reader = threading.Thread(target=read_tunnel, daemon=True)
        reader.start()
        for _ in range(90):
            if connected.is_set() and address["url"]:
                break
            if stopping.wait(1) or tunnel.poll() is not None or server.poll() is not None:
                raise RuntimeError("The site or tunnel stopped while starting.")
        if not connected.is_set() or not address["url"]:
            raise RuntimeError("The HTTPS tunnel did not connect.")
        record_url(address["url"])
        deadline = time.monotonic() + int(os.environ.get("SESSION_SECONDS", "19800"))
        reason = "time-limit"
        processes = (server, metadata, companion, tunnel)
        while time.monotonic() < deadline:
            if stopping.wait(1):
                reason = "cancelled"
                break
            if any(process.poll() is not None for process in processes):
                reason = "process-exited"
                break
        ok = reason == "time-limit"
    finally:
        stop_process(server, 120)
        stop_process(metadata)
        stop_process(companion)
        stop_process(tunnel)
        cache_safe = receipt.is_file() and receipt.read_text(encoding="ascii") == "ok"
        if cache_safe:
            with sqlite3.connect(data / "site.sqlite3") as database:
                cache_safe = database.execute("PRAGMA quick_check").fetchone() == ("ok",)
        outputs = os.environ.get("GITHUB_OUTPUT")
        if outputs:
            with open(outputs, "a", encoding="utf-8") as output:
                print(f"cache_safe={str(cache_safe).lower()}", file=output)
                print(f"ok={str(ok and cache_safe).lower()}", file=output)
        print(f"Website session ended ({reason}).", flush=True)
    if not ok or not cache_safe:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
