# Video Archive

The website server, request queue, PreserveTube metadata service, Invidious Companion, and GitHub uploader run together in one GitHub Actions workflow. The workflow imports the application from a ZIP, restores its saved state, hosts it for 5 hours 30 minutes, saves the state, and starts the next session when Continue is enabled.

A Cloudflare Tunnel provides the public HTTPS address. Videos, metadata, and the catalog are published to a separate public GitHub repository.

## Setup

1. Create two repositories. The hosting repository holds `.github/workflows/site.yml`. Initialize the public archive repository with a README so it has a default branch.
2. Extract this ZIP. Upload the ZIP as an asset on a release in your hosting repository, select **None** under **Release label**, and copy the asset's direct download link. The link should be publicly downloadable without signing in. Put the included `.github/workflows/site.yml` into your hosting repository at that exact path.
3. In the hosting repository, open Settings → Secrets and variables → Actions. Add the settings below.
4. Open Actions → Host Video Archive → Run workflow on the default branch. Leave Continue enabled. The live website link appears in the workflow run's Summary after the server and tunnel start.
5. Open Save a video on the website, enter a YouTube video URL or ID, and submit. The same running workflow downloads and uploads it. The request page shows progress and links to the archived video when it finishes.

| Kind | Name | Value |
| --- | --- | --- |
| Secret | `APP_ZIP_URL` | Direct HTTPS download link for this application ZIP |
| Secret | `GH_PAT` | Fine-grained GitHub token with Contents read/write access to the archive repository |
| Variable | `ARCHIVE_REPOSITORY` | Separate archive repository in `owner/repo` form |

Create the token under GitHub Settings → Developer settings → Personal access tokens → Fine-grained tokens. Select the archive repository and grant its Contents permission read/write. Put the token value in the hosting repository's `GH_PAT` secret.

The hosting workflow uses GitHub's automatic token for its own cache and continuation. `GH_PAT` handles video files and releases in the archive repository. The archive repository's branch rules must allow that token's user to push catalog commits.

## Website address

With the three required settings, the workflow starts a Quick Tunnel and prints a temporary `https://….trycloudflare.com` address in the run Summary. Each session receives a new address. Quick Tunnels are intended for testing and development.

For a fixed address, create a Cloudflare Tunnel, add a published application route for your domain, and set its service to `http://localhost:8080`. Add these settings to the hosting repository.

| Kind | Name | Value |
| --- | --- | --- |
| Secret | `CLOUDFLARE_TUNNEL_TOKEN` | Token for your named Cloudflare Tunnel |
| Variable | `SITE_URL` | Its HTTPS origin, such as `https://archive.example.com` |

[Cloudflare Tunnel setup](https://developers.cloudflare.com/cloudflare-one/networks/connectors/cloudflare-tunnel/get-started/create-remote-tunnel/)

## Download CDN

The archive repository's GitHub Pages site serves downloads at `https://cdn.archive.int.yt/video/{videoid}/{filename}`. Set up the archive repository separately from the website's hosting repository.

1. Copy the contents of `archive-repo/` to the archive repository root. Include `.nojekyll` and `.github/workflows/release-redirects.yml`. If you have a custom `404.html`, add the script from the supplied page to yours.
2. Under Settings → Pages, publish the default branch from `/ (root)` and use `cdn.archive.int.yt` as the custom domain. `.nojekyll` lets Pages publish IDs beginning with an underscore.
3. Add the same `GH_PAT` as an Actions secret in the archive repository. Its pushes let branch-based Pages rebuild after each redirect commit.
4. Run **Archive release redirects** once from the archive repository's Actions tab to move existing video folders and create redirects for earlier releases. Future releases trigger the workflow when published.

For a release asset named `{videoid}.mp4`, the workflow commits `video/{videoid}/{videoid}.mp4.html` and `video/{videoid}/{videoid}.mp4/index.html`. These pages start the download by default. Open `https://cdn.archive.int.yt/video/{videoid}/{videoid}.mp4.html?view=true` for a browser player that streams the release asset. After updating the workflow, run **Archive release redirects** once to add the player to existing video pages.

Metadata and thumbnail assets follow the same download redirect pattern with `{videoid}.metadata.json.html` and `{videoid}.thumbnail.jpg.html`. The index pages let the site's download links use the original filenames. The supplied `404.html` opens the directory if Pages requires its trailing slash. The watch page's player loads the MP4 from GitHub directly. Previously archived files open with their existing filenames.

[GitHub Pages publishing setup](https://docs.github.com/en/pages/getting-started-with-github-pages/configuring-a-publishing-source-for-your-github-pages-site)

## Archive storage

| Finished MP4 size | Destination in the archive repository |
| --- | --- |
| Up to and including 100 MiB | `video/{videoid}/` on its default branch |
| Over 100 MiB and under 2 GiB | Release with tag and title `{videoid}` and release label **None** |
| 2 GiB or larger | The request fails with a size-limit message |

Each new archive contains `{videoid}.mp4`, `{videoid}.metadata.json`, and `{videoid}.thumbnail.jpg` when a thumbnail is available. `catalog/{videoid}.json` records the filenames, title, channel, description, dates, duration, file size, and SHA-256. Download links for new files go live after the archive repository's Pages deployment. GitHub Pages limits the published site to 1 GB. Release assets are hosted by GitHub Releases, so only their redirect pages count toward that limit.

[GitHub Pages limits](https://docs.github.com/en/pages/getting-started-with-github-pages/github-pages-limits)

The downloader runs the code from `preservetube/metadata` at commit `88713d9290e45b790c8fb829b4bfb97a7bfacaf1`, using its active Invidious Companion path to resolve stream URLs and retrieve the audio/video. Its defaults target 480p for videos under 15 minutes and 360p for longer videos, choosing the nearest available resolution and small original-audio formats. Its FFmpeg merge keeps the selected codecs and creates an MP4.

The workflow downloads the official Linux Companion binary and installs the metadata service with Bun. The integration adjusts the local FFmpeg path, binds the service to localhost, raises the download size limit, supplies an internal Companion key, and handles failed WebSocket downloads. The metadata and Companion endpoints remain local to the runner.

[PreserveTube metadata source](https://github.com/preservetube/metadata) · [Invidious Companion source](https://github.com/iv-org/invidious-companion)

## Optional settings

| Kind | Name | Purpose |
| --- | --- | --- |
| Secret | `SITE_ARCHIVE_KEY` | Require visitors to enter this key when submitting an archive |
| Variable | `APP_ZIP_FOLDER` | Containing folder inside your ZIP, if the app files are below a parent folder |

Without `SITE_ARCHIVE_KEY`, visitors can submit videos. The server accepts three new video requests per IP per hour, keeps up to 32 open requests, and processes one video at a time. Existing archive links can be opened immediately.

## Sessions and persistence

Keep Continue enabled to start another session after shutdown and a successful cache save. Turn it off to finish after the current session. Hosting pauses during the handoff. A fixed tunnel hostname keeps the same address across sessions.

The cache stores application code, the SQLite request queue, and its small web catalog. Video downloads and the working Git checkout are temporary and stay outside this cache. Published media stays in the separate archive repository. An interrupted active request returns to the queue when its saved state is restored. A published release can repair its catalog entry if a previous push failed.

To update the application, upload the new ZIP, update `APP_ZIP_URL`, and select Force reimport on the next run. Reimport refreshes code and preserves the saved queue. GitHub may evict Actions caches, so request-state recovery depends on an available saved cache. Published media and its catalog remain in the archive repository.

## Local use

Use Python 3.12, Git, GitHub CLI, FFmpeg, and Bun. Install `aiohttp`. Run `scripts/setup_metadata.py` with `RUNNER_TEMP` and `GITHUB_ENV` set, then load the resulting `METADATA_DIRECTORY` and `COMPANION_BINARY` environment settings. Set `GH_TOKEN` to your archive-repository token, `GITHUB_REPOSITORY` to the hosting repository, `ARCHIVE_REPOSITORY` to the separate archive repository, `RUNNER_TEMP` to an empty temporary directory, and `CLOUDFLARED` to the cloudflared executable. Run `python run_session.py`.
