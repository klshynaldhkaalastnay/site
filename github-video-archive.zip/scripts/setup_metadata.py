"""Prepare PreserveTube's metadata service and its Companion dependency."""

import json
import os
from pathlib import Path
import shutil
import subprocess
import tarfile
from urllib.request import urlopen

METADATA_REF = '88713d9290e45b790c8fb829b4bfb97a7bfacaf1'
COMPANION_URL = ('https://github.com/iv-org/invidious-companion/releases/download/'
                 'release-master/invidious_companion-x86_64-unknown-linux-gnu.tar.gz')


def replace_once(text, before, after):
    if text.count(before) != 1:
        raise RuntimeError('The upstream metadata source no longer matches this integration.')
    return text.replace(before, after, 1)


def configure(directory):
    index = directory / 'index.ts'
    source = index.read_text()
    source = replace_once(source, "ffmpeg.setFfmpegPath('/usr/local/bin/ffmpeg')",
                          "ffmpeg.setFfmpegPath(process.env.FFMPEG_PATH || 'ffmpeg')")
    source = replace_once(source, 'const app = express();',
                          "const app = express();\napp.get('/readyz', (_req, res) => res.json({ status: 'ok' }));")
    source = replace_once(source, 'app.listen(8008, () => {', "app.listen(8008, '127.0.0.1', () => {")
    source = replace_once(source, "app.ws('/download/:id', async (ws, req) => {",
                          "app.ws('/download/:id', async (ws, req) => {\n  try {")
    source = replace_once(source, "  ws.send('done')\n  ws.close()\n});",
                          "  ws.send('done')\n  ws.close()\n  } catch (error: any) {\n"
                          "    console.error('Metadata download failed', error?.message);\n"
                          "    if (ws.readyState === 1) { ws.send(String(error?.message || 'Download failed')); ws.close(); }\n"
                          "  }\n});")
    source = replace_once(source, "if (info.playabilityStatus?.errorScreen", "if (info?.playabilityStatus?.errorScreen")
    index.write_text(source)

    companion = directory / 'utils' / 'companion.ts'
    source = companion.read_text()
    lines = source.splitlines(keepends=True)
    authorization = [index for index, line in enumerate(lines) if "'Authorization': 'Bearer " in line]
    if len(authorization) != 1:
        raise RuntimeError('The Companion authorization integration changed upstream.')
    lines[authorization[0]] = "      'Authorization': 'Bearer ' + process.env.COMPANION_SECRET_KEY\n"
    source = ''.join(lines)
    source = replace_once(source, '    stream.write(chunk);',
                          '    await new Promise<void>((resolve, reject) => stream.write(chunk, (error) => error ? reject(error) : resolve()));')
    source = replace_once(source, '  stream.end()',
                          "  await new Promise<void>((resolve, reject) => { stream.once('error', reject); stream.end(resolve); })")
    companion.write_text(source)
    (directory / 'config.json').write_text(json.dumps({
        'whitelist': [], 'useCompanion': True, 'maxVideoSize': (2 * 1024**3 - 1) / 1024**2,
        'companionIp': '127.0.0.1',
    }, indent=2) + '\n')
    (directory / 'output').mkdir(exist_ok=True)


def main():
    temporary = Path(os.environ['RUNNER_TEMP'])
    directory = temporary / 'preservetube-metadata'
    subprocess.run(['git', 'init', str(directory)], check=True)
    subprocess.run(['git', '-C', str(directory), 'remote', 'add', 'origin', 'https://github.com/preservetube/metadata.git'], check=True)
    subprocess.run(['git', '-C', str(directory), 'fetch', '--depth=1', 'origin', METADATA_REF], check=True)
    subprocess.run(['git', '-C', str(directory), 'checkout', '--detach', 'FETCH_HEAD'], check=True)
    configure(directory)
    subprocess.run(['bun', 'install', '--frozen-lockfile'], cwd=directory, check=True)

    archive = temporary / 'companion.tar.gz'
    with urlopen(COMPANION_URL, timeout=120) as source, archive.open('wb') as output:
        shutil.copyfileobj(source, output)
    executable = temporary / 'invidious_companion'
    with tarfile.open(archive) as bundle:
        entries = [entry for entry in bundle.getmembers() if Path(entry.name).name == 'invidious_companion' and entry.isfile()]
        if len(entries) != 1:
            raise RuntimeError('The Companion release did not contain its Linux executable.')
        with bundle.extractfile(entries[0]) as source, executable.open('wb') as output:
            shutil.copyfileobj(source, output)
    executable.chmod(0o700)
    archive.unlink()
    with open(os.environ['GITHUB_ENV'], 'a', encoding='utf-8') as environment:
        print(f'METADATA_DIRECTORY={directory}', file=environment)
        print(f'COMPANION_BINARY={executable}', file=environment)
    print('Prepared PreserveTube metadata and Invidious Companion')


if __name__ == '__main__':
    main()
