"""Assemble the website assets and its current archive catalog."""

import json
import os
from pathlib import Path
import re
import shutil
import subprocess
from urllib.parse import quote

from archive_video import (
    METADATA, THUMBNAIL, VIDEO_DIRECTORY, VIDEO_ID, metadata_name, storage_for, thumbnail_name, video_name,
)


CDN_ORIGIN = "https://cdn.archive.int.yt"


def build(repository, branch, source=Path("site"), catalog=Path("catalog"), output=Path("_site"), extra=None):
    if not re.fullmatch(r"[A-Za-z0-9_-]+/[A-Za-z0-9_.-]+", repository):
        raise ValueError("GITHUB_REPOSITORY must be in owner/repo form.")
    if not branch:
        raise ValueError("Set ARCHIVE_BRANCH to the archive repository's default branch.")

    github = f"https://github.com/{repository}"
    branch_path = quote(branch, safe="/")
    raw = f"https://raw.githubusercontent.com/{repository}/refs/heads/{branch_path}"
    # The runner only checks out the catalog. Read paths from Git to support older archives.
    tracked = set()
    if (catalog.parent / ".git").exists():
        tree = subprocess.check_output(["git", "-C", str(catalog.parent), "ls-tree", "-rz", "--name-only", "HEAD"])
        tracked = set(os.fsdecode(tree).split("\0"))
    entries = []
    for record in catalog.glob("*.json"):
        entry = json.loads(record.read_text(encoding="utf-8"))
        video_id = entry["id"]
        if not VIDEO_ID.fullmatch(video_id) or record.stem != video_id:
            raise ValueError(f"Invalid video ID in {record}.")
        storage = entry["storage"]
        if storage != storage_for(entry["size_bytes"]):
            raise ValueError(f"Invalid storage type for {video_id}.")
        metadata_filename = entry.get("metadata_filename", METADATA)
        thumbnail_filename = entry.get("thumbnail_filename", THUMBNAIL)
        if metadata_filename not in (METADATA, metadata_name(video_id)):
            raise ValueError(f"Invalid metadata filename for {video_id}.")
        if entry["thumbnail"] and thumbnail_filename not in (THUMBNAIL, thumbnail_name(video_id)):
            raise ValueError(f"Invalid thumbnail filename for {video_id}.")
        filename = video_name(video_id)
        legacy_filename = f"video-{filename}"
        folder = f"{VIDEO_DIRECTORY}/{video_id}"
        if storage == "release":
            recorded_filename = entry.get("video_filename", legacy_filename)
            if recorded_filename not in (filename, legacy_filename):
                raise ValueError(f"Invalid release filename for {video_id}.")
            filename = recorded_filename
            storage_url = f"{github}/releases/tag/{video_id}"
            asset_base = f"{github}/releases/download/{video_id}"
        else:
            for stored_folder, stored_filename in (
                (folder, filename), (folder, legacy_filename),
                (video_id, filename), (video_id, legacy_filename),
            ):
                if f"{stored_folder}/{stored_filename}" in tracked:
                    folder, filename = stored_folder, stored_filename
                    break
            storage_url = f"{github}/tree/{branch_path}/{folder}"
            asset_base = f"{raw}/{folder}"
        cdn = f"{CDN_ORIGIN}/{folder}"
        entries.append({
            **entry,
            "source_url": f"https://www.youtube.com/watch?v={video_id}",
            "storage_url": storage_url,
            "video_url": f"{asset_base}/{filename}",
            "download_url": f"{cdn}/{filename}",
            "metadata_url": f"{cdn}/{metadata_filename}",
            "thumbnail_url": f"{asset_base}/{thumbnail_filename}" if entry["thumbnail"] else None,
        })
    entries.sort(key=lambda entry: (entry["archived_at"], entry["id"]), reverse=True)

    output.mkdir(exist_ok=True)
    shutil.copytree(source, output, dirs_exist_ok=True)
    temporary = output / "catalog.json.tmp"
    temporary.write_text(json.dumps({
        "repository": repository,
        "videos": entries,
        **(extra or {}),
    }, ensure_ascii=False, separators=(",", ":")), encoding="utf-8")
    temporary.replace(output / "catalog.json")
    print(f"Built the site with {len(entries)} archived video(s).")


if __name__ == "__main__":
    build(os.environ["GITHUB_REPOSITORY"], os.environ.get("ARCHIVE_BRANCH", "main"))
