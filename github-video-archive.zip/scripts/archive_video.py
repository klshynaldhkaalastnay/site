"""Download one YouTube video and publish it with its archive metadata."""

import argparse
import asyncio
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
from urllib.error import HTTPError
from urllib.parse import parse_qs, urlsplit
from urllib.request import Request, urlopen

import aiohttp


VIDEO_ID = re.compile(r"[A-Za-z0-9_-]{11}")
GIT_LIMIT = 100 * 1024**2
RELEASE_LIMIT = 2 * 1024**3
RELEASE_NOTE = "Published by the Video Archive workflow."
VIDEO_DIRECTORY = "video"
METADATA = "metadata.json"
THUMBNAIL = "thumbnail.jpg"


def video_id_from(value):
    value = value.strip()
    if VIDEO_ID.fullmatch(value):
        return value
    parts = urlsplit(value)
    if parts.scheme not in {"http", "https"}:
        raise ValueError("Enter a YouTube video URL or an 11-character video ID.")
    host = parts.netloc.lower()
    path = parts.path.rstrip("/")
    candidate = ""
    if host in {"youtu.be", "www.youtu.be"}:
        candidate = path.removeprefix("/")
    elif host in {"youtube.com", "www.youtube.com", "m.youtube.com", "music.youtube.com"}:
        if path == "/watch":
            candidate = parse_qs(parts.query).get("v", [""])[0]
        else:
            match = re.fullmatch(r"/(?:shorts|live|embed)/([A-Za-z0-9_-]{11})", path)
            if match:
                candidate = match[1]
    if not VIDEO_ID.fullmatch(candidate):
        raise ValueError("Enter a YouTube video, Short, or recorded live stream URL or ID.")
    return candidate


def video_name(video_id):
    return f"{video_id}.mp4"


def metadata_name(video_id):
    return f"{video_id}.{METADATA}"


def thumbnail_name(video_id):
    return f"{video_id}.{THUMBNAIL}"


def storage_for(size):
    if not 0 < size < RELEASE_LIMIT:
        raise ValueError("The final MP4 must be nonempty and smaller than GitHub's 2 GiB release asset limit.")
    return "git" if size <= GIT_LIMIT else "release"


def json_text(value):
    return json.dumps(value, ensure_ascii=False, indent=2) + "\n"


def command(*args, **kwargs):
    return subprocess.run(args, check=True, **kwargs)


def save_catalog(video_id, metadata, *files):
    catalog = Path("catalog") / f"{video_id}.json"
    catalog.parent.mkdir(exist_ok=True)
    catalog.write_text(json_text(metadata), encoding="utf-8")
    branch = os.environ["ARCHIVE_BRANCH"]
    command("git", "config", "user.name", "github-actions[bot]")
    command("git", "config", "user.email", "41898282+github-actions[bot]@users.noreply.github.com")
    command("git", "add", "--", str(catalog), *map(str, files))
    command("git", "commit", "-m", f"Archive YouTube video {video_id}")
    for attempt in range(3):
        push = subprocess.run(("git", "push", "origin", f"HEAD:refs/heads/{branch}"))
        if push.returncode == 0:
            return
        if attempt == 2:
            raise ValueError("Could not push the archive catalog to the default branch.")
        command("git", "fetch", "--no-tags", "origin", branch)
        command("git", "rebase", "FETCH_HEAD")


def published_release(video_id):
    repo = os.environ["GITHUB_REPOSITORY"]
    request = Request(f"https://api.github.com/repos/{repo}/releases/tags/{video_id}", headers={
        "Accept": "application/vnd.github+json",
        "Authorization": "Bearer " + os.environ["GH_TOKEN"],
        "User-Agent": "GitHub-Video-Archive",
        "X-GitHub-Api-Version": "2022-11-28",
    })
    try:
        with urlopen(request, timeout=20) as response:
            return json.load(response)
    except HTTPError as error:
        if error.code == 404:
            return None
        raise


def recover_release(video_id, release):
    if release.get("body", "").strip() != RELEASE_NOTE or release.get("name") != video_id:
        raise ValueError(f"Release {video_id} already exists and belongs to a different process.")
    assets = {asset["name"]: asset for asset in release["assets"] if asset["state"] == "uploaded"}
    filename = video_name(video_id)
    if filename not in assets:
        filename = f"video-{filename}"
    metadata_filename = metadata_name(video_id)
    if metadata_filename not in assets:
        metadata_filename = METADATA
    thumbnail_filename = thumbnail_name(video_id)
    if thumbnail_filename not in assets:
        thumbnail_filename = THUMBNAIL
    if metadata_filename not in assets or filename not in assets:
        raise ValueError(f"Release {video_id} is missing required archive assets.")
    repo = os.environ["GITHUB_REPOSITORY"]
    with urlopen(f"https://github.com/{repo}/releases/download/{video_id}/{metadata_filename}", timeout=30) as response:
        metadata = json.loads(response.read(262_144))
    video = assets[filename]
    if (metadata["id"] != video_id or metadata["storage"] != "release"
            or metadata["size_bytes"] != video["size"]
            or storage_for(video["size"]) != "release"
            or (video.get("digest") and video["digest"] != "sha256:" + metadata["sha256"])
            or (metadata["thumbnail"] and thumbnail_filename not in assets)):
        raise ValueError(f"Release {video_id} has inconsistent archive metadata.")
    metadata.update(video_filename=filename, metadata_filename=metadata_filename,
                    thumbnail_filename=thumbnail_filename if metadata["thumbnail"] else None)
    command("gh", "auth", "setup-git", "--hostname", "github.com")
    save_catalog(video_id, metadata)


def plan(value):
    video_id = video_id_from(value)
    if (Path("catalog") / f"{video_id}.json").is_file():
        print(f"{video_id} is already in the catalog.")
        download_needed = False
    else:
        release = published_release(video_id)
        download_needed = release is None
        if release is not None:
            recover_release(video_id, release)
            print(f"Recovered the catalog entry for {video_id} from its release.")
    with Path(os.environ["GITHUB_OUTPUT"]).open("a", encoding="utf-8") as output:
        print(f"video_id={video_id}", file=output)
        print(f"download={str(download_needed).lower()}", file=output)


async def metadata_download(video_id):
    timeout = aiohttp.ClientTimeout(total=3 * 3600, connect=15, sock_read=300)
    async with aiohttp.ClientSession(timeout=timeout) as session:
        async with session.get(f"http://127.0.0.1:8008/video/{video_id}") as response:
            response.raise_for_status()
            info = await response.json()
        if info.get("error") or not info.get("videoDetails"):
            raise ValueError("PreserveTube metadata could not retrieve this video: " + str(info.get("error", "missing metadata")))
        if info["videoDetails"].get("videoId") != video_id:
            raise ValueError("The metadata service returned a different video ID.")
        if info["videoDetails"].get("isLive"):
            raise ValueError("This video is currently live.")
        done = False
        message = "The metadata download connection closed before completion."
        async with session.ws_connect(f"http://127.0.0.1:8008/download/{video_id}", heartbeat=30) as socket:
            async for event in socket:
                if event.type == aiohttp.WSMsgType.TEXT:
                    text = event.data
                    if text == "done":
                        done = True
                        break
                    if text.startswith("VIDEOSIZE-"):
                        if int(text.removeprefix("VIDEOSIZE-")) >= RELEASE_LIMIT:
                            raise ValueError("The selected streams reach the 2 GiB archive limit.")
                    else:
                        message = text
                        print(text, flush=True)
                elif event.type == aiohttp.WSMsgType.ERROR:
                    raise ValueError("The metadata download connection failed.")
        if not done:
            raise ValueError(message)
        return info


def download(video_id, directory):
    directory.mkdir(mode=0o700)
    info = asyncio.run(metadata_download(video_id))
    source = Path(os.environ["METADATA_DIRECTORY"]) / "output" / f"{video_id}.mp4"
    if not source.is_file():
        raise ValueError("The metadata service did not produce the merged MP4.")
    size = source.stat().st_size
    storage = storage_for(size)
    final = directory / video_name(video_id)
    shutil.move(source, final)
    with final.open("rb") as media:
        checksum = hashlib.file_digest(media, "sha256").hexdigest()
    details = info["videoDetails"]
    microformat = info.get("microformat", {}).get("playerMicroformatRenderer", {})
    published = microformat.get("publishDate") or microformat.get("uploadDate")
    if not isinstance(published, str):
        published = None
    thumbnail = directory / thumbnail_name(video_id)
    thumbnails = details.get("thumbnail", {}).get("thumbnails", [])
    if thumbnails:
        url = thumbnails[-1].get("url", "")
        parsed = urlsplit(url)
        if parsed.scheme == "https" and parsed.hostname in {"i.ytimg.com", "img.youtube.com"}:
            original = directory / "thumbnail-source"
            try:
                with urlopen(url, timeout=20) as response:
                    image = response.read(10 * 1024**2 + 1)
                if len(image) <= 10 * 1024**2:
                    original.write_bytes(image)
                    command("ffmpeg", "-nostdin", "-v", "error", "-i", str(original), "-frames:v", "1", str(thumbnail))
            except (OSError, subprocess.CalledProcessError):
                thumbnail.unlink(missing_ok=True)
            finally:
                original.unlink(missing_ok=True)
    metadata_file = directory / metadata_name(video_id)
    has_thumbnail = thumbnail.is_file()
    metadata = {
        "id": video_id,
        "video_filename": final.name,
        "metadata_filename": metadata_file.name,
        "thumbnail_filename": thumbnail.name if has_thumbnail else None,
        "title": str(details.get("title") or video_id)[:500],
        "channel": str(details.get("author") or "")[:250],
        "channel_id": str(details.get("channelId") or "")[:100],
        "description": str(details.get("shortDescription") or "")[:25_000],
        "published_at": published,
        "archived_at": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "duration_seconds": max(0, int(details.get("lengthSeconds") or 0)),
        "size_bytes": size,
        "sha256": checksum,
        "storage": storage,
        "thumbnail": has_thumbnail,
    }
    metadata_file.write_text(json_text(metadata), encoding="utf-8")


def create_release(video_id, files):
    repo = os.environ["GITHUB_REPOSITORY"]
    old = subprocess.run(("gh", "release", "view", "--repo", repo, "--json", "isDraft,body,name", "--", video_id),
                         capture_output=True, text=True)
    if old.returncode == 0:
        existing = json.loads(old.stdout)
        if not existing["isDraft"] or existing["body"].strip() != RELEASE_NOTE or existing["name"] != video_id:
            raise ValueError(f"Release {video_id} already exists. Rerun to recover a completed archive.")
        command("gh", "release", "delete", "--repo", repo, "--yes", "--", video_id)
    elif "release not found" not in old.stderr.lower():
        raise ValueError(f"Could not check for a draft release: {old.stderr.strip()}")

    command("gh", "release", "create", "--repo", repo, "--target", os.environ["ARCHIVE_BRANCH"],
            "--title", video_id, "--notes", RELEASE_NOTE, "--latest=false", "--", video_id, *map(str, files))


def publish(video_id, directory):
    metadata_file = directory / metadata_name(video_id)
    media_file = directory / video_name(video_id)
    metadata = json.loads(metadata_file.read_text(encoding="utf-8"))
    size = media_file.stat().st_size
    storage = storage_for(size)
    if metadata["id"] != video_id or metadata["size_bytes"] != size or metadata["storage"] != storage:
        raise ValueError("The archive files do not match their metadata.")
    thumbnail_file = directory / thumbnail_name(video_id)
    files = [media_file, metadata_file]
    if metadata["thumbnail"]:
        if not thumbnail_file.is_file():
            raise ValueError("The archive metadata lists a thumbnail, but its file is missing.")
        files.append(thumbnail_file)
    metadata.update(video_filename=media_file.name, metadata_filename=metadata_file.name,
                    thumbnail_filename=thumbnail_file.name if metadata["thumbnail"] else None)

    command("gh", "auth", "setup-git", "--hostname", "github.com")
    if storage == "git":
        folder = Path(VIDEO_DIRECTORY, video_id)
        command("git", "sparse-checkout", "add", "--", str(folder))
        if folder.parent.is_symlink() or folder.is_symlink():
            raise ValueError(f"The archive directory {folder} is a symbolic link.")
        folder.mkdir(parents=True, exist_ok=True)
        destinations = [folder / file.name for file in files]
        if any(path.exists() or path.is_symlink() for path in destinations):
            raise ValueError(f"The archive directory {folder} already contains one or more of these files.")
        for file, destination in zip(files, destinations):
            shutil.move(file, destination)
        save_catalog(video_id, metadata, *destinations)
    else:
        create_release(video_id, files)
        save_catalog(video_id, metadata)
    print(f"Archived {video_id} using {storage} storage ({size:,} bytes).")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    modes = parser.add_subparsers(dest="mode", required=True)
    modes.add_parser("plan").add_argument("url")
    for mode in ("download", "publish"):
        subparser = modes.add_parser(mode)
        subparser.add_argument("video_id")
        subparser.add_argument("directory", type=Path)
    args = parser.parse_args()
    try:
        if args.mode == "plan":
            plan(args.url)
        elif not VIDEO_ID.fullmatch(args.video_id):
            raise ValueError("Invalid YouTube video ID.")
        elif args.mode == "download":
            download(args.video_id, args.directory.resolve())
        else:
            publish(args.video_id, args.directory.resolve())
    except (ValueError, OSError, subprocess.CalledProcessError, aiohttp.ClientError) as error:
        parser.exit(1, f"Archive failed: {error}\n")
    finally:
        if args.mode == "download" and VIDEO_ID.fullmatch(args.video_id) and os.environ.get("METADATA_DIRECTORY"):
            output = Path(os.environ["METADATA_DIRECTORY"]) / "output"
            for file in output.glob(args.video_id + "*"):
                if file.is_file() and (file.name == args.video_id + ".mp4" or file.name.startswith(args.video_id + "_")):
                    file.unlink(missing_ok=True)


if __name__ == "__main__":
    main()
