"""Run the archive website and its persistent request worker."""

import asyncio
import hashlib
import hmac
import json
import logging
import os
from pathlib import Path
import secrets
import signal
import sqlite3
import sys
import tempfile
import time
from urllib.parse import urlsplit

from aiohttp import web

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / "scripts"))
from archive_video import VIDEO_DIRECTORY, video_id_from
from build_site import build

LOG = logging.getLogger("archive-site")
ACTIVE = ("queued", "planning", "downloading", "publishing")
LABELS = {
    "queued": "Waiting in the queue", "planning": "Checking for an existing archive",
    "downloading": "Downloading video", "publishing": "Uploading to GitHub",
    "archived": "Archived", "failed": "Archive failed",
}


class ArchiveSite:
    def __init__(self, repository, branch, media_dir, data_dir):
        self.repository = repository
        self.branch = branch
        self.media_dir = Path(media_dir)
        self.data_dir = Path(data_dir)
        self.data_dir.mkdir(mode=0o700, parents=True, exist_ok=True)
        self.web_dir = self.data_dir / "web"
        self.database = sqlite3.connect(self.data_dir / "site.sqlite3")
        self.database.row_factory = sqlite3.Row
        self.database.execute("PRAGMA journal_mode=WAL")
        self.database.execute("PRAGMA busy_timeout=5000")
        self.database.executescript("""
            CREATE TABLE IF NOT EXISTS jobs (
                id TEXT PRIMARY KEY, video_id TEXT NOT NULL, state TEXT NOT NULL,
                client TEXT NOT NULL, created_at INTEGER NOT NULL, updated_at INTEGER NOT NULL,
                message TEXT NOT NULL DEFAULT ''
            );
            CREATE UNIQUE INDEX IF NOT EXISTS active_video ON jobs(video_id)
                WHERE state IN ('queued','planning','downloading','publishing');
            CREATE TABLE IF NOT EXISTS settings (name TEXT PRIMARY KEY, value TEXT NOT NULL);
        """)
        with self.database:
            self.database.execute("UPDATE jobs SET state='queued', updated_at=? WHERE state IN ('planning','downloading','publishing')", (int(time.time()),))
            self.database.execute("INSERT OR IGNORE INTO settings VALUES ('ip_salt', ?)", (secrets.token_hex(32),))
        self.salt = self.database.execute("SELECT value FROM settings WHERE name='ip_salt'").fetchone()[0]
        self.wake = asyncio.Event()
        self.stopping = asyncio.Event()
        self.archive_key = os.environ.get("SITE_ARCHIVE_KEY", "")
        self.child = None
        self.refresh_catalog()

    def refresh_catalog(self):
        build(self.repository, self.branch, source=ROOT / "site", catalog=self.media_dir / "catalog", output=self.web_dir,
              extra={"archive_key_required": bool(self.archive_key)})

    def update(self, job_id, state, message=""):
        with self.database:
            self.database.execute("UPDATE jobs SET state=?, message=?, updated_at=? WHERE id=?", (state, message, int(time.time()), job_id))

    async def execute(self, *args, cwd=None, env=None):
        self.child = await asyncio.create_subprocess_exec(*map(str, args), cwd=cwd or self.media_dir, env=env,
                                                          stdin=asyncio.subprocess.DEVNULL, start_new_session=True)
        try:
            result = await self.child.wait()
            if result:
                raise RuntimeError(f"{args[0]} exited with code {result}")
        finally:
            if self.child.returncode is None:
                try:
                    try:
                        os.killpg(self.child.pid, signal.SIGTERM)
                    except ProcessLookupError:
                        pass
                    await asyncio.wait_for(self.child.wait(), timeout=30)
                except asyncio.TimeoutError:
                    try:
                        os.killpg(self.child.pid, signal.SIGKILL)
                    except ProcessLookupError:
                        pass
                    await self.child.wait()
            self.child = None

    async def process(self, job):
        job_id, video_id = job["id"], job["video_id"]
        env = dict(os.environ, GITHUB_REPOSITORY=self.repository, ARCHIVE_BRANCH=self.branch)
        script = ROOT / "scripts" / "archive_video.py"
        self.update(job_id, "planning")
        await self.execute("git", "fetch", "--no-tags", "origin", self.branch)
        await self.execute("git", "reset", "--hard", "FETCH_HEAD")
        await self.execute("git", "sparse-checkout", "set", "--cone", "catalog")
        await self.execute("git", "clean", "-fd", "--", f"{VIDEO_DIRECTORY}/{video_id}")
        work_parent = Path(os.environ.get("RUNNER_TEMP", tempfile.gettempdir()))
        with tempfile.TemporaryDirectory(prefix="site-video-", dir=work_parent) as temporary:
            work = Path(temporary)
            outputs = work / "outputs"
            env["GITHUB_OUTPUT"] = str(outputs)
            await self.execute(sys.executable, script, "plan", "--", video_id, env=env)
            plan = dict(line.split("=", 1) for line in outputs.read_text().splitlines())
            if plan["download"] == "true":
                self.update(job_id, "downloading")
                download_env = dict(env)
                for name in ("GH_TOKEN", "GITHUB_TOKEN", "SITE_ARCHIVE_KEY", "TUNNEL_TOKEN"):
                    download_env.pop(name, None)
                await self.execute(sys.executable, script, "download", "--", video_id, work / "download", env=download_env)
                self.update(job_id, "publishing")
                await self.execute(sys.executable, script, "publish", "--", video_id, work / "download", env=env)
        self.refresh_catalog()
        self.update(job_id, "archived")
        await self.execute("git", "sparse-checkout", "set", "--cone", "catalog")

    async def worker(self):
        while not self.stopping.is_set():
            self.wake.clear()
            job = self.database.execute("SELECT * FROM jobs WHERE state='queued' ORDER BY created_at, rowid LIMIT 1").fetchone()
            if job is None:
                await self.wake.wait()
                continue
            try:
                await self.process(job)
            except asyncio.CancelledError:
                self.update(job["id"], "queued")
                raise
            except Exception:
                LOG.exception("Archive request %s failed", job["id"])
                self.update(job["id"], "failed", "This attempt failed. Check the hosting workflow logs for details.")

    async def submit(self, request):
        if self.stopping.is_set():
            raise web.HTTPServiceUnavailable(text="The site is changing sessions. Try again shortly.")
        if request.content_type != "application/json":
            raise web.HTTPUnsupportedMediaType(text="Send a JSON request.")
        origin = request.headers.get("Origin")
        if origin and urlsplit(origin).netloc.lower() != request.host.lower():
            raise web.HTTPForbidden(text="Submit the request from this website.")
        authorization = request.headers.get("Authorization", "")
        if self.archive_key and not hmac.compare_digest(authorization.encode(), ("Bearer " + self.archive_key).encode()):
            raise web.HTTPUnauthorized(text="Enter the archive key.")
        try:
            body = await request.json()
            video_id = video_id_from(body["url"])
        except (ValueError, KeyError, TypeError, AttributeError):
            raise web.HTTPBadRequest(text="Enter a YouTube video URL or ID.") from None
        if (self.media_dir / "catalog" / f"{video_id}.json").is_file():
            return web.json_response({"watch_url": "?v=" + video_id})
        pending = self.database.execute("SELECT id FROM jobs WHERE video_id=? AND state IN ('queued','planning','downloading','publishing')", (video_id,)).fetchone()
        if pending:
            return web.json_response({"request_url": "?request=" + pending["id"]})
        address = request.headers.get("CF-Connecting-IP") or request.remote or "unknown"
        identity = hashlib.sha256((self.salt + address).encode()).hexdigest()
        now = int(time.time())
        recent = self.database.execute("SELECT COUNT(*) FROM jobs WHERE client=? AND created_at>?", (identity, now - 3600)).fetchone()[0]
        if recent >= 3:
            raise web.HTTPTooManyRequests(text="You can submit three new videos per hour. Try again later.")
        count = self.database.execute("SELECT COUNT(*) FROM jobs WHERE state IN ('queued','planning','downloading','publishing')").fetchone()[0]
        if count >= 32:
            raise web.HTTPServiceUnavailable(text="The archive queue is full. Try again later.")
        job_id = secrets.token_hex(16)
        with self.database:
            self.database.execute("INSERT INTO jobs(id, video_id, state, client, created_at, updated_at) VALUES (?,?,'queued',?,?,?)", (job_id, video_id, identity, now, now))
        self.wake.set()
        return web.json_response({"request_url": "?request=" + job_id}, status=202)

    async def request_status(self, request):
        row = self.database.execute("SELECT id,video_id,state,message FROM jobs WHERE id=?", (request.match_info["id"],)).fetchone()
        if row is None:
            raise web.HTTPNotFound(text="This request could not be found.")
        return web.json_response({**dict(row), "label": LABELS[row["state"]], "terminal": row["state"] in {"archived", "failed"},
                                  "watch_url": "?v=" + row["video_id"] if row["state"] == "archived" else None})

    async def static(self, request):
        name = request.match_info.get("name") or "index.html"
        if name not in {"index.html", "archive.js", "style.css", "catalog.json"}:
            raise web.HTTPNotFound()
        return web.FileResponse(self.web_dir / name)

    async def health(self, request):
        self.database.execute("SELECT 1")
        return web.json_response({"status": "ok"})

    def close(self):
        self.database.execute("PRAGMA wal_checkpoint(TRUNCATE)")
        if self.database.execute("PRAGMA quick_check").fetchall()[0][0] != "ok":
            raise RuntimeError("The site database did not pass its integrity check.")
        self.database.close()
        (self.data_dir / "clean-stop").write_text("ok", encoding="ascii")


@web.middleware
async def response_headers(request, handler):
    try:
        response = await handler(request)
    except web.HTTPException as error:
        response = web.json_response({"error": error.text}, status=error.status)
    response.headers.update({"Cache-Control": "no-store", "X-Content-Type-Options": "nosniff", "Referrer-Policy": "no-referrer",
                             "X-Frame-Options": "DENY"})
    return response


async def main():
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
    site = ArchiveSite(os.environ["ARCHIVE_REPOSITORY"], os.environ["ARCHIVE_BRANCH"],
                       os.environ["ARCHIVE_DIRECTORY"], os.environ.get("SITE_DATA_DIRECTORY", ROOT / "data"))
    (site.data_dir / "clean-stop").unlink(missing_ok=True)
    application = web.Application(client_max_size=8192, middlewares=[response_headers])
    application.add_routes([
        web.get("/healthz", site.health), web.post("/api/requests", site.submit),
        web.get("/api/requests/{id:[a-f0-9]{32}}", site.request_status),
        web.get("/", site.static), web.get("/{name}", site.static),
    ])
    runner = web.AppRunner(application, access_log=None)
    await runner.setup()
    await web.TCPSite(runner, "127.0.0.1", int(os.environ.get("SITE_PORT", "8080"))).start()
    loop = asyncio.get_running_loop()
    for signum in (signal.SIGINT, signal.SIGTERM):
        loop.add_signal_handler(signum, site.stopping.set)
    worker = asyncio.create_task(site.worker())
    stopped = asyncio.create_task(site.stopping.wait())
    try:
        done, _ = await asyncio.wait((worker, stopped), return_when=asyncio.FIRST_COMPLETED)
        if worker in done:
            await worker
            raise RuntimeError("The archive worker stopped unexpectedly.")
    finally:
        site.stopping.set()
        await runner.cleanup()
        worker.cancel()
        stopped.cancel()
        await asyncio.gather(worker, stopped, return_exceptions=True)
        site.close()


if __name__ == "__main__":
    asyncio.run(main())
