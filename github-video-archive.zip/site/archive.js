"use strict";

const content = document.querySelector("#content");
const params = new URLSearchParams(location.search);
const dateFormat = new Intl.DateTimeFormat(undefined, {
  year: "numeric", month: "short", day: "numeric", timeZone: "UTC",
});
const sizeFormat = new Intl.NumberFormat(undefined, { maximumFractionDigits: 1 });
const pageSize = 24;

function element(tag, className, text) {
  const node = document.createElement(tag);
  if (className) node.className = className;
  if (text !== undefined) node.textContent = text;
  return node;
}

function link(text, href, className) {
  const anchor = element("a", className, text);
  anchor.href = href;
  return anchor;
}

function watchUrl(id) {
  return "?" + new URLSearchParams({ v: id });
}

function date(value) {
  const parsed = value ? new Date(value) : null;
  return parsed && Number.isFinite(parsed.valueOf()) ? dateFormat.format(parsed) : "Unknown";
}

function duration(seconds) {
  const hours = Math.floor(seconds / 3600);
  const minutes = Math.floor(seconds / 60) % 60;
  const remainder = String(seconds % 60).padStart(2, "0");
  return hours ? hours + ":" + String(minutes).padStart(2, "0") + ":" + remainder : minutes + ":" + remainder;
}

function fileSize(bytes) {
  const unit = bytes >= 1024 ** 3 ? "GiB" : "MiB";
  return sizeFormat.format(bytes / (unit === "GiB" ? 1024 ** 3 : 1024 ** 2)) + " " + unit;
}

function card(video) {
  const card = link("", watchUrl(video.id), "card");
  const frame = element("div", "thumbnail");
  if (video.thumbnail_url) {
    const image = element("img");
    image.src = video.thumbnail_url;
    image.alt = "";
    image.loading = "lazy";
    image.addEventListener("error", () => image.remove());
    frame.append(image);
  }
  if (video.duration_seconds > 0) {
    frame.append(element("span", "duration", duration(video.duration_seconds)));
  }
  const copy = element("div", "card-copy");
  copy.append(element("h3", "", video.title), element("p", "muted", video.channel || "Unknown channel"),
    element("p", "muted", "Archived " + date(video.archived_at)));
  card.append(frame, copy);
  return card;
}

function browse(videos) {
  document.querySelector("#nav-browse").setAttribute("aria-current", "page");
  const query = (params.get("q") || "").trim();
  const idMatch = query.match(/(?:[?&]v=|youtu\.be\/|\/(?:shorts|live|embed)\/)([A-Za-z0-9_-]{11})(?=$|[/?&#])/i);
  const exactId = idMatch?.[1] || (/^[A-Za-z0-9_-]{11}$/.test(query) && videos.some(video => video.id === query) ? query : "");
  const terms = query.toLowerCase().split(/\s+/);
  const results = !query ? videos : videos.filter(video => {
    if (exactId) return video.id === exactId;
    const searchable = [video.title, video.channel, video.id].join(" ").toLowerCase();
    return terms.every(term => searchable.includes(term));
  });

  const hero = element("section", "hero");
  const form = element("form", "search");
  form.action = "./";
  form.setAttribute("role", "search");
  const input = element("input");
  input.type = "search";
  input.name = "q";
  input.maxLength = 200;
  input.value = query;
  input.placeholder = "Search by title, channel, or YouTube link";
  input.setAttribute("aria-label", "Search the video archive");
  const submit = element("button", "button primary", "Search");
  submit.type = "submit";
  form.append(input, submit);
  hero.append(element("p", "eyebrow", "YOUTUBE VIDEO ARCHIVE"), element("h1", "", "Video Archive"),
    element("p", "intro", "Browse and play preserved YouTube videos."), form);

  const listing = element("section", "listing");
  listing.id = "videos";
  const heading = element("div", "section-heading");
  heading.append(element("h2", "", query ? "Search results" : "Recently archived"),
    element("span", "count", results.length + (results.length === 1 ? " video" : " videos")));
  listing.append(heading);
  if (!results.length) {
    const empty = element("div", "notice");
    empty.append(element("p", "", query ? "No videos match your search." : "No videos have been archived yet."),
      link(query ? "Clear search" : "Save a video", query ? "./" : "?save=1", "button secondary"));
    listing.append(empty);
  } else {
    const pages = Math.ceil(results.length / pageSize);
    const page = Math.min(pages, Math.max(1, Number.parseInt(params.get("page"), 10) || 1));
    const grid = element("div", "grid");
    const start = (page - 1) * pageSize;
    for (const video of results.slice(start, start + pageSize)) grid.append(card(video));
    listing.append(grid);
    if (pages > 1) {
      const controls = element("nav", "pagination");
      controls.setAttribute("aria-label", "Result pages");
      const pageLink = (target, label) => {
        const targetParams = new URLSearchParams();
        if (query) targetParams.set("q", query);
        targetParams.set("page", target);
        return link(label, "?" + targetParams + "#videos", "button secondary");
      };
      if (page > 1) controls.append(pageLink(page - 1, "Previous"));
      controls.append(element("span", "muted", `Page ${page} of ${pages}`));
      if (page < pages) controls.append(pageLink(page + 1, "Next"));
      listing.append(controls);
    }
  }
  content.replaceChildren(hero, listing);
}

function watch(video) {
  if (!video) {
    content.replaceChildren(element("h1", "", "Video unavailable"),
      element("p", "muted", "This video is missing from the catalog."),
      link("Browse the archive", "./", "button secondary"));
    return;
  }
  document.title = video.title + " | Video Archive";
  const heading = element("div", "watch-heading");
  heading.append(link("← Browse", "./", "back"), element("h1", "", video.title),
    element("p", "intro", video.channel || "Unknown channel"));

  const player = element("video", "player");
  player.controls = true;
  player.playsInline = true;
  player.preload = "metadata";
  if (video.thumbnail_url) player.poster = video.thumbnail_url;
  player.src = video.video_url;
  const downloadUrl = video.download_url || video.video_url;
  const playback = element("p", "notice playback");
  playback.hidden = true;
  playback.append("Playback is unavailable in this browser. ", link("Download the MP4", downloadUrl));
  player.addEventListener("error", () => { playback.hidden = false; });

  const details = element("section", "details");
  const buttons = element("div", "actions");
  buttons.append(link("Download MP4 ↗", downloadUrl, "button primary"),
    link(video.storage === "release" ? "GitHub release ↗" : "GitHub folder ↗", video.storage_url, "button secondary"),
    link("Original YouTube video ↗", video.source_url, "button secondary"));
  const metadata = element("dl", "facts");
  for (const [label, value] of [
    ["Video ID", video.id],
    ["Published", date(video.published_at)],
    ["Archived", date(video.archived_at)],
    ["File size", fileSize(video.size_bytes)],
  ]) {
    const fact = element("div");
    fact.append(element("dt", "", label), element("dd", "", value));
    metadata.append(fact);
  }
  details.append(buttons, metadata, link("Metadata JSON ↗", video.metadata_url, "back"));
  if (video.description) {
    const description = element("section", "description");
    description.append(element("h2", "", "Description"), element("p", "", video.description));
    details.append(description);
  }
  content.replaceChildren(heading, player, playback, details);
}

function save(keyRequired) {
  document.querySelector("#nav-save").setAttribute("aria-current", "page");
  const section = element("section", "save-page");
  const form = element("form", "archive-form");
  const label = element("label", "", "YouTube video URL or ID");
  const input = element("input");
  input.name = "url";
  input.type = "text";
  input.required = true;
  input.maxLength = 2048;
  input.placeholder = "https://www.youtube.com/watch?v=…";
  label.append(input);
  form.append(label);
  const key = element("input");
  if (keyRequired) {
    const keyLabel = element("label", "", "Archive key");
    key.type = "password";
    key.autocomplete = "off";
    key.required = true;
    keyLabel.append(key);
    form.append(keyLabel);
  }
  const submit = element("button", "button primary", "Archive video");
  submit.type = "submit";
  const message = element("p", "muted");
  message.setAttribute("role", "status");
  form.append(submit, message);
  form.addEventListener("submit", async event => {
    event.preventDefault();
    submit.disabled = true;
    message.textContent = "Submitting your request…";
    try {
      const headers = { "Content-Type": "application/json" };
      if (keyRequired) headers.Authorization = "Bearer " + key.value;
      const response = await fetch("./api/requests", {
        method: "POST", headers, body: JSON.stringify({ url: input.value }),
      });
      const result = await response.json();
      if (!response.ok) throw new Error(result.error || "The request could not be submitted.");
      location.assign(result.watch_url || result.request_url);
    } catch (error) {
      message.textContent = error.message;
      submit.disabled = false;
    }
  });
  section.append(element("p", "eyebrow", "PRESERVE A VIDEO"), element("h1", "", "Save a video"),
    element("p", "intro", "Enter a YouTube video link. Follow its progress while it is preserved."), form);
  content.replaceChildren(section);
}

async function requestStatus(id) {
  const section = element("section", "save-page");
  const heading = element("h1", "", "Archive request");
  const status = element("p", "intro", "Loading your request…");
  status.setAttribute("role", "status");
  const actions = element("div", "actions");
  section.append(link("← Browse", "./", "back"), heading, status, actions);
  content.replaceChildren(section);
  if (!/^[a-f0-9]{32}$/.test(id)) {
    status.textContent = "This request could not be found.";
    return;
  }
  const update = async () => {
    try {
      const response = await fetch("./api/requests/" + id);
      const result = await response.json();
      if (!response.ok) throw new Error(result.error || "Could not read this request.");
      heading.textContent = result.label;
      status.textContent = result.message || (result.terminal ? "" : "This page updates automatically.");
      actions.replaceChildren();
      if (result.watch_url) actions.append(link("Watch archived video", result.watch_url, "button primary"));
      if (result.state === "failed") actions.append(link("Try another request", "?save=1", "button secondary"));
      if (result.terminal) return;
    } catch (error) {
      status.textContent = error.message + " Checking again shortly…";
    }
    window.setTimeout(update, 5000);
  };
  await update();
}

async function start() {
  const response = await fetch("./catalog.json");
  if (!response.ok) throw new Error("Could not load the catalog");
  const data = await response.json();
  const repositoryUrl = "https://github.com/" + data.repository;
  const repository = document.querySelector("#repository");
  repository.href = repositoryUrl;
  repository.hidden = false;
  if (params.has("v")) watch(data.videos.find(video => video.id === params.get("v")));
  else if (params.has("save")) save(data.archive_key_required);
  else if (params.has("request")) await requestStatus(params.get("request"));
  else browse(data.videos);
}

start().catch(() => {
  content.replaceChildren(element("p", "notice", "The catalog could not be loaded. Reload the page to try again."));
});
