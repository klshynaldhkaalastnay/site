"""Shared Telegram endpoint and upload limits, usable before pip installs."""
import os
from urllib.parse import urlsplit

CLOUD_API = 'https://api.telegram.org'
LOCAL_API = 'http://127.0.0.1:8081'
LARGE_VIDEO_BYTES = 50_000_000


def api_base():
    # Preserve the earlier bot's custom endpoint setting for existing local installs.
    if not os.getenv('TELEGRAM_API_BASE') and os.getenv('BOT_API_BASE_URL'):
        base = os.environ['BOT_API_BASE_URL'].strip().rstrip('/')
        parsed = urlsplit(base)
        if (parsed.scheme not in ('http', 'https') or not parsed.hostname or parsed.username
                or parsed.password or parsed.query or parsed.fragment):
            raise ValueError('Invalid custom Telegram Bot API URL')
        return base
    base = os.getenv('TELEGRAM_API_BASE', CLOUD_API).strip().rstrip('/')
    parsed = urlsplit(base)
    if (base != CLOUD_API and
            (parsed.scheme != 'http' or parsed.hostname not in ('127.0.0.1', 'localhost')
             or parsed.port not in (8081, 8082) or parsed.path or parsed.query
             or parsed.fragment or parsed.username or parsed.password)):
        raise ValueError('Use the cloud Bot API or the loopback local Bot API')
    return base


def is_local():
    return api_base() != CLOUD_API


def local_file_access():
    # The managed loopback server shares the runner filesystem with aiogram.
    # Legacy external servers keep their explicit shared-filesystem opt-in.
    return is_local() and (bool(os.getenv('TELEGRAM_API_BASE')) or
                          os.getenv('BOT_API_IS_LOCAL', 'false').lower() == 'true')


MAX_BYTES = 2_000_000_000 if is_local() else LARGE_VIDEO_BYTES
UPLOAD_TIMEOUT = 3600 if is_local() else 150
