"""Whisper controls in the same ten interface languages as the downloader."""
KEYS = [
    'Send audio, video, a voice message, or a direct media link',
    'Whisper model', 'Speech language', 'Automatic detection', 'Task', 'Transcribe',
    'Translate to English', 'Word timestamps', 'Use cached results', 'Transcript preview',
    'Transcript files', 'Preparing audio...', 'Loading Whisper...', 'Transcribing...',
    'Waiting for transcription...', 'Download {format}', 'Metadata', 'Metadata format',
    'Your queue is full, up to 4 active and 4 waiting requests are allowed',
    'This button belongs to the original requester',
    'This result has expired, send the media again', 'No speech was detected',
]
TRANSLATIONS = {
 'ar': ['أرسل ملفًا صوتيًا أو فيديو أو رسالة صوتية أو رابطًا مباشرًا للوسائط',
        'نموذج Whisper','لغة الكلام','اكتشاف تلقائي','المهمة','تفريغ النص','ترجمة إلى الإنجليزية',
        'توقيت الكلمات','استخدام النتائج المخزنة','معاينة النص','ملفات التفريغ',
        'جارٍ تجهيز الصوت...','جارٍ تحميل Whisper...','جارٍ تفريغ النص...','بانتظار تفريغ النص...',
        'تنزيل {format}','البيانات الوصفية','صيغة البيانات الوصفية',
        'قائمة الانتظار ممتلئة، يُسمح بـ4 طلبات نشطة و4 طلبات انتظار',
        'هذا الزر مخصص لصاحب الطلب الأصلي','انتهت صلاحية النتيجة، أرسل الوسائط مجددًا','لم يُكتشف أي كلام'],
 'es': ['Envía audio, vídeo, un mensaje de voz o un enlace directo al archivo',
        'Modelo Whisper','Idioma del audio','Detección automática','Tarea','Transcribir','Traducir al inglés',
        'Tiempos por palabra','Usar resultados guardados','Vista previa','Archivos de transcripción',
        'Preparando audio...','Cargando Whisper...','Transcribiendo...','Esperando transcripción...',
        'Descargar {format}','Metadatos','Formato de metadatos',
        'Tu cola está llena, se permiten 4 solicitudes activas y 4 en espera',
        'Este botón pertenece al solicitante original','El resultado ha caducado, envía el archivo otra vez','No se detectó voz'],
 'ru': ['Отправьте аудио, видео, голосовое сообщение или прямую ссылку на файл',
        'Модель Whisper','Язык аудио','Автоопределение','Задача','Расшифровать','Перевести на английский',
        'Время каждого слова','Использовать кеш','Предпросмотр текста','Файлы расшифровки',
        'Подготовка аудио...','Загрузка Whisper...','Расшифровка...','Ожидание расшифровки...',
        'Скачать {format}','Метаданные','Формат метаданных',
        'Очередь заполнена, допускается 4 активных и 4 ожидающих запроса',
        'Эта кнопка принадлежит автору запроса','Результат устарел, отправьте файл снова','Речь не обнаружена'],
 'zh': ['发送音频、视频、语音消息或媒体直链',
        'Whisper 模型','语音语言','自动检测','任务','转录','翻译成英语','逐词时间戳','使用缓存结果',
        '文本预览','转录文件','正在准备音频...','正在加载 Whisper...','正在转录...','等待转录...',
        '下载 {format}','元数据','元数据格式','队列已满，最多允许 4 个活动请求和 4 个等待请求',
        '此按钮仅供原请求者使用','结果已过期，请重新发送媒体','未检测到语音'],
 'fa': ['فایل صوتی، ویدیو، پیام صوتی یا پیوند مستقیم رسانه بفرستید',
        'مدل Whisper','زبان گفتار','تشخیص خودکار','وظیفه','رونویسی','ترجمه به انگلیسی','زمان هر واژه',
        'استفاده از نتایج ذخیره‌شده','پیش‌نمایش متن','فایل‌های رونویسی','در حال آماده‌سازی صدا...',
        'در حال بارگذاری Whisper...','در حال رونویسی...','در انتظار رونویسی...','دریافت {format}',
        'فراداده','قالب فراداده','صف پر است، ۴ درخواست فعال و ۴ درخواست در انتظار مجاز است',
        'این دکمه متعلق به درخواست‌کننده اصلی است','نتیجه منقضی شده، رسانه را دوباره بفرستید','گفتاری شناسایی نشد'],
 'ja': ['音声、動画、ボイスメッセージ、またはメディアの直接リンクを送信してください',
        'Whisperモデル','音声の言語','自動検出','タスク','文字起こし','英語に翻訳','単語のタイムスタンプ',
        'キャッシュを使う','テキストのプレビュー','文字起こしファイル','音声を準備中...',
        'Whisperを読み込み中...','文字起こし中...','文字起こしの待機中...','{format}をダウンロード',
        'メタデータ','メタデータ形式','キューが満杯です、実行中4件と待機中4件までです',
        'このボタンは元の依頼者専用です','結果の有効期限が切れました、メディアを再送信してください','音声が検出されませんでした'],
 'pt': ['Envie áudio, vídeo, uma mensagem de voz ou um link direto de mídia',
        'Modelo Whisper','Idioma da fala','Detecção automática','Tarefa','Transcrever','Traduzir para inglês',
        'Tempos por palavra','Usar resultados em cache','Prévia do texto','Arquivos de transcrição',
        'Preparando áudio...','Carregando Whisper...','Transcrevendo...','Aguardando transcrição...',
        'Baixar {format}','Metadados','Formato dos metadados',
        'Sua fila está cheia, são permitidos 4 pedidos ativos e 4 em espera',
        'Este botão pertence ao solicitante original','O resultado expirou, envie a mídia novamente','Nenhuma fala detectada'],
 'fr': ['Envoyez un audio, une vidéo, un message vocal ou un lien direct vers le média',
        'Modèle Whisper','Langue audio','Détection automatique','Tâche','Transcrire','Traduire en anglais',
        'Horodatage des mots','Utiliser le cache','Aperçu du texte','Fichiers de transcription',
        'Préparation audio...','Chargement de Whisper...','Transcription...','En attente de transcription...',
        'Télécharger {format}','Métadonnées','Format des métadonnées',
        'La file est pleine, 4 demandes actives et 4 en attente sont autorisées',
        'Ce bouton appartient au demandeur initial','Le résultat a expiré, renvoyez le média','Aucune parole détectée'],
 'de': ['Sende Audio, Video, eine Sprachnachricht oder einen direkten Medienlink',
        'Whisper-Modell','Sprache der Aufnahme','Automatisch erkennen','Aufgabe','Transkribieren','Ins Englische übersetzen',
        'Zeitstempel pro Wort','Cache verwenden','Textvorschau','Transkriptdateien','Audio wird vorbereitet...',
        'Whisper wird geladen...','Transkription läuft...','Warten auf Transkription...','{format} herunterladen',
        'Metadaten','Metadatenformat','Die Warteschlange ist voll, erlaubt sind 4 aktive und 4 wartende Anfragen',
        'Diese Schaltfläche gehört dem ursprünglichen Nutzer','Das Ergebnis ist abgelaufen, sende die Medien erneut','Keine Sprache erkannt'],
}


def install(text, languages):
    for language in languages:
        values = KEYS if language=='en' else TRANSLATIONS[language]
        assert len(values)==len(KEYS), language
        text.setdefault(language, {}).update(zip(KEYS, values))


HELP = {
 'en': 'Send audio, video, a voice message, a video note, or a direct HTTP/HTTPS media link\n\nUp to 4 active and 4 waiting requests per user\n\n/settings - Model, speech language, task and output files\n/queue - Your requests\n/cancel <job> - Cancel a request\n/ping - Check response time\n/id - Your Telegram ID\n/help - Show help\n\nStandard Telegram uploads: up to 20 MB\nDirect links: up to 500 MB by default\nDefault duration limit: 60 minutes\nWebsite page links such as YouTube are not direct media links',
 'ar': 'أرسل ملفًا صوتيًا أو فيديو أو رسالة صوتية أو رسالة فيديو أو رابط HTTP/HTTPS مباشرًا للوسائط\n\nحتى 4 طلبات نشطة و4 طلبات انتظار لكل مستخدم\n\n/settings - النموذج ولغة الكلام والمهمة وملفات الإخراج\n/queue - طلباتك\n/cancel <job> - إلغاء طلب\n/ping - قياس زمن الاستجابة\n/id - معرّف تيليجرام الخاص بك\n/help - المساعدة\n\nرفع تيليجرام العادي: حتى 20 ميغابايت\nالروابط المباشرة: حتى 500 ميغابايت افتراضيًا\nالمدة القصوى الافتراضية: 60 دقيقة\nروابط صفحات المواقع مثل يوتيوب ليست روابط وسائط مباشرة',
}
