"""Manage the loopback Bot API process and encrypted portable server state."""
import base64
import io
import json
import os
from pathlib import Path, PurePosixPath
import re
import shutil
import signal
import sqlite3
import subprocess
import sys
import time
import urllib.error
import urllib.request
import zipfile

from telegram_api import CLOUD_API, LOCAL_API

class SetupError(RuntimeError):
    """Only fixed, authored setup messages may be displayed."""


class TelegramRPCError(SetupError):
    """Safe status/retry information, without token URLs or response bodies."""
    def __init__(self, method, base, status, payload=None):
        self.status = status
        payload = payload if isinstance(payload,dict) else {}
        description = payload.get('description','')
        description = description.strip().casefold() if isinstance(description,str) else ''
        self.logged_out = status==400 and description in (
            'logged out','already logged out','bad request: logged out',
            'bad request: bot is already logged out','bad request: the bot is already logged out')
        parameters = payload.get('parameters',{})
        delay = parameters.get('retry_after') if isinstance(parameters,dict) else None
        self.retry_after = delay if type(delay) is int and delay>0 else None
        endpoint = 'cloud' if base==CLOUD_API else 'local'
        # Control methods are authored names; never copy untrusted method text.
        operation = method if method in ('getMe','logOut') else 'control request'
        message = f'Telegram {endpoint} {operation} failed'+(f', HTTP {status}' if status else ', invalid error response')
        if self.logged_out:
            message += ', the bot is already logged out'
        elif status==429:
            message += f', retry after {self.retry_after} seconds' if self.retry_after else ', temporarily rate limited'
        elif status in (401,403,404):
            message += (', check TELEGRAM_API_ID and TELEGRAM_API_HASH'
                        if endpoint=='local' and description=='unauthorized: invalid api-id/api-hash'
                        else ', check TELEGRAM_BOT_TOKEN and bot access')
        super().__init__(message)


MAX_STATE_BYTES = 256_000_000
MAX_ENCRYPTED_BYTES = 350_000_000
STATE_NAME = 'telegram-api.enc'
REQUIRED_KEY = 'local_api_state_required'


def credentials():
    identifier = os.getenv('TELEGRAM_API_ID', '').strip()
    secret = os.getenv('TELEGRAM_API_HASH', '').strip()
    token = os.getenv('TELEGRAM_BOT_TOKEN', '').strip()
    if not identifier.isascii() or not identifier.isdecimal() or not 0<int(identifier)<2**31:
        raise SetupError('Set TELEGRAM_API_ID to the numeric api_id from my.telegram.org')
    if not re.fullmatch('[A-Fa-f0-9]{32}', secret):
        raise SetupError('Set TELEGRAM_API_HASH to the api_hash from my.telegram.org')
    if not re.fullmatch(r'[0-9]+:[A-Za-z0-9_-]+', token):
        raise SetupError('Set TELEGRAM_BOT_TOKEN to the existing bot token')
    return token


def paths():
    data = Path(os.getenv('BOT_DATA_DIR', 'data')).resolve()
    runtime = Path(os.getenv('RUNNER_TEMP', '/tmp'))/'whisper-local-api'
    runtime.mkdir(parents=True, exist_ok=True, mode=0o700)
    runtime.chmod(0o700)
    binary = Path(os.getenv('BOT_API_BINARY', str(Path.home()/'.telegram-bot-api/telegram-bot-api')))
    return data, runtime, binary


def cipher():
    from cryptography.fernet import Fernet
    from cryptography.hazmat.primitives import hashes
    from cryptography.hazmat.primitives.kdf.hkdf import HKDF
    token = credentials()
    key = HKDF(algorithm=hashes.SHA256(),length=32,salt=token.split(':',1)[0].encode(),
               info=b'Whisper local Bot API state v1').derive(bytes.fromhex(os.environ['TELEGRAM_API_HASH'].strip()))
    return Fernet(base64.urlsafe_b64encode(key))


def save_state(directory, destination):
    buffer = io.BytesIO()
    total = 0
    with zipfile.ZipFile(buffer, 'w', zipfile.ZIP_DEFLATED) as archive:
        for file in sorted(directory.rglob('*')):
            if file.is_symlink():
                raise SetupError('Unexpected link in local Bot API state')
            if not file.is_file():
                continue
            total += file.stat().st_size
            if total>MAX_STATE_BYTES:
                raise SetupError('Local Bot API state exceeds the snapshot limit')
            archive.write(file,file.relative_to(directory))
    destination.parent.mkdir(parents=True,exist_ok=True)
    temporary = destination.with_suffix('.tmp')
    try:
        with temporary.open('wb') as out:
            os.chmod(temporary,0o600)
            out.write(cipher().encrypt(buffer.getvalue()))
        temporary.replace(destination)
    finally:
        temporary.unlink(missing_ok=True)


def restore_state(source, directory):
    if source.stat().st_size>MAX_ENCRYPTED_BYTES:
        raise SetupError('Encrypted local Bot API state is too large')
    raw = cipher().decrypt(source.read_bytes())
    with zipfile.ZipFile(io.BytesIO(raw)) as archive:
        entries = archive.infolist()
        if sum(item.file_size for item in entries)>MAX_STATE_BYTES or len(entries)>10000:
            raise SetupError('Local Bot API state exceeds the restore limit')
        for item in entries:
            path = PurePosixPath(item.filename)
            if (path.is_absolute() or '..' in path.parts or '\\' in item.filename
                    or item.external_attr>>16 & 0o170000 == 0o120000):
                raise SetupError('Unsafe local Bot API state entry')
        if directory.exists():
            shutil.rmtree(directory)
        directory.mkdir(parents=True,mode=0o700)
        archive.extractall(directory)


def rpc(method, base=LOCAL_API, timeout=5):
    token = credentials()
    request = urllib.request.Request(f'{base}/bot{token}/{method}',data=b'',method='POST')
    # Loopback tokens must never pass through an HTTP proxy.
    opener = urllib.request.build_opener(urllib.request.ProxyHandler({})) if base==LOCAL_API else urllib.request.build_opener()
    try:
        with opener.open(request,timeout=timeout) as response:
            raw = response.read(65536)
    except urllib.error.HTTPError as exc:
        with exc:
            try:
                payload = json.loads(exc.read(65536))
            except (ValueError,UnicodeError):
                payload = None
        raise TelegramRPCError(method,base,exc.code,payload) from None
    try:
        result = json.loads(raw)
    except (ValueError,UnicodeError):
        raise SetupError('Telegram control request returned an invalid JSON response') from None
    if not isinstance(result,dict):
        raise SetupError('Telegram control request returned an invalid response')
    if result.get('ok') is not True:
        status = result.get('error_code')
        status = status if type(status) is int and 400<=status<=599 else 0
        raise TelegramRPCError(method,base,status,result)
    return result.get('result')


def cloud_logout():
    """Deregister once, accepting the completed state and bounded retry waits."""
    deadline = time.monotonic()+660
    last_error = None
    for attempt in range(8):
        try:
            if rpc('logOut',CLOUD_API,timeout=30) is not True:
                raise SetupError('Telegram did not confirm cloud logout')
            return
        except TelegramRPCError as exc:
            if exc.logged_out:
                print('Telegram already logged out from the cloud API, continuing locally')
                return
            if exc.status==429:
                delay = exc.retry_after or 30
            elif 500<=exc.status<=599:
                delay = min(2**attempt,15)
            else:
                raise
            last_error = exc
        except (urllib.error.URLError,TimeoutError,ConnectionError):
            delay = min(2**attempt,15)
            last_error = SetupError('Could not contact Telegram cloud logOut after retries')
        if attempt==7 or delay>max(0,deadline-time.monotonic()):
            raise last_error from None
        print(f'Telegram cloud logout is temporarily unavailable, retrying in {delay} seconds',flush=True)
        wait_for_retry(delay,'cloud logout')


def wait_for_retry(delay, operation):
    while delay>0:
        pause = min(60,delay)
        time.sleep(pause)
        delay -= pause
        if delay:
            print(f'Waiting for Telegram {operation} cooldown, {delay} seconds remaining',flush=True)


def process_alive(pid):
    try:
        os.kill(pid,0)
        stat = Path(f'/proc/{pid}/stat')
        return not stat.exists() or stat.read_text().rsplit(')',1)[1].split()[0]!='Z'
    except (OSError,ValueError,IndexError):
        return False


def server_pid(runtime):
    try:
        return int((runtime/'pid').read_text())
    except (OSError,ValueError):
        return None


def owns_server(pid, runtime, binary):
    # Do not signal a reused PID belonging to an unrelated process.
    try:
        command = Path(f'/proc/{pid}/cmdline').read_bytes().split(b'\0')
        executable = Path(f'/proc/{pid}/exe').resolve()
    except OSError:
        if not process_alive(pid):
            return False
        raise SetupError('Could not verify the local Bot API process')
    owns_binary = executable==binary.resolve() or os.fsencode(str(binary.resolve())) in command[:2]
    owns_directory = os.fsencode('--dir='+str(runtime/'db')) in command
    return owns_binary and owns_directory


def stop_server(runtime, binary, timeout=45):
    pid = server_pid(runtime)
    if pid is None or not process_alive(pid):
        (runtime/'pid').unlink(missing_ok=True)
        return
    if not owns_server(pid,runtime,binary):
        raise SetupError('Local Bot API process identity changed')
    os.kill(pid,signal.SIGTERM)
    deadline = time.monotonic()+timeout
    while process_alive(pid):
        if time.monotonic()>=deadline:
            raise SetupError('Local Bot API did not stop cleanly, snapshot was not written')
        time.sleep(.2)
    (runtime/'pid').unlink(missing_ok=True)


def launch(runtime, binary):
    credentials()
    if not binary.is_file() or not os.access(binary,os.X_OK):
        raise SetupError('Cached local Bot API executable is unavailable')
    # The native server resolves --files-dir before attempting to create it.
    for name in ('db','files','temporary'):
        directory = runtime/name
        if directory.is_symlink():
            raise SetupError('Unexpected link in local Bot API runtime directories')
        directory.mkdir(parents=True,exist_ok=True,mode=0o700)
        directory.chmod(0o700)
    environment = dict(os.environ)
    for key in ('TELEGRAM_API_ID','TELEGRAM_API_HASH'):
        environment[key] = environment[key].strip()
    # Keep raw native output private, outside all cached and backed-up paths.
    # A real file keeps working after this short-lived helper process exits.
    descriptor = os.open(runtime/'startup.log',os.O_WRONLY|os.O_CREAT|os.O_TRUNC|os.O_NOFOLLOW,0o600)
    with os.fdopen(descriptor,'wb') as output:
        os.fchmod(output.fileno(),0o600)
        process = subprocess.Popen([
            str(binary),'--local','--http-ip-address=127.0.0.1','--http-port=8081',
            '--dir='+str(runtime/'db'),'--files-dir='+str(runtime/'files'),
            '--temp-dir='+str(runtime/'temporary'),'--verbosity=0'],
            stdout=output,stderr=subprocess.STDOUT,start_new_session=True,env=environment)
    (runtime/'pid').write_text(str(process.pid))
    began = time.monotonic()
    deadline = began+90
    while time.monotonic()<deadline:
        if process.poll() is not None:
            (runtime/'pid').unlink(missing_ok=True)
            startup_diagnostics(runtime)
            raise SetupError(f'Local Bot API server exited during startup, exit code {process.returncode}')
        try:
            rpc('getMe')
            return process.pid
        except TelegramRPCError as exc:
            if exc.status in (400,401,403,404):
                stop_server(runtime,binary)
                startup_diagnostics(runtime)
                raise
            if exc.status==429:
                delay = exc.retry_after or 1
                if time.monotonic()+delay>began+660:
                    stop_server(runtime,binary)
                    startup_diagnostics(runtime)
                    raise
                deadline = max(deadline,min(began+660,time.monotonic()+delay+10))
                print(f'Telegram local authorization is rate limited, retrying in {delay} seconds',flush=True)
                wait_for_retry(delay,'local authorization')
            else:
                time.sleep(.5)
        except Exception:
            time.sleep(.5)
    stop_server(runtime,binary)
    startup_diagnostics(runtime)
    raise SetupError('Local Bot API readiness timed out')


def startup_diagnostics(runtime):
    """Display only a bounded, redacted tail, never the raw native log."""
    from crash_reports import sanitize
    try:
        with (runtime/'startup.log').open('rb') as source:
            source.seek(0,os.SEEK_END)
            start = max(0,source.tell()-65536)
            source.seek(start)
            raw = source.read(65536)
        if start:
            # Drop a partial first line rather than display a cut-off secret.
            raw = raw.split(b'\n',1)[1] if b'\n' in raw else b''
        text = raw.decode('utf-8',errors='replace')
        for key,value in os.environ.items():
            if value.strip() and any(part in key.upper() for part in
                    ('TOKEN','SECRET','PASSWORD','ACCESS_KEY','COOKIES','API_HASH','ZIP_URL','TELE_ZIP')):
                text = text.replace(value.strip(),'[redacted]')
        text = sanitize(text)
        text = re.sub(r'\x1b\[[0-?]*[ -/]*[@-~]','',text)
        text = re.sub(r'[\x00-\x08\x0b-\x1f\x7f]','',text).strip()
        if text:
            print('Local Bot API startup diagnostics:\n'+text[-6000:],file=sys.stderr)
    except OSError:
        print('Local Bot API startup diagnostics are unavailable',file=sys.stderr)


def required_state(data):
    database = data/'state.db'
    if not database.is_file():
        return False
    with sqlite3.connect(f'file:{database}?mode=ro',uri=True) as db:
        return db.execute('SELECT value FROM meta WHERE key=?',(REQUIRED_KEY,)).fetchone() == ('1',)


def start():
    credentials()
    data,runtime,binary = paths()
    if not binary.is_file() or not os.access(binary,os.X_OK):
        raise SetupError('Cached local Bot API executable is unavailable')
    pid = server_pid(runtime)
    if pid is not None and process_alive(pid):
        rpc('getMe')
        return
    encrypted = data/STATE_NAME
    if not (runtime/'db').exists():
        if encrypted.is_file():
            restore_state(encrypted,runtime/'db')
        elif required_state(data):
            raise SetupError('Restore telegram-api.enc with the matching queue database before starting')
        else:
            # First migration must deregister the cloud endpoint before polling.
            cloud_logout()
    pid = launch(runtime,binary)
    output = os.getenv('GITHUB_ENV')
    if output:
        with open(output,'a') as out:
            out.write('TELEGRAM_API_BASE='+LOCAL_API+'\n')
            out.write('BOT_API_PID='+str(pid)+'\n')
    print('Local Bot API ready on loopback, maximum upload size 2 GBs')


def checkpoint():
    data,runtime,binary = paths()
    if not (runtime/'db').is_dir() or not any((runtime/'db').rglob('*')):
        raise SetupError('Local Bot API state is missing, retaining the previous snapshot')
    stop_server(runtime,binary)
    try:
        save_state(runtime/'db',data/STATE_NAME)
        if (data/'state.db').is_file():
            with sqlite3.connect(data/'state.db') as db:
                db.execute('INSERT OR REPLACE INTO meta(key,value) VALUES(?,?)',(REQUIRED_KEY,'1'))
    finally:
        pid = launch(runtime,binary)
        if output := os.getenv('GITHUB_ENV'):
            with open(output,'a') as out:
                out.write('BOT_API_PID='+str(pid)+'\n')
    print('Local Bot API state encrypted and checkpointed')


def main():
    command = sys.argv[1] if len(sys.argv)==2 else ''
    try:
        if command in ('start','ensure'):
            start()
        elif command=='checkpoint':
            checkpoint()
        elif command=='stop':
            data,runtime,binary = paths()
            stop_server(runtime,binary)
        else:
            raise SetupError('Usage: local_api.py start|ensure|checkpoint|stop')
    except Exception as exc:
        # Never print exception strings, they can contain token-bearing URLs.
        from crash_reports import exception_details
        print('Local Bot API operation failed'+(': '+str(exc) if isinstance(exc,SetupError) else '')+'\n'+exception_details(exc),file=sys.stderr)
        raise SystemExit(1)


if __name__=='__main__':
    main()
