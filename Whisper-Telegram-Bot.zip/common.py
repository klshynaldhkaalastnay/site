"""Shared input rules, limits, and per-request settings."""
import hashlib
import ipaddress
import json
import os
from pathlib import Path
import re
from urllib.parse import urlsplit, urlunsplit
from telegram_api import MAX_BYTES, is_local

TELEGRAM_DOWNLOAD_BYTES = 20_000_000
ACTIVE, WAITING = 4, 4
BUTTON_COOLDOWN = 100
CACHE_SECONDS = 3600
MODES = {'on': 'On', 'off': 'Off', 'off_no_button': 'Off with no button'}
FORMATS = ('txt', 'srt', 'vtt', 'tsv', 'json')
MODELS = ('tiny', 'base', 'small', 'medium', 'large', 'turbo')
BOT_NAME = '@transcribewhisper_bot'
BOT_LINK = 'https://t.me/transcribewhisper_bot?start=welcome_hehehehaw=='
BOT_ATTRIBUTION = f'<a href="{BOT_LINK}">{BOT_NAME}</a>'
URL_RE = re.compile(r'https?://[^\s<>"\u200b]+', re.I)


class MediaError(Exception):
    def __init__(self, code):
        self.code = code
        super().__init__(code)


def normalize_url(value):
    if len(value) > 8192 or any(ord(c) < 32 for c in value):
        raise MediaError('invalid_url')
    try:
        p = urlsplit(value)
        if p.scheme not in ('http', 'https') or not p.hostname or p.username or p.password:
            raise ValueError()
        if p.port is not None and not 1 <= p.port <= 65535:
            raise ValueError()
        host = p.hostname.rstrip('.').lower()
        if host == 'localhost' or host.endswith(('.localhost', '.local', '.internal')) or '%' in host:
            raise ValueError()
        try:
            address = ipaddress.ip_address(host)
        except ValueError:
            pass
        else:
            if not address.is_global or address.is_multicast:
                raise ValueError()
        return urlunsplit((p.scheme, p.netloc, p.path or '/', p.query, ''))
    except (ValueError, TypeError):
        raise MediaError('invalid_url') from None


def extract_links(text):
    good, bad = [], False
    for candidate in URL_RE.findall(text or ''):
        try:
            candidate = normalize_url(candidate)
            if candidate not in good:
                good.append(candidate)
        except MediaError:
            bad = True
    return good, bad


def safe_name(value):
    # Telegram names and HTTP headers never become filesystem paths.
    name = Path(str(value).replace('\\', '/')).name
    name = re.sub(r'[\x00-\x1f\x7f<>:"/\\|?*]', '_', name).strip(' .')
    return (name[:100].rstrip(' .') or 'media')


def settings(state, user):
    raw = state.get(f'options:{user}', '{}')
    try:
        saved = json.loads(raw)
    except (ValueError, TypeError):
        saved = {}
    if not isinstance(saved, dict):
        saved = {}
    default_model = os.getenv('WHISPER_MODEL', 'base')
    if default_model not in MODELS:
        default_model = 'base'
    result = {
        'model': default_model, 'language': 'auto', 'task': 'transcribe',
        'words': False, 'cache': True, 'preview': True,
        'txt': 'on', 'srt': 'off_no_button', 'vtt': 'off_no_button',
        'tsv': 'off_no_button', 'json': 'off_no_button',
        'metadata': 'off_no_button', 'metadata_format': 'json',
    }
    for k, v in saved.items():
        if k in FORMATS + ('metadata',) and v in MODES:
            result[k] = v
        elif k == 'model' and v in MODELS:
            result[k] = v
        elif k == 'task' and v in ('transcribe', 'translate'):
            result[k] = v
        elif k == 'language' and isinstance(v, str) and re.fullmatch(r'auto|[a-z]{2,3}', v):
            result[k] = v
        elif k in ('words', 'cache', 'preview') and isinstance(v, bool):
            result[k] = v
        elif k == 'metadata_format' and v in ('json', 'xml', 'txt'):
            result[k] = v
    # Turbo is not trained for translation. The menus also enforce this rule.
    if result['task'] == 'translate' and result['model'] == 'turbo':
        result['model'] = 'base'
    return result


def inference_key(options):
    payload = {key: options[key] for key in ('model', 'language', 'task', 'words')}
    return hashlib.sha256(json.dumps(payload, sort_keys=True).encode()).hexdigest()


def source_key(kind, value):
    return kind + ':' + hashlib.sha256(value.encode()).hexdigest()


def utf16_clip(text, units):
    return text.encode('utf-16-le')[:units * 2].decode('utf-16-le', errors='ignore')


def input_limit():
    value = int(os.getenv('MAX_INPUT_MB') or ('2000' if is_local() else '500')) * 1_000_000
    return min(value, MAX_BYTES) if is_local() else value


def size_label(value):
    if value >= 1_000_000_000:
        return f'{value / 1_000_000_000:g} GBs'
    return f'{value / 1_000_000:g} MB'

