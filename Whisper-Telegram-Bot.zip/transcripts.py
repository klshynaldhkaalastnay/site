"""Render timestamped Whisper results without importing PyTorch in the bot."""
import json
import re
from xml.etree import ElementTree as ET


def timestamp(seconds, vtt=False):
    milliseconds = round(max(0, float(seconds))*1000)
    hours, milliseconds = divmod(milliseconds, 3_600_000)
    minutes, milliseconds = divmod(milliseconds, 60_000)
    seconds, milliseconds = divmod(milliseconds, 1000)
    return f'{hours:02}:{minutes:02}:{seconds:02}' + ('.' if vtt else ',') + f'{milliseconds:03}'


def render(payload, kind):
    segments = payload.get('segments', [])
    if kind == 'txt':
        return (payload.get('text', '').strip()+'\n').encode('utf-8')
    if kind == 'json':
        return (json.dumps({k:v for k,v in payload.items() if k!='metadata'},
                           indent=2, ensure_ascii=False)+'\n').encode('utf-8')
    if kind in ('srt', 'vtt'):
        blocks = ['WEBVTT\n'] if kind == 'vtt' else []
        for index, segment in enumerate(segments, 1):
            text = segment.get('text', '').strip().replace('-->', '→')
            if not text:
                continue
            start, end = timestamp(segment['start'], kind=='vtt'), timestamp(segment['end'], kind=='vtt')
            blocks.append((f'{index}\n' if kind=='srt' else '')+f'{start} --> {end}\n{text}\n')
        return ('\n'.join(blocks)+'\n').encode('utf-8')
    if kind == 'tsv':
        lines = ['start\tend\ttext']
        for segment in segments:
            text = re.sub(r'[\t\r\n]+', ' ', segment.get('text', '').strip())
            lines.append(f"{round(segment['start']*1000)}\t{round(segment['end']*1000)}\t{text}")
        return ('\n'.join(lines)+'\n').encode('utf-8')
    raise ValueError('Unsupported transcript format')


def render_metadata(payload, kind):
    info = payload.get('metadata', {})
    if kind == 'json':
        return (json.dumps(info, indent=2, ensure_ascii=False)+'\n').encode('utf-8')
    if kind == 'xml':
        root = ET.Element('metadata')
        def append(parent, value):
            if isinstance(value, dict):
                for key, child in value.items():
                    node = ET.SubElement(parent, 'field', name=str(key))
                    append(node, child)
            elif isinstance(value, list):
                for item in value:
                    append(ET.SubElement(parent, 'item'), item)
            else:
                # XML 1.0 excludes C0 controls even though JSON accepts them.
                parent.text = re.sub(r'[\x00-\x08\x0b\x0c\x0e-\x1f]', '', str(value)) if value is not None else ''
        append(root, info)
        ET.indent(root)
        return ET.tostring(root, encoding='utf-8', xml_declaration=True)
    if kind == 'txt':
        lines = []
        def flatten(prefix, value):
            if isinstance(value, dict):
                for key, child in value.items():
                    flatten(f'{prefix}.{key}' if prefix else str(key), child)
            elif isinstance(value, list):
                for index, child in enumerate(value):
                    flatten(f'{prefix}[{index}]', child)
            else:
                lines.append(f'{prefix}: {value}')
        flatten('', info)
        return ('\n'.join(lines)+'\n').encode('utf-8')
    raise ValueError('Unsupported metadata format')

