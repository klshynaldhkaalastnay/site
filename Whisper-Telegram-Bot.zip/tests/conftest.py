from types import SimpleNamespace
from unittest.mock import AsyncMock
import pytest

from bot import Runner
from state import State


@pytest.fixture
def state(tmp_path):
    instance = State(tmp_path/'state.db')
    yield instance
    instance.close()


@pytest.fixture
def options(state):
    from common import settings
    return settings(state,101)


@pytest.fixture
def payload():
    return {'text':'Hello <world> مرحبًا', 'language':'en', 'model':'base', 'task':'transcribe',
            'duration':2.5, 'name':'recording.mp4',
            'segments':[{'start':0.25,'end':2.5,'text':'Hello <world> مرحبًا',
                         'words':[{'start':0.25,'end':1.2,'word':'Hello'}]}],
            'metadata':{'format':{'tags':{'title':'A&B <name>'}},'streams':[{'codec_type':'audio'}]}}


@pytest.fixture
def runner(state,tmp_path,monkeypatch):
    monkeypatch.delenv('BOT_API_BASE_URL',raising=False)
    monkeypatch.delenv('TELEGRAM_API_BASE',raising=False)
    fake = SimpleNamespace()
    for name in ('send_message','edit_message_text','send_document','send_media_group',
                 'get_file','download_file','delete_webhook','set_my_commands','copy_message'):
        setattr(fake,name,AsyncMock(return_value=SimpleNamespace(message_id=55)))
    fake.get_me = AsyncMock(return_value=SimpleNamespace(username='WhisperTestBot'))
    r = Runner(state,fake,tmp_path,999)
    async def api(chat,operation):
        return await operation()
    r.api = api
    return r


@pytest.fixture
def submit(state, options):
    def create(user=101,message=1,source=None,custom=None):
        source = source or {'kind':'url','url':'https://example.com/audio.mp3','name':'media'}
        return state.submit(user,user,message,None,source,f'media:{message}',custom or options)[0]
    return create
