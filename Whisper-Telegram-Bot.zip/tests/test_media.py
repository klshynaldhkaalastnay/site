import io
import json
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import AsyncMock
import wave

import pytest

from bot import BoundedWriter
from common import MediaError,normalize_url,extract_links,safe_name
from media import PublicResolver,download_url
from worker import prepare_audio


@pytest.mark.parametrize('url',[
    'file:///etc/passwd','http://localhost/a','http://127.0.0.1/a','http://[::1]/a',
    'http://169.254.169.254/a','https://user:password@example.com/a','http://10.0.0.1/a',
    'http://[::ffff:127.0.0.1]/a','http://224.0.0.1/a','https://example.local/a',
])
def test_rejects_nonpublic_urls(url):
    with pytest.raises(MediaError):
        normalize_url(url)


def test_signed_queries_preserved_and_filenames_sanitized():
    url = 'https://cdn.example.com/video?X-Amz-Signature=abc%2Fdef&x=1#video'
    assert normalize_url(url)==url.split('#')[0]
    assert extract_links(url+'\n'+url)[0]==[url.split('#')[0]]
    assert safe_name('../../secret.mp3')=='secret.mp3'
    assert safe_name('..\\unsafe.mp4')=='unsafe.mp4'


async def test_dns_rebinding_and_mixed_public_private_answers_rejected(monkeypatch):
    resolver = PublicResolver()
    resolver.inner.resolve = AsyncMock(return_value=[{'host':'8.8.8.8'},{'host':'127.0.0.1'}])
    with pytest.raises(OSError):
        await resolver.resolve('example.com')
    await resolver.close()


def test_unknown_file_size_is_still_bounded():
    output = BoundedWriter(io.BytesIO(),4)
    output.write(b'1234')
    with pytest.raises(MediaError):
        output.write(b'5')


def write_wave(path,seconds):
    with wave.open(str(path),'wb') as output:
        output.setnchannels(1)
        output.setsampwidth(2)
        output.setframerate(16000)
        output.writeframes(b'\0\0'*int(16000*seconds))


def test_real_ffmpeg_audio_preparation_and_duration_limit(tmp_path):
    source = tmp_path/'source.wav'
    write_wave(source,0.25)
    audio,seconds,metadata = prepare_audio(source,tmp_path,2)
    assert audio.is_file()
    assert seconds==pytest.approx(0.25)
    assert 'filename' not in metadata['format']
    assert metadata['streams'][0]['codec_type']=='audio'
    with pytest.raises(MediaError,match='too_long'):
        prepare_audio(source,tmp_path,0.1)


def test_nonmedia_is_rejected_by_real_ffprobe(tmp_path):
    source = tmp_path/'input.html'
    source.write_text('<html>not audio</html>')
    with pytest.raises(MediaError,match='invalid_media'):
        prepare_audio(source,tmp_path,30)


async def test_download_stream_limit_and_redirect_validation(tmp_path,monkeypatch):
    import media
    class Response:
        def __init__(self,status=200,location=None):
            self.status=status
            self.headers={'Location':location} if location else {}
            self.content_length=None
            self.url='https://example.com/file.mp3'
            self.content=self
        async def __aenter__(self): return self
        async def __aexit__(self,*args): pass
        async def iter_chunked(self,n):
            yield b'123'
            yield b'456'
    current = Response()
    class Session:
        def __init__(self,**kwargs): pass
        async def __aenter__(self): return self
        async def __aexit__(self,*args): pass
        def get(self,*args,**kwargs): return current
    monkeypatch.setattr(media.aiohttp,'ClientSession',Session)
    monkeypatch.setattr(media.aiohttp,'TCPConnector',lambda **kwargs:None)
    assert await download_url('https://example.com/a',tmp_path/'out',10)=='file.mp3'
    with pytest.raises(MediaError,match='too_large'):
        await download_url('https://example.com/a',tmp_path/'out',4)
    current=Response(302,'http://127.0.0.1/secret')
    with pytest.raises(MediaError,match='invalid_url'):
        await download_url('https://example.com/a',tmp_path/'out',10)
