import ast
import io
import json
from pathlib import Path
import re
import shutil
import subprocess
import zipfile

import pytest
import yaml

from backup import create_archive,restore,r2_enabled

ROOT=Path(__file__).resolve().parents[1]


def workflow():
    return yaml.safe_load((ROOT/'.github/workflows/whisper.yml').read_text())


def python_blocks(script):
    lines=script.splitlines()
    start=0
    while start<len(lines):
        match=re.match(r"python3? - <<'([A-Za-z_]+)'$",lines[start])
        if not match:
            start+=1
            continue
        end=lines.index(match[1],start+1)
        yield '\n'.join(lines[start+1:end])
        start=end+1


def test_workflow_has_valid_shell_python_and_expected_actions():
    data=workflow()
    assert data['on']['workflow_dispatch']['inputs']['model']['default']=='base'
    assert data['concurrency']['cancel-in-progress'] is False
    assert data['env']['SESSION_SECONDS']=='20400'
    for step in data['jobs']['bot']['steps']:
        if 'uses' in step:
            assert step['uses'].endswith('@main')
        if 'run' in step:
            subprocess.run(['bash','-n'],input=step['run'],text=True,check=True)
            for code in python_blocks(step['run']):
                ast.parse(code)


def test_embedded_reporters_match_packaged_sources(tmp_path,monkeypatch):
    env=tmp_path/'env'
    monkeypatch.setenv('RUNNER_TEMP',str(tmp_path))
    monkeypatch.setenv('GITHUB_ENV',str(env))
    for identifier in ('reporting','reporting_supervisor'):
        step=next(x for x in workflow()['jobs']['bot']['steps'] if x.get('id')==identifier)
        exec(compile(next(python_blocks(step['run'])),'reporting','exec'),{})
    for name in ('telegram_logs.py','crash_reports.py','telegram_api.py'):
        assert (tmp_path/name).read_bytes()==(ROOT/name).read_bytes()
    assert 'SESSION_DEADLINE_EPOCH=' in env.read_text()


def test_zip_import_is_standalone_and_preserves_state(tmp_path,monkeypatch):
    archive=io.BytesIO()
    with zipfile.ZipFile(archive,'w') as z:
        for path in ROOT.glob('*.py'):
            z.write(path,'nested/'+path.name)
        z.write(ROOT/'requirements.txt','nested/requirements.txt')
    archive.seek(0)
    class Download(io.BytesIO):
        def geturl(self): return 'https://example.com/bot.zip'
    import urllib.request
    monkeypatch.setattr(urllib.request,'urlopen',lambda *a,**kw:Download(archive.getvalue()))
    monkeypatch.chdir(tmp_path)
    (tmp_path/'state').mkdir()
    (tmp_path/'state/state.db').write_text('preserve me')
    monkeypatch.setenv('APP_ZIP_URL','https://example.com/bot.zip')
    monkeypatch.setenv('FORCE_REIMPORT','true')
    monkeypatch.setenv('GITHUB_ENV',str(tmp_path/'env'))
    monkeypatch.delenv('GITHUB_WORKFLOW_REF',raising=False)
    step=next(x for x in workflow()['jobs']['bot']['steps'] if x.get('id')=='source')
    exec(compile(next(python_blocks(step['run'])),'import','exec'),{})
    assert (tmp_path/'app/worker.py').is_file()
    assert (tmp_path/'state/state.db').read_text()=='preserve me'
    assert 'BOT_SOURCE_DIR='+str(tmp_path/'app') in (tmp_path/'env').read_text()


def test_owner_backup_includes_consistent_database_and_workflow(state,tmp_path):
    archive=tmp_path/'backup.zip'
    create_archive(tmp_path,ROOT,archive)
    with zipfile.ZipFile(archive) as z:
        assert 'state/state.db' in z.namelist()
        assert 'app/.github/workflows/whisper.yml' in z.namelist()
        assert not any('work/' in name or '.env' in name for name in z.namelist())


def test_r2_is_optional_but_partial_credentials_are_an_error(tmp_path,monkeypatch):
    for key in ('R2_ACCOUNT_ID','R2_ACCESS_KEY_ID','R2_SECRET_ACCESS_KEY','R2_BUCKET_NAME'):
        monkeypatch.delenv(key,raising=False)
    assert r2_enabled() is False
    restore(tmp_path)
    monkeypatch.setenv('R2_ACCOUNT_ID','test')
    with pytest.raises(RuntimeError):
        r2_enabled()
