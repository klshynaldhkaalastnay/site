import json
from xml.etree import ElementTree as ET
from transcripts import render,render_metadata,timestamp


def test_all_formats_preserve_transcript_and_correct_timestamps(payload):
    assert timestamp(3661.251)=='01:01:01,251'
    assert timestamp(59.9999,True)=='00:01:00.000'
    assert render(payload,'txt').decode().strip()==payload['text']
    assert '00:00:00,250 --> 00:00:02,500' in render(payload,'srt').decode()
    assert render(payload,'vtt').startswith(b'WEBVTT\n')
    assert b'250\t2500\t' in render(payload,'tsv')
    document = json.loads(render(payload,'json'))
    assert document['segments'][0]['words'][0]['word']=='Hello'
    assert 'metadata' not in document


def test_metadata_formats_and_xml_escaping(payload):
    assert json.loads(render_metadata(payload,'json'))==payload['metadata']
    xml = ET.fromstring(render_metadata(payload,'xml'))
    assert xml.tag=='metadata'
    assert xml.find('.//field[@name="title"]').text=='A&B <name>'
    assert 'format.tags.title: A&B <name>' in render_metadata(payload,'txt').decode()
