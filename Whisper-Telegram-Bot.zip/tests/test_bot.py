import asyncio
import json
from types import SimpleNamespace
from unittest.mock import AsyncMock

import pytest
from aiogram.exceptions import TelegramNetworkError
from aiogram.methods import SendMessage
from aiogram.types import Message,Update

from bot import DeliveryUncertain


def update(message_id=1,size=100,kind='audio',text=None):
    fields = dict(message_id=message_id,date=1,chat={'id':101,'type':'private'},
                  from_user={'id':101,'is_bot':False,'first_name':'Test','language_code':'ar'})
    if text is None:
        value = {'file_id':'abc','file_unique_id':'unique','duration':1,'file_size':size}
        if kind in ('audio','document'):
            value.update(file_name='recording.mp3',mime_type='audio/mpeg')
        if kind=='video_note':
            value['length']=240
        if kind=='document':
            value.pop('duration')
        if kind=='video':
            value.update(width=1920,height=1080)
        fields[kind]=value
    else:
        fields['text']=text
    return Update(update_id=message_id,message=Message(**fields))


@pytest.mark.parametrize('kind',['audio','video','voice','video_note','document'])
async def test_all_upload_types_are_accepted_without_losing_first_request(runner,kind):
    await runner.handle(update(kind=kind))
    rows = runner.state.outstanding(101)
    assert len(rows)==1
    assert json.loads(rows[0]['source'])['kind']=='telegram'
    assert runner.state.get('language:101')=='ar'


async def test_cloud_api_file_limit_rejected_before_queueing(runner):
    await runner.handle(update(size=20_000_001))
    assert not runner.state.outstanding()
    assert '20 MB' in runner.bot.send_message.call_args.args[1]


async def test_local_api_and_direct_links_support_larger_inputs(runner):
    runner.local_api=True
    await runner.handle(update(size=100_000_000))
    assert len(runner.state.outstanding())==1
    url='https://cdn.example.com/file.mp4?token=abc%2Fdef&part=1'
    await runner.handle(update(message_id=2,text=url))
    assert json.loads(runner.state.outstanding()[-1]['source'])['url']==url


async def test_job_pipeline_groups_files_and_saves_delivery_receipts(runner,options,submit,payload):
    options.update(txt='on',srt='on',json='on',metadata='on',metadata_format='txt')
    jid=submit(custom=options)
    runner.acquire=AsyncMock(return_value=(runner.work/'input.media','recording.mp4'))
    runner.worker=AsyncMock(return_value=payload)
    await runner.run_job(jid)
    row=runner.state.job(jid)
    assert row['status']=='done' and row['in_flight'] is None
    assert json.loads(row['sent'])==['txt','srt','json','metadata']
    runner.bot.send_media_group.assert_awaited_once()
    media=runner.bot.send_media_group.call_args.kwargs['media']
    assert len(media)==4
    names=[item.media.filename for item in media]
    assert len(set(names))==4
    assert any(name.endswith('.metadata.txt') for name in names)
    assert '&lt;world&gt;' in runner.bot.edit_message_text.call_args.kwargs['text']
    assert 'Done' not in runner.bot.edit_message_text.call_args.kwargs['text']


async def test_unconfirmed_upload_is_not_automatically_repeated(runner,options,submit,payload):
    jid=submit()
    runner.state.change(jid,status='running')
    runner.bot.send_document.side_effect=TelegramNetworkError(method=SendMessage(chat_id=1,text='test'),message='network')
    with pytest.raises(DeliveryUncertain):
        await runner.send_files(jid,payload,['txt'])
    assert runner.state.job(jid)['in_flight'] is not None
    runner.state.recover()
    assert runner.state.job(jid)['status']=='uncertain'
    assert not runner.state.ready()


async def test_completed_results_resume_without_retranscribing_or_resending(runner,submit,payload):
    jid=submit()
    runner.state.store_result(jid,payload)
    runner.state.change(jid,sent='["txt"]')
    runner.acquire=AsyncMock()
    runner.worker=AsyncMock()
    await runner.run_job(jid)
    runner.acquire.assert_not_awaited()
    runner.worker.assert_not_awaited()
    runner.bot.send_document.assert_not_awaited()
    assert runner.state.job(jid)['status']=='done'


async def test_manual_format_button_ownership_cooldown_and_no_new_inference(runner,options,submit,payload):
    options['srt']='off'
    jid=submit(custom=options)
    runner.state.store_result(jid,payload)
    runner.state.change(jid,status='done',status_message=55)
    query=SimpleNamespace(id='q1',data=f'file:{jid}:srt',from_user=SimpleNamespace(id=202),
        message=SimpleNamespace(message_id=55,chat=SimpleNamespace(id=101)),answer=AsyncMock())
    await runner.file_callback(query)
    runner.bot.send_document.assert_not_awaited()
    assert query.answer.call_args.kwargs['show_alert']
    query.from_user.id=101
    await runner.file_callback(query)
    runner.bot.send_document.assert_awaited_once()
    query.id='q2'
    await runner.file_callback(query)
    assert runner.bot.send_document.await_count==1
    assert 'min:sec' in query.answer.call_args.args[0]


async def test_settings_avoid_turbo_translation_and_secure_other_users(runner):
    runner.state.set('options:101',json.dumps({'model':'turbo'}))
    query=SimpleNamespace(data='settings:101:task-translate',from_user=SimpleNamespace(id=101),
        message=SimpleNamespace(message_id=55,chat=SimpleNamespace(id=101)),answer=AsyncMock())
    await runner.settings_callback(query)
    assert runner.options(101)['model']=='base'
    assert runner.options(101)['task']=='translate'
    query.from_user.id=202
    query.data='settings:101:model-large'
    await runner.settings_callback(query)
    assert runner.options(101)['model']=='base'


async def test_owner_stats_and_commands_are_private_to_owner(runner):
    msg=update(text='/stats').message
    await runner.command(msg,101,'/stats',[])
    assert 'owner' in runner.bot.send_message.call_args.args[1]
    runner.bot.send_message.reset_mock()
    await runner.command(msg,999,'/stats',[])
    text=runner.bot.send_message.call_args.args[1]
    assert '<pre>' in text
    assert '101' not in text


async def test_clean_session_writes_restart_receipt(runner,monkeypatch):
    monkeypatch.setenv('SESSION_SECONDS','1')
    async def polling():
        await runner.stop.wait()
    runner.polling=polling
    runner.dependency_updates.run=AsyncMock()
    await runner.run()
    receipt=json.loads((runner.data/'receipt.json').read_text())
    assert receipt['ok'] is True
    assert receipt['reason']=='time-limit'
    assert runner.attribution=='<a href="https://t.me/transcribewhisper_bot?start=welcome_hehehehaw==">@transcribewhisper_bot</a>'
