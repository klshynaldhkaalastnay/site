import json
import time

from common import inference_key, settings
from state import State


def test_four_active_four_waiting_and_no_owner_exemption(state,options):
    ids = [state.submit(101,101,n,None,{'kind':'url'},str(n),options)[0] for n in range(9)]
    assert ids[-1] is None
    assert [row['status'] for row in state.outstanding(101)]==['ready']*4+['queued']*4
    jid,fresh = state.submit(101,101,0,None,{'kind':'url'},'0',options)
    assert (jid,fresh)==(ids[0],False)
    assert state.submit(202,202,9,None,{'kind':'url'},'9',options)[0]
    state.change(ids[0],status='cancelled')
    state.promote()
    assert state.job(ids[4])['status']=='ready'


def test_settings_are_snapshotted_and_cache_key_only_tracks_inference(state,options,submit):
    jid = submit()
    state.set('options:101',json.dumps({'model':'small','txt':'off'}))
    assert json.loads(state.job(jid)['options'])['model']=='base'
    other = dict(options,txt='off',srt='on',preview=False)
    assert inference_key(options)==inference_key(other)
    assert inference_key(options)!=inference_key(dict(options,language='ar'))
    state.set('options:101',json.dumps({'model':'turbo','task':'translate'}))
    assert settings(state,101)['model']=='base'


def test_recovery_preserves_result_and_does_not_resend_uncertain_upload(state,submit,payload):
    first,second = submit(message=1),submit(message=2)
    state.change(first,status='running')
    state.store_result(first,payload)
    state.change(second,status='running',in_flight='["txt","json"]')
    state.recover()
    assert state.job(first)['status']=='ready'
    assert state.result(first)==payload
    assert state.job(second)['status']=='uncertain'


def test_result_cache_is_user_scoped_and_expires(state,options,payload):
    def job(user,message,key,opts):
        return state.submit(user,user,message,None,{'kind':'url'},key,opts)[0]
    a = job(101,1,'url:abc',options)
    state.store_result(a,payload)
    b = job(101,2,'url:abc',dict(options,srt='on'))
    assert state.cached_result(state.job(b))==payload
    c = job(202,1,'url:abc',options)
    assert state.cached_result(state.job(c)) is None
    d = job(101,3,'url:abc',dict(options,words=True))
    assert state.cached_result(state.job(d)) is None
    state.change(a,status='done',result_expires=time.time()-1)
    state.cleanup()
    assert state.result(a) is None
    assert state.cached_result(state.job(b)) is None


def test_database_roundtrip_and_button_recovery(tmp_path,options,payload):
    path = tmp_path/'persistent.db'
    one = State(path)
    jid = one.submit(101,101,1,None,{'kind':'telegram','file_id':'id'},'key',options)[0]
    one.store_result(jid,payload)
    one.start_button(jid,'srt','callback1')
    one.close()
    two = State(path)
    two.recover()
    assert two.result(jid)==payload
    assert two.button_remaining(jid,'srt')>90
    assert two.db.execute('SELECT status FROM button_presses').fetchone()[0]=='uncertain'
    two.close()
