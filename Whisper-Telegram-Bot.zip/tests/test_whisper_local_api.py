import os
from pathlib import Path
import subprocess
import sys

from aiogram import Bot
from aiogram.client.session.aiohttp import AiohttpSession
from aiogram.client.telegram import TelegramAPIServer
import pytest
from aiogram.exceptions import TelegramBadRequest
from aiogram.methods import GetFile

from bot import BoundedWriter
from common import MediaError
from test_workflow_backup import workflow, python_blocks

ROOT = Path(__file__).resolve().parents[1]


async def test_aiogram_reads_native_local_file_without_a_cloud_download(tmp_path):
    source = tmp_path/'native-input.mp3'
    source.write_bytes(b'local-media')
    destination = tmp_path/'downloaded.media'
    session = AiohttpSession(api=TelegramAPIServer.from_base('http://127.0.0.1:8081',is_local=True))
    async with Bot(token='123456:LOCAL_TEST_ONLY',session=session).context() as bot:
        with destination.open('wb') as out:
            await bot.download_file(str(source),BoundedWriter(out,100),seek=False)
    assert destination.read_bytes()==b'local-media'


def test_local_upload_admission_accepts_two_gb_and_rejects_one_byte_over(tmp_path):
    script = r'''
import asyncio
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import AsyncMock
from aiogram.types import Update,Message
from bot import Runner
from state import State
async def main():
    data=Path.cwd()
    state=State(data/'state.db')
    fake=SimpleNamespace(send_message=AsyncMock(return_value=SimpleNamespace(message_id=55)))
    runner=Runner(state,fake,data,999)
    async def api(chat,operation):return await operation()
    runner.api=api
    def upload(number,size):
        return Update(update_id=number,message=Message(message_id=number,date=1,
            chat={'id':101,'type':'private'},from_user={'id':101,'is_bot':False,'first_name':'Test'},
            document={'file_id':'file'+str(number),'file_unique_id':'u'+str(number),
                      'file_name':'large.mp4','file_size':size}))
    await runner.handle(upload(1,2_000_000_000))
    assert len(state.outstanding())==1
    await runner.handle(upload(2,2_000_000_001))
    assert len(state.outstanding())==1
    assert '2 GBs' in fake.send_message.call_args.args[1]
    assert '2000 MB' not in fake.send_message.call_args.args[1]
    state.close()
asyncio.run(main())
'''
    result = subprocess.run([sys.executable,'-c',script],cwd=tmp_path,
        env=dict(os.environ,TELEGRAM_API_BASE='http://127.0.0.1:8081',PYTHONPATH=str(ROOT)),
        capture_output=True,text=True,timeout=30)
    assert result.returncode==0,result.stderr


async def test_local_size_error_does_not_claim_cloud_twenty_mb_limit(runner,submit):
    runner.local_api=True
    jid=submit(source={'kind':'telegram','file_id':'file','name':'media'})
    runner.bot.get_file.side_effect=TelegramBadRequest(method=GetFile(file_id='file'),message='file is too big')
    with pytest.raises(MediaError,match='too_large'):
        await runner.acquire(runner.state.job(jid),runner.work)


def test_cache_snapshot_rejects_missing_required_native_state(state,tmp_path,monkeypatch):
    state.set('local_api_state_required','1')
    monkeypatch.chdir(tmp_path)
    monkeypatch.setenv('BOT_DATA_DIR',str(tmp_path))
    monkeypatch.setenv('GITHUB_OUTPUT',str(tmp_path/'output'))
    step=next(s for s in workflow()['jobs']['bot']['steps'] if s.get('id')=='snapshot')
    with pytest.raises(RuntimeError,match='matching encrypted'):
        exec(compile(next(python_blocks(step['run'])),'snapshot','exec'),{})
    assert not (tmp_path/'state-cache/state.db').exists()


def test_cache_snapshot_keeps_native_state_paired_with_queue(state,tmp_path,monkeypatch):
    state.set('local_api_state_required','1')
    (tmp_path/'telegram-api.enc').write_bytes(b'encrypted-authorized-session')
    monkeypatch.chdir(tmp_path)
    monkeypatch.setenv('BOT_DATA_DIR',str(tmp_path))
    monkeypatch.setenv('GITHUB_OUTPUT',str(tmp_path/'output'))
    step=next(s for s in workflow()['jobs']['bot']['steps'] if s.get('id')=='snapshot')
    exec(compile(next(python_blocks(step['run'])),'snapshot','exec'),{})
    assert (tmp_path/'state-cache/state.db').is_file()
    assert (tmp_path/'state-cache/telegram-api.enc').read_bytes()==b'encrypted-authorized-session'
    assert 'ready=true' in (tmp_path/'output').read_text()
    assert "steps.local_api_checkpoint.outcome == 'success'" in step['if']
