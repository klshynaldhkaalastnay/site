"""One isolated Whisper process, killed together with FFmpeg on cancellation."""
import argparse
import json
import math
import os
from pathlib import Path
import subprocess
import sys
import wave

from common import MediaError, MODELS


def stage(folder, value):
    target = folder/'progress.json'
    temp = folder/'progress.tmp'
    temp.write_text(json.dumps({'stage': value}))
    temp.replace(target)


def command(args, timeout=180):
    try:
        return subprocess.run(args, stdin=subprocess.DEVNULL, stdout=subprocess.PIPE,
                              stderr=subprocess.DEVNULL, timeout=timeout, check=True).stdout
    except (subprocess.SubprocessError, OSError):
        raise MediaError('invalid_media') from None


def prepare_audio(path, folder, max_duration):
    raw = command(['ffprobe', '-v', 'error', '-protocol_whitelist', 'file,pipe',
                   '-show_format', '-show_streams', '-of', 'json', str(path)])
    if len(raw) > 8_000_000:
        raise MediaError('invalid_media')
    info = json.loads(raw)
    if not any(stream.get('codec_type')=='audio' for stream in info.get('streams', [])):
        raise MediaError('no_audio')
    duration = info.get('format', {}).get('duration')
    if duration is not None:
        try:
            duration = float(duration)
        except (ValueError, TypeError):
            duration = 0
        if math.isfinite(duration) and duration > max_duration:
            raise MediaError('too_long')
    audio = folder/'audio.wav'
    command(['ffmpeg', '-nostdin', '-v', 'error', '-y', '-protocol_whitelist', 'file,pipe',
             '-i', str(path), '-t', str(max_duration+1), '-map', '0:a:0', '-vn',
             '-ac', '1', '-ar', '16000', '-c:a', 'pcm_s16le', str(audio)])
    with wave.open(str(audio), 'rb') as decoded:
        seconds = decoded.getnframes()/decoded.getframerate()
    if seconds > max_duration:
        raise MediaError('too_long')
    if seconds <= 0:
        raise MediaError('no_audio')
    # Keep tags and stream details, exclude internal runner paths.
    info.get('format', {}).pop('filename', None)
    return audio, seconds, info


def transcribe(config, folder):
    options = config['options']
    if options['model'] not in MODELS or options['task'] not in ('transcribe', 'translate'):
        raise MediaError('configuration')
    if options['task']=='translate' and options['model']=='turbo':
        raise MediaError('configuration')
    stage(folder, 'preparing')
    audio, duration, metadata = prepare_audio(Path(config['input']), folder, config['max_duration'])
    stage(folder, 'loading')
    import torch
    import whisper
    from whisper.tokenizer import LANGUAGES
    language = options['language']
    if language != 'auto' and language not in LANGUAGES:
        raise MediaError('language')
    torch.set_num_threads(max(1, int(os.getenv('WHISPER_THREADS') or min(4, os.cpu_count() or 1))))
    device = os.getenv('WHISPER_DEVICE', 'auto')
    if device == 'auto':
        device = 'cuda' if torch.cuda.is_available() else 'cpu'
    if device not in ('cpu', 'cuda'):
        raise MediaError('configuration')
    model = whisper.load_model(options['model'], device=device,
                               download_root=os.getenv('WHISPER_MODEL_DIR') or None)
    stage(folder, 'transcribing')
    result = model.transcribe(str(audio), language=None if language=='auto' else language,
        task=options['task'], word_timestamps=options['words'], verbose=None,
        fp16=device=='cuda', condition_on_previous_text=False)
    result.update(model=options['model'], task=options['task'], duration=duration, metadata=metadata)
    return result


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('config', type=Path)
    args = parser.parse_args()
    folder = args.config.resolve().parent
    try:
        payload = {'ok': True, 'result': transcribe(json.loads(args.config.read_text()), folder)}
    except MediaError as exc:
        payload = {'ok': False, 'error': exc.code}
    except Exception as exc:
        # Never include media text, tags, signed links, or exception messages in logs.
        print('Whisper worker failed: '+type(exc).__name__, file=sys.stderr)
        payload = {'ok': False, 'error': 'transcription', 'exception': type(exc).__name__}
    temp = folder/'result.tmp'
    temp.write_text(json.dumps(payload, ensure_ascii=False), encoding='utf-8')
    temp.replace(folder/'result.json')


if __name__ == '__main__':
    main()
