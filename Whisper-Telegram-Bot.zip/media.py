"""Bounded direct downloads, with public-address checks on every DNS lookup."""
import asyncio
from email.message import Message
import ipaddress
from pathlib import Path
import socket
from urllib.parse import unquote, urljoin, urlsplit

import aiohttp
from aiohttp.abc import AbstractResolver
from aiohttp.resolver import DefaultResolver

from common import MediaError, normalize_url, safe_name


class PublicResolver(AbstractResolver):
    def __init__(self):
        self.inner = DefaultResolver()

    async def resolve(self, host, port=0, family=socket.AF_INET):
        answers = await self.inner.resolve(host, port, family)
        if not answers or any(not ipaddress.ip_address(answer['host']).is_global or
                              ipaddress.ip_address(answer['host']).is_multicast for answer in answers):
            raise OSError('Public media addresses are required')
        return answers

    async def close(self):
        await self.inner.close()


def response_name(response):
    header = Message()
    header['Content-Disposition'] = response.headers.get('Content-Disposition', '')
    return safe_name(header.get_filename() or unquote(Path(urlsplit(str(response.url)).path).name) or 'media')


async def download_url(url, destination, max_bytes, timeout=600):
    current = normalize_url(url)
    connector = aiohttp.TCPConnector(resolver=PublicResolver(), use_dns_cache=False)
    try:
        async with aiohttp.ClientSession(connector=connector, trust_env=False,
                timeout=aiohttp.ClientTimeout(total=timeout, sock_read=60),
                headers={'User-Agent': 'Whisper-Telegram-Bot/1.0'}) as session:
            for _ in range(6):
                async with session.get(current, allow_redirects=False) as response:
                    if response.status in (301, 302, 303, 307, 308):
                        target = response.headers.get('Location')
                        if not target:
                            raise MediaError('download')
                        current = normalize_url(urljoin(current, target))
                        continue
                    if response.status != 200:
                        raise MediaError('download')
                    if response.content_length is not None and response.content_length > max_bytes:
                        raise MediaError('too_large')
                    total = 0
                    with Path(destination).open('wb') as out:
                        async for chunk in response.content.iter_chunked(256*1024):
                            total += len(chunk)
                            if total > max_bytes:
                                raise MediaError('too_large')
                            out.write(chunk)
                    if not total:
                        raise MediaError('invalid_media')
                    return response_name(response)
            raise MediaError('redirects')
    except (aiohttp.ClientError, OSError, asyncio.TimeoutError):
        raise MediaError('download') from None

