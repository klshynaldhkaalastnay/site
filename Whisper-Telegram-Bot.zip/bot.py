"""Telegram Whisper bot using the downloader's aiogram infrastructure."""
import asyncio
from collections import defaultdict
from contextlib import suppress
from html import escape
import json
import logging
import math
import os
from pathlib import Path
import re
import secrets
import shutil
import signal
import sys
import tempfile
import time

from aiogram import Bot
from aiogram.client.session.aiohttp import AiohttpSession
from aiogram.client.telegram import TelegramAPIServer
from aiogram.exceptions import (AiogramError, TelegramBadRequest, TelegramAPIError,
    TelegramRetryAfter, TelegramNetworkError, TelegramServerError, ClientDecodeError)
from aiogram.types import (BotCommand, BufferedInputFile, FSInputFile, InputMediaDocument,
    InlineKeyboardButton, InlineKeyboardMarkup, ReplyParameters, LinkPreviewOptions)

from common import (FORMATS, MODES, MODELS, MAX_BYTES, TELEGRAM_DOWNLOAD_BYTES,
    MediaError, extract_links, normalize_url, source_key, safe_name, settings, utf16_clip,
    input_limit, size_label, BOT_ATTRIBUTION)
from telegram_api import api_base, is_local, local_file_access, UPLOAD_TIMEOUT
from state import State
from media import download_url
from transcripts import render, render_metadata
from languages import SPEECH_LANGUAGES
from broadcasts import Broadcasts
from owner_backup import OwnerBackup
from system_specs import read_specs, code_blocks, SpecsUnavailable
from dependency_versions import read_dependencies
from dependency_updates import DependencyUpdates
from crash_reports import configure_logging, background_error
from i18n import LANGUAGES, HELP as LOCAL_HELP, OWNER_HELP, STATS_REPORT, translate

ROOT = Path(__file__).resolve().parent
COMMANDS = [('start', 'Start the bot'), ('help', 'Show help'), ('settings', 'Bot settings'),
            ('queue', 'Your requests'), ('cancel', 'Cancel a request'),
            ('ping', 'Check response time'), ('id', 'Your Telegram ID')]
ERRORS = {
    'invalid_url': 'Send a public HTTP or HTTPS direct media link',
    'download': 'Could not download this file, check that the direct link works without logging in',
    'redirects': 'This link redirects too many times, send the final direct media link',
    'too_large': 'This input is too large, the configured maximum input size is {size}',
    'telegram_size': 'Telegram only lets this bot download uploads up to 20 MB, send a direct link for larger files',
    'invalid_media': 'This file could not be decoded as audio or video, send the media file rather than a webpage',
    'no_audio': 'This file has no usable audio track',
    'too_long': 'This recording is too long, the configured maximum is {minutes} minutes',
    'language': 'This speech language is not supported by the selected Whisper model',
    'configuration': 'The selected Whisper configuration is unavailable',
    'timeout': 'Transcription exceeded the processing time limit, try a smaller model or a shorter recording',
    'transcription': 'Could not transcribe this recording, try a smaller model or send the media again',
}


class DeliveryUncertain(Exception):
    """Telegram may have accepted a send, so automatic resending would duplicate it."""


class BoundedWriter:
    def __init__(self, file, limit):
        self.file, self.limit, self.total = file, limit, 0

    def write(self, value):
        self.total += len(value)
        if self.total > self.limit:
            raise MediaError('too_large')
        return self.file.write(value)

    def flush(self):
        self.file.flush()


async def kill_process(process):
    if process.returncode is None:
        with suppress(ProcessLookupError):
            if os.name == 'posix':
                os.killpg(process.pid, signal.SIGKILL)
            else:
                process.kill()
    await process.wait()


class Runner:
    def __init__(self, state, bot, data, owner):
        self.state, self.bot, self.data, self.owner = state, bot, data, owner
        self.started_at = time.monotonic()
        self.stop = asyncio.Event()
        self.reason = 'shutdown'
        self.force_reimport = False
        self.pending_restart = None
        self.tasks = {}
        self.chat_locks = defaultdict(asyncio.Lock)
        self.chat_next = defaultdict(float)
        self.global_lock = asyncio.Lock()
        self.global_next = 0.0
        self.username = ''
        self.attribution = BOT_ATTRIBUTION
        self.local_api = is_local()
        self.max_bytes = input_limit()
        self.max_duration = int(os.getenv('MAX_DURATION_SECONDS') or '3600')
        self.transcribe_timeout = int(os.getenv('TRANSCRIBE_TIMEOUT_SECONDS') or '7200')
        if min(self.max_bytes, self.max_duration, self.transcribe_timeout) <= 0:
            raise ValueError('Input, duration, and processing limits must be positive')
        self.global_jobs = max(1, min(8, int(os.getenv('MAX_GLOBAL_JOBS') or '4')))
        # GPU/CPU memory remains bounded even when several inputs download at once.
        self.inference = asyncio.Semaphore(1)
        self.output_locks = defaultdict(asyncio.Lock)
        self.broadcasts = Broadcasts(self)
        self.dependency_updates = DependencyUpdates(self)
        self.owner_backup = OwnerBackup(self, ROOT)
        self.work = data/'work'
        shutil.rmtree(self.work, ignore_errors=True)
        self.work.mkdir(parents=True, exist_ok=True)

    def options(self, user):
        return settings(self.state, user)

    def button(self, user, label, action):
        return InlineKeyboardButton(text=label, callback_data=f'settings:{user}:{action}')

    def settings_view(self, user, page='main'):
        options = self.options(user)
        tr = lambda text: self.tr(user, text)
        button = lambda label, action: self.button(user, label, action)
        back = [button(tr('Back'), 'main')]
        if page == 'language':
            buttons = [button(label, 'ui-'+code) for code, label in LANGUAGES.items()]
            return tr('Language'), InlineKeyboardMarkup(inline_keyboard=[buttons[i:i+2] for i in range(0,len(buttons),2)]+[back])
        if page == 'model':
            rows = [[button(('✓ ' if options['model']==model else '')+model, 'model-'+model)] for model in MODELS]
            return tr('Whisper model'), InlineKeyboardMarkup(inline_keyboard=rows+[back])
        if page.startswith('speech'):
            offset = int(page.partition('-')[2] or '0')
            items = [('auto', tr('Automatic detection'))]+list(SPEECH_LANGUAGES.items())
            buttons = [button(('✓ ' if code==options['language'] else '')+label, 'source-'+code)
                       for code, label in items[offset:offset+12]]
            rows = [buttons[i:i+2] for i in range(0,len(buttons),2)]
            nav = []
            if offset:
                nav.append(button('‹', 'speech-'+str(max(0,offset-12))))
            if offset+12 < len(items):
                nav.append(button('›', 'speech-'+str(offset+12)))
            return tr('Speech language'), InlineKeyboardMarkup(inline_keyboard=rows+([nav] if nav else [])+[back])
        if page == 'task':
            rows = [[button(('✓ ' if options['task']==key else '')+tr(label), 'task-'+key)]
                    for key,label in [('transcribe','Transcribe'),('translate','Translate to English')]]
            return tr('Task'), InlineKeyboardMarkup(inline_keyboard=rows+[back])
        if page == 'files':
            rows = [[button(label.upper()+': '+tr(MODES[options[label]]), 'file-'+label)] for label in FORMATS]
            return tr('Transcript files'), InlineKeyboardMarkup(inline_keyboard=rows+[back])
        if page.startswith('file-') and page[5:] in FORMATS+('metadata',):
            key = page[5:]
            rows = [[button(('✓ ' if options[key]==mode else '')+tr(label), 'mode-'+key+'-'+mode)] for mode,label in MODES.items()]
            if key == 'metadata':
                rows.append([button(tr('Metadata format')+': '+options['metadata_format'].upper(), 'metadataformat')])
            rows.append([button(tr('Back'), 'files' if key in FORMATS else 'main')])
            return (key.upper() if key in FORMATS else tr('Metadata')), InlineKeyboardMarkup(inline_keyboard=rows)
        if page == 'metadataformat':
            rows = [[button(('✓ ' if options['metadata_format']==kind else '')+kind.upper(), 'metaformat-'+kind)] for kind in ('json','xml','txt')]
            return tr('Metadata format'), InlineKeyboardMarkup(inline_keyboard=rows+[[button(tr('Back'),'file-metadata')]])
        rows = [
            [button(tr('Language')+': '+LANGUAGES.get(self.state.get(f'language:{user}','en'),'English'),'language')],
            [button(tr('Whisper model')+': '+options['model'],'model')],
            [button(tr('Speech language')+': '+SPEECH_LANGUAGES.get(options['language'],tr('Automatic detection')),'speech')],
            [button(tr('Task')+': '+tr('Transcribe' if options['task']=='transcribe' else 'Translate to English'),'task')],
            [button(tr('Transcript files'),'files')],
            [button(tr('Metadata')+': '+tr(MODES[options['metadata']]),'file-metadata')],
        ]
        for key,label in [('preview','Transcript preview'),('words','Word timestamps'),('cache','Use cached results')]:
            rows.append([button(('✓ ' if options[key] else '')+tr(label),'toggle-'+key)])
        return tr('Settings'), InlineKeyboardMarkup(inline_keyboard=rows)

    async def settings_callback(self, query):
        parts = (query.data or '').split(':')
        if len(parts)!=3 or parts[1]!=str(query.from_user.id) or not query.message:
            await query.answer()
            return
        user, action = query.from_user.id, parts[2]
        options = self.options(user)
        page = action
        notice = None
        if action.startswith('ui-') and action[3:] in LANGUAGES:
            self.state.set(f'language:{user}',action[3:])
            page = 'main'
        elif action.startswith('model-') and action[6:] in MODELS:
            options['model'] = action[6:]
            if options['model']=='turbo' and options['task']=='translate':
                options['task'] = 'transcribe'
                notice = self.tr(user,'Turbo supports transcription, the task was changed to Transcribe')
            page = 'model'
        elif action.startswith('source-') and action[7:] in ('auto',*SPEECH_LANGUAGES):
            options['language'] = action[7:]
            page = 'main'
        elif action.startswith('task-') and action[5:] in ('transcribe','translate'):
            options['task'] = action[5:]
            if options['task']=='translate' and options['model']=='turbo':
                options['model'] = 'base'
                notice = self.tr(user,'Translation uses base because turbo does not translate speech')
            page = 'task'
        elif action.startswith('toggle-') and action[7:] in ('preview','words','cache'):
            options[action[7:]] = not options[action[7:]]
            page = 'main'
        elif action.startswith('mode-'):
            _,key,mode = action.split('-',2)
            if key not in FORMATS+('metadata',) or mode not in MODES:
                await query.answer()
                return
            options[key] = mode
            page = 'file-'+key
        elif action.startswith('metaformat-') and action[11:] in ('json','xml','txt'):
            options['metadata_format'] = action[11:]
            page = 'metadataformat'
        valid = ('main','language','model','speech','task','files','metadataformat', *('file-'+k for k in FORMATS+('metadata',)))
        if page not in valid and not re.fullmatch(r'speech-(0|[1-9][0-9]?)',page):
            await query.answer()
            return
        self.state.set(f'options:{user}',json.dumps(options))
        await query.answer(notice,show_alert=bool(notice))
        text, keyboard = self.settings_view(user,page)
        with suppress(TelegramBadRequest):
            await self.api(query.message.chat.id, lambda:self.bot.edit_message_text(
                text=text,chat_id=query.message.chat.id,message_id=query.message.message_id,reply_markup=keyboard))

    async def language_menu(self, msg, user):
        buttons = [InlineKeyboardButton(text=label,callback_data=f'lang:{user}:{code}') for code,label in LANGUAGES.items()]
        await self.api(msg.chat.id,lambda:self.bot.send_message(msg.chat.id,
            'Choose your language / اختر لغتك', message_thread_id=msg.message_thread_id,
            reply_markup=InlineKeyboardMarkup(inline_keyboard=[buttons[i:i+2] for i in range(0,len(buttons),2)])))

    async def language_callback(self, query):
        parts = (query.data or '').split(':')
        if len(parts)!=3 or parts[1]!=str(query.from_user.id) or parts[2] not in LANGUAGES or not query.message:
            await query.answer()
            return
        user = query.from_user.id
        self.state.set(f'language:{user}',parts[2])
        await query.answer()
        await self.api(query.message.chat.id,lambda:self.bot.edit_message_text(
            text=self.tr(user,'Send audio, video, a voice message, or a direct media link'),
            chat_id=query.message.chat.id,message_id=query.message.message_id))

    async def status(self, jid, text, html=False, keyboard=None):
        row = self.state.job(jid)
        kwargs = dict(text=text,parse_mode='HTML' if html else None,reply_markup=keyboard,
                      link_preview_options=LinkPreviewOptions(is_disabled=True))
        if row['status_message']:
            try:
                await self.api(row['chat_id'],lambda:self.bot.edit_message_text(
                    chat_id=row['chat_id'],message_id=row['status_message'],**kwargs))
                return
            except TelegramBadRequest as exc:
                if 'message is not modified' in str(exc).lower():
                    return
                if 'message to edit not found' not in str(exc).lower():
                    raise
        sent = await self.api(row['chat_id'],lambda:self.bot.send_message(
            chat_id=row['chat_id'],message_thread_id=row['thread_id'],
            reply_parameters=ReplyParameters(message_id=row['message_id'],allow_sending_without_reply=True),**kwargs))
        self.state.change(jid,status_message=sent.message_id)

    async def progress(self, jid, key):
        row = self.state.job(jid)
        try:
            await self.status(jid,self.tr(row['user_id'],key))
        except AiogramError:
            logging.info('Progress message unavailable')

    async def handle(self, update):
        if update.my_chat_member:
            change = update.my_chat_member
            member = change.new_chat_member
            self.broadcasts.track(change.chat.id, change.chat.type,
                member.status in ('member','administrator','creator') or
                (member.status=='restricted' and getattr(member,'is_member',False)))
            return
        if update.callback_query:
            query = update.callback_query
            prefix = (query.data or '').partition(':')[0]
            handler = {'settings':self.settings_callback,'lang':self.language_callback,
                       'file':self.file_callback,'restart':self.restart_callback,
                       'backup':self.owner_backup.callback,'broadcast':self.broadcasts.callback}.get(prefix)
            if handler:
                await handler(query)
            else:
                await query.answer()
            return
        msg = update.message
        if not msg or not msg.from_user or msg.from_user.is_bot:
            return
        self.broadcasts.track(msg.chat.id,msg.chat.type)
        user = msg.from_user.id
        text = msg.text or msg.caption or ''
        if text.startswith('/'):
            parts = text.split()
            command = parts[0].lower()
            if '@' in command:
                command,target = command.split('@',1)
                if target != self.username.lower():
                    return
            if command=='/start' and not self.state.get(f'language:{user}'):
                await self.language_menu(msg,user)
                return
            await self.command(msg,user,command,parts[1:])
            return
        if self.stop.is_set():
            await self.tell(msg.chat.id,self.tr(user,'The bot is restarting, please send your links again shortly'),msg.message_thread_id)
            return
        if not self.state.get(f'language:{user}'):
            language = (msg.from_user.language_code or 'en').split('-')[0]
            self.state.set(f'language:{user}',language if language in LANGUAGES else 'en')
        media = msg.audio or msg.video or msg.voice or msg.video_note or msg.document
        sources = []
        if media:
            known_size = media.file_size or 0
            limit = self.max_bytes if self.local_api else min(self.max_bytes,TELEGRAM_DOWNLOAD_BYTES)
            if known_size > limit:
                await self.input_error(msg,user,'too_large' if known_size>self.max_bytes else 'telegram_size')
                return
            name = getattr(media,'file_name',None) or ('voice.ogg' if msg.voice else 'video.mp4' if msg.video or msg.video_note else 'audio')
            source = {'kind':'telegram','file_id':media.file_id,'name':safe_name(name),'size':known_size}
            sources.append((source,source_key('telegram',media.file_unique_id)))
        else:
            links,bad = extract_links(text)
            for entity in msg.entities or msg.caption_entities or ():
                if entity.type=='text_link' and entity.url:
                    try:
                        url = normalize_url(entity.url)
                        if url not in links:
                            links.append(url)
                    except MediaError:
                        bad = True
            sources = [({'kind':'url','url':url,'name':'media'},source_key('url',url)) for url in links]
            if not sources:
                if bad or msg.chat.type=='private':
                    await self.tell(msg.chat.id,self.tr(user,'Send audio, video, a voice message, or a direct media link'),msg.message_thread_id)
                return
        rejected = False
        admitted = []
        for source,key in sources:
            jid,fresh = self.state.submit(user,msg.chat.id,msg.message_id,msg.message_thread_id,source,key,self.options(user))
            if jid is None:
                rejected = True
            elif fresh:
                admitted.append(jid)
        for jid in admitted:
            if self.state.job(jid)['status']=='queued':
                queue = [r['id'] for r in self.state.outstanding(user) if r['status']=='queued']
                await self.progress(jid,self.tr(user,'Queued, position {n}',n=queue.index(jid)+1))
        if rejected:
            await self.tell(msg.chat.id,self.tr(user,'Your queue is full, up to 4 active and 4 waiting requests are allowed'),msg.message_thread_id)

    async def input_error(self, msg, user, code):
        text = self.tr(user,ERRORS[code],size=size_label(self.max_bytes),minutes=round(self.max_duration/60))
        await self.api(msg.chat.id,lambda:self.bot.send_message(msg.chat.id,text,message_thread_id=msg.message_thread_id,
            reply_parameters=ReplyParameters(message_id=msg.message_id,allow_sending_without_reply=True)))

    async def acquire(self, row, folder):
        source = json.loads(row['source'])
        target = folder/'input.media'
        if source['kind']=='url':
            name = await download_url(source['url'],target,self.max_bytes)
        else:
            try:
                file = await self.bot.get_file(source['file_id'])
            except TelegramBadRequest as exc:
                too_big = 'too big' in str(exc).lower()
                raise MediaError(('too_large' if self.local_api else 'telegram_size')
                                 if too_big else 'download') from None
            if not file.file_path:
                raise MediaError('download')
            if file.file_size is not None and file.file_size>self.max_bytes:
                raise MediaError('too_large')
            with target.open('wb') as output:
                await self.bot.download_file(file.file_path,BoundedWriter(output,self.max_bytes),timeout=600,seek=False)
            name = source['name']
        if not target.stat().st_size:
            raise MediaError('invalid_media')
        return target,name

    async def worker(self, row, path, folder):
        config = folder/'job.json'
        config.write_text(json.dumps({'input':str(path),'options':json.loads(row['options']),
                                      'max_duration':self.max_duration}))
        with (folder/'worker.log').open('wb') as errors:
            process = await asyncio.create_subprocess_exec(sys.executable,str(ROOT/'worker.py'),str(config),
                stdout=asyncio.subprocess.DEVNULL,stderr=errors,start_new_session=os.name=='posix')
            async def watch():
                previous = ''
                while process.returncode is None:
                    try:
                        stage = json.loads((folder/'progress.json').read_text())['stage']
                    except (OSError,ValueError,KeyError):
                        stage = ''
                    if stage and stage!=previous:
                        label = {'preparing':'Preparing audio...','loading':'Loading Whisper...',
                                 'transcribing':'Transcribing...'}.get(stage)
                        if label:
                            await self.progress(row['id'],label)
                        previous = stage
                    await asyncio.sleep(1)
            watcher = asyncio.create_task(watch())
            try:
                await asyncio.wait_for(process.wait(),self.transcribe_timeout)
            except asyncio.TimeoutError:
                raise MediaError('timeout') from None
            finally:
                watcher.cancel()
                await asyncio.gather(watcher,return_exceptions=True)
                await kill_process(process)
        result = folder/'result.json'
        if not result.is_file() or result.stat().st_size>64_000_000:
            logging.warning('Whisper worker exited without a result, code %s',process.returncode)
            raise MediaError('transcription')
        payload = json.loads(result.read_text())
        if not payload.get('ok'):
            logging.warning('Whisper worker failed, category %s',payload.get('error','unknown'))
            raise MediaError(payload.get('error','transcription'))
        return payload['result']

    def file_data(self, payload, options, kind, jid):
        stem = safe_name(Path(payload.get('name','media')).stem)+f'-{jid}'
        if kind=='metadata':
            fmt = options['metadata_format']
            return stem+'.metadata.'+fmt,render_metadata(payload,fmt)
        return stem+'.'+kind,render(payload,kind)

    async def send_files(self, jid, payload, kinds, manual=None):
        row = self.state.job(jid)
        options = json.loads(row['options'])
        sent = json.loads(row['sent'])
        kinds = kinds if manual else [kind for kind in kinds if kind not in sent]
        if not kinds:
            return
        files = [self.file_data(payload,options,kind,jid) for kind in kinds]
        if any(len(data)>MAX_BYTES for _,data in files):
            raise MediaError('transcription')
        caption = '<code>'+escape(safe_name(payload.get('name','media')))+'</code>\n'+self.attribution
        kwargs = dict(chat_id=row['chat_id'],message_thread_id=row['thread_id'],
            reply_parameters=ReplyParameters(message_id=row['message_id'],allow_sending_without_reply=True))
        async def send():
            if not manual:
                self.state.change(jid,in_flight=json.dumps(kinds))
            if len(files)==1:
                name,data = files[0]
                return await self.bot.send_document(document=BufferedInputFile(data,filename=name),caption=caption,parse_mode='HTML',**kwargs)
            media = [InputMediaDocument(media=BufferedInputFile(data,filename=name),
                caption=caption if i==0 else None,parse_mode='HTML') for i,(name,data) in enumerate(files)]
            return await self.bot.send_media_group(media=media,**kwargs)
        try:
            await self.api(row['chat_id'],send)
        except (TelegramNetworkError,TelegramServerError,ClientDecodeError):
            raise DeliveryUncertain() from None
        except TelegramAPIError:
            # An explicit API rejection confirms that no document was accepted.
            if not manual:
                self.state.change(jid,in_flight=None)
            raise
        else:
            if not manual:
                self.state.change(jid,sent=json.dumps(sent+kinds),in_flight=None)

    def result_keyboard(self, row):
        options = json.loads(row['options'])
        buttons = [InlineKeyboardButton(text=self.tr(row['user_id'],'Download {format}',format=kind.upper()),
            callback_data=f"file:{row['id']}:{kind}") for kind in FORMATS if options[kind]=='off']
        if options['metadata']=='off':
            buttons.append(InlineKeyboardButton(text=self.tr(row['user_id'],'Metadata'),callback_data=f"file:{row['id']}:metadata"))
        return InlineKeyboardMarkup(inline_keyboard=[buttons[i:i+2] for i in range(0,len(buttons),2)]) if buttons else None

    async def result_message(self, jid, payload):
        row = self.state.job(jid)
        options = json.loads(row['options'])
        text = '<code>'+escape(safe_name(payload.get('name','media')))+'</code>'
        preview = payload.get('text','').strip()
        if not preview:
            text += '\n'+escape(self.tr(row['user_id'],'No speech was detected'))
        elif options['preview']:
            clipped = utf16_clip(preview,2800)
            text += '\n\n<pre>'+escape(clipped+('...' if clipped!=preview else ''))+'</pre>'
        text += '\n\n'+self.attribution
        await self.status(jid,text,html=True,keyboard=self.result_keyboard(row))

    async def file_callback(self, query):
        match = re.fullmatch(r'file:([0-9]{1,19}):(txt|srt|vtt|tsv|json|metadata)',query.data or '')
        row = self.state.job(int(match[1])) if match else None
        user = query.from_user.id
        if not row or not query.message or row['user_id']!=user or row['chat_id']!=query.message.chat.id or row['status_message']!=query.message.message_id:
            await query.answer(self.tr(user,'This button belongs to the original requester'),show_alert=True)
            return
        kind,jid = match[2],row['id']
        async with self.output_locks[jid]:
            options = json.loads(row['options'])
            if options[kind]!='off' or self.stop.is_set():
                await query.answer()
                return
            payload = self.state.result(jid)
            if payload is None:
                await query.answer(self.tr(user,'This result has expired, send the media again'),show_alert=True)
                return
            if self.state.db.execute('SELECT 1 FROM button_presses WHERE callback_id=?',(query.id,)).fetchone():
                await query.answer()
                return
            remaining = self.state.button_remaining(jid,kind)
            if remaining:
                minutes,seconds = divmod(math.ceil(remaining),60)
                await query.answer(self.tr(user,'Try this button again in {time} (min:sec)',time=f'{minutes}:{seconds:02}'),show_alert=True)
                return
            self.state.start_button(jid,kind,query.id)
            await query.answer()
            outcome = 'uncertain'
            try:
                await self.send_files(jid,payload,[kind],manual=query.id)
                outcome = 'sent'
            except DeliveryUncertain:
                await self.tell(row['chat_id'],self.tr(user,'Telegram did not confirm delivery, check the chat before sending the link again'),row['thread_id'])
            except (TelegramAPIError,MediaError):
                outcome = 'failed'
            finally:
                with self.state.db:
                    self.state.db.execute('UPDATE button_presses SET status=? WHERE callback_id=?',(outcome,query.id))

    async def run_job(self, jid):
        row = self.state.job(jid)
        options = json.loads(row['options'])
        folder = self.work/str(jid)
        folder.mkdir(parents=True,exist_ok=True)
        try:
            payload = self.state.result(jid,allow_expired=True)
            if payload is None and options['cache']:
                payload = self.state.cached_result(row)
                if payload is not None:
                    self.state.store_result(jid,payload,cached=True)
            if payload is None:
                await self.progress(jid,'Downloading...')
                path,name = await self.acquire(row,folder)
                await self.progress(jid,'Waiting for transcription...')
                async with self.inference:
                    payload = await self.worker(row,path,folder)
                payload['name'] = name
                self.state.store_result(jid,payload)
            await self.progress(jid,'Uploading...')
            kinds = [kind for kind in (*FORMATS,'metadata') if options[kind]=='on']
            await self.send_files(jid,payload,kinds)
            await self.result_message(jid,payload)
            self.state.change(jid,status='done',finished=time.time())
        except asyncio.CancelledError:
            row = self.state.job(jid)
            if row['status']!='cancelled':
                self.state.change(jid,status='uncertain' if row['in_flight'] else 'ready')
            raise
        except DeliveryUncertain:
            self.state.change(jid,status='uncertain',finished=time.time())
            await self.progress(jid,'Telegram did not confirm delivery, check the chat before sending the link again')
        except MediaError as exc:
            self.state.change(jid,status='failed',finished=time.time())
            logging.warning('Transcription job failed, category %s',exc.code)
            await self.progress(jid,self.tr(row['user_id'],ERRORS.get(exc.code,ERRORS['transcription']),
                size=size_label(self.max_bytes),minutes=round(self.max_duration/60)))
        except Exception:
            # The supervisor receives a sanitized stack trace, never the media contents.
            logging.error('Transcription job failed unexpectedly',exc_info=True)
            current = self.state.job(jid)
            self.state.change(jid,status='uncertain' if current['in_flight'] else 'failed',finished=time.time())
            await self.progress(jid,ERRORS['transcription'])
        finally:
            shutil.rmtree(folder,ignore_errors=True)

    async def scheduler(self):
        last_cleanup = 0
        while not self.stop.is_set():
            for jid,task in list(self.tasks.items()):
                if task.done():
                    with suppress(asyncio.CancelledError):
                        task.result()
                    del self.tasks[jid]
            self.state.promote()
            for row in self.state.ready():
                if len(self.tasks)>=self.global_jobs:
                    break
                jid = row['id']
                if jid not in self.tasks:
                    self.state.change(jid,status='running')
                    self.tasks[jid] = asyncio.create_task(self.run_job(jid))
            if time.monotonic()-last_cleanup>60:
                self.state.cleanup()
                last_cleanup = time.monotonic()
            await asyncio.sleep(0.25)

    async def run(self):
        self.state.recover()
        self.broadcasts.recover()
        me = await self.bot.get_me()
        self.username = me.username or ''
        await self.bot.delete_webhook(drop_pending_updates=False)
        await self.bot.set_my_commands([BotCommand(command=c,description=d) for c,d in COMMANDS])
        rows = self.state.db.execute("SELECT id FROM jobs WHERE status='uncertain' AND notified=0").fetchall()
        for row in rows:
            await self.progress(row['id'],'The previous upload was interrupted, check the chat before sending the link again')
            self.state.change(row['id'],notified=1)
        services = [asyncio.create_task(fn()) for fn in (self.polling,self.scheduler,self.broadcasts.run)]
        updates = asyncio.create_task(self.dependency_updates.run())
        seconds = max(1,int(os.getenv('SESSION_SECONDS') or '20400'))
        if os.getenv('SESSION_DEADLINE_EPOCH'):
            seconds = max(1,min(seconds,int(os.environ['SESSION_DEADLINE_EPOCH'])-int(time.time())))
        timer = asyncio.create_task(asyncio.sleep(seconds))
        stop_wait = asyncio.create_task(self.stop.wait())
        logging.info('Whisper bot started')
        try:
            done,_ = await asyncio.wait([*services,timer,stop_wait],return_when=asyncio.FIRST_COMPLETED)
            if timer in done:
                self.request_stop('time-limit')
            for task in services:
                if task in done:
                    task.result()
                    if not self.stop.is_set():
                        raise RuntimeError('Bot service stopped unexpectedly')
        finally:
            self.stop.set()
            with suppress(Exception):
                await asyncio.wait_for(asyncio.shield(services[0]),20)
            all_tasks = [*services,updates,timer,stop_wait,*self.tasks.values()]
            for task in all_tasks:
                task.cancel()
            await asyncio.gather(*all_tasks,return_exceptions=True)
        self.state.checkpoint()
        receipt = {'reason':self.reason,'ok':True,'time':time.time(),
                   'force_reimport':self.force_reimport and self.reason=='restart'}
        (self.data/'receipt.json').write_text(json.dumps(receipt))
        logging.info('Progress saved, session ended with %s',self.reason)

    async def api(self, chat, operation):
        # Apply Telegram pacing to exempt accounts too
        async with self.chat_locks[chat]:
            for attempt in range(4):
                await asyncio.sleep(max(0,self.chat_next[chat]-time.monotonic()))
                async with self.global_lock:
                    await asyncio.sleep(max(0,self.global_next-time.monotonic()))
                    self.global_next = time.monotonic()+0.05
                self.chat_next[chat] = time.monotonic()+(3.2 if chat < 0 else 1.1)
                try:
                    return await operation()
                except TelegramRetryAfter as exc:
                    seconds = exc.retry_after
                    if attempt == 3:
                        raise
                    await asyncio.sleep(seconds+1)

    async def tell(self, chat, text, thread=None):
        return await self.api(chat,lambda: self.bot.send_message(chat,text,message_thread_id=thread))

    def tr(self, recipient, text, **values):
        return translate(self.state.get(f'language:{recipient}', 'en'), text, **values)

    async def notify_owner(self, text):
        try:
            await self.tell(self.owner,text)
        except AiogramError:
            logging.info('Owner notification unavailable, open the bot privately and send /start')

    def request_stop(self, reason):
        if not self.stop.is_set():
            self.reason = reason
            self.stop.set()

    async def restart_menu(self, msg, user):
        token = secrets.token_hex(8)
        pending = {'token':token,'user':user,'chat':msg.chat.id,'thread':msg.message_thread_id,
                   'anchor':msg.message_id,'message':None}
        self.pending_restart = pending
        rows = [[InlineKeyboardButton(text=self.tr(user,label),callback_data=f'restart:{user}:{token}:{mode}')]
                for label,mode in (('Restart and reimport ZIP','reimport'),
                                   ('Restart without reimport','keep'),('Cancel','cancel'))]
        sent = await self.api(msg.chat.id,lambda:self.bot.send_message(
            chat_id=msg.chat.id,text=self.tr(user,'Reimport the ZIP when restarting?'),
            message_thread_id=msg.message_thread_id,
            reply_parameters=ReplyParameters(message_id=msg.message_id,allow_sending_without_reply=True),
            reply_markup=InlineKeyboardMarkup(inline_keyboard=rows)))
        pending['message'] = sent.message_id

    async def restart_callback(self, query):
        user,msg = query.from_user.id,query.message
        if user!=self.owner:
            await query.answer(self.tr(user,'Only the bot owner can use this command'),show_alert=True)
            return
        match = re.fullmatch(r'restart:([0-9]{1,19}):([a-f0-9]{16}):(reimport|keep|cancel)',query.data or '')
        pending = self.pending_restart
        if (not match or not pending or int(match[1])!=user or match[2]!=pending['token']
                or not msg or msg.chat.id!=pending['chat']
                or getattr(msg,'message_thread_id',None)!=pending['thread']
                or (msg.message_id!=pending['message'] if pending['message'] is not None else
                    getattr(getattr(msg,'reply_to_message',None),'message_id',None)!=pending['anchor'])):
            await query.answer(self.tr(user,'This restart prompt is no longer active, send /restart again'),show_alert=True)
            return
        if self.stop.is_set():
            await query.answer(self.tr(user,'The bot is already stopping'),show_alert=True)
            return
        # Consume the choice before any network await; an expired or replayed
        # button cannot trigger another restart or change the selected import.
        self.pending_restart = None
        mode = match[3]
        if mode=='cancel':
            text = self.tr(user,'Restart cancelled')
        else:
            self.force_reimport = mode=='reimport'
            self.request_stop('restart')
            text = self.tr(user,'Saving progress and restarting with ZIP reimport' if self.force_reimport else
                           'Saving progress and starting a fresh session')
        try:
            await query.answer(text)
        except AiogramError:
            logging.info('Restart callback acknowledgement unavailable')
        try:
            await self.api(msg.chat.id,lambda:self.bot.edit_message_text(
                chat_id=msg.chat.id,message_id=msg.message_id,text=text,reply_markup=None))
        except AiogramError:
            logging.info('Restart choice message could not be updated')

    def stats_report(self):
        counts = dict(self.state.db.execute('SELECT status,COUNT(*) FROM jobs GROUP BY status'))
        recent = self.state.db.execute(
            'SELECT COUNT(*),COUNT(DISTINCT user_id) FROM jobs WHERE created>=?',
            (time.time()-86400,)).fetchone()
        # Include saved preferences and private chats even without a download.
        # No IDs, links, captions or metadata are included in the report.
        users = self.state.db.execute("""SELECT COUNT(*) FROM (
            SELECT user_id AS id FROM jobs WHERE user_id>0
            UNION SELECT chat_id FROM known_chats WHERE kind='private' AND chat_id>0
            UNION SELECT CAST(substr(key,10) AS INTEGER) FROM meta
              WHERE key LIKE 'language:%' AND length(substr(key,10))>0
                AND substr(key,10) NOT GLOB '*[^0-9]*'
                AND CAST(substr(key,10) AS INTEGER)>0)""").fetchone()[0]
        chats = self.state.db.execute('SELECT COUNT(*),COALESCE(SUM(active),0) FROM known_chats').fetchone()
        days, remainder = divmod(max(0,int(time.monotonic()-self.started_at)),86400)
        hours, remainder = divmod(remainder,3600)
        minutes, seconds = divmod(remainder,60)
        return self.tr(self.owner,STATS_REPORT,days=days,hours=hours,minutes=minutes,seconds=seconds,
                       users=users,chats=chats[0],active_chats=chats[1],total=sum(counts.values()),
                       done=counts.get('done',0),failed=counts.get('failed',0),
                       cancelled=counts.get('cancelled',0),uncertain=counts.get('uncertain',0),
                       running=counts.get('running',0),ready=counts.get('ready',0),queued=counts.get('queued',0),
                       recent_requests=recent[0],recent_users=recent[1])

    async def command(self,msg,user,command,args):
        chat,thread = msg.chat.id,msg.message_thread_id
        async def reply(chat, text, thread=None):
            return await self.tell(chat, self.tr(user, text), thread)
        if command == '/broadcast':
            await self.broadcasts.command(msg,user)
        elif command == '/settings':
            text, keyboard = self.settings_view(user)
            await self.api(chat, lambda: self.bot.send_message(chat, text, message_thread_id=thread, reply_markup=keyboard))
        elif command == '/start':
            await reply(chat,'Send audio, video, a voice message, or a direct media link',thread)
        elif command == '/help':
            lang = self.state.get(f'language:{user}', 'en')
            text = LOCAL_HELP.get(lang, LOCAL_HELP['en'])
            if user == self.owner:
                text += '\n\n' + OWNER_HELP.get(lang, OWNER_HELP['en'])
            await reply(chat,text,thread)
        elif command == '/id':
            await reply(chat,self.tr(user,'Your Telegram ID is {user}',user=user),thread)
        elif command in ('/specs','/dpend','/stats'):
            if user != self.owner:
                await reply(chat,'Only the bot owner can use this command',thread)
                return
            try:
                output = (self.stats_report() if command == '/stats' else
                          await (read_specs() if command == '/specs' else read_dependencies()))
            except (OSError,ValueError,TimeoutError,SpecsUnavailable) as exc:
                logging.info('Owner report unavailable, command=%s, reason=%s',command,type(exc).__name__)
                error = {'/specs':'Could not read system specifications, please try again later',
                         '/dpend':'Could not read dependency versions, please try again later',
                         '/stats':'Could not read bot statistics, please try again later'}[command]
                await reply(chat,error,thread)
                return
            for block in code_blocks(output):
                await self.api(chat,lambda block=block:self.bot.send_message(
                    chat,block,parse_mode='HTML',message_thread_id=thread,
                    reply_parameters=ReplyParameters(message_id=msg.message_id,allow_sending_without_reply=True)))
        elif command == '/ping':
            # Measure Telegram round-trip time, excluding the local pacing wait
            async def measure():
                started = time.perf_counter()
                message = await self.bot.send_message(chat,'Pong',message_thread_id=thread)
                return message, round((time.perf_counter()-started)*1000)
            message, elapsed = await self.api(chat,measure)
            await self.api(chat, lambda: self.bot.edit_message_text(
                f'Pong! {elapsed}ms',chat_id=chat,message_id=message.message_id))
        elif command in ('/queue','/jobs'):
            if command == '/jobs' and user != self.owner:
                await reply(chat,'Only the bot owner can use this command',thread)
                return
            rows = self.state.outstanding(None if command == '/jobs' else user)
            lines = [self.tr(user,"Job {id}, {status}",id=r["id"],status=self.tr(user,r["status"]))+(", "+self.tr(user,"user {user}",user=r["user_id"]) if command=='/jobs' else '') for r in rows]
            await reply(chat,('\n'.join(lines[:60]) or 'No active or queued requests')+
                            ('\n'+self.tr(user,'And {n} more',n=len(lines)-60) if len(lines)>60 else ''),thread)
        elif command == '/cancel':
            row = self.state.job(int(args[0])) if args and args[0].isdigit() else None
            if not row or (row['user_id'] != user and user != self.owner):
                await reply(chat,'Use /cancel followed by one of your job numbers',thread)
                return
            if row['status'] not in ('ready','running','queued'):
                await reply(chat,'This request has already ended',thread)
                return
            self.state.change(row['id'],status='cancelled')
            task = self.tasks.get(row['id'])
            if task:
                task.cancel()
            await self.status(row['id'],'Cancelled, any upload already accepted by Telegram may still arrive')
        elif command in ('/restart','/upload','/shutdown'):
            if user != self.owner:
                await reply(chat,'Only the bot owner can use this command',thread)
                return
            if self.stop.is_set():
                await reply(chat,'The bot is already stopping',thread)
                return
            if command=='/restart':
                await self.restart_menu(msg,user)
                return
            if command=='/upload':
                await self.owner_backup.command(msg,user)
                return
            reason = command[1:]
            await reply(chat,'Saving progress and stopping' if reason=='shutdown' else 'Saving progress and starting a fresh session',thread)
            self.request_stop(reason)
        else:
            await reply(chat,'Send media directly, use /help for available commands',thread)

    async def polling(self):
        offset = int(self.state.get('offset','0'))
        while not self.stop.is_set():
            try:
                updates = await self.bot.get_updates(offset=offset,timeout=15,request_timeout=35,
                    allowed_updates=['message','callback_query','my_chat_member'])
                for update in updates:
                    if self.stop.is_set():
                        break
                    try:
                        await self.handle(update)
                    except AiogramError:
                        # Jobs were saved before replies, don't drop them because a reply failed
                        logging.info('A command reply could not be delivered')
                    offset = update.update_id+1
                    self.state.set('offset',offset)
            except TelegramRetryAfter as exc:
                await asyncio.sleep(exc.retry_after+1)
            except (TelegramNetworkError,TelegramServerError,ClientDecodeError):
                await asyncio.sleep(3)


async def main():
    asyncio.get_running_loop().set_exception_handler(background_error)
    token = os.getenv('TELEGRAM_BOT_TOKEN','').strip()
    owner = int(os.getenv('OWNER_ID') or os.getenv('TELE_OWNER_ID') or '0')
    if not token or owner<=0:
        raise RuntimeError('Set TELEGRAM_BOT_TOKEN and OWNER_ID')
    data = Path(os.getenv('BOT_DATA_DIR') or ROOT/'data').resolve()
    data.mkdir(parents=True,exist_ok=True)
    (data/'receipt.json').unlink(missing_ok=True)
    kwargs = {'api': TelegramAPIServer.from_base(api_base(), is_local=local_file_access())}
    state = State(data/'state.db')
    try:
        async with Bot(token=token,session=AiohttpSession(timeout=UPLOAD_TIMEOUT,limit=32,**kwargs)).context() as bot:
            runner = Runner(state,bot,data,owner)
            for sig in (signal.SIGINT,signal.SIGTERM):
                with suppress(NotImplementedError):
                    asyncio.get_running_loop().add_signal_handler(sig,runner.request_stop,'shutdown')
            await runner.run()
    finally:
        state.close()


if __name__=='__main__':
    configure_logging()
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        pass
    except Exception:
        logging.critical('Whisper bot stopped unexpectedly',exc_info=True)
        raise SystemExit(1)
