# Whisper Telegram Bot

A Telegram audio and video transcription bot built from the current TikTok bot's aiogram 3 infrastructure

It runs OpenAI's open source Whisper locally on the machine hosting the bot, an OpenAI API key is not needed

## What it accepts

- Direct HTTP or HTTPS links to audio or video files, including signed download links
- Telegram audio uploads, video uploads, voice messages, round video notes, and files sent as documents
- Multiple direct links in one message

Website pages such as YouTube, TikTok, or a Google Drive preview page need an actual media download link instead

## Features carried over

- aiogram 3, using the same Telegram library as the current TikTok bot
- The same ten interface language choices: English, Spanish, Arabic, Russian, Chinese, Persian, Japanese, Portuguese, French, and German
- Four active slots and four waiting requests per user, with no owner exemption
- Persistent SQLite queues, settings, update offsets, and delivery receipts
- `/queue`, `/cancel`, `/ping`, `/id`, `/settings`, and `/help`
- Owner commands: `/jobs`, `/stats`, `/specs`, `/dpend`, `/restart`, `/upload`, `/shutdown`, and `/broadcast`
- A ZIP reimport choice when restarting, preserving the saved queue and settings
- Private owner backup ZIPs with shutdown and restart buttons
- One hour result caching, with an option to bypass cached results
- Buttons restricted to the original requester, with the same 1 minute 40 second cooldown per output button
- Hourly logs, final logs, crash reports, workflow diagnostics, and `#update` dependency notices to `-1004434678187` by default
- Messages reply to the submitted media or link, and output attribution displays [@transcribewhisper_bot](https://t.me/transcribewhisper_bot?start=welcome_hehehehaw==)
- Status messages without a job number or a final Done message

TikTok-specific audio extraction and video compression controls are replaced with transcription controls

## Transcription settings

| Setting | Default | Choices |
| --- | --- | --- |
| Whisper model | `base` | `tiny`, `base`, `small`, `medium`, `large`, `turbo` |
| Speech language | Automatic detection | Automatic or one of Whisper's 99 common language codes |
| Task | Transcribe | Original language transcription or translation into English |
| Transcript preview | On | On or off |
| Word timestamps | Off | On or off, word details are included in JSON |
| Use cached results | On | On or off |
| TXT transcript | On | On, Off, Off with no button |
| SRT subtitles | Off with no button | On, Off, Off with no button |
| VTT subtitles | Off with no button | On, Off, Off with no button |
| TSV timestamps | Off with no button | On, Off, Off with no button |
| JSON transcript | Off with no button | On, Off, Off with no button |
| Media metadata | Off with no button | On, Off, Off with no button |
| Metadata format | JSON | JSON, XML, TXT |

`On` sends the file automatically, `Off` adds a download button, `Off with no button` hides it

When multiple files are enabled, they are sent together in one Telegram document album

Transcripts and metadata have different filenames, for example `recording-12.txt` and `recording-12.metadata.txt`, enabling both does not cause a collision

The interface language and the speech language are separate settings, Arabic audio can be transcribed while the menus remain English

Turbo is intended for transcription, choosing translation while using turbo switches the model to base and displays a notice, selecting turbo while translation is active switches the task to transcription

Settings are saved with each request when it is accepted, changing settings applies to new requests

## GitHub Actions setup, ZIP method

This matches the existing TikTok bot's ZIP-based hosting setup

1. Create a separate private repository for this bot
2. Upload `Whisper-Telegram-Bot.zip` to a host with a direct HTTPS download URL
3. Add the supplied `whisper.yml` as `.github/workflows/whisper.yml` on the repository's default branch
4. Create a new Telegram bot through BotFather
5. Add the following repository secrets under Settings > Secrets and variables > Actions

| Secret | Value |
| --- | --- |
| `TELEGRAM_BOT_TOKEN` | The new transcription bot's token |
| `TELE_OWNER_ID` | Your numeric Telegram user ID |
| `TELEGRAM_API_ID` | Numeric app ID from my.telegram.org |
| `TELEGRAM_API_HASH` | Matching app hash from my.telegram.org |
| `TELE_ZIP` | The direct HTTPS download URL for `Whisper-Telegram-Bot.zip` |

`OWNER_ID` is also accepted as an alternative to `TELE_OWNER_ID`, `APP_ZIP_URL` is an alternative to `TELE_ZIP`

6. Give the new bot access to the reporting chat, including permission to send documents, or change `REPORT_CHAT_ID`
7. Open Actions > Whisper Telegram Bot > Run workflow
8. Leave `continue` enabled for automatic continuation, choose `base` as the initial model, then run the workflow
9. Open the new bot, send `/start`, choose a language, and submit media

Do not reuse the TikTok bot token, two bot processes cannot poll the same token at once

To update the application, replace the hosted ZIP and use `/restart` > Restart and reimport ZIP, or enable `force_reimport` in Run workflow

Only source files are imported from an application ZIP, importing code never overwrites the saved queue or settings

## GitHub Actions setup, full repository method

Extract the ZIP and commit its contents at the repository root, including `.github/workflows/whisper.yml`

Set `TELEGRAM_BOT_TOKEN`, `TELE_OWNER_ID`, `TELEGRAM_API_ID`, and `TELEGRAM_API_HASH`, leave `TELE_ZIP` and `APP_ZIP_URL` unset, then start the workflow

The workflow uses the checked out application source directly, a hosted source ZIP is unnecessary in this mode

## Local Telegram Bot API setup

The workflow now runs the same managed local Bot API server as the TikTok bot, uploads and direct-link inputs can be up to **2 GBs per file** by default

1. Get your app ID and app hash from [my.telegram.org](https://my.telegram.org), under API development tools
2. Add `TELEGRAM_API_ID` and `TELEGRAM_API_HASH` as repository Actions secrets, you can use the same app credentials you use for the TikTok bot
3. Replace both the hosted Whisper ZIP and `.github/workflows/whisper.yml`
4. Run the updated workflow with `force_reimport` enabled

Keep your existing Whisper bot token, owner ID, ZIP URL, and optional R2 settings, no separate VPS or Telegram user-session login is needed

The workflow builds the official `tdlib/telegram-bot-api` source with its pinned TDLib submodule, then caches the executable by operating system, architecture, and source commit, the first build can take several minutes

The server runs beside aiogram on `127.0.0.1:8081`, the first migration calls Telegram cloud `logOut`, repeated migrations accept an already-logged-out response, transient errors and declared retry delays are handled with bounded waits

Database, download, and temporary directories are created before startup, failed startup shows a bounded, redacted diagnostic excerpt without exposing your bot token or app hash

When the session ends, the server stops cleanly before its authorization and update state is encrypted into `state/telegram-api.enc`, then it restarts for final reporting, the encrypted snapshot travels with the matching queue database in the workflow cache and optional R2 backup

Keep `TELEGRAM_API_HASH` unchanged when restoring encrypted state, rotating the token for the same bot does not change the encryption key, a migrated queue without its matching encrypted state fails instead of creating a fresh update history

The owner `/upload` ZIP excludes native authorization state, restoring that ZIP's migrated queue also requires the matching `telegram-api.enc` from its workflow cache or R2 backup

All bot requests, logs, dependency notices, and final diagnostics use the selected local endpoint, a native server crash stops the bot and blocks automatic continuation

Whisper model, transcription duration, queue, and output preferences retain their previous behavior

## Workflow behavior

- Uses `actions/checkout@main`, `actions/setup-python@main`, and `actions/cache` restore and save actions on `main`
- Uses Python 3.11 for Whisper and PyTorch compatibility
- Installs a CPU build of PyTorch on the hosted Ubuntu runner
- Caches pip downloads, FFmpeg, neofetch, Whisper model weights, the compiled Bot API server, imported source, and the paired queue and encrypted native state
- Downloads a selected Whisper model when it is first needed
- Runs sessions for up to 5 hours 40 minutes, including a deadline that shortens the session when setup takes longer so there is time to save state
- Limits inference to one Whisper process at a time, with up to four inputs downloading or waiting for inference globally
- Starts the next workflow session only after clean shutdown and successful persistence, `/shutdown` stops continuation
- Preserves a consistent database snapshot after a bot process failure when the job can still run cleanup steps
- Sends crash and workflow failure reports, automatic continuation stops on a failed run
- Retains the latest queue and source caches plus one previous copy after verifying the latest cache exists
- Caches model weights separately from private queue data

Whisper medium and large models can be very slow on a hosted CPU runner, tiny or base are the practical starting choices

An interrupted transcription restarts from the beginning after recovery, completed transcription results and confirmed output uploads are retained

If Telegram does not confirm whether an upload was accepted, the job becomes uncertain and is not automatically uploaded again, check the chat before resubmitting

GitHub may evict caches, optional R2 backups provide a second persistence location, use a private repository because saved state contains submitted links and recent transcripts

## Optional R2 backups

Add all four values, or leave all four empty

| Secret | Value |
| --- | --- |
| `R2_ACCOUNT_ID` | Cloudflare account ID |
| `R2_ACCESS_KEY_ID` | R2 access key |
| `R2_SECRET_ACCESS_KEY` | R2 secret key |
| `R2_BUCKET_NAME` | Existing R2 bucket name |

`R2_ACCOUNT_ID` and `R2_BUCKET_NAME` can also be repository variables

R2 backups contain application source, a consistent queue database snapshot, and the matching encrypted native Bot API snapshot, raw media and Whisper weights are excluded

Backup uploads are verified before older backups in this workflow's own Whisper prefix are removed, TikTok backups use a separate prefix

## Limits and optional variables

The supplied local-server workflow accepts Telegram uploads and direct-link inputs up to **2 GBs**, recordings still default to a maximum duration of 60 minutes

Manual cloud-endpoint runs retain the 20 MB Telegram upload-download limit, 50 MB output limit, and 500 MB direct-link input default

| Repository variable or local environment variable | Default | Purpose |
| --- | --- | --- |
| `REPORT_CHAT_ID` | `-1004434678187` | Destination for logs, crashes, and dependency updates, use `0` to disable reporting |
| `MAX_INPUT_MB` | `2000` internally, displayed as 2 GBs | Maximum input size in decimal MB, capped at 2 GBs for local API runs |
| `MAX_DURATION_SECONDS` | `3600` | Maximum recording duration |
| `TRANSCRIBE_TIMEOUT_SECONDS` | `7200` | Maximum processing time for one Whisper job |
| `TELEGRAM_API_BASE` | Set automatically by the workflow | Selected local endpoint, aiogram uses shared filesystem file access |

The provided workflow starts the server automatically, `BOT_API_BASE_URL` and `BOT_API_IS_LOCAL` remain available as legacy aliases for manual custom-endpoint installations, keep `BOT_API_IS_LOCAL=false` for a remote server that does not share the bot filesystem

For local use only, `WHISPER_DEVICE=auto` uses CUDA when available, `WHISPER_THREADS` controls CPU threads, and `WHISPER_MODEL_DIR` chooses the model cache location, the provided workflow explicitly uses CPU

## Running locally

Install Python 3.11 and FFmpeg, then run

```bash
python -m venv .venv
source .venv/bin/activate
python -m pip install torch --index-url https://download.pytorch.org/whl/cpu
python -m pip install -r requirements.txt
export TELEGRAM_BOT_TOKEN='your-new-bot-token'
export OWNER_ID='your-numeric-id'
export REPORT_CHAT_ID='0'
python telegram_logs.py run bot.py
```

On Windows, activate with `.venv\Scripts\activate`, set environment variables using PowerShell or CMD, and ensure FFmpeg is on PATH

The local process saves to `data` by default and uses the cloud endpoint unless configured otherwise, automatic server builds, workflow dispatch, and source reimport are provided by the GitHub Actions workflow

## Commands

| Command | Access | Action |
| --- | --- | --- |
| `/start` | Everyone | Choose an interface language on first use |
| `/help` | Everyone | Show help, owner commands are included only for the owner |
| `/settings` | Everyone | Change transcription and output settings |
| `/queue` | Everyone | List your active and waiting job IDs |
| `/cancel <job>` | Requester or owner | Cancel a job, including its Whisper process |
| `/ping` | Everyone | Telegram round trip time |
| `/id` | Everyone | Show your Telegram user ID |
| `/jobs` | Owner | List all outstanding jobs |
| `/stats` | Owner | Saved user, chat, request, and uptime statistics |
| `/specs` | Owner | Server specifications using neofetch |
| `/dpend` | Owner | Installed dependency and tool versions |
| `/restart` | Owner | Start another session, optionally reimporting source |
| `/upload` | Owner | Send a private source and state backup, then show shutdown and restart choices |
| `/shutdown` | Owner | Save and stop without starting another session |
| `/broadcast` | Owner in private chat | Reply to an announcement, review its preview, then send it to known chats |

In groups, disable BotFather privacy mode if the bot should receive ordinary uploads and direct links, forum topics are preserved in replies

## Validation

Run the included tests with

```bash
python -m pip install -r requirements-dev.txt
python -m pytest -q
```

The original transcription worker was checked with aiogram 3.31.0 and successfully transcribed the upstream Whisper JFK speech test recording using the tiny model on CPU

83 automated tests passed, covering local API migration, retry handling, process startup and shutdown using a local test server, encrypted state restoration, 2 GBs limits, and paired workflow backups

Tests cover queue admission, settings snapshots, recovery, cache expiry, protected output buttons, grouping documents, uncertain deliveries, all supported upload message types, real FFmpeg preparation, and the workflow's standalone source import and embedded reporting scripts

No Telegram bot token was supplied during development, live Telegram delivery and a hosted GitHub Actions run have not been performed

## Upstream references

- [OpenAI Whisper](https://github.com/openai/whisper)
- [aiogram 3.31 documentation](https://docs.aiogram.dev/en/v3.31.0/)
- [Telegram Bot API file downloads](https://core.telegram.org/bots/api#getfile)
- [Telegram local Bot API server](https://core.telegram.org/bots/api#using-a-local-bot-api-server)
- [GitHub Actions limits](https://docs.github.com/en/actions/reference/limits)
