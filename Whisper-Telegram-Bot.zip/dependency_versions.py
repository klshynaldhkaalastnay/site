"""Report installed runtime dependencies without contacting external services."""
import asyncio
from contextlib import suppress
from importlib.metadata import PackageNotFoundError, version
import os
from pathlib import Path
import platform
import re
import shutil
import signal
import sys

from system_specs import ANSI_ESCAPE, CONTROL_CHARACTERS

REQUIREMENTS = Path(__file__).resolve().with_name('requirements.txt')
TIMEOUT_SECONDS = 5


def python_versions():
    lines = ['Python: '+platform.python_version(), '', 'Python packages']
    seen = set()
    for line in REQUIREMENTS.read_text(encoding='utf-8').splitlines()+['torch','numpy','numba','tiktoken']:
        match = re.match(r'^([A-Za-z0-9][A-Za-z0-9_.-]*)', line.strip())
        if not match:
            continue
        name = match.group(1)
        normalized = re.sub(r'[-_.]+', '-', name).lower()
        if normalized in seen:
            continue
        seen.add(normalized)
        try:
            installed = version(name)
        except PackageNotFoundError:
            installed = 'Not installed'
        lines.append(name+': '+installed)
    return lines


def find_tool(name, cached):
    if cached.is_file() and os.access(cached, os.X_OK):
        return str(cached)
    return shutil.which(name)


async def stop_probe(process):
    with suppress(ProcessLookupError):
        if os.name == 'posix':
            os.killpg(process.pid, signal.SIGKILL)
        else:
            process.kill()
    await process.communicate()


async def probe_version(executable, arguments, pattern, *, missing_exit=None):
    if not executable:
        return 'Not installed'
    try:
        process = await asyncio.create_subprocess_exec(
            executable, *arguments, stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.DEVNULL, start_new_session=True)
    except OSError:
        return 'Unavailable'
    try:
        output, _ = await asyncio.wait_for(process.communicate(), TIMEOUT_SECONDS)
    except TimeoutError:
        await stop_probe(process)
        return 'Timed out'
    except BaseException:
        await stop_probe(process)
        raise
    if missing_exit is not None and process.returncode == missing_exit:
        return 'Not installed'
    if process.returncode:
        return 'Unavailable'
    text = ANSI_ESCAPE.sub('', output.decode('utf-8', errors='replace'))
    text = CONTROL_CHARACTERS.sub('', text)
    match = re.search(pattern, text, re.MULTILINE | re.IGNORECASE)
    return match.group(1).strip() if match else 'Unavailable'


async def read_dependencies():
    lines = python_versions()
    home = Path.home()
    tools = [
        ('telegram-bot-api', find_tool('telegram-bot-api', home/'.telegram-bot-api/telegram-bot-api'), ['--version'],
         r'(?:Bot API(?: server)?|Telegram Bot API server|telegram-bot-api)\s+(\S+)', None),
        ('FFmpeg', find_tool('ffmpeg', home/'.ffmpeg/bin/ffmpeg'), ['-version'],
         r'^ffmpeg version (\S+)', None),
        ('ffprobe', find_tool('ffprobe', home/'.ffmpeg/bin/ffprobe'), ['-version'],
         r'^ffprobe version (\S+)', None),
        ('neofetch', find_tool('neofetch', home/'.neofetch/neofetch'), ['--version'],
         r'^Neofetch (\S+)', None),
    ]
    versions = await asyncio.gather(*(probe_version(executable, args, pattern,
        missing_exit=missing) for _, executable, args, pattern, missing in tools))
    lines.extend(['', 'System tools'])
    lines.extend(label+': '+installed for (label, *_), installed in zip(tools, versions))
    return '\n'.join(lines)
