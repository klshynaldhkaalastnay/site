"""Durable admission, settings snapshots, results, and delivery receipts."""
import gzip
import json
import sqlite3
import time

from common import ACTIVE, WAITING, CACHE_SECONDS, BUTTON_COOLDOWN, inference_key

LIVE = ('ready', 'running', 'queued')


class State:
    def __init__(self, path):
        self.db = sqlite3.connect(path)
        self.db.row_factory = sqlite3.Row
        self.db.execute('PRAGMA journal_mode=WAL')
        self.db.execute('PRAGMA synchronous=FULL')
        self.db.executescript('''
        CREATE TABLE IF NOT EXISTS meta(key TEXT PRIMARY KEY, value TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS jobs(
          id INTEGER PRIMARY KEY, user_id INTEGER NOT NULL, chat_id INTEGER NOT NULL,
          message_id INTEGER NOT NULL, thread_id INTEGER, source_key TEXT NOT NULL,
          source TEXT NOT NULL, options TEXT NOT NULL, inference_key TEXT NOT NULL,
          status TEXT NOT NULL, created REAL NOT NULL, finished REAL,
          status_message INTEGER, sent TEXT NOT NULL DEFAULT '[]', in_flight TEXT,
          result BLOB, result_expires REAL, notified INTEGER NOT NULL DEFAULT 0,
          duration REAL NOT NULL DEFAULT 0, cached INTEGER NOT NULL DEFAULT 0,
          UNIQUE(chat_id,message_id,source_key));
        CREATE INDEX IF NOT EXISTS jobs_status ON jobs(status,user_id,id);
        CREATE INDEX IF NOT EXISTS jobs_cache ON jobs(user_id,source_key,inference_key,result_expires);
        CREATE TABLE IF NOT EXISTS button_presses(
          callback_id TEXT PRIMARY KEY, source_job INTEGER NOT NULL, kind TEXT NOT NULL,
          created REAL NOT NULL, status TEXT NOT NULL);
        CREATE INDEX IF NOT EXISTS buttons_source ON button_presses(source_job,kind,created);
        ''')

    def get(self, key, default=None):
        row = self.db.execute('SELECT value FROM meta WHERE key=?', (key,)).fetchone()
        return row[0] if row else default

    def set(self, key, value):
        with self.db:
            self.db.execute('INSERT INTO meta VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value',
                            (key, str(value)))

    def job(self, jid):
        return self.db.execute('SELECT * FROM jobs WHERE id=?', (jid,)).fetchone()

    def change(self, jid, **values):
        allowed = {'status', 'finished', 'status_message', 'sent', 'in_flight', 'result',
                   'result_expires', 'notified', 'duration', 'cached'}
        if not values or not set(values) <= allowed:
            raise ValueError('Invalid state mutation')
        with self.db:
            self.db.execute('UPDATE jobs SET ' + ','.join(k+'=?' for k in values) + ' WHERE id=?',
                            (*values.values(), jid))

    def submit(self, user, chat, message, thread, source, key, options):
        with self.db:
            old = self.db.execute('SELECT id FROM jobs WHERE chat_id=? AND message_id=? AND source_key=?',
                                  (chat, message, key)).fetchone()
            if old:
                return old[0], False
            rows = self.db.execute("SELECT status FROM jobs WHERE user_id=? AND status IN ('ready','running','queued')",
                                   (user,)).fetchall()
            busy = sum(r[0] != 'queued' for r in rows)
            if busy >= ACTIVE and len(rows) - busy >= WAITING:
                return None, False
            status = 'ready' if busy < ACTIVE else 'queued'
            cur = self.db.execute('''INSERT INTO jobs(user_id,chat_id,message_id,thread_id,source_key,
                source,options,inference_key,status,created) VALUES(?,?,?,?,?,?,?,?,?,?)''',
                (user, chat, message, thread, key, json.dumps(source), json.dumps(options),
                 inference_key(options), status, time.time()))
            return cur.lastrowid, True

    def promote(self):
        with self.db:
            users = self.db.execute("SELECT DISTINCT user_id FROM jobs WHERE status='queued'").fetchall()
            for (user,) in users:
                busy = self.db.execute("SELECT COUNT(*) FROM jobs WHERE user_id=? AND status IN ('ready','running')",
                                       (user,)).fetchone()[0]
                rows = self.db.execute("SELECT id FROM jobs WHERE user_id=? AND status='queued' ORDER BY id LIMIT ?",
                                       (user, max(0, ACTIVE-busy))).fetchall()
                self.db.executemany("UPDATE jobs SET status='ready' WHERE id=?", rows)

    def outstanding(self, user=None):
        sql = "SELECT * FROM jobs WHERE status IN ('ready','running','queued')"
        return self.db.execute(sql + (' AND user_id=?' if user is not None else '') + ' ORDER BY id',
                               (user,) if user is not None else ()).fetchall()

    def ready(self):
        return self.db.execute("SELECT * FROM jobs WHERE status='ready' ORDER BY id").fetchall()

    def recover(self):
        with self.db:
            self.db.execute("UPDATE jobs SET status='uncertain' WHERE status IN ('ready','running','queued') AND in_flight IS NOT NULL")
            self.db.execute("UPDATE jobs SET status='ready' WHERE status='running'")
            self.db.execute("UPDATE button_presses SET status='uncertain' WHERE status='sending'")
        self.promote()

    def store_result(self, jid, payload, cached=False):
        packed = gzip.compress(json.dumps(payload, ensure_ascii=False).encode())
        self.change(jid, result=packed, result_expires=time.time()+CACHE_SECONDS,
                    duration=payload.get('duration', 0), cached=int(cached))

    def result(self, jid, allow_expired=False):
        row = self.job(jid)
        if not row or row['result'] is None or (not allow_expired and (row['result_expires'] or 0) < time.time()):
            return None
        return json.loads(gzip.decompress(row['result']))

    def cached_result(self, row):
        old = self.db.execute('''SELECT id FROM jobs WHERE user_id=? AND source_key=?
            AND inference_key=? AND result IS NOT NULL AND result_expires>? AND id!=?
            ORDER BY id DESC LIMIT 1''',
            (row['user_id'], row['source_key'], row['inference_key'], time.time(), row['id'])).fetchone()
        return self.result(old[0]) if old else None

    def cleanup(self):
        with self.db:
            # Live jobs retain their complete result until all uploads are resolved.
            self.db.execute("UPDATE jobs SET result=NULL WHERE result_expires<? AND status NOT IN ('ready','running','queued')", (time.time(),))
            self.db.execute('DELETE FROM button_presses WHERE created<? AND status!=\'sending\'', (time.time()-86400,))

    def button_remaining(self, jid, kind):
        row = self.db.execute('SELECT MAX(created) FROM button_presses WHERE source_job=? AND kind=?', (jid, kind)).fetchone()
        return max(0, min(BUTTON_COOLDOWN, row[0]+BUTTON_COOLDOWN-time.time())) if row[0] else 0

    def start_button(self, jid, kind, callback):
        with self.db:
            self.db.execute("INSERT INTO button_presses VALUES(?,?,?,?,'sending')", (callback, jid, kind, time.time()))

    def checkpoint(self):
        self.db.execute('PRAGMA wal_checkpoint(TRUNCATE)')
        if self.db.execute('PRAGMA quick_check').fetchone()[0] != 'ok':
            raise RuntimeError('State database validation failed')

    def close(self):
        self.checkpoint()
        self.db.close()

