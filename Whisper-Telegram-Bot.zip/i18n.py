"""Common controls and owner messages reused from the downloader."""
LANGUAGES = {'en': 'English',
 'es': 'Español',
 'ar': 'العربية',
 'ru': 'Русский',
 'zh': '中文',
 'fa': 'فارسی',
 'ja': '日本語',
 'pt': 'Português',
 'fr': 'Français',
 'de': 'Deutsch'}

OWNER_HELP = {'en': 'Owner commands\n'
       '/jobs - All jobs\n'
       '/restart - Restart, optionally reimporting the ZIP\n'
       '/upload - Send backup ZIP, choose shutdown or restart\n'
       '/shutdown - Back up and stop\n'
       '/broadcast - Reply to a message to announce it to all known chats\n'
       '/specs - Show server specifications\n'
       '/dpend - Show dependencies and installed versions\n'
       '/stats - Show bot statistics',
 'es': 'Comandos del propietario\n'
       '/jobs - Todas las solicitudes\n'
       '/restart - Reiniciar, con opción de reimportar el ZIP\n'
       '/upload - Recibir copia ZIP y elegir apagar o reiniciar\n'
       '/shutdown - Copia de seguridad y parada\n'
       '/broadcast - Responde a un mensaje para anunciarlo a todos los chats conocidos\n'
       '/specs - Mostrar las especificaciones del servidor\n'
       '/dpend - Mostrar las dependencias y sus versiones instaladas\n'
       '/stats - Mostrar estadísticas del bot',
 'ar': 'أوامر المالك\n'
       '/jobs - جميع الطلبات\n'
       '/restart - إعادة التشغيل مع خيار استيراد ZIP\n'
       '/upload - إرسال نسخة ZIP احتياطية واختيار إيقاف أو إعادة تشغيل\n'
       '/shutdown - نسخ احتياطي وإيقاف\n'
       '/broadcast - رد على رسالة لإرسالها إلى جميع المحادثات المعروفة\n'
       '/specs - عرض مواصفات الخادم\n'
       '/dpend - عرض التبعيات وإصداراتها المثبتة\n'
       '/stats - عرض إحصائيات البوت',
 'ru': 'Команды владельца\n'
       '/jobs - Все запросы\n'
       '/restart - Перезапуск с возможностью импорта ZIP\n'
       '/upload - Получить резервную копию ZIP и выбрать выключение или перезапуск\n'
       '/shutdown - Резервная копия и остановка\n'
       '/broadcast - Ответьте на сообщение для рассылки во все известные чаты\n'
       '/specs - Показать характеристики сервера\n'
       '/dpend - Показать зависимости и установленные версии\n'
       '/stats - Показать статистику бота',
 'zh': '所有者命令\n'
       '/jobs - 所有请求\n'
       '/restart - 重启，可选择重新导入 ZIP\n'
       '/upload - 接收备份 ZIP，选择关闭或重启\n'
       '/shutdown - 备份并停止\n'
       '/broadcast - 回复消息以向所有已知聊天发送公告\n'
       '/specs - 查看服务器配置\n'
       '/dpend - 查看依赖及其已安装版本\n'
       '/stats - 查看机器人统计',
 'fa': 'دستورهای مالک\n'
       '/jobs - همه درخواست\u200cها\n'
       '/restart - راه\u200cاندازی مجدد با گزینه ورود دوباره ZIP\n'
       '/upload - دریافت ZIP پشتیبان و انتخاب خاموش کردن یا راه\u200cاندازی مجدد\n'
       '/shutdown - پشتیبان\u200cگیری و توقف\n'
       '/broadcast - برای ارسال پیام به همه گفتگوهای شناخته\u200cشده، با این دستور به پیام پاسخ دهید\n'
       '/specs - نمایش مشخصات سرور\n'
       '/dpend - نمایش وابستگی\u200cها و نسخه\u200cهای نصب\u200cشده\n'
       '/stats - نمایش آمار ربات',
 'ja': '所有者用コマンド\n'
       '/jobs - すべてのリクエスト\n'
       '/restart - 再起動（ZIPの再取り込みを選択）\n'
       '/upload - バックアップZIPを受け取り、停止か再起動を選択\n'
       '/shutdown - バックアップして停止\n'
       '/broadcast - メッセージに返信して全チャットに告知\n'
       '/specs - サーバーのシステム情報を表示\n'
       '/dpend - 依存関係とインストール済みバージョンを表示\n'
       '/stats - ボットの統計を表示',
 'pt': 'Comandos do proprietário\n'
       '/jobs - Todos os pedidos\n'
       '/restart - Reiniciar, com opção de reimportar o ZIP\n'
       '/upload - Receber o ZIP de backup e escolher desligar ou reiniciar\n'
       '/shutdown - Fazer backup e parar\n'
       '/broadcast - Responder a uma mensagem para anunciá-la a todos os chats\n'
       '/specs - Mostrar as especificações do servidor\n'
       '/dpend - Mostrar dependências e versões instaladas\n'
       '/stats - Mostrar estatísticas do bot',
 'fr': 'Commandes du propriétaire\n'
       '/jobs - Toutes les demandes\n'
       '/restart - Redémarrer, avec réimportation facultative du ZIP\n'
       '/upload - Recevoir le ZIP de sauvegarde et choisir arrêt ou redémarrage\n'
       '/shutdown - Sauvegarder et arrêter\n'
       '/broadcast - Répondre à un message pour l’annoncer à toutes les discussions\n'
       '/specs - Afficher les caractéristiques du serveur\n'
       '/dpend - Afficher les dépendances et leurs versions installées\n'
       '/stats - Afficher les statistiques du bot',
 'de': 'Besitzer-Befehle\n'
       '/jobs - Alle Anfragen\n'
       '/restart - Neustart, optional mit ZIP-Neuimport\n'
       '/upload - Backup-ZIP erhalten und Beenden oder Neustart wählen\n'
       '/shutdown - Sichern und beenden\n'
       '/broadcast - Auf eine Nachricht antworten, um sie an alle Chats zu senden\n'
       '/specs - Serverspezifikationen anzeigen\n'
       '/dpend - Abhängigkeiten und installierte Versionen anzeigen\n'
       '/stats - Bot-Statistik anzeigen'}

STATS_REPORT = ('Bot statistics\n'
 'Session uptime: {days}d {hours}h {minutes}m {seconds}s\n'
 'Recorded users: {users}\n'
 'Recorded chats: {chats}\n'
 'Active chat records: {active_chats}\n'
 '\n'
 'Saved requests: {total}\n'
 'Completed: {done}\n'
 'Failed: {failed}\n'
 'Cancelled: {cancelled}\n'
 'Unconfirmed: {uncertain}\n'
 '\n'
 'Current queue\n'
 'Running: {running}\n'
 'Ready: {ready}\n'
 'Waiting: {queued}\n'
 '\n'
 'Last 24 hours\n'
 'Requests: {recent_requests}\n'
 'Requesters: {recent_users}')

TEXT = {'en': {'Downloading...': 'Downloading...',
        'Uploading...': 'Uploading...',
        'The bot is restarting, please send your links again shortly': 'The bot is restarting, please send '
                                                                       'your links again shortly',
        'Only the bot owner can use this command': 'Only the bot owner can use this command',
        'No active or queued requests': 'No active or queued requests',
        'Use /cancel followed by one of your job numbers': 'Use /cancel followed by one of your job numbers',
        'This request has already ended': 'This request has already ended',
        'Cancelled, any upload already accepted by Telegram may still arrive': 'Cancelled, any upload '
                                                                               'already accepted by Telegram '
                                                                               'may still arrive',
        'The bot is already stopping': 'The bot is already stopping',
        'Saving progress and stopping': 'Saving progress and stopping',
        'Saving progress and starting a fresh session': 'Saving progress and starting a fresh session',
        'Telegram did not confirm delivery, check the chat before sending the link again': 'Telegram did not '
                                                                                           'confirm '
                                                                                           'delivery, check '
                                                                                           'the chat before '
                                                                                           'sending the link '
                                                                                           'again',
        'The previous upload was interrupted, check the chat before sending the link again': 'The previous '
                                                                                             'upload was '
                                                                                             'interrupted, '
                                                                                             'check the chat '
                                                                                             'before sending '
                                                                                             'the link again',
        'Queued, position {n}': 'Queued, position {n}',
        'Your Telegram ID is {user}': 'Your Telegram ID is {user}',
        'And {n} more': 'And {n} more',
        'Job {id}, {status}': 'Job {id}, {status}',
        'user {user}': 'user {user}',
        'ready': 'ready',
        'running': 'running',
        'queued': 'queued',
        'Settings': 'Settings',
        'Language': 'Language',
        'Back': 'Back',
        'On': 'On',
        'Off': 'Off',
        'Use /broadcast in our private chat': 'Use /broadcast in our private chat',
        'Reply to the announcement message with /broadcast': 'Reply to the announcement message with '
                                                             '/broadcast',
        'This message cannot be copied, try a text, photo, video or audio message': 'This message cannot be '
                                                                                    'copied, try a text, '
                                                                                    'photo, video or audio '
                                                                                    'message',
        'Send': 'Send',
        'Cancel': 'Cancel',
        'Send the preview above to {n} chats?': 'Send the preview above to {n} chats?',
        'Broadcast queued': 'Broadcast queued',
        'Broadcast cancelled': 'Broadcast cancelled',
        'Broadcast finished\nSent: {sent}\nSkipped or failed: {failed}\nUnconfirmed: {uncertain}': 'Broadcast '
                                                                                                   'finished\n'
                                                                                                   'Sent: '
                                                                                                   '{sent}\n'
                                                                                                   'Skipped '
                                                                                                   'or '
                                                                                                   'failed: '
                                                                                                   '{failed}\n'
                                                                                                   'Unconfirmed: '
                                                                                                   '{uncertain}',
        'Try this button again in {time} (min:sec)': 'Try this button again in {time} (min:sec)',
        'Off with no button': 'Off with no button',
        'Reimport the ZIP when restarting?': 'Reimport the ZIP when restarting?',
        'Restart and reimport ZIP': 'Restart and reimport ZIP',
        'Restart without reimport': 'Restart without reimport',
        'This restart prompt is no longer active, send /restart again': 'This restart prompt is no longer '
                                                                        'active, send /restart again',
        'Restart cancelled': 'Restart cancelled',
        'Saving progress and restarting with ZIP reimport': 'Saving progress and restarting with ZIP '
                                                            'reimport',
        'Preparing backup ZIP...': 'Preparing backup ZIP...',
        'A backup ZIP is already being prepared': 'A backup ZIP is already being prepared',
        'The backup ZIP is too large, the maximum size is 50 MB': 'The backup ZIP is too large, the maximum '
                                                                  'size is 50 MB',
        'Backup ZIP sent. Shut down or restart?': 'Backup ZIP sent, Shut down or restart?',
        'Backup ZIP sent to your private chat': 'Backup ZIP sent to your private chat',
        'Could not send the backup ZIP, open our private chat and send /start, then try /upload again': 'Could '
                                                                                                        'not '
                                                                                                        'send '
                                                                                                        'the '
                                                                                                        'backup '
                                                                                                        'ZIP, '
                                                                                                        'open '
                                                                                                        'our '
                                                                                                        'private '
                                                                                                        'chat '
                                                                                                        'and '
                                                                                                        'send '
                                                                                                        '/start, '
                                                                                                        'then '
                                                                                                        'try '
                                                                                                        '/upload '
                                                                                                        'again',
        'This backup menu is no longer active, use /upload again': 'This backup menu is no longer active, '
                                                                   'use /upload again',
        'Shut down': 'Shut down',
        'Restart': 'Restart',
        'Telegram did not confirm the backup ZIP, check your private chat before using /upload again': 'Telegram '
                                                                                                       'did '
                                                                                                       'not '
                                                                                                       'confirm '
                                                                                                       'the '
                                                                                                       'backup '
                                                                                                       'ZIP, '
                                                                                                       'check '
                                                                                                       'your '
                                                                                                       'private '
                                                                                                       'chat '
                                                                                                       'before '
                                                                                                       'using '
                                                                                                       '/upload '
                                                                                                       'again',
        'Could not read system specifications, please try again later': 'Could not read system '
                                                                        'specifications, please try again '
                                                                        'later',
        'Could not read dependency versions, please try again later': 'Could not read dependency versions, '
                                                                      'please try again later',
        'Metadata': 'Metadata',
        'Metadata format': 'Metadata format',
        'Bot statistics\nSession uptime: {days}d {hours}h {minutes}m {seconds}s\nRecorded users: {users}\nRecorded chats: {chats}\nActive chat records: {active_chats}\n\nSaved requests: {total}\nCompleted: {done}\nFailed: {failed}\nCancelled: {cancelled}\nUnconfirmed: {uncertain}\n\nCurrent queue\nRunning: {running}\nReady: {ready}\nWaiting: {queued}\n\nLast 24 hours\nRequests: {recent_requests}\nRequesters: {recent_users}': 'Bot '
                                                                                                                                                                                                                                                                                                                                                                                                                                             'statistics\n'
                                                                                                                                                                                                                                                                                                                                                                                                                                             'Session '
                                                                                                                                                                                                                                                                                                                                                                                                                                             'uptime: '
                                                                                                                                                                                                                                                                                                                                                                                                                                             '{days}d '
                                                                                                                                                                                                                                                                                                                                                                                                                                             '{hours}h '
                                                                                                                                                                                                                                                                                                                                                                                                                                             '{minutes}m '
                                                                                                                                                                                                                                                                                                                                                                                                                                             '{seconds}s\n'
                                                                                                                                                                                                                                                                                                                                                                                                                                             'Recorded '
                                                                                                                                                                                                                                                                                                                                                                                                                                             'users: '
                                                                                                                                                                                                                                                                                                                                                                                                                                             '{users}\n'
                                                                                                                                                                                                                                                                                                                                                                                                                                             'Recorded '
                                                                                                                                                                                                                                                                                                                                                                                                                                             'chats: '
                                                                                                                                                                                                                                                                                                                                                                                                                                             '{chats}\n'
                                                                                                                                                                                                                                                                                                                                                                                                                                             'Active '
                                                                                                                                                                                                                                                                                                                                                                                                                                             'chat '
                                                                                                                                                                                                                                                                                                                                                                                                                                             'records: '
                                                                                                                                                                                                                                                                                                                                                                                                                                             '{active_chats}\n'
                                                                                                                                                                                                                                                                                                                                                                                                                                             '\n'
                                                                                                                                                                                                                                                                                                                                                                                                                                             'Saved '
                                                                                                                                                                                                                                                                                                                                                                                                                                             'requests: '
                                                                                                                                                                                                                                                                                                                                                                                                                                             '{total}\n'
                                                                                                                                                                                                                                                                                                                                                                                                                                             'Completed: '
                                                                                                                                                                                                                                                                                                                                                                                                                                             '{done}\n'
                                                                                                                                                                                                                                                                                                                                                                                                                                             'Failed: '
                                                                                                                                                                                                                                                                                                                                                                                                                                             '{failed}\n'
                                                                                                                                                                                                                                                                                                                                                                                                                                             'Cancelled: '
                                                                                                                                                                                                                                                                                                                                                                                                                                             '{cancelled}\n'
                                                                                                                                                                                                                                                                                                                                                                                                                                             'Unconfirmed: '
                                                                                                                                                                                                                                                                                                                                                                                                                                             '{uncertain}\n'
                                                                                                                                                                                                                                                                                                                                                                                                                                             '\n'
                                                                                                                                                                                                                                                                                                                                                                                                                                             'Current '
                                                                                                                                                                                                                                                                                                                                                                                                                                             'queue\n'
                                                                                                                                                                                                                                                                                                                                                                                                                                             'Running: '
                                                                                                                                                                                                                                                                                                                                                                                                                                             '{running}\n'
                                                                                                                                                                                                                                                                                                                                                                                                                                             'Ready: '
                                                                                                                                                                                                                                                                                                                                                                                                                                             '{ready}\n'
                                                                                                                                                                                                                                                                                                                                                                                                                                             'Waiting: '
                                                                                                                                                                                                                                                                                                                                                                                                                                             '{queued}\n'
                                                                                                                                                                                                                                                                                                                                                                                                                                             '\n'
                                                                                                                                                                                                                                                                                                                                                                                                                                             'Last '
                                                                                                                                                                                                                                                                                                                                                                                                                                             '24 '
                                                                                                                                                                                                                                                                                                                                                                                                                                             'hours\n'
                                                                                                                                                                                                                                                                                                                                                                                                                                             'Requests: '
                                                                                                                                                                                                                                                                                                                                                                                                                                             '{recent_requests}\n'
                                                                                                                                                                                                                                                                                                                                                                                                                                             'Requesters: '
                                                                                                                                                                                                                                                                                                                                                                                                                                             '{recent_users}',
        'Could not read bot statistics, please try again later': 'Could not read bot statistics, please try '
                                                                 'again later',
        'Send audio, video, a voice message, or a direct media link': 'Send audio, video, a voice message, '
                                                                      'or a direct media link',
        'Whisper model': 'Whisper model',
        'Speech language': 'Speech language',
        'Automatic detection': 'Automatic detection',
        'Task': 'Task',
        'Transcribe': 'Transcribe',
        'Translate to English': 'Translate to English',
        'Word timestamps': 'Word timestamps',
        'Use cached results': 'Use cached results',
        'Transcript preview': 'Transcript preview',
        'Transcript files': 'Transcript files',
        'Preparing audio...': 'Preparing audio...',
        'Loading Whisper...': 'Loading Whisper...',
        'Transcribing...': 'Transcribing...',
        'Waiting for transcription...': 'Waiting for transcription...',
        'Download {format}': 'Download {format}',
        'Your queue is full, up to 4 active and 4 waiting requests are allowed': 'Your queue is full, up to '
                                                                                 '4 active and 4 waiting '
                                                                                 'requests are allowed',
        'This button belongs to the original requester': 'This button belongs to the original requester',
        'This result has expired, send the media again': 'This result has expired, send the media again',
        'No speech was detected': 'No speech was detected'},
 'es': {'Downloading...': 'Descargando...',
        'Uploading...': 'Subiendo...',
        'The bot is restarting, please send your links again shortly': 'El bot se está reiniciando, vuelve a '
                                                                       'enviar tus enlaces en breve',
        'Only the bot owner can use this command': 'Solo el propietario del bot puede usar este comando',
        'No active or queued requests': 'No hay solicitudes activas ni en espera',
        'Use /cancel followed by one of your job numbers': 'Usa /cancel seguido del número de tu solicitud',
        'This request has already ended': 'Esta solicitud ya ha finalizado',
        'Cancelled, any upload already accepted by Telegram may still arrive': 'Cancelado, los archivos ya '
                                                                               'aceptados por Telegram '
                                                                               'podrían llegar',
        'The bot is already stopping': 'El bot ya se está deteniendo',
        'Saving progress and stopping': 'Guardando el progreso y deteniendo',
        'Saving progress and starting a fresh session': 'Guardando el progreso e iniciando una nueva sesión',
        'Telegram did not confirm delivery, check the chat before sending the link again': 'Telegram no '
                                                                                           'confirmó la '
                                                                                           'entrega, revisa '
                                                                                           'el chat antes de '
                                                                                           'reenviar el '
                                                                                           'enlace',
        'The previous upload was interrupted, check the chat before sending the link again': 'La subida '
                                                                                             'anterior se '
                                                                                             'interrumpió, '
                                                                                             'revisa el chat '
                                                                                             'antes de '
                                                                                             'reenviar el '
                                                                                             'enlace',
        'Queued, position {n}': 'En espera, posición {n}',
        'Your Telegram ID is {user}': 'Tu ID de Telegram es {user}',
        'And {n} more': 'Y {n} más',
        'Job {id}, {status}': 'Solicitud {id}, {status}',
        'user {user}': 'usuario {user}',
        'ready': 'listo',
        'running': 'en curso',
        'queued': 'en espera',
        'Settings': 'Ajustes',
        'Language': 'Idioma',
        'Back': 'Atrás',
        'On': 'Activado',
        'Off': 'Desactivado',
        'Use /broadcast in our private chat': 'Usa /broadcast en nuestro chat privado',
        'Reply to the announcement message with /broadcast': 'Responde al mensaje del anuncio con /broadcast',
        'This message cannot be copied, try a text, photo, video or audio message': 'No se puede copiar este '
                                                                                    'mensaje, prueba con '
                                                                                    'texto, foto, vídeo o '
                                                                                    'audio',
        'Send': 'Enviar',
        'Cancel': 'Cancelar',
        'Send the preview above to {n} chats?': '¿Enviar la vista previa a {n} chats?',
        'Broadcast queued': 'Anuncio en cola',
        'Broadcast cancelled': 'Anuncio cancelado',
        'Broadcast finished\nSent: {sent}\nSkipped or failed: {failed}\nUnconfirmed: {uncertain}': 'Anuncio '
                                                                                                   'finalizado\n'
                                                                                                   'Enviado: '
                                                                                                   '{sent}\n'
                                                                                                   'Omitido '
                                                                                                   'o '
                                                                                                   'fallido: '
                                                                                                   '{failed}\n'
                                                                                                   'Sin '
                                                                                                   'confirmar: '
                                                                                                   '{uncertain}',
        'Try this button again in {time} (min:sec)': 'Vuelve a pulsar este botón en {time} (min:seg)',
        'Off with no button': 'Desactivado sin botón',
        'Reimport the ZIP when restarting?': '¿Reimportar el ZIP al reiniciar?',
        'Restart and reimport ZIP': 'Reiniciar y reimportar ZIP',
        'Restart without reimport': 'Reiniciar sin reimportar',
        'This restart prompt is no longer active, send /restart again': 'Esta confirmación ya no está '
                                                                        'activa, envía /restart otra vez',
        'Restart cancelled': 'Reinicio cancelado',
        'Saving progress and restarting with ZIP reimport': 'Guardando el progreso y reiniciando con '
                                                            'reimportación del ZIP',
        'Preparing backup ZIP...': 'Preparando ZIP de copia de seguridad...',
        'A backup ZIP is already being prepared': 'Ya se está preparando una copia de seguridad ZIP',
        'The backup ZIP is too large, the maximum size is 50 MB': 'El ZIP de copia de seguridad es demasiado '
                                                                  'grande, el límite es 50 MB',
        'Backup ZIP sent. Shut down or restart?': 'Copia de seguridad ZIP enviada, ¿apagar o reiniciar?',
        'Backup ZIP sent to your private chat': 'Copia de seguridad ZIP enviada a tu chat privado',
        'Could not send the backup ZIP, open our private chat and send /start, then try /upload again': 'No '
                                                                                                        'se '
                                                                                                        'pudo '
                                                                                                        'enviar '
                                                                                                        'el '
                                                                                                        'ZIP, '
                                                                                                        'abre '
                                                                                                        'nuestro '
                                                                                                        'chat '
                                                                                                        'privado, '
                                                                                                        'envía '
                                                                                                        '/start '
                                                                                                        'y '
                                                                                                        'vuelve '
                                                                                                        'a '
                                                                                                        'usar '
                                                                                                        '/upload',
        'This backup menu is no longer active, use /upload again': 'Este menú ya no está activo, usa /upload '
                                                                   'de nuevo',
        'Shut down': 'Apagar',
        'Restart': 'Reiniciar',
        'Telegram did not confirm the backup ZIP, check your private chat before using /upload again': 'Telegram '
                                                                                                       'no '
                                                                                                       'confirmó '
                                                                                                       'el '
                                                                                                       'ZIP, '
                                                                                                       'revisa '
                                                                                                       'tu '
                                                                                                       'chat '
                                                                                                       'privado '
                                                                                                       'antes '
                                                                                                       'de '
                                                                                                       'usar '
                                                                                                       '/upload '
                                                                                                       'de '
                                                                                                       'nuevo',
        'Could not read system specifications, please try again later': 'No se pudieron obtener las '
                                                                        'especificaciones del sistema, '
                                                                        'inténtalo más tarde',
        'Could not read dependency versions, please try again later': 'No se pudieron obtener las versiones '
                                                                      'de las dependencias, inténtalo más '
                                                                      'tarde',
        'Metadata': 'Metadatos',
        'Metadata format': 'Formato de metadatos',
        'Bot statistics\nSession uptime: {days}d {hours}h {minutes}m {seconds}s\nRecorded users: {users}\nRecorded chats: {chats}\nActive chat records: {active_chats}\n\nSaved requests: {total}\nCompleted: {done}\nFailed: {failed}\nCancelled: {cancelled}\nUnconfirmed: {uncertain}\n\nCurrent queue\nRunning: {running}\nReady: {ready}\nWaiting: {queued}\n\nLast 24 hours\nRequests: {recent_requests}\nRequesters: {recent_users}': 'Estadísticas '
                                                                                                                                                                                                                                                                                                                                                                                                                                             'del '
                                                                                                                                                                                                                                                                                                                                                                                                                                             'bot\n'
                                                                                                                                                                                                                                                                                                                                                                                                                                             'Tiempo '
                                                                                                                                                                                                                                                                                                                                                                                                                                             'de '
                                                                                                                                                                                                                                                                                                                                                                                                                                             'sesión: '
                                                                                                                                                                                                                                                                                                                                                                                                                                             '{days}d '
                                                                                                                                                                                                                                                                                                                                                                                                                                             '{hours}h '
                                                                                                                                                                                                                                                                                                                                                                                                                                             '{minutes}m '
                                                                                                                                                                                                                                                                                                                                                                                                                                             '{seconds}s\n'
                                                                                                                                                                                                                                                                                                                                                                                                                                             'Usuarios '
                                                                                                                                                                                                                                                                                                                                                                                                                                             'registrados: '
                                                                                                                                                                                                                                                                                                                                                                                                                                             '{users}\n'
                                                                                                                                                                                                                                                                                                                                                                                                                                             'Chats '
                                                                                                                                                                                                                                                                                                                                                                                                                                             'registrados: '
                                                                                                                                                                                                                                                                                                                                                                                                                                             '{chats}\n'
                                                                                                                                                                                                                                                                                                                                                                                                                                             'Chats '
                                                                                                                                                                                                                                                                                                                                                                                                                                             'marcados '
                                                                                                                                                                                                                                                                                                                                                                                                                                             'como '
                                                                                                                                                                                                                                                                                                                                                                                                                                             'activos: '
                                                                                                                                                                                                                                                                                                                                                                                                                                             '{active_chats}\n'
                                                                                                                                                                                                                                                                                                                                                                                                                                             '\n'
                                                                                                                                                                                                                                                                                                                                                                                                                                             'Solicitudes '
                                                                                                                                                                                                                                                                                                                                                                                                                                             'guardadas: '
                                                                                                                                                                                                                                                                                                                                                                                                                                             '{total}\n'
                                                                                                                                                                                                                                                                                                                                                                                                                                             'Completadas: '
                                                                                                                                                                                                                                                                                                                                                                                                                                             '{done}\n'
                                                                                                                                                                                                                                                                                                                                                                                                                                             'Fallidas: '
                                                                                                                                                                                                                                                                                                                                                                                                                                             '{failed}\n'
                                                                                                                                                                                                                                                                                                                                                                                                                                             'Canceladas: '
                                                                                                                                                                                                                                                                                                                                                                                                                                             '{cancelled}\n'
                                                                                                                                                                                                                                                                                                                                                                                                                                             'Sin '
                                                                                                                                                                                                                                                                                                                                                                                                                                             'confirmar: '
                                                                                                                                                                                                                                                                                                                                                                                                                                             '{uncertain}\n'
                                                                                                                                                                                                                                                                                                                                                                                                                                             '\n'
                                                                                                                                                                                                                                                                                                                                                                                                                                             'Cola '
                                                                                                                                                                                                                                                                                                                                                                                                                                             'actual\n'
                                                                                                                                                                                                                                                                                                                                                                                                                                             'En '
                                                                                                                                                                                                                                                                                                                                                                                                                                             'curso: '
                                                                                                                                                                                                                                                                                                                                                                                                                                             '{running}\n'
                                                                                                                                                                                                                                                                                                                                                                                                                                             'Listas: '
                                                                                                                                                                                                                                                                                                                                                                                                                                             '{ready}\n'
                                                                                                                                                                                                                                                                                                                                                                                                                                             'En '
                                                                                                                                                                                                                                                                                                                                                                                                                                             'espera: '
                                                                                                                                                                                                                                                                                                                                                                                                                                             '{queued}\n'
                                                                                                                                                                                                                                                                                                                                                                                                                                             '\n'
                                                                                                                                                                                                                                                                                                                                                                                                                                             'Últimas '
                                                                                                                                                                                                                                                                                                                                                                                                                                             '24 '
                                                                                                                                                                                                                                                                                                                                                                                                                                             'horas\n'
                                                                                                                                                                                                                                                                                                                                                                                                                                             'Solicitudes: '
                                                                                                                                                                                                                                                                                                                                                                                                                                             '{recent_requests}\n'
                                                                                                                                                                                                                                                                                                                                                                                                                                             'Solicitantes: '
                                                                                                                                                                                                                                                                                                                                                                                                                                             '{recent_users}',
        'Could not read bot statistics, please try again later': 'No se pudieron leer las estadísticas del '
                                                                 'bot, inténtalo más tarde',
        'Send audio, video, a voice message, or a direct media link': 'Envía audio, vídeo, un mensaje de voz '
                                                                      'o un enlace directo al archivo',
        'Whisper model': 'Modelo Whisper',
        'Speech language': 'Idioma del audio',
        'Automatic detection': 'Detección automática',
        'Task': 'Tarea',
        'Transcribe': 'Transcribir',
        'Translate to English': 'Traducir al inglés',
        'Word timestamps': 'Tiempos por palabra',
        'Use cached results': 'Usar resultados guardados',
        'Transcript preview': 'Vista previa',
        'Transcript files': 'Archivos de transcripción',
        'Preparing audio...': 'Preparando audio...',
        'Loading Whisper...': 'Cargando Whisper...',
        'Transcribing...': 'Transcribiendo...',
        'Waiting for transcription...': 'Esperando transcripción...',
        'Download {format}': 'Descargar {format}',
        'Your queue is full, up to 4 active and 4 waiting requests are allowed': 'Tu cola está llena, se '
                                                                                 'permiten 4 solicitudes '
                                                                                 'activas y 4 en espera',
        'This button belongs to the original requester': 'Este botón pertenece al solicitante original',
        'This result has expired, send the media again': 'El resultado ha caducado, envía el archivo otra '
                                                         'vez',
        'No speech was detected': 'No se detectó voz'},
 'ar': {'Downloading...': 'جارٍ التنزيل...',
        'Uploading...': 'جارٍ الرفع...',
        'The bot is restarting, please send your links again shortly': 'تتم إعادة تشغيل البوت، أعد إرسال '
                                                                       'الروابط بعد قليل',
        'Only the bot owner can use this command': 'يمكن لمالك البوت فقط استخدام هذا الأمر',
        'No active or queued requests': 'لا توجد طلبات نشطة أو في الانتظار',
        'Use /cancel followed by one of your job numbers': 'استخدم /cancel متبوعًا برقم أحد طلباتك',
        'This request has already ended': 'انتهى هذا الطلب بالفعل',
        'Cancelled, any upload already accepted by Telegram may still arrive': 'تم الإلغاء، قد تصل الملفات '
                                                                               'التي قبلها تيليجرام بالفعل',
        'The bot is already stopping': 'البوت يتوقف بالفعل',
        'Saving progress and stopping': 'جارٍ حفظ التقدم والإيقاف',
        'Saving progress and starting a fresh session': 'جارٍ حفظ التقدم وبدء جلسة جديدة',
        'Telegram did not confirm delivery, check the chat before sending the link again': 'لم يؤكد تيليجرام '
                                                                                           'التسليم، تحقق من '
                                                                                           'المحادثة قبل '
                                                                                           'إرسال الرابط '
                                                                                           'مجددًا',
        'The previous upload was interrupted, check the chat before sending the link again': 'انقطع الرفع '
                                                                                             'السابق، تحقق '
                                                                                             'من المحادثة '
                                                                                             'قبل إعادة '
                                                                                             'إرسال الرابط',
        'Queued, position {n}': 'في الانتظار، الترتيب {n}',
        'Your Telegram ID is {user}': 'معرّف تيليجرام الخاص بك هو {user}',
        'And {n} more': 'و{n} أخرى',
        'Job {id}, {status}': 'الطلب {id}، {status}',
        'user {user}': 'المستخدم {user}',
        'ready': 'جاهز',
        'running': 'قيد التنفيذ',
        'queued': 'في الانتظار',
        'Settings': 'الإعدادات',
        'Language': 'اللغة',
        'Back': 'رجوع',
        'On': 'تشغيل',
        'Off': 'إيقاف',
        'Use /broadcast in our private chat': 'استخدم /broadcast في المحادثة الخاصة معي',
        'Reply to the announcement message with /broadcast': 'رد على رسالة الإعلان بالأمر /broadcast',
        'This message cannot be copied, try a text, photo, video or audio message': 'لا يمكن نسخ هذه '
                                                                                    'الرسالة، جرّب نصاً أو '
                                                                                    'صورة أو فيديو أو صوتاً',
        'Send': 'إرسال',
        'Cancel': 'إلغاء',
        'Send the preview above to {n} chats?': 'إرسال المعاينة أعلاه إلى {n} محادثات؟',
        'Broadcast queued': 'تمت إضافة الإعلان إلى قائمة الإرسال',
        'Broadcast cancelled': 'تم إلغاء الإعلان',
        'Broadcast finished\nSent: {sent}\nSkipped or failed: {failed}\nUnconfirmed: {uncertain}': 'اكتمل '
                                                                                                   'إرسال '
                                                                                                   'الإعلان\n'
                                                                                                   'تم '
                                                                                                   'الإرسال: '
                                                                                                   '{sent}\n'
                                                                                                   'تم '
                                                                                                   'التخطي '
                                                                                                   'أو فشل: '
                                                                                                   '{failed}\n'
                                                                                                   'غير '
                                                                                                   'مؤكد: '
                                                                                                   '{uncertain}',
        'Try this button again in {time} (min:sec)': 'يمكنك الضغط على هذا الزر مجدداً بعد {time} '
                                                     '(دقيقة:ثانية)',
        'Off with no button': 'إيقاف بدون زر',
        'Reimport the ZIP when restarting?': 'إعادة استيراد ملف ZIP عند إعادة التشغيل؟',
        'Restart and reimport ZIP': 'إعادة التشغيل واستيراد ZIP',
        'Restart without reimport': 'إعادة التشغيل دون استيراد',
        'This restart prompt is no longer active, send /restart again': 'طلب إعادة التشغيل هذا لم يعد '
                                                                        'فعالاً، أرسل /restart مجدداً',
        'Restart cancelled': 'تم إلغاء إعادة التشغيل',
        'Saving progress and restarting with ZIP reimport': 'جارٍ حفظ التقدم وإعادة التشغيل مع استيراد ZIP',
        'Preparing backup ZIP...': 'جارٍ إعداد نسخة احتياطية ZIP...',
        'A backup ZIP is already being prepared': 'يجري إعداد نسخة احتياطية ZIP بالفعل',
        'The backup ZIP is too large, the maximum size is 50 MB': 'ملف ZIP الاحتياطي كبير جداً، الحد الأقصى '
                                                                  '50 ميغابايت',
        'Backup ZIP sent. Shut down or restart?': 'تم إرسال نسخة ZIP الاحتياطية، إيقاف أم إعادة تشغيل؟',
        'Backup ZIP sent to your private chat': 'تم إرسال نسخة ZIP الاحتياطية إلى محادثتك الخاصة',
        'Could not send the backup ZIP, open our private chat and send /start, then try /upload again': 'تعذر '
                                                                                                        'إرسال '
                                                                                                        'ZIP '
                                                                                                        'الاحتياطي، '
                                                                                                        'افتح '
                                                                                                        'المحادثة '
                                                                                                        'الخاصة '
                                                                                                        'معي '
                                                                                                        'وأرسل '
                                                                                                        '/start '
                                                                                                        'ثم '
                                                                                                        'جرب '
                                                                                                        '/upload '
                                                                                                        'مجدداً',
        'This backup menu is no longer active, use /upload again': 'قائمة النسخة الاحتياطية هذه لم تعد '
                                                                   'فعالة، استخدم /upload مجدداً',
        'Shut down': 'إيقاف',
        'Restart': 'إعادة التشغيل',
        'Telegram did not confirm the backup ZIP, check your private chat before using /upload again': 'لم '
                                                                                                       'يؤكد '
                                                                                                       'تيليجرام '
                                                                                                       'إرسال '
                                                                                                       'ZIP '
                                                                                                       'الاحتياطي، '
                                                                                                       'تحقق '
                                                                                                       'من '
                                                                                                       'محادثتك '
                                                                                                       'الخاصة '
                                                                                                       'قبل '
                                                                                                       'استخدام '
                                                                                                       '/upload '
                                                                                                       'مجدداً',
        'Could not read system specifications, please try again later': 'تعذر قراءة مواصفات النظام، حاول '
                                                                        'لاحقاً',
        'Could not read dependency versions, please try again later': 'تعذر قراءة إصدارات التبعيات، حاول '
                                                                      'لاحقاً',
        'Metadata': 'البيانات الوصفية',
        'Metadata format': 'صيغة البيانات الوصفية',
        'Bot statistics\nSession uptime: {days}d {hours}h {minutes}m {seconds}s\nRecorded users: {users}\nRecorded chats: {chats}\nActive chat records: {active_chats}\n\nSaved requests: {total}\nCompleted: {done}\nFailed: {failed}\nCancelled: {cancelled}\nUnconfirmed: {uncertain}\n\nCurrent queue\nRunning: {running}\nReady: {ready}\nWaiting: {queued}\n\nLast 24 hours\nRequests: {recent_requests}\nRequesters: {recent_users}': 'إحصائيات '
                                                                                                                                                                                                                                                                                                                                                                                                                                             'البوت\n'
                                                                                                                                                                                                                                                                                                                                                                                                                                             'مدة '
                                                                                                                                                                                                                                                                                                                                                                                                                                             'الجلسة: '
                                                                                                                                                                                                                                                                                                                                                                                                                                             '{days}d '
                                                                                                                                                                                                                                                                                                                                                                                                                                             '{hours}h '
                                                                                                                                                                                                                                                                                                                                                                                                                                             '{minutes}m '
                                                                                                                                                                                                                                                                                                                                                                                                                                             '{seconds}s\n'
                                                                                                                                                                                                                                                                                                                                                                                                                                             'المستخدمون '
                                                                                                                                                                                                                                                                                                                                                                                                                                             'المسجلون: '
                                                                                                                                                                                                                                                                                                                                                                                                                                             '{users}\n'
                                                                                                                                                                                                                                                                                                                                                                                                                                             'المحادثات '
                                                                                                                                                                                                                                                                                                                                                                                                                                             'المسجلة: '
                                                                                                                                                                                                                                                                                                                                                                                                                                             '{chats}\n'
                                                                                                                                                                                                                                                                                                                                                                                                                                             'سجلات '
                                                                                                                                                                                                                                                                                                                                                                                                                                             'المحادثات '
                                                                                                                                                                                                                                                                                                                                                                                                                                             'النشطة: '
                                                                                                                                                                                                                                                                                                                                                                                                                                             '{active_chats}\n'
                                                                                                                                                                                                                                                                                                                                                                                                                                             '\n'
                                                                                                                                                                                                                                                                                                                                                                                                                                             'الطلبات '
                                                                                                                                                                                                                                                                                                                                                                                                                                             'المحفوظة: '
                                                                                                                                                                                                                                                                                                                                                                                                                                             '{total}\n'
                                                                                                                                                                                                                                                                                                                                                                                                                                             'المكتملة: '
                                                                                                                                                                                                                                                                                                                                                                                                                                             '{done}\n'
                                                                                                                                                                                                                                                                                                                                                                                                                                             'الفاشلة: '
                                                                                                                                                                                                                                                                                                                                                                                                                                             '{failed}\n'
                                                                                                                                                                                                                                                                                                                                                                                                                                             'الملغاة: '
                                                                                                                                                                                                                                                                                                                                                                                                                                             '{cancelled}\n'
                                                                                                                                                                                                                                                                                                                                                                                                                                             'غير '
                                                                                                                                                                                                                                                                                                                                                                                                                                             'المؤكدة: '
                                                                                                                                                                                                                                                                                                                                                                                                                                             '{uncertain}\n'
                                                                                                                                                                                                                                                                                                                                                                                                                                             '\n'
                                                                                                                                                                                                                                                                                                                                                                                                                                             'قائمة '
                                                                                                                                                                                                                                                                                                                                                                                                                                             'الانتظار '
                                                                                                                                                                                                                                                                                                                                                                                                                                             'الحالية\n'
                                                                                                                                                                                                                                                                                                                                                                                                                                             'قيد '
                                                                                                                                                                                                                                                                                                                                                                                                                                             'التنفيذ: '
                                                                                                                                                                                                                                                                                                                                                                                                                                             '{running}\n'
                                                                                                                                                                                                                                                                                                                                                                                                                                             'جاهزة: '
                                                                                                                                                                                                                                                                                                                                                                                                                                             '{ready}\n'
                                                                                                                                                                                                                                                                                                                                                                                                                                             'منتظرة: '
                                                                                                                                                                                                                                                                                                                                                                                                                                             '{queued}\n'
                                                                                                                                                                                                                                                                                                                                                                                                                                             '\n'
                                                                                                                                                                                                                                                                                                                                                                                                                                             'آخر '
                                                                                                                                                                                                                                                                                                                                                                                                                                             '24 '
                                                                                                                                                                                                                                                                                                                                                                                                                                             'ساعة\n'
                                                                                                                                                                                                                                                                                                                                                                                                                                             'الطلبات: '
                                                                                                                                                                                                                                                                                                                                                                                                                                             '{recent_requests}\n'
                                                                                                                                                                                                                                                                                                                                                                                                                                             'أصحاب '
                                                                                                                                                                                                                                                                                                                                                                                                                                             'الطلبات: '
                                                                                                                                                                                                                                                                                                                                                                                                                                             '{recent_users}',
        'Could not read bot statistics, please try again later': 'تعذر قراءة إحصائيات البوت، حاول مرة أخرى '
                                                                 'لاحقاً',
        'Send audio, video, a voice message, or a direct media link': 'أرسل ملفًا صوتيًا أو فيديو أو رسالة '
                                                                      'صوتية أو رابطًا مباشرًا للوسائط',
        'Whisper model': 'نموذج Whisper',
        'Speech language': 'لغة الكلام',
        'Automatic detection': 'اكتشاف تلقائي',
        'Task': 'المهمة',
        'Transcribe': 'تفريغ النص',
        'Translate to English': 'ترجمة إلى الإنجليزية',
        'Word timestamps': 'توقيت الكلمات',
        'Use cached results': 'استخدام النتائج المخزنة',
        'Transcript preview': 'معاينة النص',
        'Transcript files': 'ملفات التفريغ',
        'Preparing audio...': 'جارٍ تجهيز الصوت...',
        'Loading Whisper...': 'جارٍ تحميل Whisper...',
        'Transcribing...': 'جارٍ تفريغ النص...',
        'Waiting for transcription...': 'بانتظار تفريغ النص...',
        'Download {format}': 'تنزيل {format}',
        'Your queue is full, up to 4 active and 4 waiting requests are allowed': 'قائمة الانتظار ممتلئة، '
                                                                                 'يُسمح بـ4 طلبات نشطة و4 '
                                                                                 'طلبات انتظار',
        'This button belongs to the original requester': 'هذا الزر مخصص لصاحب الطلب الأصلي',
        'This result has expired, send the media again': 'انتهت صلاحية النتيجة، أرسل الوسائط مجددًا',
        'No speech was detected': 'لم يُكتشف أي كلام'},
 'ru': {'Downloading...': 'Скачивание...',
        'Uploading...': 'Загрузка...',
        'The bot is restarting, please send your links again shortly': 'Бот перезапускается, отправьте '
                                                                       'ссылки снова чуть позже',
        'Only the bot owner can use this command': 'Эта команда доступна только владельцу бота',
        'No active or queued requests': 'Нет активных запросов или запросов в очереди',
        'Use /cancel followed by one of your job numbers': 'Используйте /cancel с номером своего запроса',
        'This request has already ended': 'Этот запрос уже завершён',
        'Cancelled, any upload already accepted by Telegram may still arrive': 'Отменено, файлы, уже '
                                                                               'принятые Telegram, могут ещё '
                                                                               'поступить',
        'The bot is already stopping': 'Бот уже останавливается',
        'Saving progress and stopping': 'Сохранение прогресса и остановка',
        'Saving progress and starting a fresh session': 'Сохранение прогресса и запуск нового сеанса',
        'Telegram did not confirm delivery, check the chat before sending the link again': 'Telegram не '
                                                                                           'подтвердил '
                                                                                           'доставку, '
                                                                                           'проверьте чат '
                                                                                           'перед повторной '
                                                                                           'отправкой ссылки',
        'The previous upload was interrupted, check the chat before sending the link again': 'Предыдущая '
                                                                                             'загрузка '
                                                                                             'прервана, '
                                                                                             'проверьте чат '
                                                                                             'перед '
                                                                                             'повторной '
                                                                                             'отправкой '
                                                                                             'ссылки',
        'Queued, position {n}': 'В очереди, позиция {n}',
        'Your Telegram ID is {user}': 'Ваш ID Telegram: {user}',
        'And {n} more': 'И ещё {n}',
        'Job {id}, {status}': 'Запрос {id}, {status}',
        'user {user}': 'пользователь {user}',
        'ready': 'готов',
        'running': 'выполняется',
        'queued': 'в очереди',
        'Settings': 'Настройки',
        'Language': 'Язык',
        'Back': 'Назад',
        'On': 'Вкл',
        'Off': 'Выкл',
        'Use /broadcast in our private chat': 'Используйте /broadcast в личном чате со мной',
        'Reply to the announcement message with /broadcast': 'Ответьте на сообщение объявления командой '
                                                             '/broadcast',
        'This message cannot be copied, try a text, photo, video or audio message': 'Не удалось скопировать '
                                                                                    'сообщение, попробуйте '
                                                                                    'текст, фото, видео или '
                                                                                    'аудио',
        'Send': 'Отправить',
        'Cancel': 'Отмена',
        'Send the preview above to {n} chats?': 'Отправить показанное выше сообщение в {n} чатов?',
        'Broadcast queued': 'Объявление добавлено в очередь',
        'Broadcast cancelled': 'Объявление отменено',
        'Broadcast finished\nSent: {sent}\nSkipped or failed: {failed}\nUnconfirmed: {uncertain}': 'Рассылка '
                                                                                                   'завершена\n'
                                                                                                   'Отправлено: '
                                                                                                   '{sent}\n'
                                                                                                   'Пропущено '
                                                                                                   'или '
                                                                                                   'ошибка: '
                                                                                                   '{failed}\n'
                                                                                                   'Не '
                                                                                                   'подтверждено: '
                                                                                                   '{uncertain}',
        'Try this button again in {time} (min:sec)': 'Нажмите эту кнопку снова через {time} (мин:сек)',
        'Off with no button': 'Выключено без кнопки',
        'Reimport the ZIP when restarting?': 'Заново импортировать ZIP при перезапуске?',
        'Restart and reimport ZIP': 'Перезапуск с импортом ZIP',
        'Restart without reimport': 'Перезапуск без импорта',
        'This restart prompt is no longer active, send /restart again': 'Это подтверждение больше не '
                                                                        'активно, отправьте /restart снова',
        'Restart cancelled': 'Перезапуск отменён',
        'Saving progress and restarting with ZIP reimport': 'Сохраняем прогресс и перезапускаем с импортом '
                                                            'ZIP',
        'Preparing backup ZIP...': 'Готовим резервную копию ZIP...',
        'A backup ZIP is already being prepared': 'Резервная копия ZIP уже готовится',
        'The backup ZIP is too large, the maximum size is 50 MB': 'Резервная копия ZIP слишком большая, '
                                                                  'максимум 50 МБ',
        'Backup ZIP sent. Shut down or restart?': 'Резервная копия ZIP отправлена, Выключить или '
                                                  'перезапустить?',
        'Backup ZIP sent to your private chat': 'Резервная копия ZIP отправлена в ваш личный чат',
        'Could not send the backup ZIP, open our private chat and send /start, then try /upload again': 'Не '
                                                                                                        'удалось '
                                                                                                        'отправить '
                                                                                                        'ZIP, '
                                                                                                        'откройте '
                                                                                                        'личный '
                                                                                                        'чат, '
                                                                                                        'отправьте '
                                                                                                        '/start '
                                                                                                        'и '
                                                                                                        'повторите '
                                                                                                        '/upload',
        'This backup menu is no longer active, use /upload again': 'Это меню резервной копии больше не '
                                                                   'активно, используйте /upload снова',
        'Shut down': 'Выключить',
        'Restart': 'Перезапустить',
        'Telegram did not confirm the backup ZIP, check your private chat before using /upload again': 'Telegram '
                                                                                                       'не '
                                                                                                       'подтвердил '
                                                                                                       'ZIP, '
                                                                                                       'проверьте '
                                                                                                       'личный '
                                                                                                       'чат '
                                                                                                       'перед '
                                                                                                       'повторным '
                                                                                                       '/upload',
        'Could not read system specifications, please try again later': 'Не удалось получить характеристики '
                                                                        'системы, попробуйте позже',
        'Could not read dependency versions, please try again later': 'Не удалось получить версии '
                                                                      'зависимостей, попробуйте позже',
        'Metadata': 'Метаданные',
        'Metadata format': 'Формат метаданных',
        'Bot statistics\nSession uptime: {days}d {hours}h {minutes}m {seconds}s\nRecorded users: {users}\nRecorded chats: {chats}\nActive chat records: {active_chats}\n\nSaved requests: {total}\nCompleted: {done}\nFailed: {failed}\nCancelled: {cancelled}\nUnconfirmed: {uncertain}\n\nCurrent queue\nRunning: {running}\nReady: {ready}\nWaiting: {queued}\n\nLast 24 hours\nRequests: {recent_requests}\nRequesters: {recent_users}': 'Статистика '
                                                                                                                                                                                                                                                                                                                                                                                                                                             'бота\n'
                                                                                                                                                                                                                                                                                                                                                                                                                                             'Время '
                                                                                                                                                                                                                                                                                                                                                                                                                                             'сеанса: '
                                                                                                                                                                                                                                                                                                                                                                                                                                             '{days}d '
                                                                                                                                                                                                                                                                                                                                                                                                                                             '{hours}h '
                                                                                                                                                                                                                                                                                                                                                                                                                                             '{minutes}m '
                                                                                                                                                                                                                                                                                                                                                                                                                                             '{seconds}s\n'
                                                                                                                                                                                                                                                                                                                                                                                                                                             'Сохранённые '
                                                                                                                                                                                                                                                                                                                                                                                                                                             'пользователи: '
                                                                                                                                                                                                                                                                                                                                                                                                                                             '{users}\n'
                                                                                                                                                                                                                                                                                                                                                                                                                                             'Сохранённые '
                                                                                                                                                                                                                                                                                                                                                                                                                                             'чаты: '
                                                                                                                                                                                                                                                                                                                                                                                                                                             '{chats}\n'
                                                                                                                                                                                                                                                                                                                                                                                                                                             'Чаты '
                                                                                                                                                                                                                                                                                                                                                                                                                                             'с '
                                                                                                                                                                                                                                                                                                                                                                                                                                             'активной '
                                                                                                                                                                                                                                                                                                                                                                                                                                             'отметкой: '
                                                                                                                                                                                                                                                                                                                                                                                                                                             '{active_chats}\n'
                                                                                                                                                                                                                                                                                                                                                                                                                                             '\n'
                                                                                                                                                                                                                                                                                                                                                                                                                                             'Сохранённые '
                                                                                                                                                                                                                                                                                                                                                                                                                                             'запросы: '
                                                                                                                                                                                                                                                                                                                                                                                                                                             '{total}\n'
                                                                                                                                                                                                                                                                                                                                                                                                                                             'Завершено: '
                                                                                                                                                                                                                                                                                                                                                                                                                                             '{done}\n'
                                                                                                                                                                                                                                                                                                                                                                                                                                             'Ошибки: '
                                                                                                                                                                                                                                                                                                                                                                                                                                             '{failed}\n'
                                                                                                                                                                                                                                                                                                                                                                                                                                             'Отменено: '
                                                                                                                                                                                                                                                                                                                                                                                                                                             '{cancelled}\n'
                                                                                                                                                                                                                                                                                                                                                                                                                                             'Не '
                                                                                                                                                                                                                                                                                                                                                                                                                                             'подтверждено: '
                                                                                                                                                                                                                                                                                                                                                                                                                                             '{uncertain}\n'
                                                                                                                                                                                                                                                                                                                                                                                                                                             '\n'
                                                                                                                                                                                                                                                                                                                                                                                                                                             'Текущая '
                                                                                                                                                                                                                                                                                                                                                                                                                                             'очередь\n'
                                                                                                                                                                                                                                                                                                                                                                                                                                             'Выполняется: '
                                                                                                                                                                                                                                                                                                                                                                                                                                             '{running}\n'
                                                                                                                                                                                                                                                                                                                                                                                                                                             'Готово '
                                                                                                                                                                                                                                                                                                                                                                                                                                             'к '
                                                                                                                                                                                                                                                                                                                                                                                                                                             'запуску: '
                                                                                                                                                                                                                                                                                                                                                                                                                                             '{ready}\n'
                                                                                                                                                                                                                                                                                                                                                                                                                                             'Ожидает: '
                                                                                                                                                                                                                                                                                                                                                                                                                                             '{queued}\n'
                                                                                                                                                                                                                                                                                                                                                                                                                                             '\n'
                                                                                                                                                                                                                                                                                                                                                                                                                                             'Последние '
                                                                                                                                                                                                                                                                                                                                                                                                                                             '24 '
                                                                                                                                                                                                                                                                                                                                                                                                                                             'часа\n'
                                                                                                                                                                                                                                                                                                                                                                                                                                             'Запросы: '
                                                                                                                                                                                                                                                                                                                                                                                                                                             '{recent_requests}\n'
                                                                                                                                                                                                                                                                                                                                                                                                                                             'Пользователи '
                                                                                                                                                                                                                                                                                                                                                                                                                                             'с '
                                                                                                                                                                                                                                                                                                                                                                                                                                             'запросами: '
                                                                                                                                                                                                                                                                                                                                                                                                                                             '{recent_users}',
        'Could not read bot statistics, please try again later': 'Не удалось прочитать статистику бота, '
                                                                 'попробуйте позже',
        'Send audio, video, a voice message, or a direct media link': 'Отправьте аудио, видео, голосовое '
                                                                      'сообщение или прямую ссылку на файл',
        'Whisper model': 'Модель Whisper',
        'Speech language': 'Язык аудио',
        'Automatic detection': 'Автоопределение',
        'Task': 'Задача',
        'Transcribe': 'Расшифровать',
        'Translate to English': 'Перевести на английский',
        'Word timestamps': 'Время каждого слова',
        'Use cached results': 'Использовать кеш',
        'Transcript preview': 'Предпросмотр текста',
        'Transcript files': 'Файлы расшифровки',
        'Preparing audio...': 'Подготовка аудио...',
        'Loading Whisper...': 'Загрузка Whisper...',
        'Transcribing...': 'Расшифровка...',
        'Waiting for transcription...': 'Ожидание расшифровки...',
        'Download {format}': 'Скачать {format}',
        'Your queue is full, up to 4 active and 4 waiting requests are allowed': 'Очередь заполнена, '
                                                                                 'допускается 4 активных и 4 '
                                                                                 'ожидающих запроса',
        'This button belongs to the original requester': 'Эта кнопка принадлежит автору запроса',
        'This result has expired, send the media again': 'Результат устарел, отправьте файл снова',
        'No speech was detected': 'Речь не обнаружена'},
 'zh': {'Downloading...': '正在下载...',
        'Uploading...': '正在上传...',
        'The bot is restarting, please send your links again shortly': '机器人正在重启，请稍后重新发送链接',
        'Only the bot owner can use this command': '只有机器人所有者可以使用此命令',
        'No active or queued requests': '没有进行中或排队的请求',
        'Use /cancel followed by one of your job numbers': '使用 /cancel 加上你的请求编号',
        'This request has already ended': '此请求已结束',
        'Cancelled, any upload already accepted by Telegram may still arrive': '已取消，Telegram 已接收的上传仍可能送达',
        'The bot is already stopping': '机器人正在停止',
        'Saving progress and stopping': '正在保存进度并停止',
        'Saving progress and starting a fresh session': '正在保存进度并启动新会话',
        'Telegram did not confirm delivery, check the chat before sending the link again': 'Telegram '
                                                                                           '未确认送达，请检查聊天后再发送链接',
        'The previous upload was interrupted, check the chat before sending the link again': '上次上传中断，请检查聊天后再发送链接',
        'Queued, position {n}': '排队中，位置 {n}',
        'Your Telegram ID is {user}': '你的 Telegram ID 是 {user}',
        'And {n} more': '还有 {n} 个',
        'Job {id}, {status}': '请求 {id}，{status}',
        'user {user}': '用户 {user}',
        'ready': '就绪',
        'running': '进行中',
        'queued': '排队中',
        'Settings': '设置',
        'Language': '语言',
        'Back': '返回',
        'On': '开启',
        'Off': '关闭',
        'Use /broadcast in our private chat': '请在与我的私聊中使用 /broadcast',
        'Reply to the announcement message with /broadcast': '回复公告消息并发送 /broadcast',
        'This message cannot be copied, try a text, photo, video or audio message': '无法复制此消息，请尝试文字、照片、视频或音频消息',
        'Send': '发送',
        'Cancel': '取消',
        'Send the preview above to {n} chats?': '将上面的预览发送到 {n} 个聊天？',
        'Broadcast queued': '公告已加入队列',
        'Broadcast cancelled': '公告已取消',
        'Broadcast finished\nSent: {sent}\nSkipped or failed: {failed}\nUnconfirmed: {uncertain}': '群发完成\n'
                                                                                                   '已发送：{sent}\n'
                                                                                                   '跳过或失败：{failed}\n'
                                                                                                   '未确认：{uncertain}',
        'Try this button again in {time} (min:sec)': '请在 {time} (分:秒) 后再次点击此按钮',
        'Off with no button': '关闭且不显示按钮',
        'Reimport the ZIP when restarting?': '重启时重新导入 ZIP？',
        'Restart and reimport ZIP': '重启并重新导入 ZIP',
        'Restart without reimport': '重启，不重新导入',
        'This restart prompt is no longer active, send /restart again': '此重启确认已失效，请重新发送 /restart',
        'Restart cancelled': '已取消重启',
        'Saving progress and restarting with ZIP reimport': '正在保存进度并重启，将重新导入 ZIP',
        'Preparing backup ZIP...': '正在准备备份 ZIP...',
        'A backup ZIP is already being prepared': '备份 ZIP 已在准备中',
        'The backup ZIP is too large, the maximum size is 50 MB': '备份 ZIP 过大，最大为 50 MB',
        'Backup ZIP sent. Shut down or restart?': '备份 ZIP 已发送，关闭还是重启？',
        'Backup ZIP sent to your private chat': '备份 ZIP 已发送到你的私聊',
        'Could not send the backup ZIP, open our private chat and send /start, then try /upload again': '无法发送备份 '
                                                                                                        'ZIP，请打开私聊，发送 '
                                                                                                        '/start，再尝试 '
                                                                                                        '/upload',
        'This backup menu is no longer active, use /upload again': '此备份菜单已失效，请再次使用 /upload',
        'Shut down': '关闭',
        'Restart': '重启',
        'Telegram did not confirm the backup ZIP, check your private chat before using /upload again': 'Telegram '
                                                                                                       '未确认备份 '
                                                                                                       'ZIP，请检查私聊后再使用 '
                                                                                                       '/upload',
        'Could not read system specifications, please try again later': '无法读取系统配置，请稍后重试',
        'Could not read dependency versions, please try again later': '无法读取依赖版本，请稍后重试',
        'Metadata': '元数据',
        'Metadata format': '元数据格式',
        'Bot statistics\nSession uptime: {days}d {hours}h {minutes}m {seconds}s\nRecorded users: {users}\nRecorded chats: {chats}\nActive chat records: {active_chats}\n\nSaved requests: {total}\nCompleted: {done}\nFailed: {failed}\nCancelled: {cancelled}\nUnconfirmed: {uncertain}\n\nCurrent queue\nRunning: {running}\nReady: {ready}\nWaiting: {queued}\n\nLast 24 hours\nRequests: {recent_requests}\nRequesters: {recent_users}': '机器人统计\n'
                                                                                                                                                                                                                                                                                                                                                                                                                                             '本次会话运行时间: '
                                                                                                                                                                                                                                                                                                                                                                                                                                             '{days}d '
                                                                                                                                                                                                                                                                                                                                                                                                                                             '{hours}h '
                                                                                                                                                                                                                                                                                                                                                                                                                                             '{minutes}m '
                                                                                                                                                                                                                                                                                                                                                                                                                                             '{seconds}s\n'
                                                                                                                                                                                                                                                                                                                                                                                                                                             '已记录用户: '
                                                                                                                                                                                                                                                                                                                                                                                                                                             '{users}\n'
                                                                                                                                                                                                                                                                                                                                                                                                                                             '已记录聊天: '
                                                                                                                                                                                                                                                                                                                                                                                                                                             '{chats}\n'
                                                                                                                                                                                                                                                                                                                                                                                                                                             '标记为活跃的聊天: '
                                                                                                                                                                                                                                                                                                                                                                                                                                             '{active_chats}\n'
                                                                                                                                                                                                                                                                                                                                                                                                                                             '\n'
                                                                                                                                                                                                                                                                                                                                                                                                                                             '已保存请求: '
                                                                                                                                                                                                                                                                                                                                                                                                                                             '{total}\n'
                                                                                                                                                                                                                                                                                                                                                                                                                                             '已完成: '
                                                                                                                                                                                                                                                                                                                                                                                                                                             '{done}\n'
                                                                                                                                                                                                                                                                                                                                                                                                                                             '失败: '
                                                                                                                                                                                                                                                                                                                                                                                                                                             '{failed}\n'
                                                                                                                                                                                                                                                                                                                                                                                                                                             '已取消: '
                                                                                                                                                                                                                                                                                                                                                                                                                                             '{cancelled}\n'
                                                                                                                                                                                                                                                                                                                                                                                                                                             '未确认: '
                                                                                                                                                                                                                                                                                                                                                                                                                                             '{uncertain}\n'
                                                                                                                                                                                                                                                                                                                                                                                                                                             '\n'
                                                                                                                                                                                                                                                                                                                                                                                                                                             '当前队列\n'
                                                                                                                                                                                                                                                                                                                                                                                                                                             '处理中: '
                                                                                                                                                                                                                                                                                                                                                                                                                                             '{running}\n'
                                                                                                                                                                                                                                                                                                                                                                                                                                             '准备就绪: '
                                                                                                                                                                                                                                                                                                                                                                                                                                             '{ready}\n'
                                                                                                                                                                                                                                                                                                                                                                                                                                             '等待中: '
                                                                                                                                                                                                                                                                                                                                                                                                                                             '{queued}\n'
                                                                                                                                                                                                                                                                                                                                                                                                                                             '\n'
                                                                                                                                                                                                                                                                                                                                                                                                                                             '最近24小时\n'
                                                                                                                                                                                                                                                                                                                                                                                                                                             '请求数: '
                                                                                                                                                                                                                                                                                                                                                                                                                                             '{recent_requests}\n'
                                                                                                                                                                                                                                                                                                                                                                                                                                             '请求用户数: '
                                                                                                                                                                                                                                                                                                                                                                                                                                             '{recent_users}',
        'Could not read bot statistics, please try again later': '无法读取机器人统计，请稍后重试',
        'Send audio, video, a voice message, or a direct media link': '发送音频、视频、语音消息或媒体直链',
        'Whisper model': 'Whisper 模型',
        'Speech language': '语音语言',
        'Automatic detection': '自动检测',
        'Task': '任务',
        'Transcribe': '转录',
        'Translate to English': '翻译成英语',
        'Word timestamps': '逐词时间戳',
        'Use cached results': '使用缓存结果',
        'Transcript preview': '文本预览',
        'Transcript files': '转录文件',
        'Preparing audio...': '正在准备音频...',
        'Loading Whisper...': '正在加载 Whisper...',
        'Transcribing...': '正在转录...',
        'Waiting for transcription...': '等待转录...',
        'Download {format}': '下载 {format}',
        'Your queue is full, up to 4 active and 4 waiting requests are allowed': '队列已满，最多允许 4 个活动请求和 4 个等待请求',
        'This button belongs to the original requester': '此按钮仅供原请求者使用',
        'This result has expired, send the media again': '结果已过期，请重新发送媒体',
        'No speech was detected': '未检测到语音'},
 'fa': {'Downloading...': 'در حال دانلود...',
        'Uploading...': 'در حال ارسال...',
        'The bot is restarting, please send your links again shortly': 'ربات در حال راه\u200cاندازی مجدد '
                                                                       'است، کمی بعد لینک\u200cها را دوباره '
                                                                       'بفرستید',
        'Only the bot owner can use this command': 'فقط مالک ربات می\u200cتواند از این دستور استفاده کند',
        'No active or queued requests': 'هیچ درخواست فعال یا در صفی وجود ندارد',
        'Use /cancel followed by one of your job numbers': 'پس از /cancel شماره یکی از درخواست\u200cهای خود '
                                                           'را بنویسید',
        'This request has already ended': 'این درخواست قبلاً پایان یافته است',
        'Cancelled, any upload already accepted by Telegram may still arrive': 'لغو شد، فایل\u200cهایی که '
                                                                               'تلگرام قبلاً پذیرفته است '
                                                                               'ممکن است همچنان ارسال شوند',
        'The bot is already stopping': 'ربات در حال توقف است',
        'Saving progress and stopping': 'در حال ذخیره پیشرفت و توقف',
        'Saving progress and starting a fresh session': 'در حال ذخیره پیشرفت و شروع نشست جدید',
        'Telegram did not confirm delivery, check the chat before sending the link again': 'تلگرام ارسال را '
                                                                                           'تأیید نکرد، قبل '
                                                                                           'از فرستادن '
                                                                                           'دوباره لینک، '
                                                                                           'گفتگو را بررسی '
                                                                                           'کنید',
        'The previous upload was interrupted, check the chat before sending the link again': 'ارسال قبلی قطع '
                                                                                             'شد، قبل از '
                                                                                             'فرستادن دوباره '
                                                                                             'لینک، گفتگو را '
                                                                                             'بررسی کنید',
        'Queued, position {n}': 'در صف، جایگاه {n}',
        'Your Telegram ID is {user}': 'شناسه تلگرام شما {user} است',
        'And {n} more': 'و {n} مورد دیگر',
        'Job {id}, {status}': 'درخواست {id}، {status}',
        'user {user}': 'کاربر {user}',
        'ready': 'آماده',
        'running': 'در حال اجرا',
        'queued': 'در صف',
        'Settings': 'تنظیمات',
        'Language': 'زبان',
        'Back': 'بازگشت',
        'On': 'روشن',
        'Off': 'خاموش',
        'Use /broadcast in our private chat': 'در گفتگوی خصوصی با ربات از /broadcast استفاده کنید',
        'Reply to the announcement message with /broadcast': 'با دستور /broadcast به پیام اطلاع\u200cرسانی '
                                                             'پاسخ دهید',
        'This message cannot be copied, try a text, photo, video or audio message': 'این پیام قابل کپی نیست، '
                                                                                    'پیام متنی، عکس، ویدیو '
                                                                                    'یا صدا را امتحان کنید',
        'Send': 'ارسال',
        'Cancel': 'لغو',
        'Send the preview above to {n} chats?': 'پیش\u200cنمایش بالا به {n} گفتگو ارسال شود؟',
        'Broadcast queued': 'پیام همگانی در صف قرار گرفت',
        'Broadcast cancelled': 'ارسال همگانی لغو شد',
        'Broadcast finished\nSent: {sent}\nSkipped or failed: {failed}\nUnconfirmed: {uncertain}': 'ارسال '
                                                                                                   'همگانی '
                                                                                                   'پایان '
                                                                                                   'یافت\n'
                                                                                                   'ارسال\u200cشده: '
                                                                                                   '{sent}\n'
                                                                                                   'ردشده یا '
                                                                                                   'ناموفق: '
                                                                                                   '{failed}\n'
                                                                                                   'تأییدنشده: '
                                                                                                   '{uncertain}',
        'Try this button again in {time} (min:sec)': 'پس از {time} (دقیقه:ثانیه) دوباره این دکمه را بزنید',
        'Off with no button': 'خاموش بدون دکمه',
        'Reimport the ZIP when restarting?': 'هنگام راه\u200cاندازی مجدد فایل ZIP دوباره وارد شود؟',
        'Restart and reimport ZIP': 'راه\u200cاندازی مجدد و ورود دوباره ZIP',
        'Restart without reimport': 'راه\u200cاندازی مجدد بدون ورود دوباره',
        'This restart prompt is no longer active, send /restart again': 'این درخواست راه\u200cاندازی مجدد '
                                                                        'دیگر فعال نیست، /restart را دوباره '
                                                                        'بفرستید',
        'Restart cancelled': 'راه\u200cاندازی مجدد لغو شد',
        'Saving progress and restarting with ZIP reimport': 'ذخیره پیشرفت و راه\u200cاندازی مجدد همراه با '
                                                            'ورود دوباره ZIP',
        'Preparing backup ZIP...': 'در حال آماده\u200cسازی ZIP پشتیبان...',
        'A backup ZIP is already being prepared': 'یک ZIP پشتیبان در حال آماده\u200cسازی است',
        'The backup ZIP is too large, the maximum size is 50 MB': 'ZIP پشتیبان بیش از حد بزرگ است، حداکثر 50 '
                                                                  'مگابایت است',
        'Backup ZIP sent. Shut down or restart?': 'ZIP پشتیبان ارسال شد، خاموش شود یا دوباره راه\u200cاندازی '
                                                  'شود؟',
        'Backup ZIP sent to your private chat': 'ZIP پشتیبان به گفتگوی خصوصی شما ارسال شد',
        'Could not send the backup ZIP, open our private chat and send /start, then try /upload again': 'ارسال '
                                                                                                        'ZIP '
                                                                                                        'پشتیبان '
                                                                                                        'ممکن '
                                                                                                        'نشد، '
                                                                                                        'گفتگوی '
                                                                                                        'خصوصی '
                                                                                                        'را '
                                                                                                        'باز '
                                                                                                        'کنید، '
                                                                                                        '/start '
                                                                                                        'بفرستید '
                                                                                                        'و '
                                                                                                        'سپس '
                                                                                                        '/upload '
                                                                                                        'را '
                                                                                                        'دوباره '
                                                                                                        'امتحان '
                                                                                                        'کنید',
        'This backup menu is no longer active, use /upload again': 'این منوی پشتیبان دیگر فعال نیست، /upload '
                                                                   'را دوباره بفرستید',
        'Shut down': 'خاموش کردن',
        'Restart': 'راه\u200cاندازی مجدد',
        'Telegram did not confirm the backup ZIP, check your private chat before using /upload again': 'تلگرام '
                                                                                                       'ارسال '
                                                                                                       'ZIP '
                                                                                                       'پشتیبان '
                                                                                                       'را '
                                                                                                       'تأیید '
                                                                                                       'نکرد، '
                                                                                                       'پیش '
                                                                                                       'از '
                                                                                                       '/upload '
                                                                                                       'دوباره '
                                                                                                       'گفتگوی '
                                                                                                       'خصوصی '
                                                                                                       'را '
                                                                                                       'بررسی '
                                                                                                       'کنید',
        'Could not read system specifications, please try again later': 'خواندن مشخصات سیستم ممکن نشد، بعداً '
                                                                        'دوباره تلاش کنید',
        'Could not read dependency versions, please try again later': 'خواندن نسخه\u200cهای وابستگی\u200cها '
                                                                      'ممکن نشد، بعداً دوباره تلاش کنید',
        'Metadata': 'فراداده',
        'Metadata format': 'قالب فراداده',
        'Bot statistics\nSession uptime: {days}d {hours}h {minutes}m {seconds}s\nRecorded users: {users}\nRecorded chats: {chats}\nActive chat records: {active_chats}\n\nSaved requests: {total}\nCompleted: {done}\nFailed: {failed}\nCancelled: {cancelled}\nUnconfirmed: {uncertain}\n\nCurrent queue\nRunning: {running}\nReady: {ready}\nWaiting: {queued}\n\nLast 24 hours\nRequests: {recent_requests}\nRequesters: {recent_users}': 'آمار '
                                                                                                                                                                                                                                                                                                                                                                                                                                             'ربات\n'
                                                                                                                                                                                                                                                                                                                                                                                                                                             'مدت '
                                                                                                                                                                                                                                                                                                                                                                                                                                             'نشست: '
                                                                                                                                                                                                                                                                                                                                                                                                                                             '{days}d '
                                                                                                                                                                                                                                                                                                                                                                                                                                             '{hours}h '
                                                                                                                                                                                                                                                                                                                                                                                                                                             '{minutes}m '
                                                                                                                                                                                                                                                                                                                                                                                                                                             '{seconds}s\n'
                                                                                                                                                                                                                                                                                                                                                                                                                                             'کاربران '
                                                                                                                                                                                                                                                                                                                                                                                                                                             'ثبت\u200cشده: '
                                                                                                                                                                                                                                                                                                                                                                                                                                             '{users}\n'
                                                                                                                                                                                                                                                                                                                                                                                                                                             'گفتگوهای '
                                                                                                                                                                                                                                                                                                                                                                                                                                             'ثبت\u200cشده: '
                                                                                                                                                                                                                                                                                                                                                                                                                                             '{chats}\n'
                                                                                                                                                                                                                                                                                                                                                                                                                                             'گفتگوهای '
                                                                                                                                                                                                                                                                                                                                                                                                                                             'ثبت\u200cشده '
                                                                                                                                                                                                                                                                                                                                                                                                                                             'به\u200cعنوان '
                                                                                                                                                                                                                                                                                                                                                                                                                                             'فعال: '
                                                                                                                                                                                                                                                                                                                                                                                                                                             '{active_chats}\n'
                                                                                                                                                                                                                                                                                                                                                                                                                                             '\n'
                                                                                                                                                                                                                                                                                                                                                                                                                                             'درخواست\u200cهای '
                                                                                                                                                                                                                                                                                                                                                                                                                                             'ذخیره\u200cشده: '
                                                                                                                                                                                                                                                                                                                                                                                                                                             '{total}\n'
                                                                                                                                                                                                                                                                                                                                                                                                                                             'تکمیل\u200cشده: '
                                                                                                                                                                                                                                                                                                                                                                                                                                             '{done}\n'
                                                                                                                                                                                                                                                                                                                                                                                                                                             'ناموفق: '
                                                                                                                                                                                                                                                                                                                                                                                                                                             '{failed}\n'
                                                                                                                                                                                                                                                                                                                                                                                                                                             'لغوشده: '
                                                                                                                                                                                                                                                                                                                                                                                                                                             '{cancelled}\n'
                                                                                                                                                                                                                                                                                                                                                                                                                                             'تأییدنشده: '
                                                                                                                                                                                                                                                                                                                                                                                                                                             '{uncertain}\n'
                                                                                                                                                                                                                                                                                                                                                                                                                                             '\n'
                                                                                                                                                                                                                                                                                                                                                                                                                                             'صف '
                                                                                                                                                                                                                                                                                                                                                                                                                                             'کنونی\n'
                                                                                                                                                                                                                                                                                                                                                                                                                                             'در '
                                                                                                                                                                                                                                                                                                                                                                                                                                             'حال '
                                                                                                                                                                                                                                                                                                                                                                                                                                             'اجرا: '
                                                                                                                                                                                                                                                                                                                                                                                                                                             '{running}\n'
                                                                                                                                                                                                                                                                                                                                                                                                                                             'آماده: '
                                                                                                                                                                                                                                                                                                                                                                                                                                             '{ready}\n'
                                                                                                                                                                                                                                                                                                                                                                                                                                             'در '
                                                                                                                                                                                                                                                                                                                                                                                                                                             'انتظار: '
                                                                                                                                                                                                                                                                                                                                                                                                                                             '{queued}\n'
                                                                                                                                                                                                                                                                                                                                                                                                                                             '\n'
                                                                                                                                                                                                                                                                                                                                                                                                                                             '24 '
                                                                                                                                                                                                                                                                                                                                                                                                                                             'ساعت '
                                                                                                                                                                                                                                                                                                                                                                                                                                             'گذشته\n'
                                                                                                                                                                                                                                                                                                                                                                                                                                             'درخواست\u200cها: '
                                                                                                                                                                                                                                                                                                                                                                                                                                             '{recent_requests}\n'
                                                                                                                                                                                                                                                                                                                                                                                                                                             'درخواست\u200cدهندگان: '
                                                                                                                                                                                                                                                                                                                                                                                                                                             '{recent_users}',
        'Could not read bot statistics, please try again later': 'خواندن آمار ربات ممکن نشد، بعداً دوباره '
                                                                 'تلاش کنید',
        'Send audio, video, a voice message, or a direct media link': 'فایل صوتی، ویدیو، پیام صوتی یا پیوند '
                                                                      'مستقیم رسانه بفرستید',
        'Whisper model': 'مدل Whisper',
        'Speech language': 'زبان گفتار',
        'Automatic detection': 'تشخیص خودکار',
        'Task': 'وظیفه',
        'Transcribe': 'رونویسی',
        'Translate to English': 'ترجمه به انگلیسی',
        'Word timestamps': 'زمان هر واژه',
        'Use cached results': 'استفاده از نتایج ذخیره\u200cشده',
        'Transcript preview': 'پیش\u200cنمایش متن',
        'Transcript files': 'فایل\u200cهای رونویسی',
        'Preparing audio...': 'در حال آماده\u200cسازی صدا...',
        'Loading Whisper...': 'در حال بارگذاری Whisper...',
        'Transcribing...': 'در حال رونویسی...',
        'Waiting for transcription...': 'در انتظار رونویسی...',
        'Download {format}': 'دریافت {format}',
        'Your queue is full, up to 4 active and 4 waiting requests are allowed': 'صف پر است، ۴ درخواست فعال '
                                                                                 'و ۴ درخواست در انتظار مجاز '
                                                                                 'است',
        'This button belongs to the original requester': 'این دکمه متعلق به درخواست\u200cکننده اصلی است',
        'This result has expired, send the media again': 'نتیجه منقضی شده، رسانه را دوباره بفرستید',
        'No speech was detected': 'گفتاری شناسایی نشد'},
 'ja': {'Telegram did not confirm the backup ZIP, check your private chat before using /upload again': 'TelegramからバックアップZIPの送信確認がありません、/upload '
                                                                                                       'を再送する前に個人チャットを確認してください',
        'Downloading...': 'ダウンロード中...',
        'Uploading...': 'アップロード中...',
        'The bot is restarting, please send your links again shortly': 'ボットは再起動中です、少し待ってからリンクを送り直してください',
        'Only the bot owner can use this command': 'このコマンドはボットの所有者のみ使用できます',
        'No active or queued requests': '実行中または待機中のリクエストはありません',
        'Use /cancel followed by one of your job numbers': '/cancel の後にリクエスト番号を入力してください',
        'This request has already ended': 'このリクエストはすでに終了しています',
        'Cancelled, any upload already accepted by Telegram may still arrive': 'キャンセルしました、Telegramがすでに受け付けたファイルは届く場合があります',
        'The bot is already stopping': 'ボットはすでに停止処理中です',
        'Saving progress and stopping': '進行状況を保存して停止しています',
        'Saving progress and starting a fresh session': '進行状況を保存して新しいセッションを開始します',
        'Telegram did not confirm delivery, check the chat before sending the link again': 'Telegramから送信確認がありません、リンクを送り直す前にチャットを確認してください',
        'The previous upload was interrupted, check the chat before sending the link again': '前回のアップロードは中断されました、リンクを送り直す前にチャットを確認してください',
        'Queued, position {n}': '待機中、順番は{n}番です',
        'Your Telegram ID is {user}': 'あなたのTelegram IDは{user}です',
        'And {n} more': 'ほか{n}件',
        'Job {id}, {status}': 'リクエスト{id}、{status}',
        'user {user}': 'ユーザー{user}',
        'ready': '準備完了',
        'running': '実行中',
        'queued': '待機中',
        'Settings': '設定',
        'Language': '言語',
        'Back': '戻る',
        'On': 'オン',
        'Off': 'オフ',
        'Use /broadcast in our private chat': '個人チャットで /broadcast を使用してください',
        'Reply to the announcement message with /broadcast': '告知するメッセージに返信して /broadcast を送ってください',
        'This message cannot be copied, try a text, photo, video or audio message': 'このメッセージはコピーできません、テキスト・写真・動画・音源をお試しください',
        'Send': '送信',
        'Cancel': 'キャンセル',
        'Send the preview above to {n} chats?': '上のプレビューを{n}件のチャットに送信しますか？',
        'Broadcast queued': '一斉送信を受け付けました',
        'Broadcast cancelled': '一斉送信をキャンセルしました',
        'Broadcast finished\nSent: {sent}\nSkipped or failed: {failed}\nUnconfirmed: {uncertain}': '一斉送信が終了しました\n'
                                                                                                   '送信済み: '
                                                                                                   '{sent}\n'
                                                                                                   'スキップ・失敗: '
                                                                                                   '{failed}\n'
                                                                                                   '未確認: '
                                                                                                   '{uncertain}',
        'Try this button again in {time} (min:sec)': '{time}（分:秒）後にもう一度押してください',
        'Off with no button': 'オフ（ボタンなし）',
        'Reimport the ZIP when restarting?': '再起動時にZIPを再取り込みしますか？',
        'Restart and reimport ZIP': '再起動してZIPを再取り込み',
        'Restart without reimport': '再取り込みせず再起動',
        'This restart prompt is no longer active, send /restart again': 'この再起動確認は無効です、/restart を送り直してください',
        'Restart cancelled': '再起動をキャンセルしました',
        'Saving progress and restarting with ZIP reimport': '進行状況を保存して再起動し、ZIPを再取り込みします',
        'Preparing backup ZIP...': 'バックアップZIPを作成中...',
        'A backup ZIP is already being prepared': 'バックアップZIPはすでに作成中です',
        'The backup ZIP is too large, the maximum size is 50 MB': 'バックアップZIPが大きすぎます、上限は50 MBです',
        'Backup ZIP sent. Shut down or restart?': 'バックアップZIPを送信しました、停止しますか、再起動しますか？',
        'Backup ZIP sent to your private chat': '個人チャットにバックアップZIPを送信しました',
        'Could not send the backup ZIP, open our private chat and send /start, then try /upload again': 'バックアップZIPを送信できませんでした、個人チャットで '
                                                                                                        '/start '
                                                                                                        'を送信し、/upload '
                                                                                                        'をもう一度お試しください',
        'This backup menu is no longer active, use /upload again': 'このバックアップメニューは無効です、/upload を送り直してください',
        'Shut down': '停止',
        'Restart': '再起動',
        'Could not read system specifications, please try again later': 'システム情報を取得できませんでした、後でもう一度お試しください',
        'Could not read dependency versions, please try again later': '依存関係のバージョンを取得できませんでした、後でもう一度お試しください',
        'Metadata': 'メタデータ',
        'Metadata format': 'メタデータ形式',
        'Bot statistics\nSession uptime: {days}d {hours}h {minutes}m {seconds}s\nRecorded users: {users}\nRecorded chats: {chats}\nActive chat records: {active_chats}\n\nSaved requests: {total}\nCompleted: {done}\nFailed: {failed}\nCancelled: {cancelled}\nUnconfirmed: {uncertain}\n\nCurrent queue\nRunning: {running}\nReady: {ready}\nWaiting: {queued}\n\nLast 24 hours\nRequests: {recent_requests}\nRequesters: {recent_users}': 'ボットの統計\n'
                                                                                                                                                                                                                                                                                                                                                                                                                                             'セッション稼働時間: '
                                                                                                                                                                                                                                                                                                                                                                                                                                             '{days}d '
                                                                                                                                                                                                                                                                                                                                                                                                                                             '{hours}h '
                                                                                                                                                                                                                                                                                                                                                                                                                                             '{minutes}m '
                                                                                                                                                                                                                                                                                                                                                                                                                                             '{seconds}s\n'
                                                                                                                                                                                                                                                                                                                                                                                                                                             '記録済みユーザー: '
                                                                                                                                                                                                                                                                                                                                                                                                                                             '{users}\n'
                                                                                                                                                                                                                                                                                                                                                                                                                                             '記録済みチャット: '
                                                                                                                                                                                                                                                                                                                                                                                                                                             '{chats}\n'
                                                                                                                                                                                                                                                                                                                                                                                                                                             '有効として記録されたチャット: '
                                                                                                                                                                                                                                                                                                                                                                                                                                             '{active_chats}\n'
                                                                                                                                                                                                                                                                                                                                                                                                                                             '\n'
                                                                                                                                                                                                                                                                                                                                                                                                                                             '保存済みリクエスト: '
                                                                                                                                                                                                                                                                                                                                                                                                                                             '{total}\n'
                                                                                                                                                                                                                                                                                                                                                                                                                                             '完了: '
                                                                                                                                                                                                                                                                                                                                                                                                                                             '{done}\n'
                                                                                                                                                                                                                                                                                                                                                                                                                                             '失敗: '
                                                                                                                                                                                                                                                                                                                                                                                                                                             '{failed}\n'
                                                                                                                                                                                                                                                                                                                                                                                                                                             'キャンセル済み: '
                                                                                                                                                                                                                                                                                                                                                                                                                                             '{cancelled}\n'
                                                                                                                                                                                                                                                                                                                                                                                                                                             '未確認: '
                                                                                                                                                                                                                                                                                                                                                                                                                                             '{uncertain}\n'
                                                                                                                                                                                                                                                                                                                                                                                                                                             '\n'
                                                                                                                                                                                                                                                                                                                                                                                                                                             '現在のキュー\n'
                                                                                                                                                                                                                                                                                                                                                                                                                                             '実行中: '
                                                                                                                                                                                                                                                                                                                                                                                                                                             '{running}\n'
                                                                                                                                                                                                                                                                                                                                                                                                                                             '実行準備完了: '
                                                                                                                                                                                                                                                                                                                                                                                                                                             '{ready}\n'
                                                                                                                                                                                                                                                                                                                                                                                                                                             '待機中: '
                                                                                                                                                                                                                                                                                                                                                                                                                                             '{queued}\n'
                                                                                                                                                                                                                                                                                                                                                                                                                                             '\n'
                                                                                                                                                                                                                                                                                                                                                                                                                                             '過去24時間\n'
                                                                                                                                                                                                                                                                                                                                                                                                                                             'リクエスト数: '
                                                                                                                                                                                                                                                                                                                                                                                                                                             '{recent_requests}\n'
                                                                                                                                                                                                                                                                                                                                                                                                                                             'リクエストしたユーザー数: '
                                                                                                                                                                                                                                                                                                                                                                                                                                             '{recent_users}',
        'Could not read bot statistics, please try again later': 'ボットの統計を取得できませんでした、後でもう一度お試しください',
        'Send audio, video, a voice message, or a direct media link': '音声、動画、ボイスメッセージ、またはメディアの直接リンクを送信してください',
        'Whisper model': 'Whisperモデル',
        'Speech language': '音声の言語',
        'Automatic detection': '自動検出',
        'Task': 'タスク',
        'Transcribe': '文字起こし',
        'Translate to English': '英語に翻訳',
        'Word timestamps': '単語のタイムスタンプ',
        'Use cached results': 'キャッシュを使う',
        'Transcript preview': 'テキストのプレビュー',
        'Transcript files': '文字起こしファイル',
        'Preparing audio...': '音声を準備中...',
        'Loading Whisper...': 'Whisperを読み込み中...',
        'Transcribing...': '文字起こし中...',
        'Waiting for transcription...': '文字起こしの待機中...',
        'Download {format}': '{format}をダウンロード',
        'Your queue is full, up to 4 active and 4 waiting requests are allowed': 'キューが満杯です、実行中4件と待機中4件までです',
        'This button belongs to the original requester': 'このボタンは元の依頼者専用です',
        'This result has expired, send the media again': '結果の有効期限が切れました、メディアを再送信してください',
        'No speech was detected': '音声が検出されませんでした'},
 'pt': {'Telegram did not confirm the backup ZIP, check your private chat before using /upload again': 'O '
                                                                                                       'Telegram '
                                                                                                       'não '
                                                                                                       'confirmou '
                                                                                                       'o '
                                                                                                       'ZIP '
                                                                                                       'de '
                                                                                                       'backup, '
                                                                                                       'confira '
                                                                                                       'seu '
                                                                                                       'chat '
                                                                                                       'privado '
                                                                                                       'antes '
                                                                                                       'de '
                                                                                                       'usar '
                                                                                                       '/upload '
                                                                                                       'novamente',
        'Downloading...': 'Baixando...',
        'Uploading...': 'Enviando...',
        'The bot is restarting, please send your links again shortly': 'O bot está reiniciando, envie seus '
                                                                       'links novamente em instantes',
        'Only the bot owner can use this command': 'Só o proprietário do bot pode usar este comando',
        'No active or queued requests': 'Nenhum pedido ativo ou na fila',
        'Use /cancel followed by one of your job numbers': 'Use /cancel seguido do número de um dos seus '
                                                           'pedidos',
        'This request has already ended': 'Este pedido já terminou',
        'Cancelled, any upload already accepted by Telegram may still arrive': 'Cancelado, arquivos já '
                                                                               'aceitos pelo Telegram ainda '
                                                                               'podem chegar',
        'The bot is already stopping': 'O bot já está parando',
        'Saving progress and stopping': 'Salvando o progresso e parando',
        'Saving progress and starting a fresh session': 'Salvando o progresso e iniciando uma nova sessão',
        'Telegram did not confirm delivery, check the chat before sending the link again': 'O Telegram não '
                                                                                           'confirmou o '
                                                                                           'envio, confira o '
                                                                                           'chat antes de '
                                                                                           'reenviar o link',
        'The previous upload was interrupted, check the chat before sending the link again': 'O envio '
                                                                                             'anterior foi '
                                                                                             'interrompido, '
                                                                                             'confira o chat '
                                                                                             'antes de '
                                                                                             'reenviar o '
                                                                                             'link',
        'Queued, position {n}': 'Na fila, posição {n}',
        'Your Telegram ID is {user}': 'Seu ID do Telegram é {user}',
        'And {n} more': 'E mais {n}',
        'Job {id}, {status}': 'Pedido {id}, {status}',
        'user {user}': 'usuário {user}',
        'ready': 'pronto',
        'running': 'em andamento',
        'queued': 'na fila',
        'Settings': 'Configurações',
        'Language': 'Idioma',
        'Back': 'Voltar',
        'On': 'Ativado',
        'Off': 'Desativado',
        'Use /broadcast in our private chat': 'Use /broadcast no nosso chat privado',
        'Reply to the announcement message with /broadcast': 'Responda à mensagem do anúncio com /broadcast',
        'This message cannot be copied, try a text, photo, video or audio message': 'Esta mensagem não pode '
                                                                                    'ser copiada, tente '
                                                                                    'texto, foto, vídeo ou '
                                                                                    'áudio',
        'Send': 'Enviar',
        'Cancel': 'Cancelar',
        'Send the preview above to {n} chats?': 'Enviar a prévia acima para {n} chats?',
        'Broadcast queued': 'Anúncio na fila',
        'Broadcast cancelled': 'Anúncio cancelado',
        'Broadcast finished\nSent: {sent}\nSkipped or failed: {failed}\nUnconfirmed: {uncertain}': 'Anúncio '
                                                                                                   'concluído\n'
                                                                                                   'Enviados: '
                                                                                                   '{sent}\n'
                                                                                                   'Ignorados '
                                                                                                   'ou '
                                                                                                   'falhos: '
                                                                                                   '{failed}\n'
                                                                                                   'Não '
                                                                                                   'confirmados: '
                                                                                                   '{uncertain}',
        'Try this button again in {time} (min:sec)': 'Tente este botão novamente em {time} (min:seg)',
        'Off with no button': 'Desativado sem botão',
        'Reimport the ZIP when restarting?': 'Importar o ZIP novamente ao reiniciar?',
        'Restart and reimport ZIP': 'Reiniciar e reimportar ZIP',
        'Restart without reimport': 'Reiniciar sem reimportar',
        'This restart prompt is no longer active, send /restart again': 'Esta confirmação não está mais '
                                                                        'ativa, envie /restart novamente',
        'Restart cancelled': 'Reinício cancelado',
        'Saving progress and restarting with ZIP reimport': 'Salvando o progresso e reiniciando com '
                                                            'reimportação do ZIP',
        'Preparing backup ZIP...': 'Preparando ZIP de backup...',
        'A backup ZIP is already being prepared': 'Um ZIP de backup já está sendo preparado',
        'The backup ZIP is too large, the maximum size is 50 MB': 'O ZIP de backup é grande demais, o limite '
                                                                  'é 50 MB',
        'Backup ZIP sent. Shut down or restart?': 'ZIP de backup enviado, Desligar ou reiniciar?',
        'Backup ZIP sent to your private chat': 'ZIP de backup enviado ao seu chat privado',
        'Could not send the backup ZIP, open our private chat and send /start, then try /upload again': 'Não '
                                                                                                        'foi '
                                                                                                        'possível '
                                                                                                        'enviar '
                                                                                                        'o '
                                                                                                        'ZIP '
                                                                                                        'de '
                                                                                                        'backup, '
                                                                                                        'abra '
                                                                                                        'nosso '
                                                                                                        'chat '
                                                                                                        'privado, '
                                                                                                        'envie '
                                                                                                        '/start '
                                                                                                        'e '
                                                                                                        'tente '
                                                                                                        '/upload '
                                                                                                        'novamente',
        'This backup menu is no longer active, use /upload again': 'Este menu de backup não está mais ativo, '
                                                                   'use /upload novamente',
        'Shut down': 'Desligar',
        'Restart': 'Reiniciar',
        'Could not read system specifications, please try again later': 'Não foi possível obter as '
                                                                        'especificações do sistema, tente '
                                                                        'novamente mais tarde',
        'Could not read dependency versions, please try again later': 'Não foi possível obter as versões das '
                                                                      'dependências, tente novamente mais '
                                                                      'tarde',
        'Metadata': 'Metadados',
        'Metadata format': 'Formato dos metadados',
        'Bot statistics\nSession uptime: {days}d {hours}h {minutes}m {seconds}s\nRecorded users: {users}\nRecorded chats: {chats}\nActive chat records: {active_chats}\n\nSaved requests: {total}\nCompleted: {done}\nFailed: {failed}\nCancelled: {cancelled}\nUnconfirmed: {uncertain}\n\nCurrent queue\nRunning: {running}\nReady: {ready}\nWaiting: {queued}\n\nLast 24 hours\nRequests: {recent_requests}\nRequesters: {recent_users}': 'Estatísticas '
                                                                                                                                                                                                                                                                                                                                                                                                                                             'do '
                                                                                                                                                                                                                                                                                                                                                                                                                                             'bot\n'
                                                                                                                                                                                                                                                                                                                                                                                                                                             'Tempo '
                                                                                                                                                                                                                                                                                                                                                                                                                                             'da '
                                                                                                                                                                                                                                                                                                                                                                                                                                             'sessão: '
                                                                                                                                                                                                                                                                                                                                                                                                                                             '{days}d '
                                                                                                                                                                                                                                                                                                                                                                                                                                             '{hours}h '
                                                                                                                                                                                                                                                                                                                                                                                                                                             '{minutes}m '
                                                                                                                                                                                                                                                                                                                                                                                                                                             '{seconds}s\n'
                                                                                                                                                                                                                                                                                                                                                                                                                                             'Utilizadores '
                                                                                                                                                                                                                                                                                                                                                                                                                                             'registados: '
                                                                                                                                                                                                                                                                                                                                                                                                                                             '{users}\n'
                                                                                                                                                                                                                                                                                                                                                                                                                                             'Conversas '
                                                                                                                                                                                                                                                                                                                                                                                                                                             'registadas: '
                                                                                                                                                                                                                                                                                                                                                                                                                                             '{chats}\n'
                                                                                                                                                                                                                                                                                                                                                                                                                                             'Conversas '
                                                                                                                                                                                                                                                                                                                                                                                                                                             'marcadas '
                                                                                                                                                                                                                                                                                                                                                                                                                                             'como '
                                                                                                                                                                                                                                                                                                                                                                                                                                             'ativas: '
                                                                                                                                                                                                                                                                                                                                                                                                                                             '{active_chats}\n'
                                                                                                                                                                                                                                                                                                                                                                                                                                             '\n'
                                                                                                                                                                                                                                                                                                                                                                                                                                             'Pedidos '
                                                                                                                                                                                                                                                                                                                                                                                                                                             'guardados: '
                                                                                                                                                                                                                                                                                                                                                                                                                                             '{total}\n'
                                                                                                                                                                                                                                                                                                                                                                                                                                             'Concluídos: '
                                                                                                                                                                                                                                                                                                                                                                                                                                             '{done}\n'
                                                                                                                                                                                                                                                                                                                                                                                                                                             'Falhados: '
                                                                                                                                                                                                                                                                                                                                                                                                                                             '{failed}\n'
                                                                                                                                                                                                                                                                                                                                                                                                                                             'Cancelados: '
                                                                                                                                                                                                                                                                                                                                                                                                                                             '{cancelled}\n'
                                                                                                                                                                                                                                                                                                                                                                                                                                             'Não '
                                                                                                                                                                                                                                                                                                                                                                                                                                             'confirmados: '
                                                                                                                                                                                                                                                                                                                                                                                                                                             '{uncertain}\n'
                                                                                                                                                                                                                                                                                                                                                                                                                                             '\n'
                                                                                                                                                                                                                                                                                                                                                                                                                                             'Fila '
                                                                                                                                                                                                                                                                                                                                                                                                                                             'atual\n'
                                                                                                                                                                                                                                                                                                                                                                                                                                             'Em '
                                                                                                                                                                                                                                                                                                                                                                                                                                             'execução: '
                                                                                                                                                                                                                                                                                                                                                                                                                                             '{running}\n'
                                                                                                                                                                                                                                                                                                                                                                                                                                             'Prontos: '
                                                                                                                                                                                                                                                                                                                                                                                                                                             '{ready}\n'
                                                                                                                                                                                                                                                                                                                                                                                                                                             'Em '
                                                                                                                                                                                                                                                                                                                                                                                                                                             'espera: '
                                                                                                                                                                                                                                                                                                                                                                                                                                             '{queued}\n'
                                                                                                                                                                                                                                                                                                                                                                                                                                             '\n'
                                                                                                                                                                                                                                                                                                                                                                                                                                             'Últimas '
                                                                                                                                                                                                                                                                                                                                                                                                                                             '24 '
                                                                                                                                                                                                                                                                                                                                                                                                                                             'horas\n'
                                                                                                                                                                                                                                                                                                                                                                                                                                             'Pedidos: '
                                                                                                                                                                                                                                                                                                                                                                                                                                             '{recent_requests}\n'
                                                                                                                                                                                                                                                                                                                                                                                                                                             'Utilizadores '
                                                                                                                                                                                                                                                                                                                                                                                                                                             'com '
                                                                                                                                                                                                                                                                                                                                                                                                                                             'pedidos: '
                                                                                                                                                                                                                                                                                                                                                                                                                                             '{recent_users}',
        'Could not read bot statistics, please try again later': 'Não foi possível ler as estatísticas do '
                                                                 'bot, tente novamente mais tarde',
        'Send audio, video, a voice message, or a direct media link': 'Envie áudio, vídeo, uma mensagem de '
                                                                      'voz ou um link direto de mídia',
        'Whisper model': 'Modelo Whisper',
        'Speech language': 'Idioma da fala',
        'Automatic detection': 'Detecção automática',
        'Task': 'Tarefa',
        'Transcribe': 'Transcrever',
        'Translate to English': 'Traduzir para inglês',
        'Word timestamps': 'Tempos por palavra',
        'Use cached results': 'Usar resultados em cache',
        'Transcript preview': 'Prévia do texto',
        'Transcript files': 'Arquivos de transcrição',
        'Preparing audio...': 'Preparando áudio...',
        'Loading Whisper...': 'Carregando Whisper...',
        'Transcribing...': 'Transcrevendo...',
        'Waiting for transcription...': 'Aguardando transcrição...',
        'Download {format}': 'Baixar {format}',
        'Your queue is full, up to 4 active and 4 waiting requests are allowed': 'Sua fila está cheia, são '
                                                                                 'permitidos 4 pedidos '
                                                                                 'ativos e 4 em espera',
        'This button belongs to the original requester': 'Este botão pertence ao solicitante original',
        'This result has expired, send the media again': 'O resultado expirou, envie a mídia novamente',
        'No speech was detected': 'Nenhuma fala detectada'},
 'fr': {'Telegram did not confirm the backup ZIP, check your private chat before using /upload again': 'Telegram '
                                                                                                       'n’a '
                                                                                                       'pas '
                                                                                                       'confirmé '
                                                                                                       'le '
                                                                                                       'ZIP '
                                                                                                       'de '
                                                                                                       'sauvegarde, '
                                                                                                       'vérifiez '
                                                                                                       'votre '
                                                                                                       'discussion '
                                                                                                       'privée '
                                                                                                       'avant '
                                                                                                       'de '
                                                                                                       'réutiliser '
                                                                                                       '/upload',
        'Downloading...': 'Téléchargement...',
        'Uploading...': 'Envoi...',
        'The bot is restarting, please send your links again shortly': 'Le bot redémarre, renvoyez vos liens '
                                                                       'dans un instant',
        'Only the bot owner can use this command': 'Seul le propriétaire du bot peut utiliser cette commande',
        'No active or queued requests': 'Aucune demande active ou en attente',
        'Use /cancel followed by one of your job numbers': 'Utilisez /cancel suivi du numéro de votre '
                                                           'demande',
        'This request has already ended': 'Cette demande est déjà terminée',
        'Cancelled, any upload already accepted by Telegram may still arrive': 'Annulé, les fichiers déjà '
                                                                               'acceptés par Telegram '
                                                                               'peuvent encore arriver',
        'The bot is already stopping': 'Le bot est déjà en cours d’arrêt',
        'Saving progress and stopping': 'Enregistrement de la progression et arrêt',
        'Saving progress and starting a fresh session': 'Enregistrement de la progression et démarrage d’une '
                                                        'nouvelle session',
        'Telegram did not confirm delivery, check the chat before sending the link again': 'Telegram n’a pas '
                                                                                           'confirmé '
                                                                                           'l’envoi, '
                                                                                           'vérifiez la '
                                                                                           'discussion avant '
                                                                                           'de renvoyer le '
                                                                                           'lien',
        'The previous upload was interrupted, check the chat before sending the link again': 'L’envoi '
                                                                                             'précédent a '
                                                                                             'été '
                                                                                             'interrompu, '
                                                                                             'vérifiez la '
                                                                                             'discussion '
                                                                                             'avant de '
                                                                                             'renvoyer le '
                                                                                             'lien',
        'Queued, position {n}': 'En attente, position {n}',
        'Your Telegram ID is {user}': 'Votre identifiant Telegram est {user}',
        'And {n} more': 'Et {n} autres',
        'Job {id}, {status}': 'Demande {id}, {status}',
        'user {user}': 'utilisateur {user}',
        'ready': 'prêt',
        'running': 'en cours',
        'queued': 'en attente',
        'Settings': 'Paramètres',
        'Language': 'Langue',
        'Back': 'Retour',
        'On': 'Activé',
        'Off': 'Désactivé',
        'Use /broadcast in our private chat': 'Utilisez /broadcast dans notre discussion privée',
        'Reply to the announcement message with /broadcast': 'Répondez au message à annoncer avec /broadcast',
        'This message cannot be copied, try a text, photo, video or audio message': 'Ce message ne peut pas '
                                                                                    'être copié, essayez un '
                                                                                    'texte, une photo, une '
                                                                                    'vidéo ou un son',
        'Send': 'Envoyer',
        'Cancel': 'Annuler',
        'Send the preview above to {n} chats?': 'Envoyer l’aperçu ci-dessus à {n} discussions ?',
        'Broadcast queued': 'Annonce mise en attente',
        'Broadcast cancelled': 'Annonce annulée',
        'Broadcast finished\nSent: {sent}\nSkipped or failed: {failed}\nUnconfirmed: {uncertain}': 'Annonce '
                                                                                                   'terminée\n'
                                                                                                   'Envoyés '
                                                                                                   ': '
                                                                                                   '{sent}\n'
                                                                                                   'Ignorés '
                                                                                                   'ou '
                                                                                                   'échoués '
                                                                                                   ': '
                                                                                                   '{failed}\n'
                                                                                                   'Non '
                                                                                                   'confirmés '
                                                                                                   ': '
                                                                                                   '{uncertain}',
        'Try this button again in {time} (min:sec)': 'Réessayez ce bouton dans {time} (min:s)',
        'Off with no button': 'Désactivé sans bouton',
        'Reimport the ZIP when restarting?': 'Réimporter le ZIP lors du redémarrage ?',
        'Restart and reimport ZIP': 'Redémarrer et réimporter le ZIP',
        'Restart without reimport': 'Redémarrer sans réimporter',
        'This restart prompt is no longer active, send /restart again': 'Cette confirmation n’est plus '
                                                                        'active, renvoyez /restart',
        'Restart cancelled': 'Redémarrage annulé',
        'Saving progress and restarting with ZIP reimport': 'Enregistrement de la progression et redémarrage '
                                                            'avec réimportation du ZIP',
        'Preparing backup ZIP...': 'Préparation du ZIP de sauvegarde...',
        'A backup ZIP is already being prepared': 'Un ZIP de sauvegarde est déjà en préparation',
        'The backup ZIP is too large, the maximum size is 50 MB': 'Le ZIP de sauvegarde est trop volumineux, '
                                                                  'la limite est de 50 MB',
        'Backup ZIP sent. Shut down or restart?': 'ZIP de sauvegarde envoyé, Arrêter ou redémarrer ?',
        'Backup ZIP sent to your private chat': 'ZIP de sauvegarde envoyé dans votre discussion privée',
        'Could not send the backup ZIP, open our private chat and send /start, then try /upload again': 'Impossible '
                                                                                                        'd’envoyer '
                                                                                                        'le '
                                                                                                        'ZIP '
                                                                                                        'de '
                                                                                                        'sauvegarde, '
                                                                                                        'ouvrez '
                                                                                                        'notre '
                                                                                                        'discussion '
                                                                                                        'privée, '
                                                                                                        'envoyez '
                                                                                                        '/start '
                                                                                                        'puis '
                                                                                                        'réessayez '
                                                                                                        '/upload',
        'This backup menu is no longer active, use /upload again': 'Ce menu de sauvegarde n’est plus actif, '
                                                                   'utilisez /upload à nouveau',
        'Shut down': 'Arrêter',
        'Restart': 'Redémarrer',
        'Could not read system specifications, please try again later': 'Impossible de lire les '
                                                                        'caractéristiques du système, '
                                                                        'réessayez plus tard',
        'Could not read dependency versions, please try again later': 'Impossible de lire les versions des '
                                                                      'dépendances, réessayez plus tard',
        'Metadata': 'Métadonnées',
        'Metadata format': 'Format des métadonnées',
        'Bot statistics\nSession uptime: {days}d {hours}h {minutes}m {seconds}s\nRecorded users: {users}\nRecorded chats: {chats}\nActive chat records: {active_chats}\n\nSaved requests: {total}\nCompleted: {done}\nFailed: {failed}\nCancelled: {cancelled}\nUnconfirmed: {uncertain}\n\nCurrent queue\nRunning: {running}\nReady: {ready}\nWaiting: {queued}\n\nLast 24 hours\nRequests: {recent_requests}\nRequesters: {recent_users}': 'Statistiques '
                                                                                                                                                                                                                                                                                                                                                                                                                                             'du '
                                                                                                                                                                                                                                                                                                                                                                                                                                             'bot\n'
                                                                                                                                                                                                                                                                                                                                                                                                                                             'Durée '
                                                                                                                                                                                                                                                                                                                                                                                                                                             'de '
                                                                                                                                                                                                                                                                                                                                                                                                                                             'la '
                                                                                                                                                                                                                                                                                                                                                                                                                                             'session: '
                                                                                                                                                                                                                                                                                                                                                                                                                                             '{days}d '
                                                                                                                                                                                                                                                                                                                                                                                                                                             '{hours}h '
                                                                                                                                                                                                                                                                                                                                                                                                                                             '{minutes}m '
                                                                                                                                                                                                                                                                                                                                                                                                                                             '{seconds}s\n'
                                                                                                                                                                                                                                                                                                                                                                                                                                             'Utilisateurs '
                                                                                                                                                                                                                                                                                                                                                                                                                                             'enregistrés: '
                                                                                                                                                                                                                                                                                                                                                                                                                                             '{users}\n'
                                                                                                                                                                                                                                                                                                                                                                                                                                             'Discussions '
                                                                                                                                                                                                                                                                                                                                                                                                                                             'enregistrées: '
                                                                                                                                                                                                                                                                                                                                                                                                                                             '{chats}\n'
                                                                                                                                                                                                                                                                                                                                                                                                                                             'Discussions '
                                                                                                                                                                                                                                                                                                                                                                                                                                             'marquées '
                                                                                                                                                                                                                                                                                                                                                                                                                                             'actives: '
                                                                                                                                                                                                                                                                                                                                                                                                                                             '{active_chats}\n'
                                                                                                                                                                                                                                                                                                                                                                                                                                             '\n'
                                                                                                                                                                                                                                                                                                                                                                                                                                             'Demandes '
                                                                                                                                                                                                                                                                                                                                                                                                                                             'sauvegardées: '
                                                                                                                                                                                                                                                                                                                                                                                                                                             '{total}\n'
                                                                                                                                                                                                                                                                                                                                                                                                                                             'Terminées: '
                                                                                                                                                                                                                                                                                                                                                                                                                                             '{done}\n'
                                                                                                                                                                                                                                                                                                                                                                                                                                             'Échouées: '
                                                                                                                                                                                                                                                                                                                                                                                                                                             '{failed}\n'
                                                                                                                                                                                                                                                                                                                                                                                                                                             'Annulées: '
                                                                                                                                                                                                                                                                                                                                                                                                                                             '{cancelled}\n'
                                                                                                                                                                                                                                                                                                                                                                                                                                             'Non '
                                                                                                                                                                                                                                                                                                                                                                                                                                             'confirmées: '
                                                                                                                                                                                                                                                                                                                                                                                                                                             '{uncertain}\n'
                                                                                                                                                                                                                                                                                                                                                                                                                                             '\n'
                                                                                                                                                                                                                                                                                                                                                                                                                                             'File '
                                                                                                                                                                                                                                                                                                                                                                                                                                             'actuelle\n'
                                                                                                                                                                                                                                                                                                                                                                                                                                             'En '
                                                                                                                                                                                                                                                                                                                                                                                                                                             'cours: '
                                                                                                                                                                                                                                                                                                                                                                                                                                             '{running}\n'
                                                                                                                                                                                                                                                                                                                                                                                                                                             'Prêtes: '
                                                                                                                                                                                                                                                                                                                                                                                                                                             '{ready}\n'
                                                                                                                                                                                                                                                                                                                                                                                                                                             'En '
                                                                                                                                                                                                                                                                                                                                                                                                                                             'attente: '
                                                                                                                                                                                                                                                                                                                                                                                                                                             '{queued}\n'
                                                                                                                                                                                                                                                                                                                                                                                                                                             '\n'
                                                                                                                                                                                                                                                                                                                                                                                                                                             'Dernières '
                                                                                                                                                                                                                                                                                                                                                                                                                                             '24 '
                                                                                                                                                                                                                                                                                                                                                                                                                                             'heures\n'
                                                                                                                                                                                                                                                                                                                                                                                                                                             'Demandes: '
                                                                                                                                                                                                                                                                                                                                                                                                                                             '{recent_requests}\n'
                                                                                                                                                                                                                                                                                                                                                                                                                                             'Utilisateurs '
                                                                                                                                                                                                                                                                                                                                                                                                                                             'ayant '
                                                                                                                                                                                                                                                                                                                                                                                                                                             'fait '
                                                                                                                                                                                                                                                                                                                                                                                                                                             'une '
                                                                                                                                                                                                                                                                                                                                                                                                                                             'demande: '
                                                                                                                                                                                                                                                                                                                                                                                                                                             '{recent_users}',
        'Could not read bot statistics, please try again later': 'Impossible de lire les statistiques du '
                                                                 'bot, réessayez plus tard',
        'Send audio, video, a voice message, or a direct media link': 'Envoyez un audio, une vidéo, un '
                                                                      'message vocal ou un lien direct vers '
                                                                      'le média',
        'Whisper model': 'Modèle Whisper',
        'Speech language': 'Langue audio',
        'Automatic detection': 'Détection automatique',
        'Task': 'Tâche',
        'Transcribe': 'Transcrire',
        'Translate to English': 'Traduire en anglais',
        'Word timestamps': 'Horodatage des mots',
        'Use cached results': 'Utiliser le cache',
        'Transcript preview': 'Aperçu du texte',
        'Transcript files': 'Fichiers de transcription',
        'Preparing audio...': 'Préparation audio...',
        'Loading Whisper...': 'Chargement de Whisper...',
        'Transcribing...': 'Transcription...',
        'Waiting for transcription...': 'En attente de transcription...',
        'Download {format}': 'Télécharger {format}',
        'Your queue is full, up to 4 active and 4 waiting requests are allowed': 'La file est pleine, 4 '
                                                                                 'demandes actives et 4 en '
                                                                                 'attente sont autorisées',
        'This button belongs to the original requester': 'Ce bouton appartient au demandeur initial',
        'This result has expired, send the media again': 'Le résultat a expiré, renvoyez le média',
        'No speech was detected': 'Aucune parole détectée'},
 'de': {'Telegram did not confirm the backup ZIP, check your private chat before using /upload again': 'Telegram '
                                                                                                       'hat '
                                                                                                       'die '
                                                                                                       'Backup-ZIP '
                                                                                                       'nicht '
                                                                                                       'bestätigt, '
                                                                                                       'Prüfe '
                                                                                                       'deinen '
                                                                                                       'privaten '
                                                                                                       'Chat, '
                                                                                                       'bevor '
                                                                                                       'du '
                                                                                                       '/upload '
                                                                                                       'erneut '
                                                                                                       'verwendest',
        'Downloading...': 'Wird heruntergeladen...',
        'Uploading...': 'Wird hochgeladen...',
        'The bot is restarting, please send your links again shortly': 'Der Bot startet neu, Sende deine '
                                                                       'Links gleich noch einmal',
        'Only the bot owner can use this command': 'Nur der Bot-Besitzer kann diesen Befehl verwenden',
        'No active or queued requests': 'Keine aktiven oder wartenden Anfragen',
        'Use /cancel followed by one of your job numbers': 'Verwende /cancel mit der Nummer einer deiner '
                                                           'Anfragen',
        'This request has already ended': 'Diese Anfrage ist bereits beendet',
        'Cancelled, any upload already accepted by Telegram may still arrive': 'Abgebrochen, Von Telegram '
                                                                               'bereits angenommene Dateien '
                                                                               'können noch ankommen',
        'The bot is already stopping': 'Der Bot wird bereits beendet',
        'Saving progress and stopping': 'Fortschritt wird gespeichert, Bot wird beendet',
        'Saving progress and starting a fresh session': 'Fortschritt wird gespeichert, eine neue Sitzung '
                                                        'wird gestartet',
        'Telegram did not confirm delivery, check the chat before sending the link again': 'Telegram hat die '
                                                                                           'Zustellung nicht '
                                                                                           'bestätigt, Prüfe '
                                                                                           'den Chat, bevor '
                                                                                           'du den Link '
                                                                                           'erneut sendest',
        'The previous upload was interrupted, check the chat before sending the link again': 'Der vorherige '
                                                                                             'Upload wurde '
                                                                                             'unterbrochen, '
                                                                                             'Prüfe den '
                                                                                             'Chat, bevor du '
                                                                                             'den Link '
                                                                                             'erneut sendest',
        'Queued, position {n}': 'In der Warteschlange, Position {n}',
        'Your Telegram ID is {user}': 'Deine Telegram-ID ist {user}',
        'And {n} more': 'Und {n} weitere',
        'Job {id}, {status}': 'Anfrage {id}, {status}',
        'user {user}': 'Benutzer {user}',
        'ready': 'bereit',
        'running': 'läuft',
        'queued': 'in der Warteschlange',
        'Settings': 'Einstellungen',
        'Language': 'Sprache',
        'Back': 'Zurück',
        'On': 'Ein',
        'Off': 'Aus',
        'Use /broadcast in our private chat': 'Verwende /broadcast in unserem privaten Chat',
        'Reply to the announcement message with /broadcast': 'Antworte mit /broadcast auf die Ankündigung',
        'This message cannot be copied, try a text, photo, video or audio message': 'Diese Nachricht kann '
                                                                                    'nicht kopiert werden, '
                                                                                    'Versuche Text, ein '
                                                                                    'Foto, Video oder Audio',
        'Send': 'Senden',
        'Cancel': 'Abbrechen',
        'Send the preview above to {n} chats?': 'Die obige Vorschau an {n} Chats senden?',
        'Broadcast queued': 'Rundsendung eingereiht',
        'Broadcast cancelled': 'Rundsendung abgebrochen',
        'Broadcast finished\nSent: {sent}\nSkipped or failed: {failed}\nUnconfirmed: {uncertain}': 'Rundsendung '
                                                                                                   'abgeschlossen\n'
                                                                                                   'Gesendet: '
                                                                                                   '{sent}\n'
                                                                                                   'Übersprungen '
                                                                                                   'oder '
                                                                                                   'fehlgeschlagen: '
                                                                                                   '{failed}\n'
                                                                                                   'Unbestätigt: '
                                                                                                   '{uncertain}',
        'Try this button again in {time} (min:sec)': 'Versuche diese Schaltfläche in {time} (Min:Sek) erneut',
        'Off with no button': 'Aus ohne Schaltfläche',
        'Reimport the ZIP when restarting?': 'Die ZIP beim Neustart neu importieren?',
        'Restart and reimport ZIP': 'Neustart mit ZIP-Neuimport',
        'Restart without reimport': 'Neustart ohne Neuimport',
        'This restart prompt is no longer active, send /restart again': 'Diese Neustart-Abfrage ist nicht '
                                                                        'mehr aktiv, Sende /restart erneut',
        'Restart cancelled': 'Neustart abgebrochen',
        'Saving progress and restarting with ZIP reimport': 'Fortschritt wird gespeichert, Neustart mit '
                                                            'ZIP-Neuimport',
        'Preparing backup ZIP...': 'Backup-ZIP wird erstellt...',
        'A backup ZIP is already being prepared': 'Eine Backup-ZIP wird bereits erstellt',
        'The backup ZIP is too large, the maximum size is 50 MB': 'Die Backup-ZIP ist zu groß, Die Grenze '
                                                                  'beträgt 50 MB',
        'Backup ZIP sent. Shut down or restart?': 'Backup-ZIP gesendet, Beenden oder neu starten?',
        'Backup ZIP sent to your private chat': 'Backup-ZIP an deinen privaten Chat gesendet',
        'Could not send the backup ZIP, open our private chat and send /start, then try /upload again': 'Die '
                                                                                                        'Backup-ZIP '
                                                                                                        'konnte '
                                                                                                        'nicht '
                                                                                                        'gesendet '
                                                                                                        'werden, '
                                                                                                        'Öffne '
                                                                                                        'unseren '
                                                                                                        'privaten '
                                                                                                        'Chat, '
                                                                                                        'sende '
                                                                                                        '/start '
                                                                                                        'und '
                                                                                                        'versuche '
                                                                                                        '/upload '
                                                                                                        'erneut',
        'This backup menu is no longer active, use /upload again': 'Dieses Backup-Menü ist nicht mehr aktiv, '
                                                                   'Verwende /upload erneut',
        'Shut down': 'Beenden',
        'Restart': 'Neustart',
        'Could not read system specifications, please try again later': 'Die Systemspezifikationen konnten '
                                                                        'nicht gelesen werden, versuche es '
                                                                        'später erneut',
        'Could not read dependency versions, please try again later': 'Die Versionen der Abhängigkeiten '
                                                                      'konnten nicht gelesen werden, '
                                                                      'versuche es später erneut',
        'Metadata': 'Metadaten',
        'Metadata format': 'Metadatenformat',
        'Bot statistics\nSession uptime: {days}d {hours}h {minutes}m {seconds}s\nRecorded users: {users}\nRecorded chats: {chats}\nActive chat records: {active_chats}\n\nSaved requests: {total}\nCompleted: {done}\nFailed: {failed}\nCancelled: {cancelled}\nUnconfirmed: {uncertain}\n\nCurrent queue\nRunning: {running}\nReady: {ready}\nWaiting: {queued}\n\nLast 24 hours\nRequests: {recent_requests}\nRequesters: {recent_users}': 'Bot-Statistik\n'
                                                                                                                                                                                                                                                                                                                                                                                                                                             'Sitzungslaufzeit: '
                                                                                                                                                                                                                                                                                                                                                                                                                                             '{days}d '
                                                                                                                                                                                                                                                                                                                                                                                                                                             '{hours}h '
                                                                                                                                                                                                                                                                                                                                                                                                                                             '{minutes}m '
                                                                                                                                                                                                                                                                                                                                                                                                                                             '{seconds}s\n'
                                                                                                                                                                                                                                                                                                                                                                                                                                             'Erfasste '
                                                                                                                                                                                                                                                                                                                                                                                                                                             'Nutzer: '
                                                                                                                                                                                                                                                                                                                                                                                                                                             '{users}\n'
                                                                                                                                                                                                                                                                                                                                                                                                                                             'Erfasste '
                                                                                                                                                                                                                                                                                                                                                                                                                                             'Chats: '
                                                                                                                                                                                                                                                                                                                                                                                                                                             '{chats}\n'
                                                                                                                                                                                                                                                                                                                                                                                                                                             'Als '
                                                                                                                                                                                                                                                                                                                                                                                                                                             'aktiv '
                                                                                                                                                                                                                                                                                                                                                                                                                                             'markierte '
                                                                                                                                                                                                                                                                                                                                                                                                                                             'Chats: '
                                                                                                                                                                                                                                                                                                                                                                                                                                             '{active_chats}\n'
                                                                                                                                                                                                                                                                                                                                                                                                                                             '\n'
                                                                                                                                                                                                                                                                                                                                                                                                                                             'Gespeicherte '
                                                                                                                                                                                                                                                                                                                                                                                                                                             'Anfragen: '
                                                                                                                                                                                                                                                                                                                                                                                                                                             '{total}\n'
                                                                                                                                                                                                                                                                                                                                                                                                                                             'Abgeschlossen: '
                                                                                                                                                                                                                                                                                                                                                                                                                                             '{done}\n'
                                                                                                                                                                                                                                                                                                                                                                                                                                             'Fehlgeschlagen: '
                                                                                                                                                                                                                                                                                                                                                                                                                                             '{failed}\n'
                                                                                                                                                                                                                                                                                                                                                                                                                                             'Abgebrochen: '
                                                                                                                                                                                                                                                                                                                                                                                                                                             '{cancelled}\n'
                                                                                                                                                                                                                                                                                                                                                                                                                                             'Unbestätigt: '
                                                                                                                                                                                                                                                                                                                                                                                                                                             '{uncertain}\n'
                                                                                                                                                                                                                                                                                                                                                                                                                                             '\n'
                                                                                                                                                                                                                                                                                                                                                                                                                                             'Aktuelle '
                                                                                                                                                                                                                                                                                                                                                                                                                                             'Warteschlange\n'
                                                                                                                                                                                                                                                                                                                                                                                                                                             'In '
                                                                                                                                                                                                                                                                                                                                                                                                                                             'Bearbeitung: '
                                                                                                                                                                                                                                                                                                                                                                                                                                             '{running}\n'
                                                                                                                                                                                                                                                                                                                                                                                                                                             'Startbereit: '
                                                                                                                                                                                                                                                                                                                                                                                                                                             '{ready}\n'
                                                                                                                                                                                                                                                                                                                                                                                                                                             'Wartend: '
                                                                                                                                                                                                                                                                                                                                                                                                                                             '{queued}\n'
                                                                                                                                                                                                                                                                                                                                                                                                                                             '\n'
                                                                                                                                                                                                                                                                                                                                                                                                                                             'Letzte '
                                                                                                                                                                                                                                                                                                                                                                                                                                             '24 '
                                                                                                                                                                                                                                                                                                                                                                                                                                             'Stunden\n'
                                                                                                                                                                                                                                                                                                                                                                                                                                             'Anfragen: '
                                                                                                                                                                                                                                                                                                                                                                                                                                             '{recent_requests}\n'
                                                                                                                                                                                                                                                                                                                                                                                                                                             'Anfragende '
                                                                                                                                                                                                                                                                                                                                                                                                                                             'Nutzer: '
                                                                                                                                                                                                                                                                                                                                                                                                                                             '{recent_users}',
        'Could not read bot statistics, please try again later': 'Die Bot-Statistik konnte nicht gelesen '
                                                                 'werden, versuche es später erneut',
        'Send audio, video, a voice message, or a direct media link': 'Sende Audio, Video, eine '
                                                                      'Sprachnachricht oder einen direkten '
                                                                      'Medienlink',
        'Whisper model': 'Whisper-Modell',
        'Speech language': 'Sprache der Aufnahme',
        'Automatic detection': 'Automatisch erkennen',
        'Task': 'Aufgabe',
        'Transcribe': 'Transkribieren',
        'Translate to English': 'Ins Englische übersetzen',
        'Word timestamps': 'Zeitstempel pro Wort',
        'Use cached results': 'Cache verwenden',
        'Transcript preview': 'Textvorschau',
        'Transcript files': 'Transkriptdateien',
        'Preparing audio...': 'Audio wird vorbereitet...',
        'Loading Whisper...': 'Whisper wird geladen...',
        'Transcribing...': 'Transkription läuft...',
        'Waiting for transcription...': 'Warten auf Transkription...',
        'Download {format}': '{format} herunterladen',
        'Your queue is full, up to 4 active and 4 waiting requests are allowed': 'Die Warteschlange ist '
                                                                                 'voll, erlaubt sind 4 '
                                                                                 'aktive und 4 wartende '
                                                                                 'Anfragen',
        'This button belongs to the original requester': 'Diese Schaltfläche gehört dem ursprünglichen '
                                                         'Nutzer',
        'This result has expired, send the media again': 'Das Ergebnis ist abgelaufen, sende die Medien '
                                                         'erneut',
        'No speech was detected': 'Keine Sprache erkannt'}}

def translate(language, text, **values):
    result = TEXT.get(language, TEXT['en']).get(text, text)
    return result.format(**values) if values else result

from whisper_i18n import install, HELP as WHISPER_HELP
install(TEXT, LANGUAGES)
HELP = {code: WHISPER_HELP.get(code,
    TEXT[code]['Send audio, video, a voice message, or a direct media link'] + '\n\n' + WHISPER_HELP['en'].split('\n\n',1)[1])
    for code in LANGUAGES}

# The same app can still be run manually against the cloud endpoint.
from telegram_api import is_local
if is_local():
    for code in HELP:
        HELP[code] = (HELP[code].replace('Standard Telegram uploads: up to 20 MB',
                                       'Telegram uploads: up to 2 GBs')
                     .replace('Direct links: up to 500 MB by default',
                              'Direct links: up to 2 GBs by default')
                     .replace('رفع تيليجرام العادي: حتى 20 ميغابايت',
                              'رفع تيليجرام: حتى 2 غيغابايت')
                     .replace('الروابط المباشرة: حتى 500 ميغابايت افتراضيًا',
                              'الروابط المباشرة: حتى 2 غيغابايت افتراضيًا'))
    for code, messages in TEXT.items():
        key = 'The backup ZIP is too large, the maximum size is 50 MB'
        if key in messages:
            messages[key] = (messages[key].replace('50 MB', '2 GBs')
                .replace('50 ميغابايت', '2 غيغابايت').replace('50 МБ', '2 ГБ'))
