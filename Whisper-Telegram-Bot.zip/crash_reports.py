"""Safe application error events for the independent Telegram supervisor."""
import json
import logging
import os
from pathlib import Path
import re
import sys

EVENT_PREFIX = '@@WHISPER_ISSUE_V1@@'
MAX_DETAILS = 12000


def sanitize(value):
    value = str(value)
    for key, secret in sorted(os.environ.items(), key=lambda item: len(item[1]), reverse=True):
        if secret and any(word in key.upper() for word in ('TOKEN', 'SECRET', 'PASSWORD', 'ACCESS_KEY', 'COOKIES', 'API_HASH', 'ZIP_URL', 'TELE_ZIP')):
            value = value.replace(secret, '[redacted]')
    value = re.sub(r'\b\d{6,}:[A-Za-z0-9_-]{20,}\b', '[redacted]', value)
    value = re.sub(r'(?im)((?:authorization|cookie|set-cookie)\s*[:=])[^\r\n]*', r'\1 [redacted]', value)
    value = re.sub(r'(https?://)[^\s/@]+:[^\s/@]+@', r'\1[redacted]@', value)
    value = re.sub(r'(?i)([?&](?:token|key|signature|sig|password|secret|auth|credential|x-amz-[\w-]+)=)[^\s&#\"\']+', r'\1[redacted]', value)
    return value


def exception_details(exc):
    # Exception strings, source lines, locals and Telegram method reprs can
    # contain tokens, cookies, captions or signed URLs, so keep only locations.
    lines, seen = [], set()
    while exc is not None and id(exc) not in seen and len(seen) < 8:
        seen.add(id(exc))
        lines.append(type(exc).__name__)
        frame = exc.__traceback__
        for _ in range(40):
            if frame is None:
                break
            code = frame.tb_frame.f_code
            lines.append(f'  {Path(code.co_filename).name}:{frame.tb_lineno} in {code.co_name}')
            frame = frame.tb_next
        if type(exc).__name__ == 'TelegramConflictError':
            lines.append('Another application is polling with this bot token, stop the other bot instance')
        elif type(exc).__name__ == 'TelegramUnauthorizedError':
            lines.append('Telegram rejected the bot token, check TELEGRAM_BOT_TOKEN')
        if isinstance(exc, OSError) and isinstance(exc.errno, int):
            lines.append(f'OS error number: {exc.errno}')
        exc = exc.__cause__ or (None if exc.__suppress_context__ else exc.__context__)
        if exc is not None:
            lines.append('Caused by')
    return sanitize('\n'.join(lines))[:MAX_DETAILS]


def emit_issue(title, details='', kind='error'):
    try:
        event = {'kind': kind, 'title': sanitize(title)[:500],
                 'details': sanitize(details)[:MAX_DETAILS]}
        print(EVENT_PREFIX + json.dumps(event, ensure_ascii=False), flush=True)
    except Exception:
        # Reporting must never replace the application's original failure.
        pass


class SafeFormatter(logging.Formatter):
    def formatException(self, exc_info):
        return exception_details(exc_info[1])

    def format(self, record):
        return sanitize(super().format(record))


class IssueHandler(logging.Handler):
    def __init__(self):
        super().__init__(logging.WARNING)

    def emit(self, record):
        try:
            kind = getattr(record, 'report_kind', 'warning' if record.levelno == logging.WARNING else 'error')
            details = exception_details(record.exc_info[1]) if record.exc_info else ''
            emit_issue(record.getMessage(), details, kind)
        except Exception:
            pass


def configure_logging():
    stream = logging.StreamHandler(sys.stderr)
    stream.setFormatter(SafeFormatter('%(asctime)s | %(levelname)s | %(message)s'))
    logging.basicConfig(level=logging.INFO, handlers=[stream, IssueHandler()], force=True)


def background_error(loop, context):
    exc = context.get('exception')
    logging.error('Background task failed', exc_info=(type(exc), exc, exc.__traceback__) if exc else None)
