"""Announce changed runtime versions, retaining the baseline in backed-up state."""
from importlib.metadata import distributions
import json
import logging
import platform
import re

from dependency_versions import read_dependencies

CHAT_ID = -1004434678187
STATE_KEY = 'dependency_versions:'+str(CHAT_ID)
NAME = re.compile(r'[A-Za-z0-9][A-Za-z0-9_.-]{0,99}\Z')
VERSION = re.compile(r'[A-Za-z0-9][A-Za-z0-9_.+~-]{0,149}\Z')


def valid_record(record):
    return (isinstance(record,dict) and isinstance(record.get('name'),str)
            and isinstance(record.get('version'),str)
            and NAME.fullmatch(record['name']) and VERSION.fullmatch(record['version'])
            and any(char.isdigit() for char in record['version']))


async def current_versions():
    current = {'runtime:python':{'name':'Python','version':platform.python_version()}}
    for package in distributions():
        name = package.metadata.get('Name','')
        record = {'name':name,'version':package.version}
        if valid_record(record):
            key = 'package:'+re.sub(r'[-_.]+','-',name).lower()
            current[key] = record
    report = await read_dependencies()
    tool_lines = report.partition('\nSystem tools\n')[2]
    for line in tool_lines.splitlines():
        name, separator, version = line.partition(': ')
        if name not in ('FFmpeg','ffprobe','Chromium','neofetch') or not separator:
            continue
        record = {'name':name,'version':version}
        if valid_record(record):
            current['tool:'+name.lower()] = record
    return current


def saved_versions(state):
    try:
        saved = json.loads(state.get(STATE_KEY,'{}'))
    except (ValueError,TypeError):
        return {}
    if not isinstance(saved,dict):
        return {}
    return {key:record for key,record in saved.items()
            if isinstance(key,str) and valid_record(record)}


class DependencyUpdates:
    def __init__(self,runner):
        self.runner = runner

    async def run(self):
        try:
            await self.check()
        except Exception as exc:
            # Exception text can include a Telegram token-bearing URL
            logging.warning('Dependency update check failed with %s',type(exc).__name__)

    async def check(self):
        if self.runner.stop.is_set():
            return
        current = await current_versions()
        if self.runner.stop.is_set():
            return
        saved = saved_versions(self.runner.state)
        if not saved:
            self.runner.state.set(STATE_KEY,json.dumps(current))
            logging.info('Dependency version baseline saved')
            return
        for key,record in sorted(current.items()):
            if self.runner.stop.is_set():
                return
            previous = saved.get(key)
            if previous is not None and previous['version']!=record['version']:
                text = '#update\n\n'+record['name']+': '+previous['version']+' ➡️ '+record['version']
                try:
                    await self.runner.api(CHAT_ID,lambda: self.runner.bot.send_message(
                        chat_id=CHAT_ID,text=text,parse_mode=None))
                except Exception as exc:
                    logging.warning('Dependency update notice failed with %s',type(exc).__name__)
                    continue
            saved[key] = record
            self.runner.state.set(STATE_KEY,json.dumps(saved))
