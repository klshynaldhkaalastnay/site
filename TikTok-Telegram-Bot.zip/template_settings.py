"""Per-user media template preferences and reply-based Telegram editing."""
from dataclasses import dataclass
from html import escape
import json
import secrets
import time

from aiogram.exceptions import AiogramError, TelegramBadRequest
from aiogram.types import ForceReply, InlineKeyboardButton, InlineKeyboardMarkup, LinkPreviewOptions, ReplyParameters
from aiogram.utils.text_decorations import html_decoration

from i18n import LANGUAGES, TEXT
import media_templates as templates


EDIT_PROMPT = 'Reply to this message with your template, or send /cancel'
EDIT_SECONDS = 600


@dataclass(frozen=True)
class TemplateEdit:
    field: str
    prompt: int
    expires: float


@dataclass(frozen=True)
class TemplateDraft:
    field: str
    value: str
    token: str
    expires: float


class TemplateSettings:
    def __init__(self, runner):
        self.runner = runner
        self.pending = {}
        self.drafts = {}

    @staticmethod
    def key(user, field):
        return f'media_template:{user}:{field}'

    def preference(self, user, field):
        value = self.runner.state.get(self.key(user,field))
        return self.valid_value(field,value)

    @staticmethod
    def valid_value(field, value):
        if value:
            try:
                return templates.validate(field,value)
            except templates.TemplateError:
                pass
        return None

    def snapshot(self, jid):
        state = self.runner.state
        row = state.job(jid)
        if row['media_templates'] is None:
            # A resumed job from before templates keeps its original layout.
            values = {}
            if row['sent']=='[]' and row['in_flight'] is None:
                for field in templates.FIELDS:
                    value = self.preference(row['user_id'],field)
                    if value:
                        values[field] = value
            state.change(jid,media_templates=json.dumps(values))
            return values
        try:
            saved = json.loads(row['media_templates'])
        except ValueError:
            return {}
        if not isinstance(saved,dict):
            return {}
        return {field:value for field in templates.FIELDS
                if (value := self.valid_value(field,saved.get(field)))}

    def panel(self, user, field=None):
        r = self.runner
        def tr(key):
            return escape(r.tr(user,key),quote=False)
        def button(key, action, marked=False):
            return InlineKeyboardButton(text=('✓ ' if marked else '')+r.tr(user,key),
                                        callback_data=f'settings:{user}:{action}')
        if field is None:
            rows = [[button(label,'tpl-'+name,bool(self.preference(user,name)))]
                    for name,label in templates.FIELDS.items()]
            rows.append([button('Back','main')])
            return tr('Media templates'), InlineKeyboardMarkup(inline_keyboard=rows)

        value = self.preference(user,field)
        current = '<pre>'+escape(value,quote=False)+'</pre>' if value else tr('Default')
        text = f"<b>{tr(templates.FIELDS[field])}</b>\n{current}\n\n<b>{tr('Preview')}</b>\n"
        text += self.preview(field,value)
        text += f"\n\n<b>{tr('Placeholders')}</b>\n"
        text += '  '.join('<code>{{.'+name+'}}</code>' for name in templates.tokens_for(field))
        rows = [[button('Edit template','tpl-edit-'+field)]]
        if value:
            rows[0].append(button('Reset to default','tpl-reset-'+field))
        rows.append([button('Formatting','tpl-format-'+field),button('Back','templates')])
        return text, InlineKeyboardMarkup(inline_keyboard=rows)

    def preview(self, field, value):
        post_id = '1234567890'
        title = 'A sample TikTok caption'
        author, username = 'Creator Name', 'creator'
        kind = 'photo' if field=='photo_caption' else 'video'
        author_url = 'https://www.tiktok.com/@creator'
        values = {'PostID':post_id,'Title':title,'Caption':title,'Author':author,
                  'Username':username,'URL':'https://vt.tiktok.com/example/',
                  'AuthorURL':author_url,'PostURL':f'{author_url}/{kind}/{post_id}',
                  **templates.details({'duration':15,'width':1080,'height':1920},3)}
        return (templates.caption(value,values)[0] if value else
                self.runner.media_caption(title,author,username))

    @staticmethod
    def scope(msg, user):
        return user,msg.chat.id,getattr(msg,'message_thread_id',None)

    def guide(self, user, field):
        r = self.runner
        examples = ('<b>Bold</b>  <i>Italic</i>  <u>Underline</u>\n'
                    '<s>Strikethrough</s>  <tg-spoiler>Spoiler</tg-spoiler>\n'
                    '<code>Inline code</code>\n'
                    '<pre>Monospace block</pre>\n'
                    '<pre><code class="language-python">print("Hello")</code></pre>\n'
                    '<blockquote>{{.Caption}}</blockquote>\n'
                    '<blockquote expandable>Expandable quote</blockquote>\n'
                    '<a href="{{.AuthorURL}}">{{.Author}}</a>\n'
                    '<a href="{{.PostURL}}">Open on TikTok</a>')
        intro = r.tr(user,'Use Telegram’s formatting menu, or copy these examples with HTML: on the first line')
        text = '<b>'+escape(r.tr(user,'Formatting'))+'</b>\n'+escape(intro)
        text += '\n\n<pre>'+escape(templates.HTML_PREFIX+examples,quote=False)+'</pre>'
        keyboard = InlineKeyboardMarkup(inline_keyboard=[[
            InlineKeyboardButton(text=r.tr(user,'Edit template'),callback_data=f'settings:{user}:tpl-edit-{field}'),
            InlineKeyboardButton(text=r.tr(user,'Back'),callback_data=f'settings:{user}:tpl-{field}'),
        ]])
        return text, keyboard

    async def callback(self, query, action):
        r = self.runner
        msg,user = query.message,query.from_user.id
        scope = self.scope(msg,user)
        field = None if action=='templates' else action.removeprefix('tpl-')
        if field and field.startswith(('save-','discard-')):
            operation,token = field.split('-',1)
            draft = self.drafts.get(scope)
            if not draft or draft.token!=token or r.stop.is_set():
                return
            del self.drafts[scope]
            expired = draft.expires<=time.monotonic()
            if expired:
                operation = 'discard'
            if operation=='save':
                r.state.set(self.key(user,draft.field),draft.value)
            text,keyboard = self.panel(user,draft.field)
            heading = ('Template edit expired, open Media templates again' if expired else
                       'Template saved' if operation=='save' else 'Template edit cancelled')
            await self.edit_panel(msg,escape(r.tr(user,heading))+'\n\n'+text,keyboard)
            return
        if field is not None:
            operation,sep,target = field.partition('-')
            if sep and operation in ('edit','reset','format'):
                field = target
            else:
                operation = 'view'
            if field not in templates.FIELDS:
                return
            if operation=='format':
                await self.edit_panel(msg,*self.guide(user,field))
                return
            if operation in ('edit','reset') and r.stop.is_set():
                return
            if operation=='reset':
                r.state.set(self.key(user,field),'')
                if (draft := self.drafts.get(scope)) and draft.field==field:
                    del self.drafts[scope]
                if (edit := self.pending.get(scope)) and edit.field==field:
                    del self.pending[scope]
            if operation=='edit':
                now = time.monotonic()
                self.pending = {k:v for k,v in self.pending.items() if v.expires>now}
                self.drafts = {k:v for k,v in self.drafts.items() if v.expires>now}
                self.drafts.pop(scope,None)
                text = escape(r.tr(user,EDIT_PROMPT),quote=False)
                if msg.chat.id<0:
                    name = templates.clean(getattr(query.from_user,'full_name',''))[:64] or str(user)
                    text += f'\n<a href="tg://user?id={user}">{escape(name,quote=False)}</a>'
                text += '\n\n<b>'+escape(r.tr(user,templates.FIELDS[field]),quote=False)+'</b>\n'
                text += '<pre>'+escape(self.preference(user,field) or templates.EXAMPLES[field],quote=False)+'</pre>'
                prompt = await r.api(msg.chat.id,lambda:r.bot.send_message(
                    msg.chat.id,text,parse_mode='HTML',message_thread_id=scope[2],
                    reply_markup=ForceReply(force_reply=True,selective=True),
                    link_preview_options=LinkPreviewOptions(is_disabled=True)))
                self.pending[scope] = TemplateEdit(field,prompt.message_id,time.monotonic()+EDIT_SECONDS)
                return
        await self.edit_panel(msg,*self.panel(user,field))

    async def edit_panel(self, msg, text, keyboard):
        r = self.runner
        try:
            await r.api(msg.chat.id,lambda:r.bot.edit_message_text(
                text,chat_id=msg.chat.id,message_id=msg.message_id,parse_mode='HTML',
                reply_markup=keyboard,link_preview_options=LinkPreviewOptions(is_disabled=True)))
        except TelegramBadRequest as exc:
            if 'message is not modified' not in exc.message.lower():
                raise

    def is_edit_prompt(self, reply):
        sender = getattr(reply,'from_user',None)
        if not getattr(sender,'is_bot',False) or sender.id!=getattr(self.runner.bot,'id',None):
            return False
        line = (getattr(reply,'text',None) or '').split('\n',1)[0]
        return any(line==TEXT[language][EDIT_PROMPT] for language in LANGUAGES)

    async def receive(self,msg):
        r = self.runner
        user = msg.from_user.id
        scope = self.scope(msg,user)
        edit = self.pending.get(scope)
        reply = getattr(msg,'reply_to_message',None)
        text = getattr(msg,'text',None)
        cancel = text and text.strip().lower() in ('/cancel',f'/cancel@{r.username.lower()}')

        async def respond(key, body='', keyboard=None, *, preview=False):
            heading = escape(r.tr(user,key),quote=False)
            try:
                await r.api(msg.chat.id,lambda:r.bot.send_message(
                    msg.chat.id,heading+('\n\n'+body if body else ''),parse_mode='HTML',
                    message_thread_id=scope[2],reply_markup=keyboard,
                    link_preview_options=LinkPreviewOptions(is_disabled=True),
                    reply_parameters=ReplyParameters(message_id=msg.message_id,allow_sending_without_reply=True)))
            except TelegramBadRequest:
                if preview:
                    raise
            except AiogramError:
                # Telegram acknowledgement is separate from the preference write.
                pass

        if cancel and reply is None and (draft := self.drafts.pop(scope,None)) and draft.expires>time.monotonic():
            await respond('Template edit cancelled')
            return True
        if not edit or (getattr(reply,'message_id',None)!=edit.prompt and not (cancel and reply is None)):
            # A reply to somebody else's or a stale edit prompt is never a download.
            return self.is_edit_prompt(reply)
        if edit.expires<=time.monotonic():
            del self.pending[scope]
            await respond('Template edit expired, open Media templates again')
            return True
        if cancel:
            del self.pending[scope]
            await respond('Template edit cancelled')
            return True
        if any(entity.type=='bot_command' and entity.offset==0 for entity in (getattr(msg,'entities',None) or ())):
            return False
        if r.stop.is_set():
            await respond('The bot is restarting, please send your links again shortly')
            return True
        try:
            entities = [entity for entity in (getattr(msg,'entities',None) or ())
                        if entity.type in templates.FORMATTED_ENTITIES]
            if text and entities and not text.strip().startswith(templates.HTML_PREFIX):
                entities.sort(key=lambda e:(e.offset,-e.length,e.type not in ('blockquote','expandable_blockquote')))
                text = templates.HTML_PREFIX+html_decoration.unparse(text,entities)
            value = templates.validate(edit.field,text)
        except templates.TemplateError as exc:
            await respond(str(exc))
            return True
        del self.pending[scope]
        token = secrets.token_hex(8)
        draft = self.drafts[scope] = TemplateDraft(edit.field,value,token,time.monotonic()+EDIT_SECONDS)
        keyboard = InlineKeyboardMarkup(inline_keyboard=[[
            InlineKeyboardButton(text=r.tr(user,'Save template'),callback_data=f'settings:{user}:tpl-save-{token}'),
            InlineKeyboardButton(text=r.tr(user,'Cancel'),callback_data=f'settings:{user}:tpl-discard-{token}'),
        ]])
        try:
            await respond('Preview',self.preview(edit.field,value),keyboard,preview=True)
        except TelegramBadRequest:
            if self.drafts.get(scope) is draft:
                del self.drafts[scope]
                self.pending[scope] = edit
                await respond('Use supported formatting tags and valid links')
        return True
