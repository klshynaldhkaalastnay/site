"""Private owner backup ZIPs with explicit shutdown/restart choices."""
import asyncio
from datetime import datetime, timezone
from html import escape
import logging
from pathlib import Path
import re
import secrets
import tempfile

from aiogram.exceptions import (AiogramError, TelegramAPIError, TelegramNetworkError,
                               TelegramServerError, ClientDecodeError)
from aiogram.types import FSInputFile, InlineKeyboardButton, InlineKeyboardMarkup, ReplyParameters

from backup import create_archive
from common import MAX_BYTES, BOT_ATTRIBUTION


class OwnerBackup:
    def __init__(self,runner,source):
        self.r,self.source = runner,source
        self.pending = None
        self.building = False

    async def command(self,msg,user):
        r = self.r
        if user!=r.owner:
            await r.tell(msg.chat.id,r.tr(user,'Only the bot owner can use this command'),msg.message_thread_id)
            return
        if r.stop.is_set():
            await r.tell(msg.chat.id,r.tr(user,'The bot is already stopping'),msg.message_thread_id)
            return
        if self.building:
            await r.tell(msg.chat.id,r.tr(user,'A backup ZIP is already being prepared'),msg.message_thread_id)
            return
        self.building = True
        pending = None
        try:
            await r.tell(msg.chat.id,r.tr(user,'Preparing backup ZIP...'),msg.message_thread_id)
            with tempfile.TemporaryDirectory(prefix='owner-backup-',dir=r.data) as td:
                token = secrets.token_hex(8)
                filename = 'TikTok-Bot-Backup-'+datetime.now(timezone.utc).strftime('%Y%m%d-%H%M%S')+'-'+token[:6]+'.zip'
                archive = Path(td)/filename
                build = asyncio.create_task(asyncio.to_thread(create_archive,r.data,self.source,archive))
                try:
                    await asyncio.shield(build)
                except asyncio.CancelledError:
                    # The worker must finish before its temporary files are removed.
                    await build
                    raise
                if r.stop.is_set():
                    return
                if archive.stat().st_size>MAX_BYTES:
                    await r.tell(msg.chat.id,r.tr(user,'The backup ZIP is too large, the maximum size is 50 MB'),msg.message_thread_id)
                    return
                pending = {'token':token,'filename':filename,'message':None}
                self.pending = pending
                keyboard = InlineKeyboardMarkup(inline_keyboard=[[
                    InlineKeyboardButton(text=r.tr(user,label),callback_data=f'backup:{user}:{token}:{mode}')
                    for label,mode in (('Shut down','shutdown'),('Restart','restart'))]])
                reply = ReplyParameters(message_id=msg.message_id,allow_sending_without_reply=True) if msg.chat.id==user else None
                sent = await r.api(user,lambda:r.bot.send_document(
                    chat_id=user,document=FSInputFile(archive,filename=filename),
                    caption=escape(r.tr(user,'Backup ZIP sent. Shut down or restart?'))+'\n'+BOT_ATTRIBUTION,
                    parse_mode='HTML',reply_markup=keyboard,reply_parameters=reply))
                pending['message'] = sent.message_id
            if msg.chat.id!=user:
                await r.tell(msg.chat.id,r.tr(user,'Backup ZIP sent to your private chat'),msg.message_thread_id)
        except asyncio.CancelledError:
            raise
        except (TelegramNetworkError,TelegramServerError,ClientDecodeError):
            logging.info('Owner backup ZIP delivery unconfirmed')
            await r.tell(msg.chat.id,r.tr(user,'Telegram did not confirm the backup ZIP, check your private chat before using /upload again'),msg.message_thread_id)
        except TelegramAPIError:
            if pending is not None and self.pending is pending and pending['message'] is None:
                self.pending = None
            await r.tell(msg.chat.id,r.tr(user,'Could not send the backup ZIP, open our private chat and send /start, then try /upload again'),msg.message_thread_id)
        except Exception:
            logging.info('Owner backup ZIP could not be prepared or confirmed')
            await r.tell(msg.chat.id,r.tr(user,'Could not send the backup ZIP, open our private chat and send /start, then try /upload again'),msg.message_thread_id)
        finally:
            self.building = False

    async def callback(self,query):
        r = self.r
        user,msg = query.from_user.id,query.message
        if user!=r.owner:
            await query.answer(r.tr(user,'Only the bot owner can use this command'),show_alert=True)
            return
        match = re.fullmatch(r'backup:([0-9]{1,19}):([a-f0-9]{16}):(shutdown|restart)',query.data or '')
        pending = self.pending
        if (not match or not pending or int(match[1])!=user or match[2]!=pending['token']
                or not msg or msg.chat.id!=user or getattr(msg,'message_thread_id',None) is not None
                or (msg.message_id!=pending['message'] if pending['message'] is not None else
                    getattr(getattr(msg,'document',None),'file_name',None)!=pending['filename'])):
            await query.answer(r.tr(user,'This backup menu is no longer active, use /upload again'),show_alert=True)
            return
        if r.stop.is_set():
            await query.answer(r.tr(user,'The bot is already stopping'),show_alert=True)
            return
        self.pending = None
        shutdown = match[3]=='shutdown'
        if shutdown:
            r.request_stop('shutdown')
        try:
            await query.answer(r.tr(user,'Saving progress and stopping') if shutdown else None)
        except AiogramError:
            logging.info('Backup choice acknowledgement unavailable')
        try:
            await r.api(user,lambda:r.bot.edit_message_reply_markup(
                chat_id=user,message_id=msg.message_id,reply_markup=InlineKeyboardMarkup(inline_keyboard=[])))
        except AiogramError:
            logging.info('Backup choice keyboard could not be removed')
        if not shutdown:
            await r.restart_menu(msg,user)
