"""Telegram TikTok downloader with durable admission and delivery tracking"""
import asyncio
import base64
from collections import defaultdict
from contextlib import suppress
import json
from html import escape
import logging
import math
import os
import re
import secrets
from pathlib import Path
import shutil
import signal
import sys
import time

from aiogram import Bot
from aiogram.client.session.aiohttp import AiohttpSession
from aiogram.types import BotCommand, FSInputFile, InputMediaPhoto, InputMediaDocument, ReplyParameters, InlineKeyboardButton, InlineKeyboardMarkup, LinkPreviewOptions
from aiogram.exceptions import AiogramError, TelegramAPIError, TelegramBadRequest, TelegramEntityTooLarge, TelegramRetryAfter, TelegramNetworkError, TelegramServerError, ClientDecodeError
from common import extract_links, MAX_BYTES, TOO_LARGE, MEDIA_CHOICES, media_preference, BOT_NAME, BOT_ATTRIBUTION
from state import State
from broadcasts import Broadcasts
from caption_files import CaptionFiles
from owner_backup import OwnerBackup
from i18n import LANGUAGES, HELP as LOCAL_HELP, OWNER_HELP, translate
from compression import options as compression_options, DEFAULTS as COMPRESSION_DEFAULTS, CHOICES as COMPRESSION_CHOICES, LABELS as COMPRESSION_LABELS

ROOT = Path(__file__).resolve().parent
HELP = LOCAL_HELP['en']
COMMANDS = [('start','Start the bot'),('help','Show help'),('queue','Your requests'),
            ('cancel','Cancel a request'),('ping','Check response time'),('id','Your Telegram ID'),
            ('settings','Bot settings')]


class Runner:
    def __init__(self, state, bot, data, owner, bypass):
        self.state,self.bot,self.data,self.owner,self.bypass = state,bot,data,owner,bypass
        self.stop = asyncio.Event()
        self.reason = 'shutdown'
        self.force_reimport = False
        self.pending_restart = None
        self.tasks = {}
        self.chat_locks = defaultdict(asyncio.Lock)
        self.chat_next = defaultdict(float)
        self.global_lock = asyncio.Lock()
        self.global_next = 0.0
        self.username = ''
        self.broadcasts = Broadcasts(self)
        self.caption_files = CaptionFiles(self)
        self.owner_backup = OwnerBackup(self,ROOT)
        self.work = data/'work'
        shutil.rmtree(self.work,ignore_errors=True)
        self.work.mkdir(parents=True,exist_ok=True)

    async def api(self, chat, operation):
        # Apply Telegram pacing to exempt accounts too
        async with self.chat_locks[chat]:
            for attempt in range(4):
                await asyncio.sleep(max(0,self.chat_next[chat]-time.monotonic()))
                async with self.global_lock:
                    await asyncio.sleep(max(0,self.global_next-time.monotonic()))
                    self.global_next = time.monotonic()+0.05
                self.chat_next[chat] = time.monotonic()+(3.2 if chat < 0 else 1.1)
                try:
                    return await operation()
                except TelegramRetryAfter as exc:
                    seconds = exc.retry_after
                    if attempt == 3:
                        raise
                    await asyncio.sleep(seconds+1)

    async def tell(self, chat, text, thread=None):
        return await self.api(chat,lambda: self.bot.send_message(chat,text,message_thread_id=thread))

    def tr(self, recipient, text, **values):
        return translate(self.state.get(f'language:{recipient}', 'en'), text, **values)

    def settings_view(self, user, page='main'):
        def button(label, action):
            return InlineKeyboardButton(text=label, callback_data=f'settings:{user}:{action}')
        if page == 'audio':
            enabled = media_preference(self.state.get(f'audio:{user}'),'on')
            rows = [[button(('✓ ' if enabled == value else '')+self.tr(user,label), 'audio-'+value) for label,value in [('On','on'),('Off','off')]],
                    [button(('✓ ' if enabled=='off_no_button' else '')+self.tr(user,'Off with no button'),'audio-off_no_button')],
                    [button(self.tr(user,'Back'), 'main')]]
            return self.tr(user,'Automatically send audio with videos and photos, Off shows an Extract audio button'), InlineKeyboardMarkup(inline_keyboard=rows)
        if page == 'subtitles':
            enabled = media_preference(self.state.get(f'subtitles:{user}'),'off_no_button')
            rows = [[button(('✓ ' if enabled == value else '')+self.tr(user,label), 'subtitles-'+value)
                     for label,value in [('On','on'),('Off','off')]],
                    [button(('✓ ' if enabled=='off_no_button' else '')+self.tr(user,'Off with no button'),'subtitles-off_no_button')],
                    [button(self.tr(user,'Back'), 'main')]]
            return self.tr(user,'Automatically send subtitle files with videos, Off shows an Extract subtitles button'), InlineKeyboardMarkup(inline_keyboard=rows)
        if page == 'caption':
            enabled = media_preference(self.state.get(f'caption:{user}'),'off')
            rows = [[button(('✓ ' if enabled == value else '')+self.tr(user,label),'caption-'+value)
                     for label,value in [('On','on'),('Off','off')]],
                    [button(('✓ ' if enabled=='off_no_button' else '')+self.tr(user,'Off with no button'),'caption-off_no_button')],
                    [button(self.tr(user,'Back'),'main')]]
            return self.tr(user,'Automatically send full captions as text files when too long, Off shows a text-file button'), InlineKeyboardMarkup(inline_keyboard=rows)
        if page == 'language':
            buttons = [button(label, 'set-'+code) for code,label in LANGUAGES.items()]
            rows = [buttons[i:i+2] for i in range(0,len(buttons),2)]
            rows += [[button(self.tr(user,'Back'), 'main')]]
            return self.tr(user,'Language'), InlineKeyboardMarkup(inline_keyboard=rows)
        settings = compression_options(self.state.get(f'compression:{user}'))
        if page == 'compression':
            rows = [[button(('✓ ' if settings['mode']==value else '')+self.tr(user,label),
                            'compress-mode-'+value)] for value,label in COMPRESSION_CHOICES['mode'].items()]
            customized = any(settings[key]!=COMPRESSION_DEFAULTS[key] for key in COMPRESSION_LABELS)
            rows += [[button(('✓ ' if customized else '')+self.tr(user,'Advanced'), 'compress-advanced')],
                     [button(self.tr(user,'Back'), 'main')]]
            return self.tr(user,'Compress videos, None keeps the original and the 50 MB limit'), InlineKeyboardMarkup(inline_keyboard=rows)
        if page == 'compress-advanced':
            rows = [[button(self.tr(user,label)+': '+self.tr(user,COMPRESSION_CHOICES[key][settings[key]]),
                            'compress-'+key)] for key,label in COMPRESSION_LABELS.items()]
            rows += [[button(self.tr(user,'Reset advanced defaults'), 'compress-reset')],
                     [button(self.tr(user,'Back'), 'compression')]]
            return self.tr(user,'Advanced compression options, frame rate and resolution are maximums, fitting to 50 MB may lower resolution, video audio bitrate does not change separate sound files'), InlineKeyboardMarkup(inline_keyboard=rows)
        if page.startswith('compress-') and page[9:] in COMPRESSION_LABELS:
            key = page[9:]
            buttons = [button(('✓ ' if settings[key]==value else '')+self.tr(user,label),
                              'compress-'+key+'-'+value) for value,label in COMPRESSION_CHOICES[key].items()]
            rows = [buttons[i:i+2] for i in range(0,len(buttons),2)]
            rows += [[button(self.tr(user,'Back'), 'compress-advanced')]]
            return self.tr(user,COMPRESSION_LABELS[key]), InlineKeyboardMarkup(inline_keyboard=rows)
        current = LANGUAGES.get(self.state.get(f'language:{user}', 'en'), 'English')
        return self.tr(user,'Settings'), InlineKeyboardMarkup(inline_keyboard=[
            [button(self.tr(user,'Language')+': '+current, 'language')],
            [button(self.tr(user,'Audio')+': '+self.tr(user,MEDIA_CHOICES[media_preference(self.state.get(f'audio:{user}'),'on')]), 'audio')],
            [button(self.tr(user,'Compression')+': '+self.tr(user,COMPRESSION_CHOICES['mode'][settings['mode']]), 'compression')],
            [button(self.tr(user,'Subtitles')+': '+self.tr(user,MEDIA_CHOICES[media_preference(self.state.get(f'subtitles:{user}'),'off_no_button')]), 'subtitles')],
            [button(self.tr(user,'Full caption')+': '+self.tr(user,MEDIA_CHOICES[media_preference(self.state.get(f'caption:{user}'),'off')]), 'caption')]])

    async def settings_callback(self, query):
        parts = (query.data or '').split(':')
        await query.answer()
        if len(parts) != 3 or parts[1] != str(query.from_user.id) or not query.message:
            return
        user, action = query.from_user.id, parts[2]
        if action.startswith('set-') and action[4:] in LANGUAGES:
            self.state.set(f'language:{user}', action[4:])
            action = 'main'
        if action.startswith('audio-') and action[6:] in MEDIA_CHOICES:
            self.state.set(f'audio:{user}', action[6:])
            action = 'main'
        if action.startswith('subtitles-') and action[10:] in MEDIA_CHOICES:
            self.state.set(f'subtitles:{user}', action[10:])
            action = 'main'
        if action.startswith('caption-') and action[8:] in MEDIA_CHOICES:
            self.state.set(f'caption:{user}', action[8:])
            action = 'main'
        if action.startswith('compress-'):
            fields = action.split('-',2)
            settings = compression_options(self.state.get(f'compression:{user}'))
            if len(fields)==3 and fields[1] in COMPRESSION_CHOICES and fields[2] in COMPRESSION_CHOICES[fields[1]]:
                settings[fields[1]] = fields[2]
                self.state.set(f'compression:{user}',json.dumps(settings))
                action = 'compression' if fields[1]=='mode' else 'compress-'+fields[1]
            elif action == 'compress-reset':
                self.state.set(f'compression:{user}',json.dumps(dict(COMPRESSION_DEFAULTS,mode=settings['mode'])))
                action = 'compress-advanced'
        if action not in ('main','language','audio','subtitles','caption','compression','compress-advanced',
                          *('compress-'+key for key in COMPRESSION_LABELS)):
            return
        text, keyboard = self.settings_view(user, action)
        await self.api(query.message.chat.id, lambda: self.bot.edit_message_text(
            text=text, chat_id=query.message.chat.id, message_id=query.message.message_id, reply_markup=keyboard))

    async def extract_audio_callback(self, query):
        await self.extract_callback(query,'audio')

    async def extract_subtitles_callback(self, query):
        await self.extract_callback(query,'subtitles')

    async def button_wait(self, query, jid, kind):
        remaining = self.state.button_remaining(jid,kind)
        if remaining:
            minutes,seconds = divmod(math.ceil(remaining),60)
            await query.answer(self.tr(query.from_user.id,'Try this button again in {time} (min:sec)',
                                       time=f'{minutes}:{seconds:02d}'),show_alert=True)
            return True
        if self.state.button_press(query.id):
            await query.answer(self.tr(query.from_user.id,'This request was already received, check the chat and /queue'),
                               show_alert=True)
            return True
        return False

    async def extract_callback(self, query, kind):
        audio = kind=='audio'
        prefix = 'extract' if audio else 'extract_subtitles'
        match = re.fullmatch(prefix+r':([0-9]{1,19})', query.data or '')
        source = self.state.job(int(match[1])) if match else None
        msg = query.message
        user = query.from_user.id
        ownership = ('This audio button belongs to the original requester' if audio else
                     'This subtitle button belongs to the original requester')
        if (not source or not msg or source['audio_only'] or source['subtitles_only']
                or not source['manual_audio' if audio else 'manual_subtitles']
                or source['user_id'] != user or source['chat_id'] != msg.chat.id):
            await query.answer(self.tr(user,ownership), show_alert=True)
            return
        if (source['audio_button_message' if audio else 'subtitle_button_message'] or source['reply_message']) != msg.message_id:
            anchor = getattr(msg,'reply_to_message',None)
            if (audio and source['audio_button_pending'] and source['audio_button_in_flight']
                    and getattr(anchor,'message_id',None)==source['reply_message']
                    and getattr(msg,'message_thread_id',None)==source['thread_id']):
                # A click on the correctly routed reply confirms a button send
                # whose HTTP response was lost, without sending another reply.
                self.state.change(source['id'],audio_button_message=msg.message_id,
                                  audio_button_pending=0,audio_button_in_flight=0)
            else:
                await query.answer(self.tr(user,ownership), show_alert=True)
                return
        if self.stop.is_set():
            await query.answer(self.tr(user,'The bot is restarting, please send your links again shortly'), show_alert=True)
            return
        if await self.button_wait(query,source['id'],kind):
            return
        # Save admission and its cooldown before acknowledging the callback.
        jid, fresh = self.state.submit(user,source['chat_id'],source['reply_message'],source['thread_id'],
                                      source['url'],user == self.bypass,audio_only=audio,subtitles_only=not audio,
                                      request_token=query.id,button_source=source['id'])
        if jid is None:
            await query.answer(self.tr(user,'Your download queue is full, try again later'), show_alert=True)
            return
        row = self.state.job(jid)
        if not fresh:
            await query.answer(self.tr(user,'Audio already requested, check the chat and /queue' if audio else
                                      'Subtitles already requested, check the chat and /queue'), show_alert=True)
            return
        await query.answer(self.tr(user,'Audio requested' if audio else 'Subtitles requested'))
        if row['status'] == 'queued':
            queue = [r['id'] for r in self.state.outstanding(user) if r['status']=='queued']
            await self.status(jid,self.tr(user,'Queued, position {n}',n=queue.index(jid)+1))

    def audio_keyboard(self, user, jid):
        return self.extraction_keyboard(user,jid,audio=True)

    def extraction_keyboard(self, user, jid, audio=False, subtitles=False):
        buttons = []
        if audio:
            buttons.append(InlineKeyboardButton(text=self.tr(user,'Extract audio'),callback_data=f'extract:{jid}'))
        if subtitles:
            buttons.append(InlineKeyboardButton(text=self.tr(user,'Extract subtitles'),callback_data=f'extract_subtitles:{jid}'))
        return InlineKeyboardMarkup(inline_keyboard=[buttons])

    async def install_audio_button(self, jid):
        row = self.state.job(jid)
        if (not row or not row['audio_button_pending'] or not row['reply_message']
                or row['audio_button_in_flight'] or self.stop.is_set()):
            return
        # Albums have no keyboard field. Send one ordinary reply with the
        # button, recording intent before the send and its binding on success.
        async def send_button():
            self.state.change(jid,audio_button_in_flight=1)
            try:
                return await self.bot.send_message(
                    chat_id=row['chat_id'],text=BOT_ATTRIBUTION,parse_mode='HTML',
                    link_preview_options=LinkPreviewOptions(is_disabled=True),
                    message_thread_id=row['thread_id'],
                    reply_parameters=ReplyParameters(message_id=row['reply_message'],allow_sending_without_reply=True),
                    reply_markup=self.audio_keyboard(row['user_id'],jid))
            except TelegramRetryAfter:
                # A rate-limit rejection confirms no reply was sent. If the
                # backoff is interrupted, startup may safely try again.
                self.state.change(jid,audio_button_in_flight=0)
                raise
        try:
            message = await self.api(row['chat_id'],send_button)
        except TelegramEntityTooLarge:
            self.state.change(jid,audio_button_in_flight=0)
            logging.info('Audio button reply rejected for job %s, retaining the pending button',jid)
            return
        except (TelegramNetworkError,TelegramServerError,ClientDecodeError):
            # A reply may have arrived without an acknowledgement. Do not
            # blindly create another button after recovery.
            logging.info('Audio button reply not confirmed for job %s',jid)
            return
        except TelegramAPIError:
            self.state.change(jid,audio_button_in_flight=0)
            logging.info('Audio button reply rejected for job %s, retaining the pending button',jid)
            return
        except AiogramError:
            logging.info('Audio button reply not confirmed for job %s',jid)
            return
        # No await between acknowledgement and the durable button binding.
        self.state.change(jid,audio_button_message=message.message_id,
                          audio_button_pending=0,audio_button_in_flight=0)

    async def language_menu(self, msg, user):
        buttons = [InlineKeyboardButton(text=label, callback_data=f'lang:{user}:{code}')
                   for code,label in LANGUAGES.items()]
        keyboard = InlineKeyboardMarkup(inline_keyboard=[buttons[i:i+2] for i in range(0,len(buttons),2)])
        await self.api(msg.chat.id, lambda: self.bot.send_message(
            msg.chat.id, 'Choose your language / Elige tu idioma / اختر لغتك / Выберите язык / 选择语言 / زبان خود را انتخاب کنید / 言語を選んでください / Escolha seu idioma / Choisissez votre langue / Wähle deine Sprache',
            message_thread_id=msg.message_thread_id, reply_markup=keyboard))

    async def select_language(self, query):
        parts = (query.data or '').split(':')
        if len(parts) != 3 or parts[0] != 'lang' or parts[1] != str(query.from_user.id) or parts[2] not in LANGUAGES:
            await query.answer()
            return
        self.state.set(f'language:{query.from_user.id}', parts[2])
        await query.answer()
        if query.message:
            await self.api(query.message.chat.id, lambda: self.bot.edit_message_text(
                text=self.tr(query.from_user.id, 'Send a TikTok video or photo link'),
                chat_id=query.message.chat.id, message_id=query.message.message_id))

    async def status(self, jid, text):
        row = self.state.job(jid)
        if not row:
            return
        text = self.tr(row['user_id'], text)
        try:
            if row['status_message']:
                await self.api(row['chat_id'],lambda: self.bot.edit_message_text(
                    text,chat_id=row['chat_id'],message_id=row['status_message']))
            else:
                msg = await self.tell(row['chat_id'],text,row['thread_id'])
                self.state.change(jid,status_message=msg.message_id)
        except AiogramError:
            logging.info('Status delivery unavailable for job %s',jid)

    async def notify_owner(self, text):
        try:
            await self.tell(self.owner,text)
        except AiogramError:
            logging.info('Owner notification unavailable, open the bot privately and send /start')

    def request_stop(self, reason):
        if not self.stop.is_set():
            self.reason = reason
            self.stop.set()

    async def restart_menu(self, msg, user):
        token = secrets.token_hex(8)
        pending = {'token':token,'user':user,'chat':msg.chat.id,'thread':msg.message_thread_id,
                   'anchor':msg.message_id,'message':None}
        self.pending_restart = pending
        rows = [[InlineKeyboardButton(text=self.tr(user,label),callback_data=f'restart:{user}:{token}:{mode}')]
                for label,mode in (('Restart and reimport ZIP','reimport'),
                                   ('Restart without reimport','keep'),('Cancel','cancel'))]
        sent = await self.api(msg.chat.id,lambda:self.bot.send_message(
            chat_id=msg.chat.id,text=self.tr(user,'Reimport the ZIP when restarting?'),
            message_thread_id=msg.message_thread_id,
            reply_parameters=ReplyParameters(message_id=msg.message_id,allow_sending_without_reply=True),
            reply_markup=InlineKeyboardMarkup(inline_keyboard=rows)))
        pending['message'] = sent.message_id

    async def restart_callback(self, query):
        user,msg = query.from_user.id,query.message
        if user!=self.owner:
            await query.answer(self.tr(user,'Only the bot owner can use this command'),show_alert=True)
            return
        match = re.fullmatch(r'restart:([0-9]{1,19}):([a-f0-9]{16}):(reimport|keep|cancel)',query.data or '')
        pending = self.pending_restart
        if (not match or not pending or int(match[1])!=user or match[2]!=pending['token']
                or not msg or msg.chat.id!=pending['chat']
                or getattr(msg,'message_thread_id',None)!=pending['thread']
                or (msg.message_id!=pending['message'] if pending['message'] is not None else
                    getattr(getattr(msg,'reply_to_message',None),'message_id',None)!=pending['anchor'])):
            await query.answer(self.tr(user,'This restart prompt is no longer active, send /restart again'),show_alert=True)
            return
        if self.stop.is_set():
            await query.answer(self.tr(user,'The bot is already stopping'),show_alert=True)
            return
        # Consume the choice before any network await; an expired or replayed
        # button cannot trigger another restart or change the selected import.
        self.pending_restart = None
        mode = match[3]
        if mode=='cancel':
            text = self.tr(user,'Restart cancelled')
        else:
            self.force_reimport = mode=='reimport'
            self.request_stop('restart')
            text = self.tr(user,'Saving progress and restarting with ZIP reimport' if self.force_reimport else
                           'Saving progress and starting a fresh session')
        try:
            await query.answer(text)
        except AiogramError:
            logging.info('Restart callback acknowledgement unavailable')
        try:
            await self.api(msg.chat.id,lambda:self.bot.edit_message_text(
                chat_id=msg.chat.id,message_id=msg.message_id,text=text,reply_markup=None))
        except AiogramError:
            logging.info('Restart choice message could not be updated')

    async def handle(self, update):
        membership = getattr(update,'my_chat_member',None)
        if membership:
            member = membership.new_chat_member
            active = member.status in ('member','administrator','creator') or (member.status=='restricted' and getattr(member,'is_member',False))
            self.broadcasts.track(membership.chat.id,membership.chat.type,active)
            return
        if getattr(update, 'callback_query', None):
            if (update.callback_query.data or '').startswith('broadcast:'):
                await self.broadcasts.callback(update.callback_query)
            elif (update.callback_query.data or '').startswith('settings:'):
                await self.settings_callback(update.callback_query)
            elif (update.callback_query.data or '').startswith('extract:'):
                await self.extract_audio_callback(update.callback_query)
            elif (update.callback_query.data or '').startswith('extract_subtitles:'):
                await self.extract_subtitles_callback(update.callback_query)
            elif (update.callback_query.data or '').startswith('caption:'):
                await self.caption_files.callback(update.callback_query)
            elif (update.callback_query.data or '').startswith('restart:'):
                await self.restart_callback(update.callback_query)
            elif (update.callback_query.data or '').startswith('backup:'):
                await self.owner_backup.callback(update.callback_query)
            else:
                await self.select_language(update.callback_query)
            return
        msg = update.message
        if not msg or not msg.from_user or msg.from_user.is_bot:
            return
        self.broadcasts.track(msg.chat.id,getattr(getattr(msg,'chat',None),'type',None))
        if getattr(msg,'migrate_to_chat_id',None):
            self.broadcasts.track(msg.chat.id,active=False)
            self.broadcasts.track(msg.migrate_to_chat_id,'supergroup')
        if getattr(msg,'migrate_from_chat_id',None):
            self.broadcasts.track(msg.migrate_from_chat_id,active=False)
        user = msg.from_user.id
        if not self.state.get(f'language:{user}'):
            await self.language_menu(msg, user)
            return
        async def reply(chat, text, thread=None):
            return await self.tell(chat, self.tr(user, text), thread)
        text = msg.text or msg.caption or ''
        if text.startswith('/'):
            parts = text.split()
            command = parts[0].lower()
            if '@' in command:
                command,target = command.split('@',1)
                if target != self.username.lower():
                    return
            args = parts[1:]
            await self.command(msg,user,command,args)
            return
        for entity in (msg.entities or msg.caption_entities or ()):
            if entity.type == 'text_link' and entity.url:
                text += '\n'+entity.url
        links,bad = extract_links(text)
        if not links:
            if bad:
                await reply(msg.chat.id,'Send a TikTok video or photo post link',msg.message_thread_id)
            return
        if self.stop.is_set():
            await reply(msg.chat.id,'The bot is restarting, please send your links again shortly',msg.message_thread_id)
            return
        rejected = []
        # Commit the complete batch before network replies or Telegram acknowledgment
        admitted = []
        for url in links:
            jid,fresh = self.state.submit(user,msg.chat.id,msg.message_id,msg.message_thread_id,url,user == self.bypass)
            if jid is None:
                rejected.append(url)
            elif fresh:
                admitted.append(jid)
        for jid in admitted:
            row = self.state.job(jid)
            if row['status'] == 'queued':
                queue = [r['id'] for r in self.state.outstanding(user) if r['status']=='queued']
                await self.status(jid,self.tr(user,'Queued, position {n}',n=queue.index(jid)+1))
            # Ready jobs get a status message when their worker starts
        if rejected:
            await reply(msg.chat.id,
                self.tr(user,'You have reached the limit of 4 active downloads and 4 waiting requests\n'
                'These links were not accepted\n')+'\n'.join(rejected)[:3000],msg.message_thread_id)

    async def command(self,msg,user,command,args):
        chat,thread = msg.chat.id,msg.message_thread_id
        async def reply(chat, text, thread=None):
            return await self.tell(chat, self.tr(user, text), thread)
        if command == '/broadcast':
            await self.broadcasts.command(msg,user)
        elif command == '/settings':
            text, keyboard = self.settings_view(user)
            await self.api(chat, lambda: self.bot.send_message(chat, text, message_thread_id=thread, reply_markup=keyboard))
        elif command == '/start':
            await reply(chat,'Send a TikTok video or photo link',thread)
        elif command == '/help':
            lang = self.state.get(f'language:{user}', 'en')
            text = LOCAL_HELP.get(lang, LOCAL_HELP['en'])
            if user == self.owner:
                text += '\n\n' + OWNER_HELP.get(lang, OWNER_HELP['en'])
            await reply(chat,text,thread)
        elif command == '/id':
            await reply(chat,self.tr(user,'Your Telegram ID is {user}',user=user),thread)
        elif command == '/ping':
            # Measure Telegram round-trip time, excluding the local pacing wait
            async def measure():
                started = time.perf_counter()
                message = await self.bot.send_message(chat,'Pong',message_thread_id=thread)
                return message, round((time.perf_counter()-started)*1000)
            message, elapsed = await self.api(chat,measure)
            await self.api(chat, lambda: self.bot.edit_message_text(
                f'Pong! {elapsed}ms',chat_id=chat,message_id=message.message_id))
        elif command in ('/queue','/jobs'):
            if command == '/jobs' and user != self.owner:
                await reply(chat,'Only the bot owner can use this command',thread)
                return
            rows = self.state.outstanding(None if command == '/jobs' else user)
            lines = [self.tr(user,"Job {id}, {status}",id=r["id"],status=self.tr(user,r["status"]))+(", "+self.tr(user,"user {user}",user=r["user_id"]) if command=='/jobs' else '') for r in rows]
            await reply(chat,('\n'.join(lines[:60]) or 'No active or queued requests')+
                            ('\n'+self.tr(user,'And {n} more',n=len(lines)-60) if len(lines)>60 else ''),thread)
        elif command == '/cancel':
            row = self.state.job(int(args[0])) if args and args[0].isdigit() else None
            if not row or (row['user_id'] != user and user != self.owner):
                await reply(chat,'Use /cancel followed by one of your job numbers',thread)
                return
            if row['status'] not in ('ready','running','queued'):
                await reply(chat,'This request has already ended',thread)
                return
            self.state.change(row['id'],status='cancelled')
            task = self.tasks.get(row['id'])
            if task:
                task.cancel()
            await self.status(row['id'],'Cancelled, any upload already accepted by Telegram may still arrive')
        elif command in ('/restart','/upload','/shutdown'):
            if user != self.owner:
                await reply(chat,'Only the bot owner can use this command',thread)
                return
            if self.stop.is_set():
                await reply(chat,'The bot is already stopping',thread)
                return
            if command=='/restart':
                await self.restart_menu(msg,user)
                return
            if command=='/upload':
                await self.owner_backup.command(msg,user)
                return
            reason = command[1:]
            await reply(chat,'Saving progress and stopping' if reason=='shutdown' else 'Saving progress and starting a fresh session',thread)
            self.request_stop(reason)
        else:
            await reply(chat,'Send a TikTok link directly, use /help for available commands',thread)

    async def polling(self):
        offset = int(self.state.get('offset','0'))
        while not self.stop.is_set():
            try:
                updates = await self.bot.get_updates(offset=offset,timeout=15,request_timeout=35,
                    allowed_updates=['message','callback_query','my_chat_member'])
                for update in updates:
                    if self.stop.is_set():
                        break
                    try:
                        await self.handle(update)
                    except AiogramError:
                        # Jobs were saved before replies, don't drop them because a reply failed
                        logging.info('A command reply could not be delivered')
                    offset = update.update_id+1
                    self.state.set('offset',offset)
            except TelegramRetryAfter as exc:
                await asyncio.sleep(exc.retry_after+1)
            except (TelegramNetworkError,TelegramServerError,ClientDecodeError):
                await asyncio.sleep(3)

    async def scheduler(self):
        while not self.stop.is_set():
            self.state.promote()
            for row in self.state.ready():
                jid = row['id']
                if jid in self.tasks:
                    continue
                self.state.change(jid,status='running')
                self.tasks[jid] = asyncio.create_task(self.run_job(jid))
            for jid,task in list(self.tasks.items()):
                if task.done():
                    try:
                        task.result()
                    except asyncio.CancelledError:
                        pass
                    except Exception:
                        logging.error('Job %s ended unexpectedly',jid)
                        self.state.change(jid,status='failed')
                    del self.tasks[jid]
            await asyncio.sleep(0.25)

    async def worker(self, row, folder):
        folder.mkdir(parents=True,exist_ok=True)
        self.caption_files.snapshot(row['id'])
        job = self.state.job(row['id'])
        saved = job['compression']
        settings = compression_options(saved or self.state.get(f"compression:{row['user_id']}"))
        if saved is None:
            self.state.change(row['id'],compression=json.dumps(settings))
        audio_mode = job['audio_mode']
        subtitle_mode = job['subtitle_mode']
        if audio_mode is None:
            audio_mode = media_preference(self.state.get(f"audio:{row['user_id']}"),'on')
            self.state.change(row['id'],audio_mode=audio_mode)
        if subtitle_mode is None:
            subtitle_mode = ('on' if job['subtitles'] else 'off') if job['subtitles'] is not None else media_preference(
                self.state.get(f"subtitles:{row['user_id']}"),'off_no_button')
            self.state.change(row['id'],subtitle_mode=subtitle_mode)
        subtitles = int(not row['audio_only'] and (row['subtitles_only'] or subtitle_mode=='on'))
        if job['subtitles'] is None:
            self.state.change(row['id'],subtitles=subtitles)
        process = await asyncio.create_subprocess_exec(sys.executable,str(ROOT/'worker.py'),row['url'],str(folder),
                       '--audio='+audio_mode,
                       '--subtitles='+('off' if row['audio_only'] else 'on' if row['subtitles_only'] else subtitle_mode),
                       '--compression='+json.dumps(settings),
                       *(['--audio-only'] if row['audio_only'] else []),
                       *(['--subtitles-only'] if row['subtitles_only'] else []),
                       stdout=asyncio.subprocess.DEVNULL,stderr=asyncio.subprocess.DEVNULL,start_new_session=True)
        async def progress():
            while process.returncode is None:
                if (folder/'progress.txt').is_file():
                    await self.status(row['id'],'Compressing...')
                    return
                await asyncio.sleep(1)
        watcher = asyncio.create_task(progress())
        try:
            timeout = 600 if row['audio_only'] or row['subtitles_only'] or settings['mode']=='none' else 2400
            await asyncio.wait_for(process.wait(),timeout=timeout)
            result = folder/'result.json'
            if not result.exists():
                logging.warning('Download worker ended without a result, exit code %s',process.returncode)
                return {'ok':False,'error':'unavailable'}
            payload = json.loads(result.read_text())
            self.log_diagnostics(payload)
            return payload
        finally:
            watcher.cancel()
            with suppress(asyncio.CancelledError):
                await watcher
            if process.returncode is None:
                with suppress(ProcessLookupError):
                    os.killpg(process.pid,signal.SIGTERM)
                try:
                    await asyncio.wait_for(process.wait(),10)
                except asyncio.TimeoutError:
                    with suppress(ProcessLookupError):
                        os.killpg(process.pid,signal.SIGKILL)
                    await process.wait()

    @staticmethod
    def log_diagnostics(payload):
        for entry in payload.get('diagnostics',[])[:40]:
            if not isinstance(entry,dict):
                continue
            # A second boundary prevents raw exception messages or links from
            # ever appearing in Actions logs, even from a malformed worker result.
            fields = []
            for key in ('stage','reason','exception'):
                value = entry.get(key)
                if isinstance(value,str) and re.fullmatch(r'[A-Za-z_]{1,80}',value):
                    fields.append(key+'='+value)
            if isinstance(entry.get('status'),int):
                fields.append('status='+str(entry['status']))
            if fields:
                logging.info('Download diagnostic: %s', ' '.join(fields))
        if not payload.get('ok') or payload.get('audio_error'):
            logging.warning('Download did not complete%s', ' its audio attachment' if payload.get('ok') else '')

    @staticmethod
    def groups(records,folder):
        groups = []
        for index,record in enumerate(records):
            prefix = ('audio' if record['kind']=='audio' else
                      'subtitle:'+record.get('subtitle_id',record['file']) if record['kind']=='subtitle' else str(index))
            record = dict(record,key=f"{prefix}:{record.get('source_sha256',record['sha256'])}")
            path = folder/record['file']
            if path.parent != folder or not path.is_file() or path.stat().st_size > MAX_BYTES:
                raise ValueError('Invalid media file')
            if record['kind']=='audio':
                kind = 'audio'
            elif record['kind']=='subtitle':
                kind = 'subtitle'
            elif record['kind']=='video':
                kind = 'video' if path.suffix == '.mp4' else 'document'
            else:
                w,h = record['width'],record['height']
                kind = 'photo' if path.suffix in ('.jpg','.png') and path.stat().st_size<=10_000_000 and 0 < w+h<=10000 and max(w,h)/max(1,min(w,h))<=20 else 'document'
            if groups and kind not in ('video','audio','subtitle') and groups[-1][0]==kind and len(groups[-1][1])<10:
                groups[-1][1].append(record)
            else:
                groups.append((kind,[record]))
        return groups

    @staticmethod
    def media_caption(title, account_name='', username=''):
        return Runner.caption_content(title,account_name,username)[0]

    @staticmethod
    def caption_content(title, account_name='', username=''):
        def truncate(text, budget):
            encoded = text.encode('utf-16-le', errors='replace')
            if len(encoded) <= budget * 2:
                return text
            return encoded[:(budget-1)*2].decode('utf-16-le', errors='ignore') + '…'

        title = str(title or '').strip()
        name = ' '.join(str(account_name or '').split())
        username = ' '.join(str(username or '').split()).lstrip('@')
        header = f'{name} (@{username})' if name and username else name or (f'@{username}' if username else '')
        header = truncate(header, 256)
        footer = BOT_ATTRIBUTION
        parts = ['<pre>' + escape(header) + '</pre>'] if header else []
        too_long = False
        if title:
            # Count visible UTF-16 units, reserving separators and attribution
            budget = 1024 - len(BOT_NAME) - 2
            if header:
                budget -= len(header.encode('utf-16-le')) // 2 + 1
            too_long = len(title.encode('utf-16-le',errors='replace')) // 2 > budget
            parts.append('<blockquote>' + escape(truncate(title, budget)) + '</blockquote>')
        return '\n'.join(parts) + ('\n\n' if parts else '') + footer, too_long

    async def deliver(self,jid,records,folder,title='',account_name='',username='',post_id=None):
        await self.install_audio_button(jid)
        caption, too_long = self.caption_content(title,account_name,username)
        if any(record['kind'] in ('image','video') for record in records):
            self.caption_files.remember(jid,title,post_id,too_long)
        await self.caption_files.install(jid)
        row = self.state.job(jid)
        sent = set(json.loads(row['sent']))
        reply_message = row['reply_message']
        photo_reply_message = row['photo_reply_message']
        groups = self.groups(records,folder)
        if photo_reply_message is None and any(
                r['kind']=='image' and r['key'] in sent for _,group in groups for r in group):
            # Older receipts stored only the first delivered message as a reply target.
            photo_reply_message = reply_message
        for kind,group in groups:
            group = [r for r in group if r['key'] not in sent]
            if not group:
                continue
            if self.stop.is_set() or self.state.job(jid)['status']=='cancelled':
                raise asyncio.CancelledError()
            await self.status(jid,'Uploading...')
            # Durable intent precedes the send, an interrupted send is never blindly repeated
            self.state.change(jid,in_flight=json.dumps([r['key'] for r in group]))
            try:
                delivered = None
                uploads = [FSInputFile(folder/r['file'],filename=r.get('filename')) for r in group]
                kwargs = {'chat_id':row['chat_id'],'message_thread_id':row['thread_id'],
                          'request_timeout':150,
                          'reply_parameters':ReplyParameters(message_id=row['message_id'],
                                                            allow_sending_without_reply=True)}
                photo_batch = all(r['kind']=='image' for r in group)
                group_caption = caption
                if photo_batch and photo_reply_message:
                    kwargs['reply_parameters'] = ReplyParameters(
                        message_id=photo_reply_message,allow_sending_without_reply=True)
                    group_caption = BOT_ATTRIBUTION
                binding = self.state.job(jid)
                manual_audio = bool(group[0].get('manual_audio'))
                manual_subtitles = bool(group[0].get('manual_subtitles') and group[0]['kind']=='video')
                button_needed = bool((manual_audio and not (binding['audio_button_message'] or binding['audio_button_pending']))
                                     or (manual_subtitles and not binding['subtitle_button_message']))
                if button_needed:
                    self.state.change(jid,manual_audio=int(manual_audio),manual_subtitles=int(manual_subtitles))
                    if len(group)==1:
                        kwargs['reply_markup'] = self.extraction_keyboard(
                            row['user_id'],jid,audio=manual_audio,subtitles=manual_subtitles)
                async def single(method,field,**extra):
                    # FSInputFile opens a fresh stream for every attempt and fallback.
                    return await method(**{field:uploads[0]},caption=BOT_ATTRIBUTION if kind in ('audio','subtitle') else group_caption,parse_mode='HTML',**kwargs,**extra)
                if kind=='audio':
                    if group[0].get('reply_to_source'):
                        reply_message = row['message_id']
                    if not reply_message:
                        raise ValueError('The media reply target is unavailable')
                    kwargs['reply_parameters'] = ReplyParameters(message_id=reply_message)
                    record = group[0]
                    for field in ('title','performer','duration'):
                        if record.get(field) is not None:
                            kwargs[field] = record[field]
                    if record.get('thumbnail'):
                        thumbnail = folder/record['thumbnail']
                        if thumbnail.parent == folder and thumbnail.is_file() and thumbnail.stat().st_size < 200_000:
                            kwargs['thumbnail'] = FSInputFile(thumbnail)
                    delivered = await self.api(row['chat_id'],lambda:single(self.bot.send_audio,'audio'))
                elif kind=='subtitle':
                    if group[0].get('reply_to_source'):
                        reply_message = row['message_id']
                    if not reply_message:
                        raise ValueError('The video reply target is unavailable')
                    kwargs['reply_parameters'] = ReplyParameters(message_id=reply_message)
                    delivered = await self.api(row['chat_id'],lambda:single(self.bot.send_document,'document'))
                elif len(group)>1:
                    cls = InputMediaPhoto if kind=='photo' else InputMediaDocument
                    media = [cls(media=f,caption=group_caption if i==0 else None,parse_mode='HTML') for i,f in enumerate(uploads)]
                    delivered = await self.api(row['chat_id'],lambda:self.bot.send_media_group(media=media,**kwargs))
                elif kind=='photo':
                    delivered = await self.api(row['chat_id'],lambda:single(self.bot.send_photo,'photo'))
                elif kind=='video':
                    try:
                        record = group[0]
                        video_info = {key:int(record[key]) for key in ('width','height','duration')
                                      if isinstance(record.get(key),(int,float)) and record[key]>0}
                        if record.get('supports_streaming') is not None:
                            video_info['supports_streaming'] = bool(record['supports_streaming'])
                        delivered = await self.api(row['chat_id'],lambda:single(self.bot.send_video,'video',**video_info))
                    except TelegramBadRequest:
                        # A rejected video send has no delivery, offer its unchanged bytes as a file.
                        delivered = await self.api(row['chat_id'],lambda:single(self.bot.send_document,'document'))
                else:
                    delivered = await self.api(row['chat_id'],lambda:single(self.bot.send_document,'document'))
            except TelegramEntityTooLarge:
                # aiogram makes HTTP 413 a NetworkError subclass despite a definitive rejection.
                self.state.change(jid,in_flight=None)
                raise
            except (TelegramNetworkError,TelegramServerError,ClientDecodeError):
                # No usable acknowledgement: retain intent to prevent duplicate uploads.
                raise
            except TelegramAPIError:
                # aiogram separates definitive rejections such as HTTP 413/404 from BadRequest.
                self.state.change(jid,in_flight=None)
                raise
            # No await between a successful send and saving the receipt
            sent.update(r['key'] for r in group)
            button_receipt = {}
            if kind not in ('audio','subtitle'):
                message = delivered[0] if isinstance(delivered,(tuple,list)) and delivered else delivered
                message_id = getattr(message,'message_id',None)
                if not reply_message:
                    reply_message = message_id
                if photo_batch and message_id:
                    photo_reply_message = message_id
                if button_needed:
                    if manual_audio:
                        button_receipt.update(audio_button_message=None if len(group)>1 else message_id,
                                              audio_button_pending=int(len(group)>1))
                    if manual_subtitles:
                        button_receipt['subtitle_button_message'] = message_id
            self.state.change(jid,sent=json.dumps(sorted(sent)),in_flight=None,
                              reply_message=reply_message,photo_reply_message=photo_reply_message,**button_receipt)
            await self.install_audio_button(jid)
            await self.caption_files.install(jid)
        await self.caption_files.automatic(jid)

    async def run_job(self,jid):
        folder = self.work/str(jid)
        try:
            row = self.state.job(jid)
            await self.status(jid,'Downloading...')
            result = None
            for attempt in range(3):
                shutil.rmtree(folder,ignore_errors=True)
                result = await self.worker(row,folder)
                if result['ok'] or result['error'] in ('too_large','audio_too_large','authentication','sound_unavailable',
                                                      'compression_too_large','compression_failed','video_input_too_large',
                                                      'no_subtitles','subtitles_too_large'):
                    break
                if attempt<2:
                    await asyncio.sleep(3*(attempt+1))
            if not result['ok']:
                self.state.change(jid,status='failed')
                code = result['error']
                if code=='audio_too_large':
                    await self.status(jid,'This audio is too large, the maximum size is 50 MB')
                elif code=='sound_unavailable':
                    await self.status(jid,'TikTok did not provide this sound, try a video or photo post using it')
                elif code=='audio_unavailable':
                    await self.status(jid,'Audio is unavailable for this post')
                elif code=='no_subtitles':
                    await self.status(jid,'No subtitle files are available for this video')
                elif code=='subtitles_unavailable':
                    await self.status(jid,'Could not download subtitle files for this video')
                elif code=='subtitles_too_large':
                    await self.status(jid,'The subtitle files are too large, the maximum size is 50 MB')
                elif code=='too_large':
                    await self.status(jid,TOO_LARGE)
                elif code=='compression_too_large':
                    await self.status(jid,'Could not compress this video below 50 MB, try lower quality or resolution')
                elif code=='compression_failed':
                    await self.status(jid,'Could not compress this video, try again or choose None in Compression settings')
                elif code=='video_input_too_large':
                    await self.status(jid,'This video is too large to process, the maximum download size is 1 GB')
                elif code=='authentication':
                    await self.status(jid,'TikTok refused access to this post, please try again later')
                    if time.time()-float(self.state.get('auth_notice','0'))>3600:
                        self.state.set('auth_notice',time.time())
                        await self.notify_owner('TikTok refused access to a download, check TikTok availability')
                else:
                    await self.status(jid,'Could not download this post, it may be unavailable or TikTok may be blocking access')
                return
            await self.deliver(jid,result['media'],folder,result.get('title',''),
                               result.get('account_name',''),result.get('username',''),result.get('post_id'))
            self.state.change(jid,status='done')
            row = self.state.job(jid)
            notices = []
            if row['caption_mode']=='on' and row['caption_text'] and not row['caption_file_message']:
                notices.append(self.tr(row['user_id'],'Caption delivery is pending or unconfirmed, check the chat'
                                      if row['caption_file_in_flight'] else
                                      'Could not send the caption file, it will be retried after restart'))
            if row['caption_button_in_flight']:
                notices.append(self.tr(row['user_id'],'Telegram did not confirm the caption button, check the chat before sending the link again'))
            elif row['caption_button_pending']:
                notices.append(self.tr(row['user_id'],'Could not add the caption button yet, it will be retried after restart'))
            if row['audio_button_in_flight']:
                notices.append(self.tr(row['user_id'],'Telegram did not confirm the audio button, check the chat before sending the link again'))
            elif row['audio_button_pending']:
                notices.append(self.tr(row['user_id'],'Could not add the audio button yet, it will be retried after restart'))
            if result.get('audio_error'):
                notices.append(self.tr(row['user_id'], 'This audio is too large, the maximum size is 50 MB'
                                      if result['audio_error']=='too_large' else 'Audio is unavailable for this post'))
            if result.get('subtitle_error'):
                notices.append(self.tr(row['user_id'], 'Some subtitle files are too large, the maximum size is 50 MB'
                                      if result['subtitle_error']=='too_large' else 'Some subtitle files could not be downloaded'))
            if notices:
                await self.status(jid,'\n'.join(notices))
            elif row['status_message']:
                try:
                    await self.api(row['chat_id'], lambda: self.bot.delete_message(
                        chat_id=row['chat_id'], message_id=row['status_message']))
                except AiogramError:
                    logging.info('Completed status message could not be removed')
        except asyncio.CancelledError:
            row = self.state.job(jid)
            if row['status'] != 'cancelled':
                self.state.change(jid,status='uncertain' if row['in_flight'] else 'ready')
            raise
        except TelegramEntityTooLarge:
            self.state.change(jid,status='failed')
            await self.status(jid,TOO_LARGE)
        except (TelegramNetworkError,TelegramServerError,ClientDecodeError):
            row = self.state.job(jid)
            self.state.change(jid,status='uncertain' if row['in_flight'] else 'failed')
            await self.status(jid,'Telegram did not confirm delivery, check the chat before sending the link again')
        except Exception:
            row = self.state.job(jid)
            self.state.change(jid,status='uncertain' if row['in_flight'] else 'failed')
            await self.status(jid,'Could not send this post, please try again later')
            logging.info('Job %s could not finish',jid)
        finally:
            shutil.rmtree(folder,ignore_errors=True)

    async def run(self):
        self.state.recover()
        me = await self.bot.get_me()
        self.username = me.username
        await self.bot.delete_webhook(drop_pending_updates=False)
        await self.bot.set_my_commands([BotCommand(command=c,description=d) for c,d in COMMANDS])
        for row in self.state.db.execute('SELECT id FROM jobs WHERE audio_button_pending=1').fetchall():
            await self.install_audio_button(row['id'])
        for row in self.state.db.execute('SELECT id FROM jobs WHERE caption_button_pending=1').fetchall():
            await self.caption_files.install(row['id'])
        for row in self.state.db.execute("""SELECT id FROM jobs WHERE caption_mode='on'
                AND caption_text!='' AND caption_file_message IS NULL AND caption_file_in_flight=0
                AND status!='cancelled'""").fetchall():
            await self.caption_files.automatic(row['id'])
        for row in self.state.db.execute("SELECT id FROM jobs WHERE status='uncertain' AND notified=0").fetchall():
            await self.status(row['id'],'The previous upload was interrupted, check the chat before sending the link again')
            self.state.change(row['id'],notified=1)
        logging.info('Bot started')
        poll = asyncio.create_task(self.polling())
        schedule = asyncio.create_task(self.scheduler())
        announce = asyncio.create_task(self.broadcasts.run())
        stop_wait = asyncio.create_task(self.stop.wait())
        timer = asyncio.create_task(asyncio.sleep(int(os.getenv('SESSION_SECONDS','19800'))))
        try:
            done,_ = await asyncio.wait([poll,schedule,announce,stop_wait,timer],return_when=asyncio.FIRST_COMPLETED)
            if timer in done:
                self.request_stop('time-limit')
            for task in (poll,schedule,announce):
                if task in done:
                    task.result()
                    if not self.stop.is_set():
                        raise RuntimeError('Bot service stopped unexpectedly')
        finally:
            self.stop.set()
            # Finish handling the current update before saving the cursor
            try:
                await asyncio.wait_for(asyncio.shield(poll),20)
            except (asyncio.TimeoutError,Exception):
                poll.cancel()
            schedule.cancel()
            announce.cancel()
            timer.cancel()
            stop_wait.cancel()
            for task in self.tasks.values():
                task.cancel()
            await asyncio.gather(poll,schedule,announce,timer,stop_wait,*self.tasks.values(),return_exceptions=True)
        self.state.checkpoint()
        receipt = {'reason':self.reason,'ok':True,'time':time.time(),
                   'force_reimport':self.force_reimport and self.reason=='restart'}
        (self.data/'receipt.json').write_text(json.dumps(receipt))
        logging.info('Progress saved, session ended with %s',self.reason)


async def main():
    token = os.environ.get('TELEGRAM_BOT_TOKEN','').strip()
    owner = int(os.environ.get('OWNER_ID','0'))
    bypass = int(os.environ.get('QUEUE_BYPASS_USER_ID','0'))
    if not token or owner <= 0:
        raise RuntimeError('Set TELEGRAM_BOT_TOKEN and OWNER_ID')
    if not bypass:
        logging.warning('Queue exemption not configured, set QUEUE_BYPASS_USER_ID to the ID of Tog991')
    data = Path(os.getenv('BOT_DATA_DIR',str(ROOT/'data'))).resolve()
    data.mkdir(parents=True,exist_ok=True)
    (data/'receipt.json').unlink(missing_ok=True)
    cookie = data/'cookies.txt'
    cookie.unlink(missing_ok=True)
    if value := os.getenv('TIKTOK_COOKIES_BASE64','').strip():
        decoded = base64.b64decode(value,validate=True)
        if b'\t' not in decoded:
            raise RuntimeError('TIKTOK_COOKIES_BASE64 must contain a Netscape cookie file')
        cookie.write_bytes(decoded)
        cookie.chmod(0o600)
        os.environ['TIKTOK_COOKIE_FILE'] = str(cookie)
    state = State(data/'state.db')
    try:
        session = AiohttpSession(timeout=150,limit=64)
        async with Bot(token=token,session=session).context() as bot:
            runner = Runner(state,bot,data,owner,bypass)
            for sig in (signal.SIGINT,signal.SIGTERM):
                asyncio.get_running_loop().add_signal_handler(sig,runner.request_stop,'shutdown')
            await runner.run()
    finally:
        state.close()
        cookie.unlink(missing_ok=True)


if __name__=='__main__':
    logging.basicConfig(level=logging.INFO,format='%(asctime)s | %(message)s')
    for name in ('aiogram','aiohttp','botocore','boto3'):
        logging.getLogger(name).setLevel(logging.CRITICAL)
    try:
        asyncio.run(main())
    except Exception as exc:
        # Do not print exception text, it may contain a token-bearing request URL
        logging.error('Session failed with %s, automatic continuation is stopped',type(exc).__name__)
        sys.exit(1)
