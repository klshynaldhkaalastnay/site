"""Telegram TikTok downloader with durable admission and delivery tracking"""
import asyncio
import base64
from collections import defaultdict
from contextlib import ExitStack
import json
from html import escape
import logging
import os
from pathlib import Path
import shutil
import signal
import sys
import time

from telegram import Bot, BotCommand, InputMediaPhoto, InputMediaDocument
from telegram.error import BadRequest, Forbidden, NetworkError, RetryAfter, TelegramError
from telegram.request import HTTPXRequest
from common import extract_links, MAX_BYTES, TOO_LARGE
from state import State

ROOT = Path(__file__).resolve().parent
HELP = ('Send TikTok video or photo links, multiple links work too\n\n'
        'Up to 4 active downloads and 4 waiting requests per user\n'
        'Each photo post counts as one request\n'
        'Maximum file size is 50 MB\n\n'
        '/queue — Your requests\n/cancel <job> — Cancel a request\n'
        '/ping — Check the bot\n/id — Your Telegram ID')
COMMANDS = [('start','How to use the bot'),('help','Show help'),('queue','Your requests'),
            ('cancel','Cancel a request'),('ping','Check the bot'),('id','Your Telegram ID')]


class Runner:
    def __init__(self, state, bot, data, owner, bypass):
        self.state,self.bot,self.data,self.owner,self.bypass = state,bot,data,owner,bypass
        self.stop = asyncio.Event()
        self.reason = 'shutdown'
        self.tasks = {}
        self.chat_locks = defaultdict(asyncio.Lock)
        self.chat_next = defaultdict(float)
        self.global_lock = asyncio.Lock()
        self.global_next = 0.0
        self.username = ''
        self.work = data/'work'
        shutil.rmtree(self.work,ignore_errors=True)
        self.work.mkdir(parents=True,exist_ok=True)

    async def api(self, chat, operation):
        # Apply Telegram pacing to exempt accounts too
        async with self.chat_locks[chat]:
            for attempt in range(4):
                await asyncio.sleep(max(0,self.chat_next[chat]-time.monotonic()))
                async with self.global_lock:
                    await asyncio.sleep(max(0,self.global_next-time.monotonic()))
                    self.global_next = time.monotonic()+0.05
                self.chat_next[chat] = time.monotonic()+(3.2 if chat < 0 else 1.1)
                try:
                    return await operation()
                except RetryAfter as exc:
                    seconds = exc.retry_after.total_seconds() if hasattr(exc.retry_after,'total_seconds') else exc.retry_after
                    if attempt == 3:
                        raise
                    await asyncio.sleep(seconds+1)

    async def tell(self, chat, text, thread=None):
        return await self.api(chat,lambda: self.bot.send_message(chat,text,message_thread_id=thread))

    async def status(self, jid, text):
        row = self.state.job(jid)
        if not row:
            return
        try:
            if row['status_message']:
                await self.api(row['chat_id'],lambda: self.bot.edit_message_text(
                    text,chat_id=row['chat_id'],message_id=row['status_message']))
            else:
                msg = await self.tell(row['chat_id'],text,row['thread_id'])
                self.state.change(jid,status_message=msg.message_id)
        except TelegramError:
            logging.info('Status delivery unavailable for job %s',jid)

    async def notify_owner(self, text):
        try:
            await self.tell(self.owner,text)
        except TelegramError:
            logging.info('Owner notification unavailable, open the bot privately and send /start')

    def request_stop(self, reason):
        if not self.stop.is_set():
            self.reason = reason
            self.stop.set()

    async def handle(self, update):
        msg = update.message
        if not msg or not msg.from_user or msg.from_user.is_bot:
            return
        user = msg.from_user.id
        text = msg.text or msg.caption or ''
        if text.startswith('/'):
            parts = text.split()
            command = parts[0].lower()
            if '@' in command:
                command,target = command.split('@',1)
                if target != self.username.lower():
                    return
            args = parts[1:]
            await self.command(msg,user,command,args)
            return
        for entity in (msg.entities or msg.caption_entities or ()):
            if entity.type == 'text_link' and entity.url:
                text += '\n'+entity.url
        links,bad = extract_links(text)
        if not links:
            if bad:
                await self.tell(msg.chat_id,'Send a TikTok video or photo post link',msg.message_thread_id)
            return
        if self.stop.is_set():
            await self.tell(msg.chat_id,'The bot is restarting, please send your links again shortly',msg.message_thread_id)
            return
        rejected = []
        # Commit the complete batch before network replies or Telegram acknowledgment
        admitted = []
        for url in links:
            jid,fresh = self.state.submit(user,msg.chat_id,msg.message_id,msg.message_thread_id,url,user == self.bypass)
            if jid is None:
                rejected.append(url)
            elif fresh:
                admitted.append(jid)
        for jid in admitted:
            row = self.state.job(jid)
            if row['status'] == 'queued':
                queue = [r['id'] for r in self.state.outstanding(user) if r['status']=='queued']
                await self.status(jid,f'Queued, position {queue.index(jid)+1}')
            # Ready jobs get a status message when their worker starts
        if rejected:
            await self.tell(msg.chat_id,
                'You have reached the limit of 4 active downloads and 4 waiting requests\n'
                'These links were not accepted\n'+'\n'.join(rejected)[:3000],msg.message_thread_id)

    async def command(self,msg,user,command,args):
        chat,thread = msg.chat_id,msg.message_thread_id
        if command in ('/start','/help'):
            text = HELP
            if user == self.owner:
                text += '\n\nOwner commands\n/jobs — All jobs\n/restart — Start a fresh session\n/upload — Back up and restart\n/shutdown — Back up and stop'
            await self.tell(chat,text,thread)
        elif command == '/id':
            await self.tell(chat,f'Your Telegram ID is {user}',thread)
        elif command == '/ping':
            await self.tell(chat,'Pong',thread)
        elif command in ('/queue','/jobs'):
            if command == '/jobs' and user != self.owner:
                await self.tell(chat,'Only the bot owner can use this command',thread)
                return
            rows = self.state.outstanding(None if command == '/jobs' else user)
            lines = [f"Job {r['id']}, {r['status']}"+(f", user {r['user_id']}" if command=='/jobs' else '') for r in rows]
            await self.tell(chat,('\n'.join(lines[:60]) or 'No active or queued requests')+
                            (f'\nAnd {len(lines)-60} more' if len(lines)>60 else ''),thread)
        elif command == '/cancel':
            row = self.state.job(int(args[0])) if args and args[0].isdigit() else None
            if not row or (row['user_id'] != user and user != self.owner):
                await self.tell(chat,'Use /cancel followed by one of your job numbers',thread)
                return
            if row['status'] not in ('ready','running','queued'):
                await self.tell(chat,'This request has already ended',thread)
                return
            self.state.change(row['id'],status='cancelled')
            task = self.tasks.get(row['id'])
            if task:
                task.cancel()
            await self.status(row['id'],'Cancelled, any upload already accepted by Telegram may still arrive')
        elif command in ('/restart','/upload','/shutdown'):
            if user != self.owner:
                await self.tell(chat,'Only the bot owner can use this command',thread)
                return
            if self.stop.is_set():
                await self.tell(chat,'The bot is already stopping',thread)
                return
            reason = command[1:]
            await self.tell(chat,'Saving progress and stopping' if reason=='shutdown' else 'Saving progress and starting a fresh session',thread)
            self.request_stop(reason)
        else:
            await self.tell(chat,'Send a TikTok link directly, use /help for available commands',thread)

    async def polling(self):
        offset = int(self.state.get('offset','0'))
        while not self.stop.is_set():
            try:
                updates = await self.bot.get_updates(offset=offset,timeout=15,allowed_updates=['message'])
                for update in updates:
                    if self.stop.is_set():
                        break
                    try:
                        await self.handle(update)
                    except TelegramError:
                        # Jobs were saved before replies, don't drop them because a reply failed
                        logging.info('A command reply could not be delivered')
                    offset = update.update_id+1
                    self.state.set('offset',offset)
            except (NetworkError,RetryAfter):
                await asyncio.sleep(3)

    async def scheduler(self):
        while not self.stop.is_set():
            self.state.promote()
            for row in self.state.ready():
                jid = row['id']
                if jid in self.tasks:
                    continue
                self.state.change(jid,status='running')
                self.tasks[jid] = asyncio.create_task(self.run_job(jid))
            for jid,task in list(self.tasks.items()):
                if task.done():
                    try:
                        task.result()
                    except asyncio.CancelledError:
                        pass
                    except Exception:
                        logging.error('Job %s ended unexpectedly',jid)
                        self.state.change(jid,status='failed')
                    del self.tasks[jid]
            await asyncio.sleep(0.25)

    async def worker(self, row, folder):
        folder.mkdir(parents=True,exist_ok=True)
        process = await asyncio.create_subprocess_exec(sys.executable,str(ROOT/'worker.py'),row['url'],str(folder),
                       stdout=asyncio.subprocess.DEVNULL,stderr=asyncio.subprocess.DEVNULL,start_new_session=True)
        try:
            await asyncio.wait_for(process.wait(),timeout=600)
            result = folder/'result.json'
            return json.loads(result.read_text()) if result.exists() else {'ok':False,'error':'unavailable'}
        finally:
            if process.returncode is None:
                process.terminate()
                try:
                    await asyncio.wait_for(process.wait(),10)
                except asyncio.TimeoutError:
                    process.kill()
                    await process.wait()

    @staticmethod
    def groups(records,folder):
        groups = []
        for index,record in enumerate(records):
            record = dict(record,key=f"{index}:{record['sha256']}")
            path = folder/record['file']
            if path.parent != folder or not path.is_file() or path.stat().st_size > MAX_BYTES:
                raise ValueError('Invalid media file')
            if record['kind']=='video':
                kind = 'video' if path.suffix == '.mp4' else 'document'
            else:
                w,h = record['width'],record['height']
                kind = 'photo' if path.suffix in ('.jpg','.png') and path.stat().st_size<=10_000_000 and 0 < w+h<=10000 and max(w,h)/max(1,min(w,h))<=20 else 'document'
            if groups and kind != 'video' and groups[-1][0]==kind and len(groups[-1][1])<10:
                groups[-1][1].append(record)
            else:
                groups.append((kind,[record]))
        return groups

    @staticmethod
    def media_caption(title):
        title = str(title or '').strip()
        footer = '@TikTokdownloaderbestbot'
        if not title:
            return footer
        # Telegram counts caption length after HTML parsing, allow for emoji pairs
        budget = 1024 - len(footer) - 2
        encoded = title.encode('utf-16-le', errors='replace')
        if len(encoded) > budget * 2:
            title = encoded[:(budget-1)*2].decode('utf-16-le', errors='ignore') + '…'
        return '<pre>' + escape(title) + '</pre>\n\n' + footer

    async def deliver(self,jid,records,folder,title=''):
        row = self.state.job(jid)
        sent = set(json.loads(row['sent']))
        caption = self.media_caption(title)
        for kind,group in self.groups(records,folder):
            group = [r for r in group if r['key'] not in sent]
            if not group:
                continue
            if self.stop.is_set() or self.state.job(jid)['status']=='cancelled':
                raise asyncio.CancelledError()
            await self.status(jid,'Uploading...')
            # Durable intent precedes the send, an interrupted send is never blindly repeated
            self.state.change(jid,in_flight=json.dumps([r['key'] for r in group]))
            try:
                with ExitStack() as stack:
                    handles = [stack.enter_context((folder/r['file']).open('rb')) for r in group]
                    kwargs = {'chat_id':row['chat_id'],'message_thread_id':row['thread_id'],
                              'read_timeout':150,'write_timeout':150}
                    async def single(method,field):
                        handles[0].seek(0)
                        return await method(**{field:handles[0]},caption=caption,parse_mode='HTML',**kwargs)
                    if len(group)>1:
                        cls = InputMediaPhoto if kind=='photo' else InputMediaDocument
                        media = [cls(media=h,caption=caption if i==0 else None,parse_mode='HTML') for i,h in enumerate(handles)]
                        await self.api(row['chat_id'],lambda:self.bot.send_media_group(media=media,**kwargs))
                    elif kind=='photo':
                        await self.api(row['chat_id'],lambda:single(self.bot.send_photo,'photo'))
                    elif kind=='video':
                        try:
                            await self.api(row['chat_id'],lambda:single(self.bot.send_video,'video'))
                        except BadRequest:
                            # A rejected video send has no delivery, offer its unchanged bytes as a file
                            await self.api(row['chat_id'],lambda:single(self.bot.send_document,'document'))
                    else:
                        await self.api(row['chat_id'],lambda:single(self.bot.send_document,'document'))
            except (BadRequest,Forbidden,RetryAfter):
                self.state.change(jid,in_flight=None)
                raise
            # No await between a successful send and saving the receipt
            sent.update(r['key'] for r in group)
            self.state.change(jid,sent=json.dumps(sorted(sent)),in_flight=None)

    async def run_job(self,jid):
        folder = self.work/str(jid)
        try:
            row = self.state.job(jid)
            await self.status(jid,'Downloading...')
            result = None
            for attempt in range(3):
                shutil.rmtree(folder,ignore_errors=True)
                result = await self.worker(row,folder)
                if result['ok'] or result['error'] in ('too_large','authentication'):
                    break
                if attempt<2:
                    await asyncio.sleep(3*(attempt+1))
            if not result['ok']:
                self.state.change(jid,status='failed')
                code = result['error']
                if code=='too_large':
                    await self.status(jid,TOO_LARGE)
                elif code=='authentication':
                    await self.status(jid,'TikTok refused access to this post, please try again later')
                    if time.time()-float(self.state.get('auth_notice','0'))>3600:
                        self.state.set('auth_notice',time.time())
                        await self.notify_owner('TikTok refused access to a download, check cookie access and TikTok availability\nIf you update TIKTOK_COOKIES_BASE64, use /restart to load it')
                else:
                    await self.status(jid,'Could not download this post, it may be unavailable or TikTok may be blocking access')
                return
            await self.deliver(jid,result['media'],folder,result.get('title',''))
            self.state.change(jid,status='done')
            row = self.state.job(jid)
            if row['status_message']:
                try:
                    await self.api(row['chat_id'], lambda: self.bot.delete_message(
                        chat_id=row['chat_id'], message_id=row['status_message']))
                except TelegramError:
                    logging.info('Completed status message could not be removed')
        except asyncio.CancelledError:
            row = self.state.job(jid)
            if row['status'] != 'cancelled':
                self.state.change(jid,status='uncertain' if row['in_flight'] else 'ready')
            raise
        except NetworkError:
            row = self.state.job(jid)
            self.state.change(jid,status='uncertain' if row['in_flight'] else 'failed')
            await self.status(jid,'Telegram did not confirm delivery, check the chat before sending the link again')
        except Exception:
            row = self.state.job(jid)
            self.state.change(jid,status='uncertain' if row['in_flight'] else 'failed')
            await self.status(jid,'Could not send this post, please try again later')
            logging.info('Job %s could not finish',jid)
        finally:
            shutil.rmtree(folder,ignore_errors=True)

    async def run(self):
        self.state.recover()
        me = await self.bot.get_me()
        self.username = me.username
        await self.bot.delete_webhook(drop_pending_updates=False)
        await self.bot.set_my_commands([BotCommand(*c) for c in COMMANDS])
        for row in self.state.db.execute("SELECT id FROM jobs WHERE status='uncertain' AND notified=0").fetchall():
            await self.status(row['id'],'The previous upload was interrupted, check the chat before sending the link again')
            self.state.change(row['id'],notified=1)
        logging.info('Bot started')
        poll = asyncio.create_task(self.polling())
        schedule = asyncio.create_task(self.scheduler())
        stop_wait = asyncio.create_task(self.stop.wait())
        timer = asyncio.create_task(asyncio.sleep(int(os.getenv('SESSION_SECONDS','19800'))))
        try:
            done,_ = await asyncio.wait([poll,schedule,stop_wait,timer],return_when=asyncio.FIRST_COMPLETED)
            if timer in done:
                self.request_stop('time-limit')
            for task in (poll,schedule):
                if task in done:
                    task.result()
                    if not self.stop.is_set():
                        raise RuntimeError('Bot service stopped unexpectedly')
        finally:
            self.stop.set()
            # Finish handling the current update before saving the cursor
            try:
                await asyncio.wait_for(asyncio.shield(poll),20)
            except (asyncio.TimeoutError,Exception):
                poll.cancel()
            schedule.cancel()
            timer.cancel()
            stop_wait.cancel()
            for task in self.tasks.values():
                task.cancel()
            await asyncio.gather(poll,schedule,timer,stop_wait,*self.tasks.values(),return_exceptions=True)
        self.state.checkpoint()
        receipt = {'reason':self.reason,'ok':True,'time':time.time()}
        (self.data/'receipt.json').write_text(json.dumps(receipt))
        logging.info('Progress saved, session ended with %s',self.reason)


async def main():
    token = os.environ.get('TELEGRAM_BOT_TOKEN','').strip()
    owner = int(os.environ.get('OWNER_ID','0'))
    bypass = int(os.environ.get('QUEUE_BYPASS_USER_ID','0'))
    if not token or owner <= 0:
        raise RuntimeError('Set TELEGRAM_BOT_TOKEN and OWNER_ID')
    if not bypass:
        logging.warning('Queue exemption not configured, set QUEUE_BYPASS_USER_ID to the ID of Tog991')
    data = Path(os.getenv('BOT_DATA_DIR',str(ROOT/'data'))).resolve()
    data.mkdir(parents=True,exist_ok=True)
    (data/'receipt.json').unlink(missing_ok=True)
    cookie = data/'cookies.txt'
    cookie.unlink(missing_ok=True)
    if value := os.getenv('TIKTOK_COOKIES_BASE64','').strip():
        decoded = base64.b64decode(value,validate=True)
        if b'\t' not in decoded:
            raise RuntimeError('TIKTOK_COOKIES_BASE64 must contain a Netscape cookie file')
        cookie.write_bytes(decoded)
        cookie.chmod(0o600)
        os.environ['TIKTOK_COOKIE_FILE'] = str(cookie)
    state = State(data/'state.db')
    request = HTTPXRequest(connection_pool_size=64,read_timeout=150,write_timeout=150,pool_timeout=60)
    try:
        async with Bot(token,request=request) as bot:
            runner = Runner(state,bot,data,owner,bypass)
            for sig in (signal.SIGINT,signal.SIGTERM):
                asyncio.get_running_loop().add_signal_handler(sig,runner.request_stop,'shutdown')
            await runner.run()
    finally:
        state.close()
        cookie.unlink(missing_ok=True)


if __name__=='__main__':
    logging.basicConfig(level=logging.INFO,format='%(asctime)s | %(message)s')
    for name in ('httpx','httpcore','telegram','botocore','boto3'):
        logging.getLogger(name).setLevel(logging.CRITICAL)
    try:
        asyncio.run(main())
    except Exception as exc:
        # Do not print exception text, it may contain a token-bearing request URL
        logging.error('Session failed with %s, automatic continuation is stopped',type(exc).__name__)
        sys.exit(1)
