"""Read current runner specifications with the cached neofetch executable."""
import asyncio
from contextlib import suppress
from html import escape
import os
from pathlib import Path
import re
import shutil
import signal

TIMEOUT_SECONDS = 10
ANSI_ESCAPE = re.compile(r'\x1b(?:\[[0-?]*[ -/]*[@-~]|\][^\x07\x1b]*(?:\x07|\x1b\\)|[@-Z\\-_])')
CONTROL_CHARACTERS = re.compile(r'[\x00-\x08\x0b-\x1f\x7f]')


class SpecsUnavailable(RuntimeError):
    pass


async def read_specs():
    cached = Path.home()/'.neofetch/neofetch'
    executable = str(cached) if cached.is_file() and os.access(cached,os.X_OK) else shutil.which('neofetch')
    if not executable:
        raise SpecsUnavailable('neofetch is not installed')
    process = await asyncio.create_subprocess_exec(
        executable,'--stdout',stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.DEVNULL,start_new_session=True)
    try:
        output,_ = await asyncio.wait_for(process.communicate(),TIMEOUT_SECONDS)
    except BaseException:
        # Stop neofetch and its probes when a command times out or is cancelled.
        with suppress(ProcessLookupError):
            os.killpg(process.pid,signal.SIGKILL)
        await process.communicate()
        raise
    text = ANSI_ESCAPE.sub('',output.decode('utf-8',errors='replace'))
    text = CONTROL_CHARACTERS.sub('',text.replace('\r\n','\n')).strip('\n')
    if process.returncode or not text.strip():
        raise SpecsUnavailable('neofetch did not return specifications')
    return text


def code_blocks(text):
    # 2,000 Unicode characters fit even when every character uses two UTF-16 units.
    return ['<pre>'+escape(text[start:start+2000],quote=False)+'</pre>'
            for start in range(0,len(text),2000)]
