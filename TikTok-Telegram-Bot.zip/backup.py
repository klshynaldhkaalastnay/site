"""Only source files and a consistent SQLite snapshot enter R2 backups"""
import hashlib
import json
import os
from pathlib import Path
import re
import sqlite3
import sys
import tempfile
import time
import zipfile

import boto3
from botocore.config import Config
from boto3.s3.transfer import TransferConfig


def check_db(path):
    if not path.is_file():
        raise RuntimeError('State database is missing')
    with sqlite3.connect(f'file:{path}?mode=ro',uri=True) as db:
        if db.execute('PRAGMA quick_check').fetchone()[0] != 'ok':
            raise RuntimeError('State database is invalid')
        db.execute('SELECT id FROM jobs LIMIT 1')
        db.execute('SELECT value FROM meta LIMIT 1')


def connection():
    required = ('R2_ACCOUNT_ID','R2_ACCESS_KEY_ID','R2_SECRET_ACCESS_KEY','R2_BUCKET_NAME')
    if any(not os.getenv(k) for k in required):
        raise RuntimeError('Set all R2 backup credentials')
    client = boto3.client('s3',endpoint_url=f"https://{os.environ['R2_ACCOUNT_ID']}.r2.cloudflarestorage.com",
        aws_access_key_id=os.environ['R2_ACCESS_KEY_ID'],aws_secret_access_key=os.environ['R2_SECRET_ACCESS_KEY'],
        region_name='auto',config=Config(request_checksum_calculation='when_required',response_checksum_validation='when_required'))
    scope = os.getenv('GITHUB_WORKFLOW_REF','local')
    prefix = 'tiktok-bot-backups/'+hashlib.sha256(scope.encode()).hexdigest()[:24]+'/'
    return client,os.environ['R2_BUCKET_NAME'],prefix


def managed(client,bucket,prefix):
    pattern = re.compile(re.escape(prefix)+r'backup-\d+-[A-Za-z0-9_-]+\.zip$')
    entries = []
    for page in client.get_paginator('list_objects_v2').paginate(Bucket=bucket,Prefix=prefix):
        entries.extend(x for x in page.get('Contents',[]) if pattern.fullmatch(x['Key']))
    return sorted(entries,key=lambda x:x['LastModified'],reverse=True)


def backup(data,source):
    check_db(data/'state.db')
    client,bucket,prefix = connection()
    old = managed(client,bucket,prefix)
    run = re.sub(r'[^A-Za-z0-9_-]','_',os.getenv('GITHUB_RUN_ID','local')+'-'+os.getenv('GITHUB_RUN_ATTEMPT','1'))
    key = prefix+f'backup-{time.time_ns()}-{run}.zip'
    with tempfile.TemporaryDirectory() as td:
        snapshot = Path(td)/'state.db'
        with sqlite3.connect(data/'state.db') as src,sqlite3.connect(snapshot) as dst:
            src.backup(dst)
        check_db(snapshot)
        archive = Path(td)/'backup.zip'
        with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
            z.write(snapshot,'state/state.db')
            for file in source.iterdir():
                if file.is_file() and not file.is_symlink() and (file.suffix=='.py' or file.name in ('requirements.txt','README.md')):
                    z.write(file,'app/'+file.name)
            workflow = source/'.github/workflows/tik.yml'
            if workflow.is_file():
                z.write(workflow,'app/.github/workflows/tik.yml')
        digest = hashlib.sha256(archive.read_bytes()).hexdigest()
        client.upload_file(str(archive),bucket,key,ExtraArgs={'Metadata':{'sha256':digest},'ContentType':'application/zip'},
                           Config=TransferConfig(preferred_transfer_client='classic'))
        result = client.get_object(Bucket=bucket,Key=key)
        verify = hashlib.sha256()
        count = 0
        try:
            for chunk in result['Body'].iter_chunks(1024*1024):
                verify.update(chunk)
                count += len(chunk)
        finally:
            result['Body'].close()
        if verify.hexdigest()!=digest or count!=archive.stat().st_size:
            raise RuntimeError('R2 verification failed, previous backups retained')
        for entry in old:
            client.delete_object(Bucket=bucket,Key=entry['Key'])
    print('R2 backup verified, previous backups removed')


def restore(data):
    data.mkdir(parents=True,exist_ok=True)
    if (data/'state.db').exists():
        check_db(data/'state.db')
        print('Using validated cached state')
        return
    client,bucket,prefix = connection()
    entries = managed(client,bucket,prefix)
    if not entries:
        print('No previous state, starting a new bot')
        return
    # Fail on corruption rather than silently roll back delivered-job receipts
    result = client.get_object(Bucket=bucket,Key=entries[0]['Key'])
    with tempfile.TemporaryDirectory() as td:
        archive = Path(td)/'restore.zip'
        digest = hashlib.sha256()
        try:
            with archive.open('wb') as out:
                for chunk in result['Body'].iter_chunks(1024*1024):
                    out.write(chunk)
                    digest.update(chunk)
        finally:
            result['Body'].close()
        if result.get('Metadata',{}).get('sha256') != digest.hexdigest():
            raise RuntimeError('R2 state checksum failed')
        with zipfile.ZipFile(archive) as z:
            info = z.getinfo('state/state.db')
            if info.file_size>256_000_000:
                raise RuntimeError('State database is unexpectedly large')
            tmp = data/'restore.db'
            with z.open(info) as inp,tmp.open('wb') as out:
                import shutil
                shutil.copyfileobj(inp,out)
        check_db(tmp)
        tmp.replace(data/'state.db')
    print('Restored verified R2 state')


def receipt(data):
    info = json.loads((data/'receipt.json').read_text())
    if info.get('ok') is not True or info.get('reason') not in ('shutdown','restart','upload','time-limit'):
        raise RuntimeError('Session did not finish cleanly')
    check_db(data/'state.db')
    with open(os.environ['GITHUB_OUTPUT'],'a') as out:
        out.write('reason='+info['reason']+'\n')
        out.write('ok=true\n')


if __name__=='__main__':
    mode = sys.argv[1]
    data = Path(os.getenv('BOT_DATA_DIR','data')).resolve()
    try:
        if mode=='check':
            client,bucket,_ = connection()
            client.head_bucket(Bucket=bucket)
            print('R2 configuration checked')
        elif mode=='restore':
            restore(data)
        elif mode=='backup':
            backup(data,Path(os.getenv('BOT_SOURCE_DIR','.')).resolve())
        elif mode=='receipt':
            receipt(data)
        else:
            raise RuntimeError('Unknown backup command')
    except Exception as exc:
        print(f'Backup operation failed, {type(exc).__name__}, automatic continuation is stopped',file=sys.stderr)
        sys.exit(1)
