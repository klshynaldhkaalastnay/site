"""Synchronous SQLite transactions, used only on the bot event-loop thread"""
import json
import re
import sqlite3
import time
from common import ACTIVE, WAITING, PRIVILEGED_ACTIVE

BUTTON_COOLDOWN = 100
QUEUE_MODES = {'parallel':'Five at once','sequential':'One at a time'}


class State:
    def __init__(self, path):
        self.db = sqlite3.connect(path)
        self.db.row_factory = sqlite3.Row
        self.db.execute('PRAGMA journal_mode=WAL')
        self.db.execute('PRAGMA synchronous=FULL')
        self.db.executescript('''
        CREATE TABLE IF NOT EXISTS meta(key TEXT PRIMARY KEY, value TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS jobs(
          id INTEGER PRIMARY KEY, user_id INTEGER NOT NULL, chat_id INTEGER NOT NULL,
          message_id INTEGER NOT NULL, thread_id INTEGER, url TEXT NOT NULL,
          privileged INTEGER NOT NULL, status TEXT NOT NULL, status_message INTEGER,
          created REAL NOT NULL, sent TEXT NOT NULL DEFAULT '[]',
          in_flight TEXT, notified INTEGER NOT NULL DEFAULT 0,
          audio_only INTEGER NOT NULL DEFAULT 0, subtitles_only INTEGER NOT NULL DEFAULT 0,
          request_token TEXT NOT NULL DEFAULT '',
          UNIQUE(chat_id,message_id,url,audio_only,subtitles_only,request_token));
        CREATE INDEX IF NOT EXISTS jobs_status ON jobs(status,user_id,id);
        CREATE TABLE IF NOT EXISTS mirror_receipts(
          source_job INTEGER NOT NULL,name TEXT NOT NULL,digest TEXT NOT NULL,
          onlyfiles TEXT,github TEXT,PRIMARY KEY(source_job,name,digest));
        CREATE TABLE IF NOT EXISTS mirror_edits(
          job_id INTEGER NOT NULL,message_id INTEGER NOT NULL,file_key TEXT NOT NULL,
          digest TEXT,has_body INTEGER NOT NULL,keyboard TEXT,
          PRIMARY KEY(job_id,message_id));
        ''')
        # Existing queue databases retain all requests during this additive migration
        for column,kind in (('metadata_mode','TEXT'),('metadata_format','TEXT'),('metadata_data','BLOB'),
                            ('metadata_post_id','TEXT'),('metadata_button_message','INTEGER'),
                            ('metadata_file_message','INTEGER'),('metadata_request_token','TEXT'),
                            ('metadata_button_pending','INTEGER NOT NULL DEFAULT 0'),
                            ('metadata_button_in_flight','INTEGER NOT NULL DEFAULT 0'),
                            ('metadata_file_in_flight','INTEGER NOT NULL DEFAULT 0')):
            if column not in {r[1] for r in self.db.execute('PRAGMA table_info(jobs)')}:
                self.db.execute(f'ALTER TABLE jobs ADD COLUMN {column} {kind}')
        for column,kind in (('files_mode','TEXT'),('files_only','INTEGER NOT NULL DEFAULT 0'),
                            ('files_photo_reply_message','INTEGER'),
                            ('files_button_message','INTEGER'),('files_button_pending','INTEGER NOT NULL DEFAULT 0'),
                            ('files_button_in_flight','INTEGER NOT NULL DEFAULT 0')):
            if column not in {r[1] for r in self.db.execute('PRAGMA table_info(jobs)')}:
                self.db.execute(f'ALTER TABLE jobs ADD COLUMN {column} {kind}')
        for column in ('reply_message', 'photo_reply_message', 'audio_button_message','subtitle_button_message'):
            if column not in {r[1] for r in self.db.execute('PRAGMA table_info(jobs)')}:
                self.db.execute(f'ALTER TABLE jobs ADD COLUMN {column} INTEGER')
        for column in ('audio_only', 'subtitles_only', 'manual_audio', 'manual_subtitles', 'audio_button_pending'):
            if column not in {r[1] for r in self.db.execute('PRAGMA table_info(jobs)')}:
                self.db.execute(f'ALTER TABLE jobs ADD COLUMN {column} INTEGER NOT NULL DEFAULT 0')
        if 'audio_button_in_flight' not in {r[1] for r in self.db.execute('PRAGMA table_info(jobs)')}:
            self.db.execute('ALTER TABLE jobs ADD COLUMN audio_button_in_flight INTEGER NOT NULL DEFAULT 0')
            # Earlier versions bound album buttons to the last photo. Replace
            # those bindings with a visible reply, including acknowledged edits.
            self.db.execute('''UPDATE jobs SET audio_button_message=NULL,audio_button_pending=1
                WHERE manual_audio=1 AND audio_only=0 AND photo_reply_message IS NOT NULL
                  AND audio_button_message IS NOT NULL AND audio_button_message!=reply_message''')
        if 'compression' not in {r[1] for r in self.db.execute('PRAGMA table_info(jobs)')}:
            self.db.execute('ALTER TABLE jobs ADD COLUMN compression TEXT')
        if 'subtitles' not in {r[1] for r in self.db.execute('PRAGMA table_info(jobs)')}:
            self.db.execute('ALTER TABLE jobs ADD COLUMN subtitles INTEGER')
        for column in ('audio_mode','subtitle_mode','caption_mode','mirror_target'):
            if column not in {r[1] for r in self.db.execute('PRAGMA table_info(jobs)')}:
                self.db.execute(f'ALTER TABLE jobs ADD COLUMN {column} TEXT')
        for column in ('caption_text','caption_post_id'):
            if column not in {r[1] for r in self.db.execute('PRAGMA table_info(jobs)')}:
                self.db.execute(f'ALTER TABLE jobs ADD COLUMN {column} TEXT')
        for column in ('caption_button_message','caption_file_message'):
            if column not in {r[1] for r in self.db.execute('PRAGMA table_info(jobs)')}:
                self.db.execute(f'ALTER TABLE jobs ADD COLUMN {column} INTEGER')
        for column in ('caption_button_pending','caption_button_in_flight','caption_file_in_flight'):
            if column not in {r[1] for r in self.db.execute('PRAGMA table_info(jobs)')}:
                self.db.execute(f'ALTER TABLE jobs ADD COLUMN {column} INTEGER NOT NULL DEFAULT 0')
        if 'request_token' not in {r[1] for r in self.db.execute('PRAGMA table_info(jobs)')}:
            self.db.execute("ALTER TABLE jobs ADD COLUMN request_token TEXT NOT NULL DEFAULT ''")
        if 'caption_request_token' not in {r[1] for r in self.db.execute('PRAGMA table_info(jobs)')}:
            self.db.execute('ALTER TABLE jobs ADD COLUMN caption_request_token TEXT')
        if 'media_templates' not in {r[1] for r in self.db.execute('PRAGMA table_info(jobs)')}:
            self.db.execute('ALTER TABLE jobs ADD COLUMN media_templates TEXT')
        self.db.commit()
        # Each accepted extraction click gets its own request and receipts. Normal
        # link messages retain their original deduplication with an empty token.
        # Replace either older constraint atomically, preserving every column.
        definition = self.db.execute("SELECT sql FROM sqlite_master WHERE type='table' AND name='jobs'").fetchone()[0]
        updated,changed = re.subn(r'UNIQUE\s*\(\s*chat_id\s*,\s*message_id\s*,\s*url\s*(?:,\s*audio_only\s*,\s*subtitles_only\s*)?\)',
                                  'UNIQUE(chat_id,message_id,url,audio_only,subtitles_only,request_token)',definition,flags=re.I)
        if changed:
            temporary = re.sub(r'CREATE\s+TABLE\s+(?:IF\s+NOT\s+EXISTS\s+)?"?jobs"?',
                               'CREATE TABLE jobs_requests',updated,count=1,flags=re.I)
            with self.db:
                self.db.execute('BEGIN')
                self.db.execute(temporary)
                self.db.execute('INSERT INTO jobs_requests SELECT * FROM jobs')
                self.db.execute('DROP TABLE jobs')
                self.db.execute('ALTER TABLE jobs_requests RENAME TO jobs')
                self.db.execute('CREATE INDEX jobs_status ON jobs(status,user_id,id)')
        self.db.executescript('''
        CREATE TABLE IF NOT EXISTS button_presses(
          callback_id TEXT PRIMARY KEY, source_job INTEGER NOT NULL, kind TEXT NOT NULL,
          created REAL NOT NULL, file_message INTEGER, in_flight INTEGER NOT NULL DEFAULT 0);
        CREATE INDEX IF NOT EXISTS button_presses_source ON button_presses(source_job,kind,created);
        ''')
        with self.db:
            # Older extraction jobs already record the time the click was admitted.
            self.db.execute('''INSERT OR IGNORE INTO button_presses(callback_id,source_job,kind,created)
                SELECT 'legacy:extract:'||request.id,source.id,
                       CASE WHEN request.audio_only=1 THEN 'audio' ELSE 'subtitles' END,request.created
                FROM jobs AS request JOIN jobs AS source
                  ON source.chat_id=request.chat_id AND source.reply_message=request.message_id
                    AND source.url=request.url AND source.user_id=request.user_id
                WHERE source.audio_only=0 AND source.subtitles_only=0 AND request.request_token=''
                  AND (request.audio_only=1 OR request.subtitles_only=1)''')
            # Old caption receipts have no click timestamp. Start their timer once
            # on upgrade, retaining the receipt and any unconfirmed send.
            self.db.execute('''INSERT OR IGNORE INTO button_presses
                (callback_id,source_job,kind,created,file_message,in_flight)
                SELECT 'legacy:caption:'||jobs.id,jobs.id,'caption',?,caption_file_message,caption_file_in_flight
                FROM jobs WHERE (caption_mode IS NULL OR caption_mode='off')
                  AND (caption_file_message IS NOT NULL OR caption_file_in_flight=1)
                  AND NOT EXISTS (SELECT 1 FROM button_presses WHERE source_job=jobs.id AND kind='caption')''',
                (time.time(),))

    def get(self, key, default=None):
        row = self.db.execute('SELECT value FROM meta WHERE key=?', (key,)).fetchone()
        return row[0] if row else default

    def set(self, key, value):
        with self.db:
            self.db.execute('INSERT OR REPLACE INTO meta VALUES(?,?)', (key, str(value)))

    def queue_mode(self, user):
        mode = self.get(f'queue_mode:{user}')
        return mode if mode in QUEUE_MODES else 'parallel'

    def active_limit(self, user, privileged=False):
        return 1 if self.queue_mode(user)=='sequential' else PRIVILEGED_ACTIVE if privileged else ACTIVE

    def set_queue_mode(self, user, mode):
        if mode not in QUEUE_MODES:
            raise ValueError('Unknown queue mode')
        with self.db:
            self.db.execute('INSERT OR REPLACE INTO meta VALUES(?,?)',(f'queue_mode:{user}',mode))
            privileged = bool(self.db.execute("""SELECT MAX(privileged) FROM jobs WHERE user_id=?
                AND status IN ('ready','running','queued','deferred')""",(user,)).fetchone()[0])
            self._promote_user(user,self.active_limit(user,privileged),privileged)

    def job(self, jid):
        return self.db.execute('SELECT * FROM jobs WHERE id=?', (jid,)).fetchone()

    def change(self,jid,*,mirror_edits=(),**values):
        allowed = {'status','status_message','sent','in_flight','notified','reply_message','photo_reply_message','manual_audio','manual_subtitles','audio_button_message','subtitle_button_message','audio_button_pending','audio_button_in_flight','compression','subtitles','audio_mode','subtitle_mode'}
        allowed.update(('caption_text','caption_post_id','caption_button_message','caption_file_message',
                        'caption_button_pending','caption_button_in_flight','caption_file_in_flight','caption_mode'))
        allowed.update(('metadata_mode','metadata_format','metadata_data','metadata_post_id',
                        'metadata_button_message','metadata_file_message','metadata_request_token',
                        'metadata_button_pending','metadata_button_in_flight','metadata_file_in_flight'))
        allowed.update(('files_mode','files_photo_reply_message','files_button_message',
                        'files_button_pending','files_button_in_flight'))
        allowed.update(('media_templates','mirror_target'))
        assert set(values) <= allowed
        with self.db:
            self.db.execute('UPDATE jobs SET '+','.join(k+'=?' for k in values)+' WHERE id=?',
                            (*values.values(), jid))
            self._bind_mirror_edits(jid,mirror_edits)

    def submit(self, user, chat, message, thread, url, privileged=False, audio_only=False, subtitles_only=False,
               request_token='', button_source=None, files_only=False):
        if sum(bool(value) for value in (audio_only,subtitles_only,files_only))>1:
            raise ValueError('An extraction request must select audio, subtitles or files')
        with self.db:
            existing = self.db.execute('''SELECT id FROM jobs WHERE chat_id=? AND message_id=? AND url=?
                                         AND audio_only=? AND subtitles_only=? AND request_token=?''',
                                       (chat,message,url,int(audio_only),int(subtitles_only),request_token)).fetchone()
            if existing:
                return existing[0], False
            limit = self.active_limit(user,privileged)
            # A new link must not take a slot ahead of an older waiting request.
            self._promote_user(user,limit,privileged)
            busy = self.db.execute("SELECT COUNT(*) FROM jobs WHERE user_id=? AND status IN ('ready','running')",
                                   (user,)).fetchone()[0]
            waiting = self.db.execute("SELECT COUNT(*) FROM jobs WHERE user_id=? AND status='queued'",
                                      (user,)).fetchone()[0]
            deferred = self.db.execute("SELECT 1 FROM jobs WHERE user_id=? AND status='deferred' LIMIT 1",
                                       (user,)).fetchone()
            if not privileged and (deferred or (busy>=limit and waiting>=WAITING)):
                status = 'deferred'
            else:
                status = 'ready' if busy < limit else 'queued'
            now = time.time()
            cur = self.db.execute('''INSERT INTO jobs(user_id,chat_id,message_id,thread_id,url,privileged,status,created,audio_only,subtitles_only,request_token,files_only)
                VALUES(?,?,?,?,?,?,?,?,?,?,?,?)''', (user,chat,message,thread,url,int(privileged),status,now,int(audio_only),int(subtitles_only),request_token,int(files_only)))
            if files_only:
                source = self.job(button_source) if button_source is not None else None
                self.db.execute('''UPDATE jobs SET files_mode='on',audio_mode='off_no_button',
                    subtitle_mode='off_no_button',subtitles=0,caption_mode='off_no_button',
                    metadata_mode='off_no_button',compression=? WHERE id=?''',
                                (source['compression'] if source is not None else None,cur.lastrowid))
            if button_source is not None:
                assert request_token and (audio_only or subtitles_only or files_only)
                self.db.execute('INSERT INTO button_presses(callback_id,source_job,kind,created) VALUES(?,?,?,?)',
                                (request_token,button_source,'files' if files_only else 'audio' if audio_only else 'subtitles',now))
            return cur.lastrowid, True

    def button_remaining(self, jid, kind):
        row = self.db.execute('SELECT MAX(created) FROM button_presses WHERE source_job=? AND kind=?',
                              (jid,kind)).fetchone()
        return max(0,min(BUTTON_COOLDOWN,row[0]+BUTTON_COOLDOWN-time.time())) if row[0] is not None else 0

    def button_press(self, callback_id):
        return self.db.execute('SELECT * FROM button_presses WHERE callback_id=?',(callback_id,)).fetchone()

    def mirror_receipt(self,job,name,digest):
        row = self.db.execute('SELECT onlyfiles,github FROM mirror_receipts WHERE source_job=? AND name=? AND digest=?',
                              (job,name,digest)).fetchone()
        return tuple(row) if row else (None,None)

    def claim_onlyfiles(self,job,name,digest):
        # OnlyFiles has no idempotency key or lookup by client request.
        with self.db:
            self.db.execute('INSERT OR IGNORE INTO mirror_receipts(source_job,name,digest) VALUES(?,?,?)',
                            (job,name,digest))
            return bool(self.db.execute('''UPDATE mirror_receipts SET onlyfiles='pending'
                WHERE source_job=? AND name=? AND digest=? AND onlyfiles IS NULL''',(job,name,digest)).rowcount)

    def save_mirror(self,job,name,digest,provider,url):
        assert provider in ('onlyfiles','github')
        with self.db:
            self.db.execute(f'''INSERT INTO mirror_receipts(source_job,name,digest,{provider}) VALUES(?,?,?,?)
                ON CONFLICT (source_job,name,digest) DO UPDATE SET {provider}=excluded.{provider}''',
                (job,name,digest,url))

    def _bind_mirror_edits(self,jid,edits):
        if edits:
            self.db.executemany('''INSERT OR IGNORE INTO mirror_edits
                (job_id,message_id,file_key,digest,has_body,keyboard) VALUES(?,?,?,?,?,?)''',
                ((jid,*entry) for entry in edits))

    def bind_mirror_edits(self,jid,edits):
        with self.db:
            self._bind_mirror_edits(jid,edits)

    def pending_mirror_edits(self,jid):
        return self.db.execute('SELECT * FROM mirror_edits WHERE job_id=? ORDER BY message_id',(jid,)).fetchall()

    def finish_mirror_edit(self,jid,message_id):
        with self.db:
            self.db.execute('DELETE FROM mirror_edits WHERE job_id=? AND message_id=?',(jid,message_id))

    def start_caption_request(self, jid, callback_id):
        # Commit the timer and upload intent together before acknowledging the tap.
        with self.db:
            self.db.execute('''INSERT INTO button_presses(callback_id,source_job,kind,created,in_flight)
                VALUES(?,?,'caption',?,1)''',(callback_id,jid,time.time()))
            self.db.execute('''UPDATE jobs SET caption_request_token=?,caption_file_message=NULL,
                caption_file_in_flight=1 WHERE id=?''',(callback_id,jid))

    def caption_request_result(self, jid, callback_id, file_message=None):
        with self.db:
            if callback_id is not None:
                self.db.execute('UPDATE button_presses SET file_message=?,in_flight=0 WHERE callback_id=?',
                                (file_message,callback_id))
            # A late acknowledgement for an older click must not change the latest
            # request's intent. Each manual request also keeps its own receipt above.
            self.db.execute('''UPDATE jobs SET caption_file_message=?,caption_file_in_flight=0
                WHERE id=? AND caption_request_token IS ?''',(file_message,jid,callback_id))

    def start_metadata_request(self, jid, callback_id):
        # Commit the timer and upload intent together before acknowledging the tap.
        with self.db:
            self.db.execute('''INSERT INTO button_presses(callback_id,source_job,kind,created,in_flight)
                VALUES(?,?,'metadata',?,1)''',(callback_id,jid,time.time()))
            self.db.execute('''UPDATE jobs SET metadata_request_token=?,metadata_file_message=NULL,
                metadata_file_in_flight=1 WHERE id=?''',(callback_id,jid))

    def metadata_request_result(self, jid, callback_id, file_message=None):
        with self.db:
            if callback_id is not None:
                self.db.execute('UPDATE button_presses SET file_message=?,in_flight=0 WHERE callback_id=?',
                                (file_message,callback_id))
            # A late acknowledgement for an older click must not change the latest
            # request's intent. Each manual request also keeps its own receipt above.
            self.db.execute('''UPDATE jobs SET metadata_file_message=?,metadata_file_in_flight=0
                WHERE id=? AND metadata_request_token IS ?''',(file_message,jid,callback_id))

    def _promote_user(self, user, limit, privileged):
        # A lower preference never cancels running downloads. Requeue unstarted
        # work so the scheduler and recovery also respect the newly saved limit.
        running = self.db.execute("SELECT COUNT(*) FROM jobs WHERE user_id=? AND status='running'",
                                  (user,)).fetchone()[0]
        self.db.execute("""UPDATE jobs SET status='queued' WHERE user_id=? AND status='ready'
            AND id NOT IN (SELECT id FROM jobs WHERE user_id=? AND status='ready' ORDER BY id LIMIT ?)""",
                        (user,user,max(0,limit-running)))
        if privileged:
            # Owners and the bypass account use one unlimited waiting queue.
            self.db.execute("UPDATE jobs SET status='queued' WHERE user_id=? AND status='deferred'",(user,))
        else:
            self.db.execute("""UPDATE jobs SET status='deferred' WHERE user_id=? AND status='queued'
                AND id NOT IN (SELECT id FROM jobs WHERE user_id=? AND status='queued' ORDER BY id LIMIT ?)""",
                            (user,user,WAITING))
        busy = self.db.execute("SELECT COUNT(*) FROM jobs WHERE user_id=? AND status IN ('running','ready')",
                               (user,)).fetchone()[0]
        waiting = self.db.execute("SELECT COUNT(*) FROM jobs WHERE user_id=? AND status='queued'",
                                  (user,)).fetchone()[0]
        if not privileged and busy==0 and waiting==0:
            # A secondary batch only opens after the entire current batch ends.
            ids = self.db.execute("SELECT id FROM jobs WHERE user_id=? AND status='deferred' ORDER BY id LIMIT ?",
                                   (user,limit+WAITING)).fetchall()
            self.db.executemany("UPDATE jobs SET status=? WHERE id=?",
                                [('ready' if index<limit else 'queued',row[0]) for index,row in enumerate(ids)])
            return
        ids = self.db.execute("SELECT id FROM jobs WHERE user_id=? AND status='queued' ORDER BY id LIMIT ?",
                              (user, max(0,limit-busy))).fetchall()
        self.db.executemany("UPDATE jobs SET status='ready' WHERE id=?", [(r[0],) for r in ids])

    def promote(self):
        with self.db:
            for row in self.db.execute("""SELECT user_id,MAX(privileged) AS privileged FROM jobs
                WHERE status IN ('ready','running','queued','deferred') GROUP BY user_id""").fetchall():
                limit = self.active_limit(row['user_id'],bool(row['privileged']))
                self._promote_user(row['user_id'],limit,bool(row['privileged']))

    def queue_position(self, jid):
        return self.db.execute('''SELECT COUNT(*) FROM jobs
            WHERE status=(SELECT status FROM jobs WHERE id=?) AND status IN ('queued','deferred')
              AND user_id=(SELECT user_id FROM jobs WHERE id=?) AND id<=?''',
                               (jid,jid,jid)).fetchone()[0]

    def recover(self):
        with self.db:
            # Telegram has no idempotency key for sending media, do not resend unknown deliveries
            self.db.execute("UPDATE jobs SET status='uncertain' WHERE status IN ('ready','running','queued','deferred') AND in_flight IS NOT NULL")
            self.db.execute("UPDATE jobs SET status='ready' WHERE status='running'")
        self.promote()

    def queue_exemptions(self, owner, bypass):
        with self.db:
            self.db.execute("""UPDATE jobs SET privileged=(user_id IN (?,?))
                WHERE status IN ('ready','running','queued','deferred')""",(owner,bypass))
            # Preserve requests if an account loses its exemption or an older
            # source version allowed a larger ordinary waiting queue.
            users = self.db.execute("""SELECT user_id FROM jobs WHERE status='queued' AND privileged=0
                GROUP BY user_id HAVING COUNT(*)>?""",(WAITING,)).fetchall()
            for row in users:
                self.db.execute("""UPDATE jobs SET status='deferred' WHERE user_id=? AND status='queued'
                    AND id NOT IN (SELECT id FROM jobs WHERE user_id=? AND status='queued' ORDER BY id LIMIT ?)""",
                                (row[0],row[0],WAITING))

    def ready(self):
        return self.db.execute("SELECT * FROM jobs WHERE status='ready' ORDER BY privileged DESC,id").fetchall()

    def outstanding(self, user=None):
        sql = "SELECT * FROM jobs WHERE status IN ('ready','running','queued','deferred')"
        return self.db.execute(sql + (' AND user_id=?' if user is not None else '') + ' ORDER BY id',
                               (user,) if user is not None else ()).fetchall()

    def checkpoint(self):
        self.db.execute('PRAGMA wal_checkpoint(TRUNCATE)')
        if self.db.execute('PRAGMA quick_check').fetchone()[0] != 'ok':
            raise RuntimeError('State database validation failed')

    def close(self):
        self.checkpoint()
        self.db.close()
