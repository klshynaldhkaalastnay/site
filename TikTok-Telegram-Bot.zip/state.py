"""Synchronous SQLite transactions, used only on the bot event-loop thread"""
import json
import re
import sqlite3
import time
from common import ACTIVE, WAITING, PRIVILEGED_ACTIVE


class State:
    def __init__(self, path):
        self.db = sqlite3.connect(path)
        self.db.row_factory = sqlite3.Row
        self.db.execute('PRAGMA journal_mode=WAL')
        self.db.execute('PRAGMA synchronous=FULL')
        self.db.executescript('''
        CREATE TABLE IF NOT EXISTS meta(key TEXT PRIMARY KEY, value TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS jobs(
          id INTEGER PRIMARY KEY, user_id INTEGER NOT NULL, chat_id INTEGER NOT NULL,
          message_id INTEGER NOT NULL, thread_id INTEGER, url TEXT NOT NULL,
          privileged INTEGER NOT NULL, status TEXT NOT NULL, status_message INTEGER,
          created REAL NOT NULL, sent TEXT NOT NULL DEFAULT '[]',
          in_flight TEXT, notified INTEGER NOT NULL DEFAULT 0,
          audio_only INTEGER NOT NULL DEFAULT 0, subtitles_only INTEGER NOT NULL DEFAULT 0,
          UNIQUE(chat_id,message_id,url,audio_only,subtitles_only));
        CREATE INDEX IF NOT EXISTS jobs_status ON jobs(status,user_id,id);
        ''')
        # Existing queue databases retain all requests during this additive migration
        for column in ('reply_message', 'photo_reply_message', 'audio_button_message','subtitle_button_message'):
            if column not in {r[1] for r in self.db.execute('PRAGMA table_info(jobs)')}:
                self.db.execute(f'ALTER TABLE jobs ADD COLUMN {column} INTEGER')
        for column in ('audio_only', 'subtitles_only', 'manual_audio', 'manual_subtitles', 'audio_button_pending'):
            if column not in {r[1] for r in self.db.execute('PRAGMA table_info(jobs)')}:
                self.db.execute(f'ALTER TABLE jobs ADD COLUMN {column} INTEGER NOT NULL DEFAULT 0')
        if 'audio_button_in_flight' not in {r[1] for r in self.db.execute('PRAGMA table_info(jobs)')}:
            self.db.execute('ALTER TABLE jobs ADD COLUMN audio_button_in_flight INTEGER NOT NULL DEFAULT 0')
            # Earlier versions bound album buttons to the last photo. Replace
            # those bindings with a visible reply, including acknowledged edits.
            self.db.execute('''UPDATE jobs SET audio_button_message=NULL,audio_button_pending=1
                WHERE manual_audio=1 AND audio_only=0 AND photo_reply_message IS NOT NULL
                  AND audio_button_message IS NOT NULL AND audio_button_message!=reply_message''')
        if 'compression' not in {r[1] for r in self.db.execute('PRAGMA table_info(jobs)')}:
            self.db.execute('ALTER TABLE jobs ADD COLUMN compression TEXT')
        if 'subtitles' not in {r[1] for r in self.db.execute('PRAGMA table_info(jobs)')}:
            self.db.execute('ALTER TABLE jobs ADD COLUMN subtitles INTEGER')
        for column in ('audio_mode','subtitle_mode'):
            if column not in {r[1] for r in self.db.execute('PRAGMA table_info(jobs)')}:
                self.db.execute(f'ALTER TABLE jobs ADD COLUMN {column} TEXT')
        self.db.commit()
        # Audio and subtitle clicks on the same video are separate requests.
        # Replace the older uniqueness constraint in one transaction, preserving
        # every column, job ID and receipt in existing databases.
        definition = self.db.execute("SELECT sql FROM sqlite_master WHERE type='table' AND name='jobs'").fetchone()[0]
        updated,changed = re.subn(r'UNIQUE\s*\(\s*chat_id\s*,\s*message_id\s*,\s*url\s*\)',
                                  'UNIQUE(chat_id,message_id,url,audio_only,subtitles_only)',definition,flags=re.I)
        if changed:
            temporary = re.sub(r'CREATE\s+TABLE\s+(?:IF\s+NOT\s+EXISTS\s+)?"?jobs"?',
                               'CREATE TABLE jobs_requests',updated,count=1,flags=re.I)
            with self.db:
                self.db.execute('BEGIN')
                self.db.execute(temporary)
                self.db.execute('INSERT INTO jobs_requests SELECT * FROM jobs')
                self.db.execute('DROP TABLE jobs')
                self.db.execute('ALTER TABLE jobs_requests RENAME TO jobs')
                self.db.execute('CREATE INDEX jobs_status ON jobs(status,user_id,id)')

    def get(self, key, default=None):
        row = self.db.execute('SELECT value FROM meta WHERE key=?', (key,)).fetchone()
        return row[0] if row else default

    def set(self, key, value):
        with self.db:
            self.db.execute('INSERT OR REPLACE INTO meta VALUES(?,?)', (key, str(value)))

    def job(self, jid):
        return self.db.execute('SELECT * FROM jobs WHERE id=?', (jid,)).fetchone()

    def change(self, jid, **values):
        allowed = {'status','status_message','sent','in_flight','notified','reply_message','photo_reply_message','manual_audio','manual_subtitles','audio_button_message','subtitle_button_message','audio_button_pending','audio_button_in_flight','compression','subtitles','audio_mode','subtitle_mode'}
        assert set(values) <= allowed
        with self.db:
            self.db.execute('UPDATE jobs SET '+','.join(k+'=?' for k in values)+' WHERE id=?',
                            (*values.values(), jid))

    def submit(self, user, chat, message, thread, url, privileged=False, audio_only=False, subtitles_only=False):
        if audio_only and subtitles_only:
            raise ValueError('An extraction request must select audio or subtitles')
        with self.db:
            existing = self.db.execute('''SELECT id FROM jobs WHERE chat_id=? AND message_id=? AND url=?
                                         AND audio_only=? AND subtitles_only=?''',
                                       (chat,message,url,int(audio_only),int(subtitles_only))).fetchone()
            if existing:
                return existing[0], False
            rows = self.db.execute("SELECT status FROM jobs WHERE user_id=? AND status IN ('ready','running','queued')",
                                   (user,)).fetchall()
            limit = PRIVILEGED_ACTIVE if privileged else ACTIVE
            busy = sum(r[0] in ('ready','running') for r in rows)
            waiting = sum(r[0] == 'queued' for r in rows)
            if not privileged and busy >= limit and waiting >= WAITING:
                return None, False
            status = 'ready' if busy < limit else 'queued'
            cur = self.db.execute('''INSERT INTO jobs(user_id,chat_id,message_id,thread_id,url,privileged,status,created,audio_only,subtitles_only)
                VALUES(?,?,?,?,?,?,?,?,?,?)''', (user,chat,message,thread,url,int(privileged),status,time.time(),int(audio_only),int(subtitles_only)))
            return cur.lastrowid, True

    def promote(self):
        with self.db:
            for row in self.db.execute("SELECT DISTINCT user_id,privileged FROM jobs WHERE status='queued'").fetchall():
                limit = PRIVILEGED_ACTIVE if row['privileged'] else ACTIVE
                busy = self.db.execute("SELECT COUNT(*) FROM jobs WHERE user_id=? AND status IN ('running','ready')",
                                       (row['user_id'],)).fetchone()[0]
                ids = self.db.execute("SELECT id FROM jobs WHERE user_id=? AND status='queued' ORDER BY id LIMIT ?",
                                      (row['user_id'], max(0,limit-busy))).fetchall()
                self.db.executemany("UPDATE jobs SET status='ready' WHERE id=?", [(r[0],) for r in ids])

    def recover(self):
        with self.db:
            # Telegram has no idempotency key for sending media, do not resend unknown deliveries
            self.db.execute("UPDATE jobs SET status='uncertain' WHERE status IN ('ready','running','queued') AND in_flight IS NOT NULL")
            self.db.execute("UPDATE jobs SET status='ready' WHERE status='running'")
        self.promote()

    def ready(self):
        return self.db.execute("SELECT * FROM jobs WHERE status='ready' ORDER BY privileged DESC,id").fetchall()

    def outstanding(self, user=None):
        sql = "SELECT * FROM jobs WHERE status IN ('ready','running','queued')"
        return self.db.execute(sql + (' AND user_id=?' if user is not None else '') + ' ORDER BY id',
                               (user,) if user is not None else ()).fetchall()

    def checkpoint(self):
        self.db.execute('PRAGMA wal_checkpoint(TRUNCATE)')
        if self.db.execute('PRAGMA quick_check').fetchone()[0] != 'ok':
            raise RuntimeError('State database validation failed')

    def close(self):
        self.checkpoint()
        self.db.close()
