"""Durable, requester-owned downloads of captions that exceed the media limit."""
import asyncio
import logging
import re
from urllib.parse import urlsplit

from aiogram.exceptions import (AiogramError, TelegramAPIError, TelegramEntityTooLarge,
                               TelegramNetworkError, TelegramServerError, TelegramRetryAfter,
                               ClientDecodeError)
from aiogram.types import BufferedInputFile, InlineKeyboardButton, InlineKeyboardMarkup, ReplyParameters, LinkPreviewOptions

from common import MAX_BYTES, POST_RE, BOT_ATTRIBUTION, media_preference


class CaptionFiles:
    def __init__(self, runner):
        self.runner = runner

    def snapshot(self, jid):
        state = self.runner.state
        row = state.job(jid)
        if row['caption_mode'] is None:
            # Jobs with saved caption data predate the setting and retain their
            # original button behavior, regardless of a newer user preference.
            mode = 'off' if row['caption_text'] is not None else media_preference(
                state.get(f"caption:{row['user_id']}"),'off')
            state.change(jid,caption_mode=mode)
            return mode
        return media_preference(row['caption_mode'],'off')

    def remember(self, jid, title, post_id, too_long):
        state = self.runner.state
        row = state.job(jid)
        mode = self.snapshot(jid)
        if row['caption_text'] is not None or row['audio_only'] or row['subtitles_only']:
            return
        if post_id is None:
            match = POST_RE.fullmatch(urlsplit(row['url']).path)
            post_id = match.group(1) if match else None
        post_id = str(post_id or '')
        if not re.fullmatch(r'[0-9]{1,32}',post_id):
            if too_long:
                logging.warning('Caption post ID unavailable for job %s',jid)
            return
        # Store the original text, not the shortened/HTML-escaped media preview.
        state.change(jid,caption_post_id=post_id,
                     caption_text=str(title) if too_long and mode!='off_no_button' else '',
                     caption_button_pending=int(too_long and mode=='off'))

    def keyboard(self, user, jid):
        return InlineKeyboardMarkup(inline_keyboard=[[
            InlineKeyboardButton(text=self.runner.tr(user,'Send caption as text file'),
                                 callback_data=f'caption:{jid}')]])

    async def install(self, jid):
        r = self.runner
        row = r.state.job(jid)
        if row and self.snapshot(jid)!='off':
            return
        if (not row or not row['caption_button_pending'] or not row['reply_message']
                or row['caption_button_in_flight'] or r.stop.is_set()):
            return
        async def send_button():
            r.state.change(jid,caption_button_in_flight=1)
            try:
                return await r.bot.send_message(
                    chat_id=row['chat_id'],message_thread_id=row['thread_id'],
                    text=BOT_ATTRIBUTION,parse_mode='HTML',
                    link_preview_options=LinkPreviewOptions(is_disabled=True),
                    reply_parameters=ReplyParameters(message_id=row['reply_message'],allow_sending_without_reply=True),
                    reply_markup=self.keyboard(row['user_id'],jid))
            except TelegramRetryAfter:
                r.state.change(jid,caption_button_in_flight=0)
                raise
        try:
            message = await r.api(row['chat_id'],send_button)
        except TelegramEntityTooLarge:
            r.state.change(jid,caption_button_in_flight=0)
            return
        except (TelegramNetworkError,TelegramServerError,ClientDecodeError):
            logging.info('Caption button reply not confirmed for job %s',jid)
            return
        except TelegramAPIError:
            r.state.change(jid,caption_button_in_flight=0)
            return
        except AiogramError:
            logging.info('Caption button reply not confirmed for job %s',jid)
            return
        r.state.change(jid,caption_button_message=message.message_id,
                       caption_button_pending=0,caption_button_in_flight=0)

    async def automatic(self, jid):
        r = self.runner
        row = r.state.job(jid)
        if (not row or self.snapshot(jid)!='on' or not row['caption_text'] or not row['reply_message']
                or row['caption_file_message'] or row['caption_file_in_flight']
                or row['status']=='cancelled' or r.stop.is_set()):
            return
        await self.send_file(jid)

    async def callback(self, query):
        r = self.runner
        match = re.fullmatch(r'caption:([0-9]{1,19})',query.data or '')
        row = r.state.job(int(match[1])) if match else None
        msg = query.message
        user = query.from_user.id
        if (not row or not msg or not row['caption_text'] or not row['caption_post_id']
                or row['user_id']!=user or row['chat_id']!=msg.chat.id
                or row['thread_id']!=getattr(msg,'message_thread_id',None)):
            await query.answer(r.tr(user,'This caption button belongs to the original requester'),show_alert=True)
            return
        jid = row['id']
        if row['caption_button_message']!=msg.message_id:
            anchor = getattr(msg,'reply_to_message',None)
            if (row['caption_button_pending'] and row['caption_button_in_flight']
                    and getattr(anchor,'message_id',None)==row['reply_message']):
                # This click confirms an actual reply whose acknowledgement was lost.
                r.state.change(jid,caption_button_message=msg.message_id,
                               caption_button_pending=0,caption_button_in_flight=0)
            else:
                await query.answer(r.tr(user,'This caption button belongs to the original requester'),show_alert=True)
                return
        if r.stop.is_set():
            await query.answer(r.tr(user,'The bot is restarting, please send your links again shortly'),show_alert=True)
            return
        if await r.button_wait(query,jid,'caption'):
            return
        await self.send_file(jid,query)

    async def send_file(self, jid, query=None):
        r = self.runner
        row = r.state.job(jid)
        user = row['user_id']
        if not query and row['caption_file_message']:
            return
        if not query and row['caption_file_in_flight']:
            return
        data = row['caption_text'].encode('utf-8')
        if len(data)>MAX_BYTES:
            if query:
                await query.answer(r.tr(user,'This caption file is too large, the maximum size is 50 MB'),show_alert=True)
            return
        # Each eligible manual tap is an explicit new upload after its cooldown;
        # automatic delivery retains the original once-only receipt.
        token = query.id if query else row['caption_request_token']
        if query:
            r.state.start_caption_request(jid,token)
        else:
            r.state.change(jid,caption_file_in_flight=1)
        started = False
        async def send_file():
            nonlocal started
            started = True
            try:
                return await r.bot.send_document(
                    chat_id=row['chat_id'],message_thread_id=row['thread_id'],
                    document=BufferedInputFile(data,filename=row['caption_post_id']+'.txt'),
                    caption=BOT_ATTRIBUTION,parse_mode='HTML',
                    reply_parameters=ReplyParameters(message_id=row['reply_message'],allow_sending_without_reply=True))
            except TelegramRetryAfter:
                started = False
                raise
        try:
            if query:
                await query.answer(r.tr(user,'Sending caption file...'))
            message = await r.api(row['chat_id'],send_file)
        except asyncio.CancelledError:
            if not started:
                r.state.caption_request_result(jid,token)
            raise
        except TelegramEntityTooLarge:
            r.state.caption_request_result(jid,token)
            if query:
                await r.tell(row['chat_id'],r.tr(user,'Could not send the caption file, try the button again'),row['thread_id'])
            return
        except (TelegramNetworkError,TelegramServerError,ClientDecodeError):
            if not started:
                r.state.caption_request_result(jid,token)
            logging.info('Caption file delivery not confirmed for job %s',jid)
            if query:
                await r.tell(row['chat_id'],r.tr(user,'Caption delivery is pending or unconfirmed, check the chat'),row['thread_id'])
            return
        except TelegramAPIError:
            r.state.caption_request_result(jid,token)
            if query:
                await r.tell(row['chat_id'],r.tr(user,'Could not send the caption file, try the button again'),row['thread_id'])
            return
        except AiogramError:
            if not started:
                r.state.caption_request_result(jid,token)
            logging.info('Caption file delivery not confirmed for job %s',jid)
            return
        r.state.caption_request_result(jid,token,message.message_id)
