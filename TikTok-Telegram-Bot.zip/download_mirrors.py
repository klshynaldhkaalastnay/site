"""Opt-in public mirrors for the individual files sent by Telegram."""
import asyncio
import base64
from dataclasses import dataclass
import hashlib
from html import escape
import json
import logging
import mimetypes
import os
from pathlib import Path
import re
import tempfile
from urllib.parse import quote
from weakref import WeakValueDictionary
import zlib

import aiohttp
from aiogram.exceptions import (AiogramError, ClientDecodeError, TelegramAPIError, TelegramBadRequest,
                                TelegramNetworkError, TelegramRetryAfter, TelegramServerError)
from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup, LinkPreviewOptions, ReplyParameters

from common import BOT_ATTRIBUTION, BOT_NAME, MAX_BYTES
from i18n import translate
from metadata_formats import chosen_format, export_metadata


ONLYFILES_API = 'https://api.onlyfiles.com/v1/upload'
ONLYFILES_LIMIT = 100_000_000
REPOSITORY = 'ytarchive/tikcdn'
GITHUB_API = f'https://api.github.com/repos/{REPOSITORY}'
CDN = 'https://tikcdn.files.int.yt/'
# Keep large media outside the Pages build and Git object history.
GIT_FILE_LIMIT = 100 * 1024**2
GIT_BATCH_LIMIT = 100 * 1024**2
GIT_REPOSITORY_SOFT_LIMIT_KIB = 700_000
RELEASE_FILE_LIMIT = 2 * 1024**3
TARGET = re.compile(r'(?:video|photo)/[0-9]{1,32}')
NAME = re.compile(r'[A-Za-z0-9][A-Za-z0-9_.-]{0,179}')
SHA = re.compile(r'[a-f0-9]{40}')
REQUEST_ERRORS = (aiohttp.ClientError, TimeoutError, OSError, ValueError)
DEFAULT_FOOTER = (BOT_ATTRIBUTION,len(BOT_NAME))
SETTING = 'Download mirrors'
SETTING_DESCRIPTION = 'Create public links for each file, Off shows a button to request them'
PUBLISH_DELAY = '(may take a while for the file to be there)'
REQUEST_BUTTON = 'Get public links'
REQUEST_STARTED = 'Creating public links...'
REQUEST_BUSY = 'Public links are already being created'
REQUEST_UNAVAILABLE = 'Public links are unavailable for these files'
REQUEST_FINISHED = 'Public links are already added'


class MirrorError(ValueError):
    def __init__(self,status=0):
        self.status = status
        super().__init__('Mirror request failed')


def sha(data):
    value = data.get('sha') if isinstance(data,dict) else None
    if not isinstance(value,str) or not SHA.fullmatch(value):
        raise MirrorError()
    return value


def onlyfiles_link(value):
    if not isinstance(value,str) or len(value)>512 or not re.fullmatch(
            r'https://onlyfiles\.com/[A-Za-z0-9]+(?:/[A-Za-z0-9_.%+-]+)?',value):
        return None
    return value


def footer(links=None, translate=lambda s:s, *, photo_number=None):
    only,github = links or (None,None)
    if not (only or github):
        return DEFAULT_FOOTER
    photo_label = '' if photo_number is None else ' '+translate('photo {n}').format(n=photo_number)
    lines,labels = [],[]
    for url,label,note in ((only,'Download link 1',''),(github,'Download link 2',' '+translate(PUBLISH_DELAY))):
        if url:
            label = translate(label)+photo_label
            lines.append(f'<a href="{escape(url)}">{escape(label)}</a>'+escape(note))
            labels.append(label+note)
    units = len(('\n'.join(labels)+'\n\n'+BOT_NAME).encode('utf-16-le'))//2
    return '\n'.join(lines)+'\n\n'+BOT_ATTRIBUTION,units


def button_target(value):
    if value and value.startswith('button:') and TARGET.fullmatch(value[7:]):
        return value[7:]
    return None


def delivered_file_id(message):
    for field in ('document','video','audio','animation'):
        media = getattr(message,field,None)
        if media and media.file_id:
            return media.file_id
    photos = getattr(message,'photo',None)
    if photos:
        return max(photos,key=lambda image:image.width*image.height).file_id
    return None


def safe_name(value):
    value = re.sub(r'[^A-Za-z0-9_.-]+','_',value).strip('._-')
    stem,dot,ext = value.rpartition('.')
    return stem[:145].rstrip('.')+dot+ext[:16] if stem else value[:145]


@dataclass(frozen=True)
class File:
    key: str
    name: str
    path: Path
    size: int
    digest: str

    @classmethod
    def read(cls,key,name,path):
        if not NAME.fullmatch(name) or path.is_symlink() or not path.is_file():
            raise ValueError('Invalid mirror file')
        size = path.stat().st_size
        with path.open('rb') as content:
            return cls(key,name,path,size,hashlib.file_digest(content,'sha256').hexdigest())

    @property
    def fingerprint(self):
        return self.digest[:16]

    @property
    def release_asset_name(self):
        # Release assets share a flat namespace, so keep the existing names.
        stem,dot,ext = self.name.rpartition('.')
        return f'{stem}-{self.fingerprint}{dot}{ext}'


def media_sources(folder,records,post_id):
    photo_count = sum(record['kind']=='image' for record in records)
    seen = {}
    photo_number = 0
    for record in records:
        key, kind = record['file'],record['kind']
        if not isinstance(key,str) or Path(key).name!=key:
            continue
        extension = Path(key).suffix.lower()
        if not re.fullmatch(r'\.[a-z0-9]{1,16}',extension):
            continue
        if kind=='image':
            photo_number += 1
            stem = f'{post_id}_{photo_number:02d}' if photo_count>1 else post_id
            name = stem+extension
        elif kind=='video':
            name = post_id+extension
        elif kind=='audio':
            name = post_id+'.audio'+extension
        elif kind=='subtitle':
            if extension not in ('.srt','.vtt','.json','.txt','.ass','.ssa','.ttml','.xml'):
                extension = '.txt'
            name = safe_name(str(record.get('filename') or '')) or post_id+'.subtitle'+extension
            stem = Path(name).stem if name.startswith(post_id+'_') else post_id+'.subtitle'
            name = stem+extension
        else:
            continue
        seen[key] = (name,folder/key)
    return seen


async def request_json(session, method, url, *, missing=False, **kwargs):
    async with session.request(method,url,allow_redirects=False,**kwargs) as response:
        if missing and response.status==404:
            return None
        if not 200<=response.status<300:
            raise MirrorError(response.status)
        data = await response.json()
        if not isinstance(data,dict):
            raise MirrorError()
        return data


async def only_upload(session,file):
    with file.path.open('rb') as stream:
        form = aiohttp.FormData()
        form.add_field('expire','0')
        form.add_field('file',stream,filename=file.name,
                       content_type=mimetypes.guess_type(file.name)[0] or 'application/octet-stream')
        data = await request_json(session,'POST',ONLYFILES_API,data=form)
    try:
        returned = data['data']['file']['url']
        url = onlyfiles_link(returned.get('full')) or onlyfiles_link(returned.get('short'))
    except (KeyError,TypeError,AttributeError):
        raise MirrorError() from None
    if data.get('status') is not True or not url:
        raise MirrorError()
    return url


def asset_redirect(url,filename):
    encoded = escape(url,quote=True)
    source = json.dumps(url).replace('<','\\u003c')
    head = ('<!doctype html><html lang="en"><head><meta charset="utf-8">'
            '<meta name="viewport" content="width=device-width, initial-scale=1">'
            f'<title>{escape(filename)}</title>')
    refresh = f'<meta http-equiv="refresh" content="0; url={encoded}">'
    link = f'<a href="{encoded}">Download file</a>'
    if not (mimetypes.guess_type(filename)[0] or '').startswith('video/'):
        return head+refresh+f'</head><body>{link}<script>location.replace({source});</script></body></html>'
    return (head+'<style>body{margin:0;background:#111;color:#fff;text-align:center;'
            'font:1rem system-ui}video{display:block;width:min(100vw,1200px);max-height:90vh;'
            'margin:auto}a{color:#b7d5ff}</style>'
            f'<noscript>{refresh}</noscript></head><body>'
            f'<main hidden><video controls playsinline preload="metadata"></video><p>{link}</p></main>'
            f'<noscript>{link}</noscript><script>const source={source};'
            'if(new URLSearchParams(location.search).get("view")==="true"){'
            'document.querySelector("video").src=source;document.querySelector("main").hidden=false;'
            '}else{location.replace(source);}</script></body></html>')


class GitHub:
    def __init__(self,session,branch,lock):
        self.session,self.branch,self.lock = session,branch,lock
        self.ref = quote(branch,safe='/')

    async def api(self,method,path,**kwargs):
        return await request_json(self.session,method,GITHUB_API+path,**kwargs)

    async def release(self,target):
        tag = 'tiktok-'+target.replace('/','-')
        route = '/releases/tags/'+tag
        release = await self.api('GET',route,missing=True)
        if release is None:
            try:
                release = await self.api('POST','/releases',json={
                    'tag_name':tag,'name':'TikTok '+target,'draft':False,
                    'target_commitish':self.branch,'make_latest':'false'})
            except MirrorError as exc:
                if exc.status!=422:
                    raise
                # Another runner may have created the release meanwhile.
                release = await self.api('GET',route)
        return tag,release

    async def asset(self,tag,release,file):
        release_id = release.get('id')
        if type(release_id) is not int or release_id<1:
            raise MirrorError()
        name = file.release_asset_name
        download = f'https://github.com/{REPOSITORY}/releases/download/{tag}/{name}'
        assets = release.get('assets')
        if isinstance(assets,list) and any(
                a.get('name')==name and a.get('size')==file.size and a.get('state')=='uploaded'
                for a in assets if isinstance(a,dict)):
            return download
        with file.path.open('rb') as stream:
            data = await request_json(self.session,'POST',
                f'https://uploads.github.com/repos/{REPOSITORY}/releases/{release_id}/assets',
                params={'name':name},data=stream,headers={
                    'Content-Type':'application/octet-stream','Content-Length':str(file.size)})
        if data.get('name')!=name or data.get('state')!='uploaded' or data.get('size')!=file.size:
            raise MirrorError()
        return download

    async def commit(self,entries,target):
        if not entries:
            return
        async with self.lock:
            for attempt in range(3):
                ref = await self.api('GET','/git/ref/heads/'+self.ref)
                parent = sha(ref.get('object'))
                head = await self.api('GET','/git/commits/'+parent)
                base = sha(head.get('tree'))
                tree = sha(await self.api('POST','/git/trees',json={'base_tree':base,'tree':entries}))
                if tree==base:
                    return
                commit = sha(await self.api('POST','/git/commits',json={
                    'message':'Add TikTok files for '+target,'tree':tree,'parents':[parent]}))
                try:
                    await self.api('PATCH','/git/refs/heads/'+self.ref,json={'sha':commit,'force':False})
                    return
                except MirrorError as exc:
                    if exc.status not in (409,422) or attempt==2:
                        raise

    async def publish(self,target,files):
        entries,urls = [],{}
        repo = await self.api('GET','')
        size = repo.get('size')
        git_budget = GIT_BATCH_LIMIT if type(size) is int and 0<=size<GIT_REPOSITORY_SOFT_LIMIT_KIB else 0
        release = None
        for file in files:
            name = file.name
            folder = f'{target}/{file.fingerprint}/'
            try:
                if file.size<=min(GIT_FILE_LIMIT,git_budget):
                    raw = await asyncio.to_thread(file.path.read_bytes)
                    blob = sha(await self.api('POST','/git/blobs',json={
                        'content':base64.b64encode(raw).decode('ascii'),'encoding':'base64'}))
                    value = {'sha':blob}
                    git_budget -= file.size
                elif file.size<RELEASE_FILE_LIMIT and repo.get('private') is False:
                    if release is None:
                        release = await self.release(target)
                    destination = await self.asset(*release,file)
                    value = {'content':asset_redirect(destination,file.name)}
                    # Preserve the old .html URL. A file sent to a release
                    # because Pages is full can already exist as a Git blob
                    # at its bare path, so only its alias needs a subfolder.
                    entries.append({'path':folder+name+'.html','mode':'100644','type':'blob',**value})
                    if file.size<=GIT_FILE_LIMIT:
                        name = 'download/'+name
                    name += '/'
                    entries.append({'path':folder+name+'index.html','mode':'100644','type':'blob',**value})
                    urls[file.key] = CDN+folder+name
                    continue
                else:
                    continue
                path = folder+name
                entries.append({'path':path,'mode':'100644','type':'blob',**value})
                urls[file.key] = CDN+path
            except REQUEST_ERRORS as exc:
                logging.info('GitHub mirror file unavailable, %s',type(exc).__name__)
        await self.commit(entries,target)
        return urls


class DownloadMirrors:
    def __init__(self,runner):
        self.runner = runner
        self.slots = asyncio.Semaphore(2)
        self.git_lock = asyncio.Lock()
        self.origin_locks = WeakValueDictionary()
        self.documents = set()
        self.document_messages = set()
        self.requests = {}
        self.request_slots = asyncio.Semaphore(2)

    def preference(self,user):
        value = self.runner.state.get(f'mirrors:{user}')
        # Older versions saved "off" for the behavior now named Off with no button.
        return {'on':'on','button':'off'}.get(value,'off_no_button')

    def set_preference(self,user,mode):
        self.runner.state.set(f'mirrors:{user}','button' if mode=='off' else mode)

    def source_job(self,row):
        press = self.runner.state.button_press(row['request_token']) if row['request_token'] else None
        if press and press['kind'] in ('audio','subtitles','files'):
            source = self.runner.state.job(press['source_job'])
            if source and source['user_id']==row['user_id'] and source['chat_id']==row['chat_id']:
                return source
        return row

    def snapshot(self,jid):
        state = self.runner.state
        row = state.job(jid)
        if row['mirror_target'] is not None:
            return row['mirror_target']
        source = self.source_job(row)
        mode = self.preference(row['user_id'])
        if source['id']!=jid:
            source_target = source['mirror_target'] or 'off'
            target = source_target if ((mode=='on' and TARGET.fullmatch(source_target))
                                       or (mode!='off_no_button' and button_target(source_target))) else 'off'
        else:
            target = 'off'
            if not row['request_token'] and row['sent']=='[]':
                target = {'on':'on','off':'button'}.get(mode,'off')
        state.change(jid,mirror_target=target)
        return target

    def bind(self,jid,kind,post_id):
        target = self.snapshot(jid)
        if target in ('on','button') and kind and re.fullmatch(r'[0-9]{1,32}',str(post_id or '')):
            folder = ('photo' if kind=='image' else 'video')+'/'+str(post_id)
            target = 'button:'+folder if target=='button' else folder
            self.runner.state.change(jid,mirror_target=target)
        return target

    def file_entry(self,row,message,name,body='',photo_number=None,keyboard=None,*,language=None):
        file_id = delivered_file_id(message)
        if file_id and NAME.fullmatch(name):
            source = self.source_job(row)
            return (source['id'],message.message_id,file_id,name,body,photo_number,keyboard,
                    language or self.runner.state.get(f"language:{row['user_id']}",'en'))
        return None

    def keyboard(self,user,jid):
        return InlineKeyboardMarkup(inline_keyboard=[[InlineKeyboardButton(
            text=self.runner.tr(user,REQUEST_BUTTON),callback_data=f'public_links:{jid}')]])

    async def install_button(self,jid):
        r = self.runner
        row = r.state.job(jid)
        if (not row or not button_target(row['mirror_target']) or not row['reply_message']
                or row['links_button_message'] or row['links_button_in_flight']
                or row['status']=='cancelled' or r.stop.is_set()
                or self.source_job(row)['id']!=jid or not r.state.public_link_files(jid)):
            return
        async def send_button():
            r.state.change(jid,links_button_in_flight=1)
            try:
                return await r.bot.send_message(
                    chat_id=row['chat_id'],message_thread_id=row['thread_id'],text=BOT_ATTRIBUTION,
                    parse_mode='HTML',link_preview_options=LinkPreviewOptions(is_disabled=True),
                    reply_parameters=ReplyParameters(message_id=row['reply_message'],allow_sending_without_reply=True),
                    reply_markup=self.keyboard(row['user_id'],jid))
            except TelegramRetryAfter:
                r.state.change(jid,links_button_in_flight=0)
                raise
        try:
            message = await r.api(row['chat_id'],send_button)
        except (TelegramNetworkError,TelegramServerError,ClientDecodeError):
            logging.info('Public links button delivery not confirmed')
            return
        except TelegramAPIError:
            r.state.change(jid,links_button_in_flight=0)
            return
        except AiogramError:
            logging.info('Public links button delivery not confirmed')
            return
        r.state.change(jid,links_button_message=message.message_id,links_button_in_flight=0)

    async def callback(self,query):
        r = self.runner
        match = re.fullmatch(r'public_links:([0-9]{1,19})',query.data or '')
        row = r.state.job(int(match[1])) if match else None
        user,msg = query.from_user.id,query.message
        if (not row or not msg or not button_target(row['mirror_target'])
                or row['user_id']!=user or row['chat_id']!=msg.chat.id
                or row['thread_id']!=getattr(msg,'message_thread_id',None) or row['status']=='cancelled'
                or not row['reply_message'] or self.source_job(row)['id']!=row['id']):
            await query.answer(r.tr(user,'This button belongs to the original requester'),show_alert=True)
            return
        jid = row['id']
        if row['links_button_message']!=msg.message_id:
            anchor = getattr(msg,'reply_to_message',None)
            if row['links_button_in_flight'] and getattr(anchor,'message_id',None)==row['reply_message']:
                r.state.change(jid,links_button_message=msg.message_id,links_button_in_flight=0)
            else:
                await query.answer(r.tr(user,'This button belongs to the original requester'),show_alert=True)
                return
        if r.stop.is_set():
            await query.answer(r.tr(user,'The bot is restarting, please send your links again shortly'),show_alert=True)
            return
        if jid in self.requests:
            await query.answer(r.tr(user,REQUEST_BUSY),show_alert=True)
            return
        if not r.state.public_link_files(jid):
            await query.answer(r.tr(user,REQUEST_FINISHED),show_alert=True)
            return
        if await r.button_wait(query,jid,'public_links'):
            return
        r.state.start_public_links(jid,query.id)
        self.schedule_request(jid,query.id)
        await query.answer(r.tr(user,REQUEST_STARTED))

    def schedule_request(self,jid,callback_id):
        if jid in self.requests or self.runner.stop.is_set():
            return
        task = asyncio.create_task(self.run_request(jid,callback_id))
        self.requests[jid] = task
        def finished(task):
            self.requests.pop(jid,None)
            if not task.cancelled() and (exc := task.exception()) is not None:
                logging.info('Public links request unavailable, %s',type(exc).__name__)
        task.add_done_callback(finished)

    def resume_requests(self):
        for row in self.runner.state.db.execute("""SELECT source_job,callback_id FROM button_presses
                WHERE kind='public_links' AND in_flight=1 ORDER BY created"""):
            self.schedule_request(row['source_job'],row['callback_id'])

    async def telegram_file(self,row,entry,destination):
        r = self.runner
        file = await r.api(row['chat_id'],lambda:r.bot.get_file(entry['file_id'],request_timeout=60))
        if not file.file_path or (file.file_size is not None and file.file_size>MAX_BYTES):
            raise MirrorError()
        if r.bot.session.api.is_local:
            local = Path(r.bot.session.api.wrap_local_file.to_local(file.file_path))
            if local.is_absolute() and local.is_file() and not local.is_symlink():
                if not 0<local.stat().st_size<=MAX_BYTES:
                    raise MirrorError()
                return local
        await r.bot.download_file(file.file_path,destination=destination,timeout=90)
        if not 0<destination.stat().st_size<=MAX_BYTES:
            raise MirrorError()
        return destination

    async def run_request(self,jid,callback_id):
        r = self.runner
        row = r.state.job(jid)
        target = button_target(row['mirror_target']) if row else None
        entries = r.state.public_link_files(jid)
        if not target or row['status']=='cancelled' or not entries:
            r.state.finish_public_links(callback_id)
            return
        edited = 0
        try:
            async with self.request_slots,asyncio.timeout(540):
                with tempfile.TemporaryDirectory(prefix='public-link-request-',dir=r.work) as td:
                    uploads,files = {},{}
                    for entry in entries:
                        key = str(entry['message_id'])
                        if not NAME.fullmatch(entry['name']):
                            continue
                        try:
                            path = await self.telegram_file(row,entry,Path(td)/key)
                        except (AiogramError,*REQUEST_ERRORS) as exc:
                            logging.info('Telegram file unavailable for public links, %s',type(exc).__name__)
                            continue
                        uploads[key] = (entry['name'],path)
                        files[key] = entry
                    links = await self.publish(jid,target,uploads)
                    for key,pair in links.items():
                        if key not in files:
                            continue
                        entry = files[key]
                        language = entry['language']
                        suffix,_ = footer(pair,lambda label:translate(language,label),
                                          photo_number=entry['photo_number'])
                        try:
                            await self.edit_caption(row,entry,entry['body']+suffix)
                        except AiogramError as exc:
                            logging.info('Public link caption edit unavailable, %s',type(exc).__name__)
                            continue
                        edited += 1
                        r.state.finish_public_link_file(jid,entry['message_id'])
        except (OSError,ValueError,TimeoutError) as exc:
            logging.info('Public links request unavailable, %s',type(exc).__name__)
        r.state.finish_public_links(callback_id)
        if row['links_button_message'] and not r.stop.is_set():
            try:
                await r.api(row['chat_id'],lambda:r.bot.edit_message_text(
                    chat_id=row['chat_id'],message_id=row['links_button_message'],
                    text=BOT_ATTRIBUTION if edited else r.tr(row['user_id'],REQUEST_UNAVAILABLE),
                    parse_mode='HTML',reply_markup=self.keyboard(row['user_id'],jid)))
            except TelegramBadRequest as exc:
                if 'message is not modified' not in exc.message.lower():
                    logging.info('Public links status could not be updated')
            except AiogramError:
                logging.info('Public links status could not be updated')

    async def only(self,origin,files):
        state = self.runner.state
        timeout = aiohttp.ClientTimeout(total=180,connect=12,sock_read=75)
        async with aiohttp.ClientSession(timeout=timeout) as session:
            for file in files:
                if not 0<file.size<=ONLYFILES_LIMIT:
                    continue
                if not state.claim_onlyfiles(origin,file.name,file.digest):
                    continue
                try:
                    url = await only_upload(session,file)
                except REQUEST_ERRORS as exc:
                    logging.info('OnlyFiles mirror file unavailable, %s',type(exc).__name__)
                    continue
                state.save_mirror(origin,file.name,file.digest,'onlyfiles',url)

    async def github(self,origin,target,files):
        token = os.getenv('TIKCDN_TOKEN','').strip()
        branch = os.getenv('TIKCDN_BRANCH','').strip() or 'main'
        if not files or not token or not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9_./-]{0,126}',branch) or '..' in branch:
            return
        timeout = aiohttp.ClientTimeout(total=300,connect=12,sock_read=90)
        headers = {'Authorization':'Bearer '+token,'Accept':'application/vnd.github+json',
                   'X-GitHub-Api-Version':'2022-11-28','User-Agent':'TikTok-Telegram-Bot'}
        async with aiohttp.ClientSession(timeout=timeout,headers=headers) as session:
            urls = await GitHub(session,branch,self.git_lock).publish(target,files)
        for file in files:
            if file.key in urls:
                self.runner.state.save_mirror(origin,file.name,file.digest,'github',urls[file.key])

    async def publish(self,jid,target,sources):
        if not TARGET.fullmatch(target or '') or not sources:
            return {}
        state = self.runner.state
        origin = self.source_job(state.job(jid))['id']
        origin_lock = self.origin_locks.get(origin)
        if origin_lock is None:
            origin_lock = self.origin_locks[origin] = asyncio.Lock()
        # A button can request a file copy while its original is being
        # mirrored. Wait for that origin's receipts before reusing its links.
        async with origin_lock,self.slots:
            files = []
            for key,(name,path) in sources.items():
                try:
                    files.append(await asyncio.to_thread(File.read,key,name,path))
                except (OSError,ValueError) as exc:
                    logging.info('Mirror source unavailable, %s',type(exc).__name__)
            pending = [f for f in files if not state.mirror_receipt(origin,f.name,f.digest)[1]]
            async def bounded(provider,call):
                try:
                    await asyncio.wait_for(call,360)
                except Exception as exc:
                    logging.info('%s mirror unavailable, %s',provider,type(exc).__name__)
            await asyncio.gather(bounded('OnlyFiles',self.only(origin,files)),
                                 bounded('GitHub',self.github(origin,target,pending)))
            results = {}
            for file in files:
                only,github = state.mirror_receipt(origin,file.name,file.digest)
                if not isinstance(github,str) or not github.startswith(CDN+target+'/'):
                    github = None
                if onlyfiles_link(only) or github:
                    results[file.key] = (onlyfiles_link(only),github)
            return results

    async def delivered_document(self,jid,kind,message,filename,*,defer=False,manual=False):
        r = self.runner
        target = self.snapshot(jid)
        if button_target(target):
            if entry := self.file_entry(r.state.job(jid),message,filename):
                r.state.bind_public_link_files([entry])
            return
        if manual:
            if self.preference(r.state.job(jid)['user_id'])!='on':
                return
        if not TARGET.fullmatch(target):
            return
        r.state.bind_mirror_edits(jid,[(message.message_id,'@'+kind,None,0,None)])
        if not defer:
            # Manual document buttons run in the update polling loop. Wait
            # for their Telegram receipt there, but keep mirror IO out of it.
            self.schedule_documents(jid,{message.message_id})

    def schedule_documents(self,jid,message_ids):
        if self.runner.stop.is_set():
            return
        message_ids = {mid for mid in message_ids if (jid,mid) not in self.document_messages}
        if not message_ids:
            return
        scheduled = {(jid,mid) for mid in message_ids}
        self.document_messages.update(scheduled)
        task = asyncio.create_task(self.edit_delivered(jid,message_ids=message_ids))
        self.documents.add(task)
        def finished(task):
            self.documents.discard(task)
            self.document_messages.difference_update(scheduled)
            if not task.cancelled() and (exc := task.exception()) is not None:
                logging.info('Document mirror task unavailable, %s',type(exc).__name__)
        task.add_done_callback(finished)

    def resume_documents(self):
        pending = {}
        for row in self.runner.state.db.execute("""SELECT job_id,mirror_edits.message_id
                FROM mirror_edits JOIN jobs ON jobs.id=job_id
                WHERE file_key IN ('@caption','@metadata') AND jobs.status IN ('done','failed','uncertain')"""):
            pending.setdefault(row['job_id'],set()).add(row['message_id'])
        for jid,ids in pending.items():
            self.schedule_documents(jid,ids)

    async def close(self):
        tasks = (*self.documents,*self.requests.values())
        for task in tasks:
            task.cancel()
        await asyncio.gather(*tasks,return_exceptions=True)

    async def edit_caption(self,row,entry,caption):
        r = self.runner
        keyboard = InlineKeyboardMarkup.model_validate_json(entry['keyboard']) if entry['keyboard'] else None
        await r.api(row['chat_id'],lambda:r.bot.edit_message_caption(
            chat_id=row['chat_id'],message_id=entry['message_id'],caption=caption,
            parse_mode='HTML',reply_markup=keyboard))

    @staticmethod
    def document_payload(row,key):
        if key=='@caption' and row['caption_text']:
            return row['caption_post_id']+'.txt',row['caption_text'].encode('utf-8')
        if key=='@metadata' and row['metadata_data']:
            fmt = chosen_format(row['metadata_format'])
            return row['metadata_post_id']+'.metadata.'+fmt,export_metadata(row['metadata_data'],fmt)
        return None

    async def edit_delivered(self,jid,*,sources=None,records=None,render=None,message_ids=None,photo_numbers=None):
        r = self.runner
        row = r.state.job(jid)
        target = row['mirror_target']
        if not TARGET.fullmatch(target or ''):
            return
        entries = [entry for entry in r.state.pending_mirror_edits(jid)
                   if ((jid,entry['message_id']) not in self.document_messages if message_ids is None
                       else entry['message_id'] in message_ids)]
        if not entries:
            return
        sources,records = sources or {},records or {}
        photo_numbers = photo_numbers or {}
        translate = lambda label:r.tr(row['user_id'],label)
        try:
            with tempfile.TemporaryDirectory(prefix='mirror-edit-',dir=r.work) as td:
                uploads,matched = {},[]
                for entry in entries:
                    if r.stop.is_set():
                        return
                    key = entry['file_key']
                    if key in records:
                        record = records[key]
                        key = record['file']
                        if record['sha256']!=entry['digest'] or key not in sources:
                            continue
                        uploads[key] = sources[key]
                    elif key.startswith('@'):
                        try:
                            payload = self.document_payload(row,key)
                            if not payload:
                                continue
                            name,data = payload
                            if not NAME.fullmatch(name) or len(data)>MAX_BYTES:
                                continue
                            path = Path(td)/name
                            if key not in uploads:
                                await asyncio.to_thread(path.write_bytes,data)
                                uploads[key] = (name,path)
                        except (TypeError,ValueError,UnicodeError,zlib.error) as exc:
                            logging.info('Document mirror unavailable, %s',type(exc).__name__)
                            continue
                    else:
                        continue
                    matched.append((entry,key))
                links = await self.publish(jid,target,uploads)
                for entry,key in matched:
                    if r.stop.is_set():
                        return
                    if key in links:
                        suffix = footer(links[key],translate,photo_number=photo_numbers.get(key))
                        caption = render(suffix)[0] if render and entry['has_body'] else suffix[0]
                        try:
                            await self.edit_caption(row,entry,caption)
                        except AiogramError as exc:
                            logging.info('Mirror caption edit unavailable, %s',type(exc).__name__)
                    r.state.finish_mirror_edit(jid,entry['message_id'])
        except (OSError,ValueError) as exc:
            logging.info('Mirror edit unavailable, %s',type(exc).__name__)
