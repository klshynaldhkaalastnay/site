"""Optional ZIP source import, state always lives outside the imported code"""
import os
from pathlib import Path, PurePosixPath
import shutil
import sys
import tempfile
import urllib.request
import zipfile


def extract_project(archive,destination):
    with zipfile.ZipFile(archive) as z:
        files = z.infolist()
        if sum(f.file_size for f in files)>30_000_000 or len(files)>500:
            raise ValueError('Bot ZIP is too large')
        for item in files:
            p = PurePosixPath(item.filename)
            mode = item.external_attr>>16
            if p.is_absolute() or '..' in p.parts or '\\' in item.filename or mode & 0o170000 == 0o120000:
                raise ValueError('Unsafe ZIP entry')
        with tempfile.TemporaryDirectory() as td:
            z.extractall(td)
            candidates = [p.parent for p in Path(td).rglob('bot.py') if (p.parent/'requirements.txt').is_file()]
            if len(candidates)!=1:
                raise ValueError('ZIP must contain exactly one bot project')
            source = candidates[0]
            if destination.exists():
                shutil.rmtree(destination)
            destination.mkdir(parents=True)
            # Never import saved credentials or queue data from a code ZIP
            for file in source.iterdir():
                if file.is_file() and (file.suffix=='.py' or file.name in ('requirements.txt','README.md')):
                    shutil.copy2(file,destination/file.name)
            workflow = source/'.github/workflows/tiktok.yml'
            if workflow.is_file():
                target = destination/'.github/workflows/tiktok.yml'
                target.parent.mkdir(parents=True)
                shutil.copy2(workflow,target)


def main():
    root = Path.cwd()
    app = root/'app'
    url = os.getenv('APP_ZIP_URL','').strip()
    refresh = os.getenv('FORCE_REIMPORT','false')=='true'
    if url:
        if refresh or not (app/'bot.py').is_file():
            if not url.startswith('https://'):
                raise ValueError('APP_ZIP_URL must use HTTPS')
            with tempfile.TemporaryDirectory() as td:
                archive = Path(td)/'app.zip'
                with urllib.request.urlopen(url,timeout=60) as response,archive.open('wb') as out:
                    count = 0
                    while chunk:=response.read(1024*1024):
                        count += len(chunk)
                        if count>30_000_000:
                            raise ValueError('Bot ZIP is too large')
                        out.write(chunk)
                extract_project(archive,app)
        source = app
    else:
        source = root
    required = ('bot.py','worker.py','state.py','common.py','backup.py','requirements.txt')
    if any(not (source/p).is_file() for p in required):
        raise ValueError('Bot source files are missing')
    with open(os.environ['GITHUB_ENV'],'a') as out:
        out.write('BOT_SOURCE_DIR='+str(source)+'\n')
    print('Bot source ready')


if __name__=='__main__':
    try:
        main()
    except Exception as exc:
        print(f'Source import failed, {type(exc).__name__}',file=sys.stderr)
        sys.exit(1)
