"""Isolated gallery-dl native extraction and bounded HTTP downloads, no converters"""
import hashlib
import ipaddress
import json
import logging
import math
import re
from pathlib import Path
import shutil
import socket
import sys
from urllib.parse import urlsplit, urljoin

import requests
from gallery_dl import config, extractor
from gallery_dl.extractor.common import Message
from PIL import Image
from mutagen import MutagenError
from mutagen.id3 import ID3, ID3NoHeaderError, TIT2, TPE1, TALB, APIC, TXXX, WOAS, TLEN
from mutagen.mp4 import MP4, MP4Cover
from common import MAX_BYTES, normalize_url, POST_RE, MUSIC_RE, media_preference
from video_compression import (options as compression_options, should_compress, compress_video,
                         digest_file, MAX_VIDEO_INPUT_BYTES, CompressionError, CompressionTooLarge)


DIAGNOSTICS = []


def note(stage, reason, exc=None, status=None):
    # Only internal labels, exception class names and numeric status codes leave
    # the worker. Never include exception text, URLs, HTML or cookie values.
    entry = {'stage':stage, 'reason':reason}
    if exc is not None:
        entry['exception'] = type(exc).__name__
    if isinstance(status,int):
        entry['status'] = status
    DIAGNOSTICS.append(entry)
    del DIAGNOSTICS[:-40]


def media_addresses(value):
    if isinstance(value,str):
        return [value] if value.startswith('https://') else []
    if isinstance(value,list):
        return list(dict.fromkeys(url for item in value for url in media_addresses(item)))[:4]
    if isinstance(value,dict):
        for key in ('urlList','UrlList','url_list','url','Url'):
            urls = media_addresses(value.get(key))
            if urls:
                return urls
    return []


def music_addresses(music):
    if not isinstance(music,dict):
        return []
    return media_addresses(music.get('playUrl')) or media_addresses(music.get('play_url'))


class AccessObserver(logging.Handler):
    def __init__(self):
        super().__init__()
        self.refused = False

    def emit(self, record):
        # Observe only the category, never save cookie-bearing messages or URLs
        message = record.getMessage().lower()
        if any(word in message for word in ('authorizationerror', 'redirect to login', '403 forbidden', '401 unauthorized', 'login required', 'need cookies')):
            self.refused = True


class TooLarge(Exception):
    pass


class VideoInputTooLarge(TooLarge):
    pass


class Authentication(Exception):
    pass


def public_url(url):
    p = urlsplit(url)
    if p.scheme != 'https' or not p.hostname or p.username or p.password or p.port not in (None,443):
        raise ValueError('Unsupported media address')
    addresses = socket.getaddrinfo(p.hostname,443,type=socket.SOCK_STREAM)
    if not addresses or any(not ipaddress.ip_address(a[4][0]).is_global for a in addresses):
        raise ValueError('Unsupported media address')


def get(session, url, *, tiktok_only=False):
    for _ in range(8):
        public_url(url)
        if tiktok_only and urlsplit(url).hostname not in ('www.tiktok.com','tiktok.com','m.tiktok.com','vm.tiktok.com','vt.tiktok.com'):
            raise ValueError('Invalid TikTok redirect')
        response = session.get(url, stream=True, allow_redirects=False, timeout=(15,40))
        if response.status_code in (301,302,303,307,308):
            new_url = urljoin(url, response.headers.get('Location',''))
            response.close()
            url = new_url
            continue
        if response.status_code in (401,403):
            note('http','access_refused',status=response.status_code)
            response.close()
            raise Authentication('TikTok refused access')
        response.raise_for_status()
        return response
    raise ValueError('Too many redirects')


def resolve(url):
    if POST_RE.fullmatch(urlsplit(url).path) or MUSIC_RE.fullmatch(urlsplit(url).path):
        return normalize_url(url)
    with requests.Session() as s:
        s.trust_env = False
        s.headers['User-Agent'] = 'Mozilla/5.0'
        with get(s,url,tiktok_only=True) as response:
            resolved = normalize_url(response.url)
    if not (POST_RE.fullmatch(urlsplit(resolved).path) or MUSIC_RE.fullmatch(urlsplit(resolved).path)):
        raise ValueError('The share link did not resolve to a post')
    return resolved


def save_response(response, path, limit=None):
    limit = MAX_BYTES if limit is None else limit
    try:
        if int(response.headers.get('Content-Length',0)) > limit:
            raise TooLarge()
    except ValueError:
        pass
    total = 0
    digest = hashlib.sha256()
    try:
        with path.open('wb') as out:
            for chunk in response.iter_content(128*1024):
                if not chunk:
                    continue
                total += len(chunk)
                if total > limit:
                    raise TooLarge()
                if shutil.disk_usage(path.parent).free < 100_000_000:
                    raise OSError('Low disk space')
                digest.update(chunk)
                out.write(chunk)
        if not total:
            raise ValueError('Empty media')
        return digest.hexdigest()
    except BaseException:
        path.unlink(missing_ok=True)
        raise


def sound_name(title, post_id):
    title = title.strip() if isinstance(title, str) else ''
    name = re.sub(r'[<>:"/\\|?*\x00-\x1f\x7f]', '_', title).strip(' .')
    name = name.encode('utf-8')[:180].decode('utf-8', errors='ignore').rstrip(' .')
    if not name or name.split('.')[0].upper() in {'CON','PRN','AUX','NUL',*[f'COM{i}' for i in range(1,10)],*[f'LPT{i}' for i in range(1,10)]}:
        name = post_id
    return name


def sound_artwork(session, music, directory):
    raw = directory/'sound-cover.download'
    thumb = directory/'sound-thumbnail.jpg'
    for key in ('coverLarge','coverMedium','coverThumb'):
        urls = media_addresses(music.get(key))
        if not urls:
            continue
        try:
            with get(session,urls[0]) as response:
                save_response(response,raw)
            with Image.open(raw) as picture:
                if picture.width * picture.height > 20_000_000:
                    continue
                picture.load()
                if picture.format in ('JPEG','PNG'):
                    # Preserve original compressed bytes, dimensions and quality
                    mime = 'image/jpeg' if picture.format=='JPEG' else 'image/png'
                    cover = directory/('sound-cover.jpg' if picture.format=='JPEG' else 'sound-cover.png')
                    shutil.copyfile(raw,cover)
                else:
                    # MP4 artwork supports JPEG/PNG, use lossless PNG without resizing
                    mime = 'image/png'
                    cover = directory/'sound-cover.png'
                    picture.convert('RGBA').save(cover,format='PNG')
                if cover.stat().st_size > MAX_BYTES:
                    cover.unlink(missing_ok=True)
                    continue
                preview = picture.convert('RGB')
                preview.thumbnail((320,320))
                preview.save(thumb,format='JPEG',quality=80)
            thumbnail = thumb.name if thumb.stat().st_size < 200_000 else None
            if not thumbnail:
                thumb.unlink(missing_ok=True)
            return {'cover':cover.name,'cover_mime':mime,'thumbnail':thumbnail}
        except (requests.RequestException,Authentication,TooLarge,ValueError,OSError,Image.DecompressionBombError):
            pass
        finally:
            raw.unlink(missing_ok=True)
    thumb.unlink(missing_ok=True)
    return {}


def embed_sound_metadata(path, music, post_id, record, source_url):
    def value(key):
        item = music.get(key)
        return item.strip()[:4096] if isinstance(item,str) else ''
    title = value('title') or post_id
    artist, album = value('authorName'), value('album')
    cover = (path.parent/record['cover']).read_bytes() if record.get('cover') else None
    identifiers = {'Source URL':source_url}
    if not MUSIC_RE.fullmatch(urlsplit(source_url).path):
        identifiers['TikTok Post ID'] = post_id
    if isinstance(music.get('id'),(str,int)):
        identifiers['TikTok Sound ID'] = str(music['id'])[:128]
    if record.get('duration'):
        identifiers['TikTok Sound Duration'] = str(record['duration'])
    if path.suffix == '.mp3':
        try:
            tags = ID3(path)
        except ID3NoHeaderError:
            tags = ID3()
        tags.add(TIT2(encoding=3,text=title))
        if artist:
            tags.add(TPE1(encoding=3,text=artist))
        if album:
            tags.add(TALB(encoding=3,text=album))
        if cover:
            tags.delall('APIC')
            tags.add(APIC(encoding=3,mime=record['cover_mime'],type=3,desc='Cover',data=cover))
        if record.get('duration'):
            tags.add(TLEN(encoding=3,text=str(record['duration']*1000)))
        tags.add(WOAS(url=source_url))
        for key,value_ in identifiers.items():
            tags.add(TXXX(encoding=3,desc=key,text=value_))
        tags.save(path,v2_version=3)
    else:
        audio = MP4(path)
        if audio.tags is None:
            audio.add_tags()
        audio['\xa9nam'] = [title]
        if artist:
            audio['\xa9ART'] = [artist]
        if album:
            audio['\xa9alb'] = [album]
        if cover:
            audio['covr'] = [MP4Cover(cover,imageformat=MP4Cover.FORMAT_PNG if record['cover_mime']=='image/png' else MP4Cover.FORMAT_JPEG)]
        for key,value_ in identifiers.items():
            audio['----:com.apple.iTunes:'+key] = [value_.encode('utf-8')]
        audio.save()


def download_sound(session, music, post_id, directory, source_url=None):
    """Use TikTok's separate sound track, without extracting or converting video"""
    path = directory / (post_id + '.audio')
    final = None
    completed = False
    stage = 'audio_metadata'
    try:
        urls = music_addresses(music)
        if not urls:
            note(stage,'missing_play_url' if music else 'missing_music_metadata')
            return None, 'unavailable'
        stage = 'audio_download'
        for index,url in enumerate(urls):
            try:
                with get(session, url) as response:
                    digest = save_response(response, path)
                break
            except (requests.RequestException, Authentication, ValueError) as exc:
                note(stage,'address_failed',exc,status=getattr(getattr(exc,'response',None),'status_code',None))
                if index == len(urls)-1:
                    raise
        stage = 'audio_format'
        with path.open('rb') as file:
            header = file.read(16)
        if header.startswith(b'ID3') or (len(header) >= 2 and header[0] == 255 and header[1] & 0xe0 == 0xe0 and header[1] & 6 != 0):
            extension = '.mp3'
        elif header[4:8] == b'ftyp':
            extension = '.m4a'
        else:
            raise ValueError('Unsupported audio format')
        sound_title = music.get('title')
        sound_title = sound_title.strip() if isinstance(sound_title,str) else ''
        artist = music.get('authorName')
        artist = artist.strip() if isinstance(artist,str) else ''
        # Keep internal names separate to avoid collisions with numbered photo files
        final = directory / ('sound' + extension)
        path.rename(final)
        record = {'file':final.name, 'kind':'audio', 'sha256':digest,
                  'filename':sound_name(sound_title,post_id)+extension,
                  'title':sound_title[:128] or post_id,'performer':artist[:128] or None,
                  **sound_artwork(session,music,directory)}
        try:
            duration = int(music.get('duration',0))
            if 0 < duration <= 86400:
                record['duration'] = duration
        except (ValueError,TypeError,OverflowError):
            pass
        stage = 'audio_tags'
        embed_sound_metadata(final,music,post_id,record,
                             source_url or f'https://www.tiktok.com/share/video/{post_id}')
        if final.stat().st_size > MAX_BYTES:
            raise TooLarge()
        completed = True
        return record, None
    except TooLarge:
        note(stage,'too_large')
        return None, 'too_large'
    except (requests.RequestException, Authentication, ValueError, MutagenError) as exc:
        note(stage,'failed',exc,status=getattr(getattr(exc,'response',None),'status_code',None))
        return None, 'unavailable'
    finally:
        path.unlink(missing_ok=True)
        if final is not None and not completed:
            final.unlink(missing_ok=True)


def music_from_page(data, sound_id):
    """Only accept the requested sound, never a related video's audio."""
    if isinstance(data, dict):
        if str(data.get('id', data.get('musicId', ''))) == sound_id and music_addresses(data):
            return dict(data,id=sound_id)
        for value in data.values():
            found = music_from_page(value, sound_id)
            if found:
                return found
    elif isinstance(data, list):
        for value in data:
            found = music_from_page(value, sound_id)
            if found:
                return found
    return None


def download_music_page(url, sound_id, directory):
    from gallery_dl.extractor.tiktok import TiktokExtractor
    class SoundPage(TiktokExtractor):
        subcategory = 'music'
    ex = SoundPage(re.match(r'.*', url))
    ex.initialize()
    note('sound_page','anonymous_session')
    ex.session.headers['Referer'] = url
    music = None
    try:
        data = ex._extract_rehydration_data(url)
        music = music_from_page(data, sound_id)
        note('sound_page','play_url_found' if music else 'no_play_url_for_requested_sound')
    except Exception as exc:
        note('sound_page','extraction_failed',exc)
    if not music:
        # TikTok's detail endpoint can carry musicInfo.music when the HTML
        # only includes display metadata. Reuse the same anonymous session.
        try:
            with get(ex.session,'https://www.tiktok.com/api/music/detail/?musicId='+sound_id,
                     tiktok_only=True) as response:
                body = bytearray()
                for chunk in response.iter_content(65536):
                    body.extend(chunk)
                    if len(body) > 2_000_000:
                        raise ValueError('Music metadata too large')
                if not body:
                    note('sound_detail','empty_response')
                data = json.loads(body) if body else {}
            status = data.get('statusCode') if isinstance(data,dict) else None
            music = music_from_page(data,sound_id)
            note('sound_detail','play_url_found' if music else 'no_play_url_for_requested_sound',status=status)
        except Exception as exc:
            note('sound_detail','request_failed',exc,
                 status=getattr(getattr(exc,'response',None),'status_code',None))
    if not music:
        from sound_browser import extract_sound
        music = extract_sound(url,sound_id,ex.session,music_from_page,note)
    if not music:
        return {'ok':False, 'error':'sound_unavailable'}
    audio, error = download_sound(ex.session, music, sound_id, directory, url)
    if error:
        return {'ok':False, 'error':'audio_'+error}
    audio['reply_to_source'] = True
    return {'ok':True, 'media':[audio], 'title':''}


def download_subtitle(session, url, metadata, post_id, directory, index):
    path = directory / f'subtitle-{index:04}.part'
    try:
        with get(session,url) as response:
            digest = save_response(response,path)
        extension = str(metadata.get('extension') or metadata.get('subtitle_format') or 'txt').lower()
        extension = {'webvtt':'vtt','creator_caption':'json'}.get(extension,extension)
        if not re.fullmatch(r'[a-z0-9]{1,16}',extension):
            extension = 'txt'
        language = metadata.get('subtitle_lang_codename') or metadata.get('subtitle_lang_id') or 'unknown'
        source = metadata.get('subtitle_source') or 'unknown'
        version = metadata.get('subtitle_version') or '1'
        track_id = str(metadata.get('file_id') or f'{language}_{source}_{version}_{extension}')
        final = path.with_suffix('.'+extension)
        path.rename(final)
        return {'file':final.name,'filename':sound_name(f'{post_id}_{language}_{source}_{version}',post_id)+'.'+extension,
                'kind':'subtitle','subtitle_id':track_id,'sha256':digest}, None
    except TooLarge as exc:
        note('subtitles','too_large',exc)
        return None, 'too_large'
    except (requests.RequestException,Authentication,ValueError,OSError) as exc:
        note('subtitles','download_failed',exc)
        return None, 'unavailable'
    finally:
        path.unlink(missing_ok=True)


def download(url, directory, include_audio=True, audio_only=False, compression=None, include_subtitles=False,
             subtitles_only=False, audio_button=True, subtitle_button=False):
    if audio_only and subtitles_only:
        raise ValueError('An extraction request must select audio or subtitles')
    compression = compression_options(compression)
    # Do not load a user/system gallery-dl configuration or spawn its postprocessors
    config.clear()
    config.set(('extractor','tiktok'),'videos',True)
    config.set(('extractor','tiktok'),'photos',True)
    config.set(('extractor','tiktok'),'audio',False)
    config.set(('extractor','tiktok'),'covers',False)
    config.set(('extractor','tiktok'),'subtitles','all' if (include_subtitles or subtitles_only) and not audio_only else False)
    config.set(('extractor','tiktok','posts'),'ytdl',False)
    config.set(('extractor',),'retries',2)
    config.set(('extractor',),'timeout',30)
    # Saved login cookies are imported only inside the Chromium sound fallback.
    note('cookies','chromium_only')
    note('resolve','started')
    resolved = resolve(url)
    note('resolve','sound' if MUSIC_RE.fullmatch(urlsplit(resolved).path) else 'post')
    music_match = MUSIC_RE.fullmatch(urlsplit(resolved).path)
    if music_match:
        if subtitles_only:
            return {'ok':False,'error':'no_subtitles'}
        return download_music_page(resolved, music_match.group(1), directory)
    ex = extractor.find(resolved)
    if ex is None or ex.category != 'tiktok' or ex.subcategory != 'post':
        raise ValueError('Only single TikTok posts are supported')
    post_match = POST_RE.fullmatch(urlsplit(resolved).path)
    if not post_match:
        raise ValueError('Missing TikTok post ID')
    post_id = post_match.group(1)
    music = None
    records = []
    video_post = False
    subtitle_entries = []
    title = ''
    account_name = ''
    username = ''
    for message in ex:
        if message[0] != Message.Url:
            continue
        media_url, metadata = message[1:]
        if music is None and isinstance(metadata.get('music'), dict):
            music = dict(metadata['music'])
        if not title:
            title = metadata.get('description') or metadata.get('title') or metadata.get('desc') or ''
        author = metadata.get('author') or {}
        if isinstance(author, dict):
            account_name = account_name or author.get('nickname') or ''
            username = username or author.get('uniqueId') or ''
        username = username or metadata.get('user') or ''
        kind = metadata.get('type')
        if kind=='subtitle':
            if (include_subtitles or subtitles_only) and not audio_only:
                # gallery-dl reuses the post dict, retain this track's fields before it changes.
                subtitle_entries.append((media_url,dict(metadata)))
            continue
        if kind not in ('image','video'):
            continue
        video_post = video_post or kind=='video'
        if subtitles_only:
            # Retain the post/track metadata without fetching video, images,
            # sound or cover art, and without starting FFmpeg or Chromium.
            continue
        if audio_only:
            # Fetch the original post's sound without downloading its media again
            audio, error = download_sound(ex.session, music, post_id, directory, resolved)
            if error:
                return {'ok':False, 'error':'audio_'+error}
            audio['reply_to_source'] = True
            return {'ok':True, 'media':[audio], 'title':''}
        if len(records) >= 200:
            raise ValueError('Too many images in this post')
        last = None
        path = directory / f'{len(records)+1:04}.media'
        limit = MAX_VIDEO_INPUT_BYTES if kind=='video' and compression['mode']!='none' else MAX_BYTES
        for candidate in [media_url, *metadata.get('_fallback',[])]:
            try:
                with get(ex.session, candidate) as response:
                    digest = save_response(response,path,limit=limit)
                break
            except TooLarge:
                if limit>MAX_BYTES:
                    raise VideoInputTooLarge()
                raise
            except (requests.RequestException, Authentication, ValueError) as exc:
                last = exc
        else:
            raise last or ValueError('Media download failed')
        if kind == 'image':
            with Image.open(path) as img:
                width,height = img.size
                fmt = img.format
                img.verify()
            ext = {'JPEG':'jpg','PNG':'png','WEBP':'webp','GIF':'gif'}.get(fmt,'img')
        else:
            with path.open('rb') as file:
                header = file.read(16)
            if header[4:8] == b'ftyp':
                ext = 'mp4'
            elif header[:4] == b'\x1aE\xdf\xa3':
                ext = 'webm'
            else:
                raise ValueError('The returned file is not a supported video')
            width,height = metadata.get('width',0),metadata.get('height',0)
        final = path.with_suffix('.'+ext)
        path.rename(final)
        record = {'file':final.name,'kind':kind,'sha256':digest,
                  'width':width,'height':height,'duration':metadata.get('duration',0)}
        if kind=='video' and should_compress(final.stat().st_size,compression):
            (directory/'progress.txt').write_text('Compressing...')
            final, info = compress_video(final,compression,note)
            record.update(file=final.name,sha256=digest_file(final),source_sha256=digest,
                          width=info['width'],height=info['height'],duration=math.ceil(info['duration']),
                          supports_streaming=final.name.endswith('.compressed.mp4'))
        records.append(record)
    if subtitles_only and (not video_post or not subtitle_entries):
        return {'ok':False,'error':'no_subtitles'}
    if not records and not subtitles_only:
        raise ValueError('No downloadable media was returned')
    audio, audio_error = (download_sound(ex.session, music, post_id, directory, resolved)
                          if include_audio and not subtitles_only else (None, None))
    if not include_audio and audio_button:
        for record in records:
            if record['kind'] in ('video','image'):
                record['manual_audio'] = True
    if not include_subtitles and subtitle_button and not subtitles_only:
        for record in records:
            if record['kind']=='video':
                record['manual_subtitles'] = True
    if audio:
        records.append(audio)
    subtitle_error = None
    seen_subtitles = set()
    if (include_subtitles or subtitles_only) and not audio_only and video_post:
        for index,(subtitle_url,metadata) in enumerate(subtitle_entries,1):
            subtitle,error = download_subtitle(ex.session,subtitle_url,metadata,post_id,directory,index)
            if error:
                subtitle_error = subtitle_error or error
            if subtitle:
                key = (subtitle['subtitle_id'],subtitle['sha256'])
                if key in seen_subtitles:
                    (directory/subtitle['file']).unlink(missing_ok=True)
                    continue
                seen_subtitles.add(key)
                if subtitles_only:
                    subtitle['reply_to_source'] = True
                records.append(subtitle)
    if subtitles_only and not records:
        return {'ok':False,'error':'subtitles_too_large' if subtitle_error=='too_large' else 'subtitles_unavailable'}
    return {'ok':True,'media':records,'audio_error':audio_error,'title':str(title),
            'post_id':post_id,
            'subtitle_error':subtitle_error,
            'account_name':str(account_name),'username':str(username)}


def main():
    observer = AccessObserver()
    logging.disable(logging.NOTSET)
    logging.getLogger().handlers = [observer]
    logging.getLogger().setLevel(logging.WARNING)
    directory = Path(sys.argv[2]).resolve()
    directory.mkdir(parents=True,exist_ok=True)
    try:
        audio_mode = media_preference(next((arg.split('=',1)[1] for arg in sys.argv[3:]
                                            if arg.startswith('--audio=')),None),'on')
        subtitle_mode = media_preference(next((arg.split('=',1)[1] for arg in sys.argv[3:]
                                               if arg.startswith('--subtitles=')),None),'off_no_button')
        result = download(sys.argv[1],directory,include_audio=audio_mode=='on',
                          audio_only='--audio-only' in sys.argv[3:],
                          subtitles_only='--subtitles-only' in sys.argv[3:],
                          include_subtitles=subtitle_mode=='on',
                          audio_button=audio_mode=='off',subtitle_button=subtitle_mode=='off',
                          compression=next((arg.split('=',1)[1] for arg in sys.argv[3:]
                                            if arg.startswith('--compression=')),None))
    except VideoInputTooLarge:
        note('worker','video_input_too_large')
        result = {'ok':False,'error':'video_input_too_large'}
    except TooLarge:
        note('worker','too_large')
        result = {'ok':False,'error':'too_large'}
    except CompressionTooLarge as exc:
        note('compression','cannot_fit',exc)
        result = {'ok':False,'error':'compression_too_large'}
    except CompressionError as exc:
        note('compression','failed',exc)
        result = {'ok':False,'error':'compression_failed'}
    except Authentication as exc:
        note('worker','authentication_failed',exc)
        result = {'ok':False,'error':'authentication'}
    except Exception as exc:
        note('worker','failed',exc)
        result = {'ok':False,'error':'authentication' if observer.refused else 'unavailable'}
    result['diagnostics'] = DIAGNOSTICS
    (directory/'result.json').write_text(json.dumps(result),encoding='utf-8')
    return 0 if result['ok'] else 1


if __name__ == '__main__':
    sys.exit(main())
