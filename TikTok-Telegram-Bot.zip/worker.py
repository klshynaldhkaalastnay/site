"""Isolated gallery-dl native extraction and bounded HTTP downloads, no converters"""
import hashlib
import ipaddress
import json
import logging
import os
from pathlib import Path
import shutil
import socket
import sys
from urllib.parse import urlsplit, urljoin

import requests
from gallery_dl import config, extractor
from gallery_dl.extractor.common import Message
from PIL import Image
from common import MAX_BYTES, normalize_url, POST_RE


class AccessObserver(logging.Handler):
    def __init__(self):
        super().__init__()
        self.refused = False

    def emit(self, record):
        # Observe only the category, never save cookie-bearing messages or URLs
        message = record.getMessage().lower()
        if any(word in message for word in ('authorizationerror', 'redirect to login', '403 forbidden', '401 unauthorized', 'login required', 'need cookies')):
            self.refused = True


class TooLarge(Exception):
    pass


class Authentication(Exception):
    pass


def public_url(url):
    p = urlsplit(url)
    if p.scheme != 'https' or not p.hostname or p.username or p.password or p.port not in (None,443):
        raise ValueError('Unsupported media address')
    addresses = socket.getaddrinfo(p.hostname,443,type=socket.SOCK_STREAM)
    if not addresses or any(not ipaddress.ip_address(a[4][0]).is_global for a in addresses):
        raise ValueError('Unsupported media address')


def get(session, url, *, tiktok_only=False):
    for _ in range(8):
        public_url(url)
        if tiktok_only and urlsplit(url).hostname not in ('www.tiktok.com','tiktok.com','m.tiktok.com','vm.tiktok.com','vt.tiktok.com'):
            raise ValueError('Invalid TikTok redirect')
        response = session.get(url, stream=True, allow_redirects=False, timeout=(15,40))
        if response.status_code in (301,302,303,307,308):
            new_url = urljoin(url, response.headers.get('Location',''))
            response.close()
            url = new_url
            continue
        if response.status_code in (401,403):
            response.close()
            raise Authentication('TikTok refused access')
        response.raise_for_status()
        return response
    raise ValueError('Too many redirects')


def resolve(url):
    if POST_RE.fullmatch(urlsplit(url).path):
        return normalize_url(url)
    with requests.Session() as s:
        s.trust_env = False
        s.headers['User-Agent'] = 'Mozilla/5.0'
        with get(s,url,tiktok_only=True) as response:
            resolved = normalize_url(response.url)
    if not POST_RE.fullmatch(urlsplit(resolved).path):
        raise ValueError('The share link did not resolve to a post')
    return resolved


def save_response(response, path):
    try:
        if int(response.headers.get('Content-Length',0)) > MAX_BYTES:
            raise TooLarge()
    except ValueError:
        pass
    total = 0
    digest = hashlib.sha256()
    try:
        with path.open('wb') as out:
            for chunk in response.iter_content(128*1024):
                if not chunk:
                    continue
                total += len(chunk)
                if total > MAX_BYTES:
                    raise TooLarge()
                if shutil.disk_usage(path.parent).free < 100_000_000:
                    raise OSError('Low disk space')
                digest.update(chunk)
                out.write(chunk)
        if not total:
            raise ValueError('Empty media')
        return digest.hexdigest()
    except BaseException:
        path.unlink(missing_ok=True)
        raise


def download(url, directory):
    # Do not load a user/system gallery-dl configuration or spawn its postprocessors
    config.clear()
    config.set(('extractor','tiktok'),'videos',True)
    config.set(('extractor','tiktok'),'photos',True)
    config.set(('extractor','tiktok'),'audio',False)
    config.set(('extractor','tiktok'),'covers',False)
    config.set(('extractor','tiktok'),'subtitles',False)
    config.set(('extractor','tiktok','posts'),'ytdl',False)
    config.set(('extractor',),'retries',2)
    config.set(('extractor',),'timeout',30)
    cookies = os.environ.get('TIKTOK_COOKIE_FILE')
    if cookies:
        config.set(('extractor','tiktok'),'cookies',cookies)
    resolved = resolve(url)
    ex = extractor.find(resolved)
    if ex is None or ex.category != 'tiktok' or ex.subcategory != 'post':
        raise ValueError('Only single TikTok posts are supported')
    records = []
    title = ''
    account_name = ''
    username = ''
    for message in ex:
        if message[0] != Message.Url:
            continue
        media_url, metadata = message[1:]
        if not title:
            title = metadata.get('description') or metadata.get('title') or metadata.get('desc') or ''
        author = metadata.get('author') or {}
        if isinstance(author, dict):
            account_name = account_name or author.get('nickname') or ''
            username = username or author.get('uniqueId') or ''
        username = username or metadata.get('user') or ''
        kind = metadata.get('type')
        if kind not in ('image','video'):
            continue
        if len(records) >= 200:
            raise ValueError('Too many images in this post')
        last = None
        path = directory / f'{len(records)+1:04}.media'
        for candidate in [media_url, *metadata.get('_fallback',[])]:
            try:
                with get(ex.session, candidate) as response:
                    digest = save_response(response,path)
                break
            except TooLarge:
                raise
            except (requests.RequestException, Authentication, ValueError) as exc:
                last = exc
        else:
            raise last or ValueError('Media download failed')
        if kind == 'image':
            with Image.open(path) as img:
                width,height = img.size
                fmt = img.format
                img.verify()
            ext = {'JPEG':'jpg','PNG':'png','WEBP':'webp','GIF':'gif'}.get(fmt,'img')
        else:
            with path.open('rb') as file:
                header = file.read(16)
            if header[4:8] == b'ftyp':
                ext = 'mp4'
            elif header[:4] == b'\x1aE\xdf\xa3':
                ext = 'webm'
            else:
                raise ValueError('The returned file is not a supported video')
            width,height = metadata.get('width',0),metadata.get('height',0)
        final = path.with_suffix('.'+ext)
        path.rename(final)
        records.append({'file':final.name,'kind':kind,'sha256':digest,
                        'width':width,'height':height,'duration':metadata.get('duration',0)})
    if not records:
        raise ValueError('No downloadable media was returned')
    return {'ok':True,'media':records,'title':str(title),
            'account_name':str(account_name),'username':str(username)}


def main():
    observer = AccessObserver()
    logging.disable(logging.NOTSET)
    logging.getLogger().handlers = [observer]
    logging.getLogger().setLevel(logging.WARNING)
    directory = Path(sys.argv[2]).resolve()
    directory.mkdir(parents=True,exist_ok=True)
    try:
        result = download(sys.argv[1],directory)
    except TooLarge:
        result = {'ok':False,'error':'too_large'}
    except Authentication:
        result = {'ok':False,'error':'authentication'}
    except Exception:
        result = {'ok':False,'error':'authentication' if observer.refused else 'unavailable'}
    (directory/'result.json').write_text(json.dumps(result),encoding='utf-8')
    return 0 if result['ok'] else 1


if __name__ == '__main__':
    sys.exit(main())
