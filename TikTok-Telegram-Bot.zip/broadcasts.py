"""Owner announcements with a durable audience and per-chat delivery receipts."""
import asyncio
import logging
import time
from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup
from aiogram.exceptions import AiogramError, TelegramBadRequest, TelegramEntityTooLarge, TelegramForbiddenError, TelegramNetworkError, TelegramServerError, ClientDecodeError, TelegramRetryAfter, TelegramMigrateToChat


class Broadcasts:
    def __init__(self, runner):
        self.r = runner
        self.db = runner.state.db
        self.db.executescript('''
        CREATE TABLE IF NOT EXISTS known_chats(
          chat_id INTEGER PRIMARY KEY, kind TEXT NOT NULL, active INTEGER NOT NULL, updated REAL NOT NULL);
        CREATE TABLE IF NOT EXISTS broadcasts(
          id INTEGER PRIMARY KEY, source_chat INTEGER NOT NULL, command_message INTEGER NOT NULL,
          preview_message INTEGER, status TEXT NOT NULL, created REAL NOT NULL,
          notified INTEGER NOT NULL DEFAULT 0, UNIQUE(source_chat,command_message));
        CREATE TABLE IF NOT EXISTS broadcast_targets(
          broadcast_id INTEGER NOT NULL, chat_id INTEGER NOT NULL, status TEXT NOT NULL,
          PRIMARY KEY(broadcast_id,chat_id));
        INSERT OR IGNORE INTO known_chats(chat_id,kind,active,updated)
          SELECT DISTINCT chat_id,CASE WHEN chat_id>0 THEN 'private' ELSE 'group' END,1,0 FROM jobs;
        ''')
        self.db.commit()

    def track(self, chat_id, kind=None, active=True):
        kind = kind or ('private' if chat_id > 0 else 'group')
        if kind not in ('private','group','supergroup'):
            return
        with self.db:
            self.db.execute('INSERT INTO known_chats VALUES(?,?,?,?) ON CONFLICT(chat_id) DO UPDATE SET kind=excluded.kind,active=excluded.active,updated=excluded.updated',
                            (chat_id,kind,int(active),time.time()))

    def recover(self):
        with self.db:
            self.db.execute("UPDATE broadcast_targets SET status='uncertain' WHERE status='sending'")
            self.db.execute("UPDATE broadcasts SET status='cancelled' WHERE status='building'")

    async def command(self, msg, user):
        r=self.r
        if user != r.owner:
            await r.tell(msg.chat.id,r.tr(user,'Only the bot owner can use this command'),msg.message_thread_id)
            return
        if msg.chat.id != r.owner:
            await r.tell(msg.chat.id,r.tr(user,'Use /broadcast in our private chat'),msg.message_thread_id)
            return
        source=getattr(msg,'reply_to_message',None)
        if source is None:
            await r.tell(user,r.tr(user,'Reply to the announcement message with /broadcast'))
            return
        if r.stop.is_set():
            return
        existing=self.db.execute('SELECT id FROM broadcasts WHERE source_chat=? AND command_message=?',
                                 (msg.chat.id,msg.message_id)).fetchone()
        if existing:
            return
        with self.db:
            bid=self.db.execute("INSERT INTO broadcasts(source_chat,command_message,status,created) VALUES(?,?,'building',?)",
                                (msg.chat.id,msg.message_id,time.time())).lastrowid
            self.db.execute("INSERT INTO broadcast_targets SELECT ?,chat_id,'pending' FROM known_chats WHERE active=1",(bid,))
        try:
            preview=await r.api(user,lambda:r.bot.copy_message(chat_id=user,from_chat_id=msg.chat.id,message_id=source.message_id))
        except AiogramError:
            with self.db:self.db.execute("UPDATE broadcasts SET status='cancelled' WHERE id=?",(bid,))
            await r.tell(user,r.tr(user,'This message cannot be copied, try a text, photo, video or audio message'))
            return
        with self.db:
            self.db.execute("UPDATE broadcasts SET preview_message=?,status='draft' WHERE id=?",(preview.message_id,bid))
        count=self.db.execute('SELECT COUNT(*) FROM broadcast_targets WHERE broadcast_id=?',(bid,)).fetchone()[0]
        keyboard=InlineKeyboardMarkup(inline_keyboard=[[InlineKeyboardButton(text=r.tr(user,'Send'),callback_data=f'broadcast:{bid}:send'),
                                        InlineKeyboardButton(text=r.tr(user,'Cancel'),callback_data=f'broadcast:{bid}:cancel')]])
        await r.api(user,lambda:r.bot.send_message(user,r.tr(user,'Send the preview above to {n} chats?',n=count),reply_markup=keyboard))

    async def callback(self, query):
        r=self.r
        if query.from_user.id != r.owner or not query.message or query.message.chat.id != r.owner:
            await query.answer()
            return
        parts=(query.data or '').split(':')
        if len(parts)!=3 or not parts[1].isdigit() or parts[2] not in ('send','cancel'):
            await query.answer();return
        bid=int(parts[1]);status='queued' if parts[2]=='send' else 'cancelled'
        with self.db:
            changed=self.db.execute("UPDATE broadcasts SET status=? WHERE id=? AND status='draft'",(status,bid)).rowcount
        await query.answer()
        if changed:
            await r.api(r.owner,lambda:r.bot.edit_message_text(
                text=r.tr(r.owner,'Broadcast queued' if status=='queued' else 'Broadcast cancelled'),
                chat_id=query.message.chat.id,message_id=query.message.message_id))

    def receipt(self, bid, chat, status):
        with self.db:
            self.db.execute('UPDATE broadcast_targets SET status=? WHERE broadcast_id=? AND chat_id=?',(status,bid,chat))

    async def step(self):
        r=self.r
        job=self.db.execute("SELECT * FROM broadcasts WHERE status='queued' ORDER BY id LIMIT 1").fetchone()
        if job is None:
            # Completion notice can be retried independently of recipient sends.
            job=self.db.execute("SELECT * FROM broadcasts WHERE status='done' AND notified=0 ORDER BY id LIMIT 1").fetchone()
            if job:
                counts={row['status']:row['n'] for row in self.db.execute('SELECT status,COUNT(*) n FROM broadcast_targets WHERE broadcast_id=? GROUP BY status',(job['id'],))}
                await r.tell(r.owner,r.tr(r.owner,'Broadcast finished\nSent: {sent}\nSkipped or failed: {failed}\nUnconfirmed: {uncertain}',
                           sent=counts.get('sent',0),failed=counts.get('failed',0)+counts.get('skipped',0),uncertain=counts.get('uncertain',0)))
                with self.db:self.db.execute('UPDATE broadcasts SET notified=1 WHERE id=?',(job['id'],))
            return
        bid=job['id']
        target=self.db.execute("SELECT * FROM broadcast_targets WHERE broadcast_id=? AND status='pending' ORDER BY chat_id LIMIT 1",(bid,)).fetchone()
        if target is None:
            with self.db:self.db.execute("UPDATE broadcasts SET status='done' WHERE id=?",(bid,))
            return
        chat=target['chat_id']
        active=self.db.execute('SELECT active FROM known_chats WHERE chat_id=?',(chat,)).fetchone()
        if not active or not active['active']:
            self.receipt(bid,chat,'skipped');return
        # Persist intent after pacing, just before the actual API request.
        async def send():
            self.receipt(bid,chat,'sending')
            return await r.bot.copy_message(chat_id=chat,from_chat_id=r.owner,message_id=job['preview_message'])
        try:
            await r.api(chat,send)
            self.receipt(bid,chat,'sent')
        except TelegramForbiddenError:
            self.receipt(bid,chat,'failed');self.track(chat,active=False)
        except TelegramMigrateToChat as exc:
            self.track(chat,active=False);self.track(exc.migrate_to_chat_id,'supergroup')
            with self.db:
                self.db.execute("INSERT OR IGNORE INTO broadcast_targets VALUES(?,?,'pending')",(bid,exc.migrate_to_chat_id))
            self.receipt(bid,chat,'skipped')
        except TelegramRetryAfter:
            self.receipt(bid,chat,'pending')
            await asyncio.sleep(10)
        except TelegramBadRequest as exc:
            self.receipt(bid,chat,'failed')
            reason=str(exc).lower()
            if 'chat not found' in reason:
                self.track(chat,active=False)
            if 'message to copy not found' in reason or "message can't be copied" in reason:
                # The preview was removed or became uncopyable. Don't spam the
                # API for every remaining chat with the same broken source.
                with self.db:self.db.execute("UPDATE broadcast_targets SET status='failed' WHERE broadcast_id=? AND status='pending'",(bid,))
        except TelegramEntityTooLarge:
            self.receipt(bid,chat,'failed')
        except (TelegramNetworkError,TelegramServerError,ClientDecodeError):
            self.receipt(bid,chat,'uncertain')
        except AiogramError:
            self.receipt(bid,chat,'failed')

    async def run(self):
        self.recover()
        while not self.r.stop.is_set():
            try:
                await self.step()
            except AiogramError:
                logging.info('Broadcast completion notice could not be delivered')
                await asyncio.sleep(5)
            await asyncio.sleep(0.1)
