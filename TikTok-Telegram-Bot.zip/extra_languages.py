"""Japanese, Portuguese, French and German interface translations."""

LANGUAGES = {"ja": "日本語", "pt": "Português", "fr": "Français", "de": "Deutsch"}

# Values follow the language order above; source labels are written once.
_ROWS = {
  "Telegram did not confirm the backup ZIP, check your private chat before using /upload again": [
    "TelegramからバックアップZIPの送信確認がありません。/upload を再送する前に個人チャットを確認してください",
    "O Telegram não confirmou o ZIP de backup, confira seu chat privado antes de usar /upload novamente",
    "Telegram n’a pas confirmé le ZIP de sauvegarde, vérifiez votre discussion privée avant de réutiliser /upload",
    "Telegram hat die Backup-ZIP nicht bestätigt. Prüfe deinen privaten Chat, bevor du /upload erneut verwendest"
  ],
  "Send a TikTok video or photo link": [
    "TikTokの動画・写真・音源のリンクを送ってください",
    "Envie um link de vídeo, fotos ou áudio do TikTok",
    "Envoyez un lien vers une vidéo, des photos ou un son TikTok",
    "Sende einen TikTok-Link zu einem Video, Fotos oder einem Sound"
  ],
  "Downloading...": [
    "ダウンロード中...",
    "Baixando...",
    "Téléchargement...",
    "Wird heruntergeladen..."
  ],
  "Uploading...": [
    "アップロード中...",
    "Enviando...",
    "Envoi...",
    "Wird hochgeladen..."
  ],
  "Send a TikTok video or photo post link": [
    "TikTokの動画・写真・音源のリンクを送ってください",
    "Envie um link de vídeo, fotos ou áudio do TikTok",
    "Envoyez un lien vers une vidéo, des photos ou un son TikTok",
    "Sende einen TikTok-Link zu einem Video, Fotos oder einem Sound"
  ],
  "The bot is restarting, please send your links again shortly": [
    "ボットは再起動中です。少し待ってからリンクを送り直してください",
    "O bot está reiniciando, envie seus links novamente em instantes",
    "Le bot redémarre, renvoyez vos liens dans un instant",
    "Der Bot startet neu. Sende deine Links gleich noch einmal"
  ],
  "You have reached the limit of 4 active downloads and 4 waiting requests\nThese links were not accepted\n": [
    "同時ダウンロード4件と待機リクエスト4件の上限に達しました\n次のリンクは受け付けられませんでした\n",
    "Você atingiu o limite de 4 downloads ativos e 4 pedidos em espera\nEstes links não foram aceitos\n",
    "Vous avez atteint la limite de 4 téléchargements actifs et 4 demandes en attente\nCes liens n’ont pas été acceptés\n",
    "Du hast das Limit von 4 aktiven Downloads und 4 wartenden Anfragen erreicht\nDiese Links wurden nicht angenommen\n"
  ],
  "Only the bot owner can use this command": [
    "このコマンドはボットの所有者のみ使用できます",
    "Só o proprietário do bot pode usar este comando",
    "Seul le propriétaire du bot peut utiliser cette commande",
    "Nur der Bot-Besitzer kann diesen Befehl verwenden"
  ],
  "No active or queued requests": [
    "実行中または待機中のリクエストはありません",
    "Nenhum pedido ativo ou na fila",
    "Aucune demande active ou en attente",
    "Keine aktiven oder wartenden Anfragen"
  ],
  "Use /cancel followed by one of your job numbers": [
    "/cancel の後にリクエスト番号を入力してください",
    "Use /cancel seguido do número de um dos seus pedidos",
    "Utilisez /cancel suivi du numéro de votre demande",
    "Verwende /cancel mit der Nummer einer deiner Anfragen"
  ],
  "This request has already ended": [
    "このリクエストはすでに終了しています",
    "Este pedido já terminou",
    "Cette demande est déjà terminée",
    "Diese Anfrage ist bereits beendet"
  ],
  "Cancelled, any upload already accepted by Telegram may still arrive": [
    "キャンセルしました。Telegramがすでに受け付けたファイルは届く場合があります",
    "Cancelado, arquivos já aceitos pelo Telegram ainda podem chegar",
    "Annulé, les fichiers déjà acceptés par Telegram peuvent encore arriver",
    "Abgebrochen. Von Telegram bereits angenommene Dateien können noch ankommen"
  ],
  "The bot is already stopping": [
    "ボットはすでに停止処理中です",
    "O bot já está parando",
    "Le bot est déjà en cours d’arrêt",
    "Der Bot wird bereits beendet"
  ],
  "Saving progress and stopping": [
    "進行状況を保存して停止しています",
    "Salvando o progresso e parando",
    "Enregistrement de la progression et arrêt",
    "Fortschritt wird gespeichert, Bot wird beendet"
  ],
  "Saving progress and starting a fresh session": [
    "進行状況を保存して新しいセッションを開始します",
    "Salvando o progresso e iniciando uma nova sessão",
    "Enregistrement de la progression et démarrage d’une nouvelle session",
    "Fortschritt wird gespeichert, eine neue Sitzung wird gestartet"
  ],
  "Send a TikTok link directly, use /help for available commands": [
    "TikTokのリンクを直接送ってください。コマンドは /help で確認できます",
    "Envie um link do TikTok diretamente, use /help para ver os comandos",
    "Envoyez directement un lien TikTok, utilisez /help pour voir les commandes",
    "Sende direkt einen TikTok-Link. Mit /help siehst du die Befehle"
  ],
  "This video is too large, the maximum size is 50 MB": [
    "動画が大きすぎます。上限は50 MBです",
    "Este vídeo é muito grande, o tamanho máximo é 50 MB",
    "Cette vidéo est trop volumineuse, la limite est de 50 MB",
    "Dieses Video ist zu groß. Die maximale Größe beträgt 50 MB"
  ],
  "TikTok refused access to this post, please try again later": [
    "TikTokがこの投稿へのアクセスを拒否しました。後でもう一度お試しください",
    "O TikTok negou acesso a esta publicação, tente novamente mais tarde",
    "TikTok a refusé l’accès à cette publication, réessayez plus tard",
    "TikTok hat den Zugriff auf diesen Beitrag verweigert. Versuche es später erneut"
  ],
  "Could not download this post, it may be unavailable or TikTok may be blocking access": [
    "投稿をダウンロードできませんでした。投稿が非公開か、TikTokがアクセスを制限している可能性があります",
    "Não foi possível baixar esta publicação, ela pode estar indisponível ou o TikTok pode estar bloqueando o acesso",
    "Impossible de télécharger cette publication, elle est peut-être indisponible ou TikTok bloque l’accès",
    "Dieser Beitrag konnte nicht heruntergeladen werden. Er ist möglicherweise nicht verfügbar oder TikTok blockiert den Zugriff"
  ],
  "Telegram did not confirm delivery, check the chat before sending the link again": [
    "Telegramから送信確認がありません。リンクを送り直す前にチャットを確認してください",
    "O Telegram não confirmou o envio, confira o chat antes de reenviar o link",
    "Telegram n’a pas confirmé l’envoi, vérifiez la discussion avant de renvoyer le lien",
    "Telegram hat die Zustellung nicht bestätigt. Prüfe den Chat, bevor du den Link erneut sendest"
  ],
  "Could not send this post, please try again later": [
    "投稿を送信できませんでした。後でもう一度お試しください",
    "Não foi possível enviar esta publicação, tente novamente mais tarde",
    "Impossible d’envoyer cette publication, réessayez plus tard",
    "Dieser Beitrag konnte nicht gesendet werden. Versuche es später erneut"
  ],
  "The previous upload was interrupted, check the chat before sending the link again": [
    "前回のアップロードは中断されました。リンクを送り直す前にチャットを確認してください",
    "O envio anterior foi interrompido, confira o chat antes de reenviar o link",
    "L’envoi précédent a été interrompu, vérifiez la discussion avant de renvoyer le lien",
    "Der vorherige Upload wurde unterbrochen. Prüfe den Chat, bevor du den Link erneut sendest"
  ],
  "Queued, position {n}": [
    "待機中、順番は{n}番です",
    "Na fila, posição {n}",
    "En attente, position {n}",
    "In der Warteschlange, Position {n}"
  ],
  "Your Telegram ID is {user}": [
    "あなたのTelegram IDは{user}です",
    "Seu ID do Telegram é {user}",
    "Votre identifiant Telegram est {user}",
    "Deine Telegram-ID ist {user}"
  ],
  "And {n} more": [
    "ほか{n}件",
    "E mais {n}",
    "Et {n} autres",
    "Und {n} weitere"
  ],
  "Job {id}, {status}": [
    "リクエスト{id}、{status}",
    "Pedido {id}, {status}",
    "Demande {id}, {status}",
    "Anfrage {id}, {status}"
  ],
  "user {user}": [
    "ユーザー{user}",
    "usuário {user}",
    "utilisateur {user}",
    "Benutzer {user}"
  ],
  "ready": [
    "準備完了",
    "pronto",
    "prêt",
    "bereit"
  ],
  "running": [
    "実行中",
    "em andamento",
    "en cours",
    "läuft"
  ],
  "queued": [
    "待機中",
    "na fila",
    "en attente",
    "in der Warteschlange"
  ],
  "Audio is unavailable for this post": [
    "この投稿の音源は利用できません",
    "O áudio desta publicação está indisponível",
    "Le son de cette publication est indisponible",
    "Für diesen Beitrag ist kein Audio verfügbar"
  ],
  "This audio is too large, the maximum size is 50 MB": [
    "音源が大きすぎます。上限は50 MBです",
    "Este áudio é muito grande, o tamanho máximo é 50 MB",
    "Ce fichier audio est trop volumineux, la limite est de 50 MB",
    "Diese Audiodatei ist zu groß. Die maximale Größe beträgt 50 MB"
  ],
  "Settings": [
    "設定",
    "Configurações",
    "Paramètres",
    "Einstellungen"
  ],
  "Language": [
    "言語",
    "Idioma",
    "Langue",
    "Sprache"
  ],
  "Back": [
    "戻る",
    "Voltar",
    "Retour",
    "Zurück"
  ],
  "Audio": [
    "音源",
    "Áudio",
    "Audio",
    "Audio"
  ],
  "On": [
    "オン",
    "Ativado",
    "Activé",
    "Ein"
  ],
  "Off": [
    "オフ",
    "Desativado",
    "Désactivé",
    "Aus"
  ],
  "Send sound with videos and photos": [
    "動画や写真と一緒に音源を送信する",
    "Enviar áudio com vídeos e fotos",
    "Envoyer le son avec les vidéos et les photos",
    "Audio zusammen mit Videos und Fotos senden"
  ],
  "TikTok did not provide this sound, try a video or photo post using it": [
    "TikTokから音源を取得できませんでした。この音源を使った動画や写真のリンクをお試しください",
    "O TikTok não forneceu este áudio, tente uma publicação de vídeo ou fotos que o use",
    "TikTok n’a pas fourni ce son, essayez une vidéo ou des photos qui l’utilisent",
    "TikTok hat diesen Sound nicht bereitgestellt. Versuche einen Video- oder Fotobeitrag, der ihn verwendet"
  ],
  "Use /broadcast in our private chat": [
    "個人チャットで /broadcast を使用してください",
    "Use /broadcast no nosso chat privado",
    "Utilisez /broadcast dans notre discussion privée",
    "Verwende /broadcast in unserem privaten Chat"
  ],
  "Reply to the announcement message with /broadcast": [
    "告知するメッセージに返信して /broadcast を送ってください",
    "Responda à mensagem do anúncio com /broadcast",
    "Répondez au message à annoncer avec /broadcast",
    "Antworte mit /broadcast auf die Ankündigung"
  ],
  "This message cannot be copied, try a text, photo, video or audio message": [
    "このメッセージはコピーできません。テキスト・写真・動画・音源をお試しください",
    "Esta mensagem não pode ser copiada, tente texto, foto, vídeo ou áudio",
    "Ce message ne peut pas être copié, essayez un texte, une photo, une vidéo ou un son",
    "Diese Nachricht kann nicht kopiert werden. Versuche Text, ein Foto, Video oder Audio"
  ],
  "Send": [
    "送信",
    "Enviar",
    "Envoyer",
    "Senden"
  ],
  "Cancel": [
    "キャンセル",
    "Cancelar",
    "Annuler",
    "Abbrechen"
  ],
  "Send the preview above to {n} chats?": [
    "上のプレビューを{n}件のチャットに送信しますか？",
    "Enviar a prévia acima para {n} chats?",
    "Envoyer l’aperçu ci-dessus à {n} discussions ?",
    "Die obige Vorschau an {n} Chats senden?"
  ],
  "Broadcast queued": [
    "一斉送信を受け付けました",
    "Anúncio na fila",
    "Annonce mise en attente",
    "Rundsendung eingereiht"
  ],
  "Broadcast cancelled": [
    "一斉送信をキャンセルしました",
    "Anúncio cancelado",
    "Annonce annulée",
    "Rundsendung abgebrochen"
  ],
  "Broadcast finished\nSent: {sent}\nSkipped or failed: {failed}\nUnconfirmed: {uncertain}": [
    "一斉送信が終了しました\n送信済み: {sent}\nスキップ・失敗: {failed}\n未確認: {uncertain}",
    "Anúncio concluído\nEnviados: {sent}\nIgnorados ou falhos: {failed}\nNão confirmados: {uncertain}",
    "Annonce terminée\nEnvoyés : {sent}\nIgnorés ou échoués : {failed}\nNon confirmés : {uncertain}",
    "Rundsendung abgeschlossen\nGesendet: {sent}\nÜbersprungen oder fehlgeschlagen: {failed}\nUnbestätigt: {uncertain}"
  ],
  "Automatically send audio with videos and photos, Off shows an Extract audio button": [
    "動画や写真の音源を自動送信します。オフでは「音源を抽出」ボタンを表示します",
    "Enviar áudio automaticamente com vídeos e fotos, Desativado mostra o botão Extrair áudio",
    "Envoyer automatiquement le son avec les vidéos et les photos, Désactivé affiche le bouton Extraire l’audio",
    "Audio automatisch mit Videos und Fotos senden. Aus zeigt die Schaltfläche Audio extrahieren"
  ],
  "Extract audio": [
    "音源を抽出",
    "Extrair áudio",
    "Extraire l’audio",
    "Audio extrahieren"
  ],
  "This audio button belongs to the original requester": [
    "この音源ボタンは元のリクエストを送った方のみ使用できます",
    "Este botão de áudio pertence a quem fez o pedido original",
    "Ce bouton audio est réservé à l’auteur de la demande",
    "Diese Audio-Schaltfläche ist nur für den ursprünglichen Anfragenden"
  ],
  "Your download queue is full, try again later": [
    "ダウンロードの待機枠がいっぱいです。後でもう一度お試しください",
    "Sua fila de downloads está cheia, tente novamente mais tarde",
    "Votre file de téléchargements est pleine, réessayez plus tard",
    "Deine Download-Warteschlange ist voll. Versuche es später erneut"
  ],
  "Audio already requested, check the chat and /queue": [
    "音源はすでにリクエスト済みです。チャットや /queue を確認してください",
    "Áudio já solicitado, confira o chat e /queue",
    "Audio déjà demandé, vérifiez la discussion et /queue",
    "Audio wurde bereits angefragt. Prüfe den Chat und /queue"
  ],
  "Audio requested": [
    "音源のリクエストを受け付けました",
    "Áudio solicitado",
    "Audio demandé",
    "Audio angefragt"
  ],
  "Compression": [
    "圧縮",
    "Compressão",
    "Compression",
    "Komprimierung"
  ],
  "All videos": [
    "すべての動画",
    "Todos os vídeos",
    "Toutes les vidéos",
    "Alle Videos"
  ],
  "Over 50 MB": [
    "50 MBを超える動画",
    "Acima de 50 MB",
    "Plus de 50 MB",
    "Über 50 MB"
  ],
  "None": [
    "なし",
    "Nenhuma",
    "Aucune",
    "Keine"
  ],
  "Advanced": [
    "詳細設定",
    "Avançado",
    "Avancé",
    "Erweitert"
  ],
  "Reset advanced defaults": [
    "詳細設定を初期値に戻す",
    "Restaurar padrões avançados",
    "Rétablir les réglages avancés par défaut",
    "Erweiterte Standardwerte wiederherstellen"
  ],
  "Maximum frame rate": [
    "最大フレームレート",
    "Taxa máxima de quadros",
    "Fréquence d’images maximale",
    "Maximale Bildrate"
  ],
  "Maximum resolution": [
    "最大解像度",
    "Resolução máxima",
    "Résolution maximale",
    "Maximale Auflösung"
  ],
  "Quality": [
    "画質",
    "Qualidade",
    "Qualité",
    "Qualität"
  ],
  "Encoding speed": [
    "エンコード速度",
    "Velocidade de codificação",
    "Vitesse d’encodage",
    "Kodiergeschwindigkeit"
  ],
  "Video audio bitrate": [
    "動画音声のビットレート",
    "Taxa de bits do áudio do vídeo",
    "Débit audio de la vidéo",
    "Audio-Bitrate des Videos"
  ],
  "Original": [
    "元のまま",
    "Original",
    "D’origine",
    "Original"
  ],
  "High quality": [
    "高画質",
    "Alta qualidade",
    "Haute qualité",
    "Hohe Qualität"
  ],
  "Balanced": [
    "バランス",
    "Equilibrada",
    "Équilibrée",
    "Ausgewogen"
  ],
  "Smaller files": [
    "ファイルサイズを優先",
    "Arquivos menores",
    "Fichiers plus petits",
    "Kleinere Dateien"
  ],
  "Fast": [
    "高速",
    "Rápida",
    "Rapide",
    "Schnell"
  ],
  "Medium": [
    "標準",
    "Média",
    "Moyenne",
    "Mittel"
  ],
  "Slow": [
    "低速",
    "Lenta",
    "Lente",
    "Langsam"
  ],
  "Compressing...": [
    "圧縮中...",
    "Comprimindo...",
    "Compression...",
    "Wird komprimiert..."
  ],
  "Compress videos, None keeps the original and the 50 MB limit": [
    "動画を圧縮します。「なし」では元のファイルを保持し、50 MBの上限が適用されます",
    "Comprimir vídeos, Nenhuma mantém o original e o limite de 50 MB",
    "Compresser les vidéos, Aucune conserve l’original et la limite de 50 MB",
    "Videos komprimieren. Keine behält das Original und die Grenze von 50 MB bei"
  ],
  "Advanced compression options, frame rate and resolution are maximums, fitting to 50 MB may lower resolution, video audio bitrate does not change separate sound files": [
    "詳細圧縮設定です。フレームレートと解像度は上限値です。50 MB以内に収めるため解像度が下がる場合があります。動画音声のビットレートは別送する音源には影響しません",
    "Opções avançadas, a taxa de quadros e a resolução são limites máximos, ajustar a 50 MB pode reduzir a resolução, a taxa de bits do áudio do vídeo não altera arquivos de áudio separados",
    "Options avancées, la fréquence d’images et la résolution sont des maximums, respecter 50 MB peut réduire la résolution, le débit audio de la vidéo ne modifie pas les fichiers audio séparés",
    "Erweiterte Optionen: Bildrate und Auflösung sind Höchstwerte. Für 50 MB kann die Auflösung sinken. Die Audio-Bitrate des Videos ändert separate Audiodateien nicht"
  ],
  "Could not compress this video below 50 MB, try lower quality or resolution": [
    "動画を50 MB未満に圧縮できませんでした。画質や解像度を下げてお試しください",
    "Não foi possível comprimir este vídeo abaixo de 50 MB, tente reduzir a qualidade ou a resolução",
    "Impossible de compresser cette vidéo sous 50 MB, réduisez la qualité ou la résolution",
    "Dieses Video konnte nicht unter 50 MB komprimiert werden. Wähle eine geringere Qualität oder Auflösung"
  ],
  "Could not compress this video, try again or choose None in Compression settings": [
    "動画を圧縮できませんでした。もう一度お試しいただくか、圧縮設定で「なし」を選んでください",
    "Não foi possível comprimir este vídeo, tente novamente ou escolha Nenhuma em Compressão",
    "Impossible de compresser cette vidéo, réessayez ou choisissez Aucune dans Compression",
    "Dieses Video konnte nicht komprimiert werden. Versuche es erneut oder wähle Keine unter Komprimierung"
  ],
  "This video is too large to process, the maximum download size is 1 GB": [
    "動画が大きすぎて処理できません。ダウンロードの上限は1 GBです",
    "Este vídeo é grande demais para processar, o limite de download é 1 GB",
    "Cette vidéo est trop volumineuse pour être traitée, la limite de téléchargement est de 1 GB",
    "Dieses Video ist zu groß zur Verarbeitung. Die maximale Downloadgröße beträgt 1 GB"
  ],
  "24 fps": [
    "24 fps",
    "24 fps",
    "24 images/s",
    "24 Bilder/s"
  ],
  "30 fps": [
    "30 fps",
    "30 fps",
    "30 images/s",
    "30 Bilder/s"
  ],
  "60 fps": [
    "60 fps",
    "60 fps",
    "60 images/s",
    "60 Bilder/s"
  ],
  "64 kbps": [
    "64 kbps",
    "64 kbps",
    "64 kbit/s",
    "64 kbit/s"
  ],
  "96 kbps": [
    "96 kbps",
    "96 kbps",
    "96 kbit/s",
    "96 kbit/s"
  ],
  "128 kbps": [
    "128 kbps",
    "128 kbps",
    "128 kbit/s",
    "128 kbit/s"
  ],
  "192 kbps": [
    "192 kbps",
    "192 kbps",
    "192 kbit/s",
    "192 kbit/s"
  ],
  "Subtitles": [
    "字幕",
    "Legendas",
    "Sous-titres",
    "Untertitel"
  ],
  "Send available subtitle files as replies to videos": [
    "利用可能な字幕ファイルを動画への返信として送信する",
    "Enviar legendas disponíveis em resposta aos vídeos",
    "Envoyer les sous-titres disponibles en réponse aux vidéos",
    "Verfügbare Untertiteldateien als Antwort auf Videos senden"
  ],
  "Some subtitle files could not be downloaded": [
    "一部の字幕ファイルをダウンロードできませんでした",
    "Algumas legendas não puderam ser baixadas",
    "Certains sous-titres n’ont pas pu être téléchargés",
    "Einige Untertiteldateien konnten nicht heruntergeladen werden"
  ],
  "Some subtitle files are too large, the maximum size is 50 MB": [
    "一部の字幕ファイルが大きすぎます。上限は50 MBです",
    "Algumas legendas são grandes demais, o limite é 50 MB",
    "Certains sous-titres sont trop volumineux, la limite est de 50 MB",
    "Einige Untertiteldateien sind zu groß. Die Grenze beträgt 50 MB"
  ],
  "Try this button again in {time} (min:sec)": [
    "{time}（分:秒）後にもう一度押してください",
    "Tente este botão novamente em {time} (min:seg)",
    "Réessayez ce bouton dans {time} (min:s)",
    "Versuche diese Schaltfläche in {time} (Min:Sek) erneut"
  ],
  "This request was already received, check the chat and /queue": [
    "このリクエストはすでに受け付けています。チャットや /queue を確認してください",
    "Este pedido já foi recebido, confira o chat e /queue",
    "Cette demande a déjà été reçue, vérifiez la discussion et /queue",
    "Diese Anfrage wurde bereits empfangen. Prüfe den Chat und /queue"
  ],
  "Full caption": [
    "説明文全体",
    "Descrição completa",
    "Description complète",
    "Vollständige Beschreibung"
  ],
  "Automatically send full captions as text files when too long, Off shows a text-file button": [
    "長すぎる説明文をテキストファイルで自動送信します。オフではファイル送信ボタンを表示します",
    "Enviar descrições longas automaticamente como arquivos de texto, Desativado mostra um botão",
    "Envoyer automatiquement les descriptions trop longues en fichiers texte, Désactivé affiche un bouton",
    "Zu lange Beschreibungen automatisch als Textdateien senden. Aus zeigt eine Schaltfläche für die Textdatei"
  ],
  "Could not send the caption file, it will be retried after restart": [
    "説明文ファイルを送信できませんでした。再起動後に再試行します",
    "Não foi possível enviar a descrição, uma nova tentativa será feita após reiniciar",
    "Impossible d’envoyer le fichier de description, une nouvelle tentative aura lieu après le redémarrage",
    "Die Beschreibungsdatei konnte nicht gesendet werden. Nach dem Neustart wird es erneut versucht"
  ],
  "Send full caption as text file": [
    "説明文全体をテキストファイルで送信",
    "Enviar descrição completa como arquivo de texto",
    "Envoyer la description complète en fichier texte",
    "Vollständige Beschreibung als Textdatei senden"
  ],
  "The caption is too long, use the button to get the full text": [
    "説明文が長すぎます。ボタンを押すと全文を取得できます",
    "A descrição é longa demais, use o botão para obter o texto completo",
    "La description est trop longue, utilisez le bouton pour obtenir le texte complet",
    "Die Beschreibung ist zu lang. Verwende die Schaltfläche für den vollständigen Text"
  ],
  "This caption button belongs to the original requester": [
    "この説明文ボタンは元のリクエストを送った方のみ使用できます",
    "Este botão de descrição pertence a quem fez o pedido original",
    "Ce bouton de description est réservé à l’auteur de la demande",
    "Diese Beschreibungs-Schaltfläche ist nur für den ursprünglichen Anfragenden"
  ],
  "Caption file already sent, check the chat": [
    "説明文ファイルはすでに送信済みです。チャットを確認してください",
    "A descrição já foi enviada, confira o chat",
    "Le fichier de description a déjà été envoyé, vérifiez la discussion",
    "Die Beschreibungsdatei wurde bereits gesendet. Prüfe den Chat"
  ],
  "Caption delivery is pending or unconfirmed, check the chat": [
    "説明文ファイルは送信待ち、または送信未確認です。チャットを確認してください",
    "O envio da descrição está pendente ou não confirmado, confira o chat",
    "L’envoi de la description est en attente ou non confirmé, vérifiez la discussion",
    "Die Zustellung der Beschreibung ist ausstehend oder unbestätigt. Prüfe den Chat"
  ],
  "This caption file is too large, the maximum size is 50 MB": [
    "説明文ファイルが大きすぎます。上限は50 MBです",
    "A descrição é grande demais, o limite é 50 MB",
    "Ce fichier de description est trop volumineux, la limite est de 50 MB",
    "Diese Beschreibungsdatei ist zu groß. Die Grenze beträgt 50 MB"
  ],
  "Sending caption file...": [
    "説明文ファイルを送信中...",
    "Enviando descrição...",
    "Envoi du fichier de description...",
    "Beschreibungsdatei wird gesendet..."
  ],
  "Could not send the caption file, try the button again": [
    "説明文ファイルを送信できませんでした。もう一度ボタンをお試しください",
    "Não foi possível enviar a descrição, tente o botão novamente",
    "Impossible d’envoyer le fichier de description, réessayez le bouton",
    "Die Beschreibungsdatei konnte nicht gesendet werden. Versuche die Schaltfläche erneut"
  ],
  "Telegram did not confirm the caption button, check the chat before sending the link again": [
    "Telegramから説明文ボタンの送信確認がありません。リンクを送り直す前にチャットを確認してください",
    "O Telegram não confirmou o botão de descrição, confira o chat antes de reenviar o link",
    "Telegram n’a pas confirmé le bouton de description, vérifiez la discussion avant de renvoyer le lien",
    "Telegram hat die Beschreibungs-Schaltfläche nicht bestätigt. Prüfe den Chat, bevor du den Link erneut sendest"
  ],
  "Could not add the caption button yet, it will be retried after restart": [
    "説明文ボタンをまだ追加できていません。再起動後に再試行します",
    "Ainda não foi possível adicionar o botão de descrição, uma nova tentativa será feita após reiniciar",
    "Impossible d’ajouter le bouton de description pour le moment, une nouvelle tentative aura lieu après le redémarrage",
    "Die Beschreibungs-Schaltfläche konnte noch nicht hinzugefügt werden. Nach dem Neustart wird es erneut versucht"
  ],
  "Off with no button": [
    "オフ（ボタンなし）",
    "Desativado sem botão",
    "Désactivé sans bouton",
    "Aus ohne Schaltfläche"
  ],
  "Extract subtitles": [
    "字幕を抽出",
    "Extrair legendas",
    "Extraire les sous-titres",
    "Untertitel extrahieren"
  ],
  "Automatically send subtitle files with videos, Off shows an Extract subtitles button": [
    "動画の字幕ファイルを自動送信します。オフでは「字幕を抽出」ボタンを表示します",
    "Enviar legendas automaticamente com vídeos, Desativado mostra o botão Extrair legendas",
    "Envoyer automatiquement les sous-titres avec les vidéos, Désactivé affiche le bouton Extraire les sous-titres",
    "Untertiteldateien automatisch mit Videos senden. Aus zeigt die Schaltfläche Untertitel extrahieren"
  ],
  "This subtitle button belongs to the original requester": [
    "この字幕ボタンは元のリクエストを送った方のみ使用できます",
    "Este botão de legendas pertence a quem fez o pedido original",
    "Ce bouton de sous-titres est réservé à l’auteur de la demande",
    "Diese Untertitel-Schaltfläche ist nur für den ursprünglichen Anfragenden"
  ],
  "Subtitles requested": [
    "字幕のリクエストを受け付けました",
    "Legendas solicitadas",
    "Sous-titres demandés",
    "Untertitel angefragt"
  ],
  "Subtitles already requested, check the chat and /queue": [
    "字幕はすでにリクエスト済みです。チャットや /queue を確認してください",
    "Legendas já solicitadas, confira o chat e /queue",
    "Sous-titres déjà demandés, vérifiez la discussion et /queue",
    "Untertitel wurden bereits angefragt. Prüfe den Chat und /queue"
  ],
  "No subtitle files are available for this video": [
    "この動画には利用可能な字幕ファイルがありません",
    "Não há legendas disponíveis para este vídeo",
    "Aucun sous-titre n’est disponible pour cette vidéo",
    "Für dieses Video sind keine Untertiteldateien verfügbar"
  ],
  "Could not download subtitle files for this video": [
    "この動画の字幕ファイルをダウンロードできませんでした",
    "Não foi possível baixar as legendas deste vídeo",
    "Impossible de télécharger les sous-titres de cette vidéo",
    "Die Untertiteldateien für dieses Video konnten nicht heruntergeladen werden"
  ],
  "The subtitle files are too large, the maximum size is 50 MB": [
    "字幕ファイルが大きすぎます。上限は50 MBです",
    "As legendas são grandes demais, o limite é 50 MB",
    "Les sous-titres sont trop volumineux, la limite est de 50 MB",
    "Die Untertiteldateien sind zu groß. Die Grenze beträgt 50 MB"
  ],
  "Telegram did not confirm the audio button, check the chat before sending the link again": [
    "Telegramから音源ボタンの送信確認がありません。リンクを送り直す前にチャットを確認してください",
    "O Telegram não confirmou o botão de áudio, confira o chat antes de reenviar o link",
    "Telegram n’a pas confirmé le bouton audio, vérifiez la discussion avant de renvoyer le lien",
    "Telegram hat die Audio-Schaltfläche nicht bestätigt. Prüfe den Chat, bevor du den Link erneut sendest"
  ],
  "Could not add the audio button yet, it will be retried after restart": [
    "音源ボタンをまだ追加できていません。再起動後に再試行します",
    "Ainda não foi possível adicionar o botão de áudio, uma nova tentativa será feita após reiniciar",
    "Impossible d’ajouter le bouton audio pour le moment, une nouvelle tentative aura lieu après le redémarrage",
    "Die Audio-Schaltfläche konnte noch nicht hinzugefügt werden. Nach dem Neustart wird es erneut versucht"
  ],
  "Reimport the ZIP when restarting?": [
    "再起動時にZIPを再取り込みしますか？",
    "Importar o ZIP novamente ao reiniciar?",
    "Réimporter le ZIP lors du redémarrage ?",
    "Die ZIP beim Neustart neu importieren?"
  ],
  "Restart and reimport ZIP": [
    "再起動してZIPを再取り込み",
    "Reiniciar e reimportar ZIP",
    "Redémarrer et réimporter le ZIP",
    "Neustart mit ZIP-Neuimport"
  ],
  "Restart without reimport": [
    "再取り込みせず再起動",
    "Reiniciar sem reimportar",
    "Redémarrer sans réimporter",
    "Neustart ohne Neuimport"
  ],
  "This restart prompt is no longer active, send /restart again": [
    "この再起動確認は無効です。/restart を送り直してください",
    "Esta confirmação não está mais ativa, envie /restart novamente",
    "Cette confirmation n’est plus active, renvoyez /restart",
    "Diese Neustart-Abfrage ist nicht mehr aktiv. Sende /restart erneut"
  ],
  "Restart cancelled": [
    "再起動をキャンセルしました",
    "Reinício cancelado",
    "Redémarrage annulé",
    "Neustart abgebrochen"
  ],
  "Saving progress and restarting with ZIP reimport": [
    "進行状況を保存して再起動し、ZIPを再取り込みします",
    "Salvando o progresso e reiniciando com reimportação do ZIP",
    "Enregistrement de la progression et redémarrage avec réimportation du ZIP",
    "Fortschritt wird gespeichert, Neustart mit ZIP-Neuimport"
  ],
  "Preparing backup ZIP...": [
    "バックアップZIPを作成中...",
    "Preparando ZIP de backup...",
    "Préparation du ZIP de sauvegarde...",
    "Backup-ZIP wird erstellt..."
  ],
  "A backup ZIP is already being prepared": [
    "バックアップZIPはすでに作成中です",
    "Um ZIP de backup já está sendo preparado",
    "Un ZIP de sauvegarde est déjà en préparation",
    "Eine Backup-ZIP wird bereits erstellt"
  ],
  "The backup ZIP is too large, the maximum size is 50 MB": [
    "バックアップZIPが大きすぎます。上限は50 MBです",
    "O ZIP de backup é grande demais, o limite é 50 MB",
    "Le ZIP de sauvegarde est trop volumineux, la limite est de 50 MB",
    "Die Backup-ZIP ist zu groß. Die Grenze beträgt 50 MB"
  ],
  "Backup ZIP sent. Shut down or restart?": [
    "バックアップZIPを送信しました。停止しますか、再起動しますか？",
    "ZIP de backup enviado. Desligar ou reiniciar?",
    "ZIP de sauvegarde envoyé. Arrêter ou redémarrer ?",
    "Backup-ZIP gesendet. Beenden oder neu starten?"
  ],
  "Backup ZIP sent to your private chat": [
    "個人チャットにバックアップZIPを送信しました",
    "ZIP de backup enviado ao seu chat privado",
    "ZIP de sauvegarde envoyé dans votre discussion privée",
    "Backup-ZIP an deinen privaten Chat gesendet"
  ],
  "Could not send the backup ZIP, open our private chat and send /start, then try /upload again": [
    "バックアップZIPを送信できませんでした。個人チャットで /start を送信し、/upload をもう一度お試しください",
    "Não foi possível enviar o ZIP de backup, abra nosso chat privado, envie /start e tente /upload novamente",
    "Impossible d’envoyer le ZIP de sauvegarde, ouvrez notre discussion privée, envoyez /start puis réessayez /upload",
    "Die Backup-ZIP konnte nicht gesendet werden. Öffne unseren privaten Chat, sende /start und versuche /upload erneut"
  ],
  "This backup menu is no longer active, use /upload again": [
    "このバックアップメニューは無効です。/upload を送り直してください",
    "Este menu de backup não está mais ativo, use /upload novamente",
    "Ce menu de sauvegarde n’est plus actif, utilisez /upload à nouveau",
    "Dieses Backup-Menü ist nicht mehr aktiv. Verwende /upload erneut"
  ],
  "Shut down": [
    "停止",
    "Desligar",
    "Arrêter",
    "Beenden"
  ],
  "Restart": [
    "再起動",
    "Reiniciar",
    "Redémarrer",
    "Neustart"
  ]
}

if any(len(values) != len(LANGUAGES) for values in _ROWS.values()):
    raise ValueError("Incomplete language translation row")
TEXT = {code: {key: values[index] for key, values in _ROWS.items()}
        for index, code in enumerate(LANGUAGES)}
HELP = {
  "ja": "TikTokの動画・写真・音源のリンクを送ってください。複数のリンクも送れます\n\n1人につき同時ダウンロード4件と待機リクエスト4件まで\n写真の投稿は1件のリクエストとして扱います\nファイルサイズの上限は50 MBです\n\n/queue - 自分のリクエスト\n/cancel <job> - リクエストをキャンセル\n/ping - 応答時間を確認\n/id - 自分のTelegram ID\n/settings - 設定",
  "pt": "Envie links de vídeos, fotos ou áudios do TikTok, vários links também funcionam\n\nAté 4 downloads ativos e 4 pedidos em espera por usuário\nCada publicação de fotos conta como um pedido\nTamanho máximo por arquivo: 50 MB\n\n/queue - Seus pedidos\n/cancel <job> - Cancelar um pedido\n/ping - Ver o tempo de resposta\n/id - Seu ID do Telegram\n/settings - Configurações",
  "fr": "Envoyez des liens vers des vidéos, des photos ou des sons TikTok, plusieurs liens sont acceptés\n\nJusqu’à 4 téléchargements actifs et 4 demandes en attente par utilisateur\nChaque publication de photos compte comme une demande\nTaille maximale par fichier : 50 MB\n\n/queue - Vos demandes\n/cancel <job> - Annuler une demande\n/ping - Vérifier le temps de réponse\n/id - Votre identifiant Telegram\n/settings - Paramètres",
  "de": "Sende TikTok-Links zu Videos, Fotos oder Sounds. Mehrere Links sind möglich\n\nBis zu 4 aktive Downloads und 4 wartende Anfragen pro Benutzer\nJeder Fotobeitrag zählt als eine Anfrage\nMaximale Dateigröße: 50 MB\n\n/queue - Deine Anfragen\n/cancel <job> - Eine Anfrage abbrechen\n/ping - Antwortzeit prüfen\n/id - Deine Telegram-ID\n/settings - Einstellungen"
}
OWNER_HELP = {
  "ja": "所有者用コマンド\n/jobs - すべてのリクエスト\n/restart - 再起動（ZIPの再取り込みを選択）\n/upload - バックアップZIPを受け取り、停止か再起動を選択\n/shutdown - バックアップして停止\n/broadcast - メッセージに返信して全チャットに告知",
  "pt": "Comandos do proprietário\n/jobs - Todos os pedidos\n/restart - Reiniciar, com opção de reimportar o ZIP\n/upload - Receber o ZIP de backup e escolher desligar ou reiniciar\n/shutdown - Fazer backup e parar\n/broadcast - Responder a uma mensagem para anunciá-la a todos os chats",
  "fr": "Commandes du propriétaire\n/jobs - Toutes les demandes\n/restart - Redémarrer, avec réimportation facultative du ZIP\n/upload - Recevoir le ZIP de sauvegarde et choisir arrêt ou redémarrage\n/shutdown - Sauvegarder et arrêter\n/broadcast - Répondre à un message pour l’annoncer à toutes les discussions",
  "de": "Besitzer-Befehle\n/jobs - Alle Anfragen\n/restart - Neustart, optional mit ZIP-Neuimport\n/upload - Backup-ZIP erhalten und Beenden oder Neustart wählen\n/shutdown - Sichern und beenden\n/broadcast - Auf eine Nachricht antworten, um sie an alle Chats zu senden"
}
