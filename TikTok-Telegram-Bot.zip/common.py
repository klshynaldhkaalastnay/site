"""Shared limits and URL validation"""
import re
from urllib.parse import urlsplit, urlunsplit

MAX_BYTES = 50_000_000
BOT_NAME = '@TikTokdownloaderbestbot'
BOT_LINK = 'https://t.me/TikTokdownloaderbestbot?start=welcome_hehehehaw=='
BOT_ATTRIBUTION = f'<a href="{BOT_LINK}">{BOT_NAME}</a>'
ACTIVE = 4
WAITING = 4
PRIVILEGED_ACTIVE = 1
TERMINAL = ('done', 'failed', 'cancelled', 'uncertain')
TOO_LARGE = 'This video is too large, the maximum size is 50 MB'
MEDIA_CHOICES = {'on':'On','off':'Off','off_no_button':'Off with no button'}
URL_RE = re.compile(r'https?://[^\s<>"\u200b]+', re.I)
POST_RE = re.compile(r'^/(?:@[\w.-]+|share)/(?:video|photo)/(\d+)/?$')
MUSIC_RE = re.compile(r'^/(?:music/(?:[^/]+-)?|share/music/)(\d+)/?$')
SHORT_RE = re.compile(r'^/(?:t/)?[A-Za-z0-9_-]+/?$')


def media_preference(value, default):
    return value if value in MEDIA_CHOICES else default


def normalize_url(url):
    url = url.rstrip('.,;!?)]}،')
    if len(url) > 2048:
        raise ValueError('Invalid TikTok link')
    p = urlsplit(url)
    host = (p.hostname or '').lower()
    if p.scheme not in ('http', 'https') or p.username or p.password or p.port not in (None, 80, 443):
        raise ValueError('Invalid TikTok link')
    if host not in ('tiktok.com', 'www.tiktok.com', 'm.tiktok.com', 'vm.tiktok.com', 'vt.tiktok.com'):
        raise ValueError('Only TikTok links are supported')
    music = MUSIC_RE.fullmatch(p.path)
    if music:
        path = p.path.rstrip('/')
        if path.startswith('/share/') or path == '/music/'+music.group(1):
            path = '/music/original-sound-'+music.group(1)
        return urlunsplit(('https', 'www.tiktok.com', path, '', ''))
    match = POST_RE.fullmatch(p.path)
    if match:
        # Keep the creator path while removing tracking queries
        path = p.path.replace('/photo/', '/video/').rstrip('/')
        return urlunsplit(('https', 'www.tiktok.com', path, '', ''))
    if host in ('vm.tiktok.com', 'vt.tiktok.com') and SHORT_RE.fullmatch(p.path):
        return urlunsplit(('https', host, p.path, '', ''))
    if host in ('www.tiktok.com', 'tiktok.com') and p.path.startswith('/t/') and SHORT_RE.fullmatch(p.path):
        return urlunsplit(('https', 'www.tiktok.com', p.path, '', ''))
    raise ValueError('Send a TikTok video or photo post link')


def extract_links(text):
    good, bad = [], False
    for candidate in URL_RE.findall(text or ''):
        try:
            url = normalize_url(candidate)
            if url not in good:
                good.append(url)
        except ValueError:
            bad = True
    return good, bad
