"""Run before hosting to retrieve Telegram numeric IDs, requires only the bot token"""
import asyncio
import getpass
import os
from aiogram import Bot
from aiogram.client.session.aiohttp import AiohttpSession


async def main():
    token = os.getenv('TELEGRAM_BOT_TOKEN') or getpass.getpass('BotFather token, hidden input: ')
    print('Send /id to your new bot from the owner account and from Tog991')
    print('Do not run this while the hosting workflow is active, press Ctrl+C when finished')
    offset = 0
    async with Bot(token=token,session=AiohttpSession(timeout=30)).context() as bot:
        while True:
            for update in await bot.get_updates(offset=offset,timeout=20,request_timeout=30,allowed_updates=['message']):
                offset = update.update_id+1
                msg = update.message
                if msg and (msg.text or '').strip()=='/id' and msg.from_user:
                    user = msg.from_user
                    print(f"Username: @{user.username or 'no_username'}, Telegram ID: {user.id}")


if __name__=='__main__':
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        print('Finished')
    except Exception as exc:
        print(f'Could not read Telegram updates, {type(exc).__name__}')
