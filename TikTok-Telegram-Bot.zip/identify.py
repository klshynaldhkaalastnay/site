"""Run before hosting to retrieve Telegram numeric IDs, requires only the bot token"""
import getpass
import json
import os
import urllib.request


def main():
    token = os.getenv('TELEGRAM_BOT_TOKEN') or getpass.getpass('BotFather token, hidden input: ')
    print('Send /id to your new bot from the owner account and from Tog991')
    print('Do not run this while the hosting workflow is active, press Ctrl+C when finished')
    offset = 0
    while True:
        body = json.dumps({'offset':offset,'timeout':20,'allowed_updates':['message']}).encode()
        req = urllib.request.Request(f'https://api.telegram.org/bot{token}/getUpdates',data=body,
                                     headers={'Content-Type':'application/json'})
        with urllib.request.urlopen(req,timeout=30) as response:
            result = json.load(response)
        for update in result.get('result',[]):
            offset = update['update_id']+1
            msg = update.get('message',{})
            if msg.get('text','').strip()=='/id' and 'from' in msg:
                user = msg['from']
                print(f"Username: @{user.get('username','no_username')}, Telegram ID: {user['id']}")


if __name__=='__main__':
    try:
        main()
    except KeyboardInterrupt:
        print('Finished')
    except Exception as exc:
        print(f'Could not read Telegram updates, {type(exc).__name__}')
