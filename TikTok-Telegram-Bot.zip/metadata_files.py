"""Durable, requester-owned downloads of post metadata in the selected export format."""
import asyncio
import logging
import json
import zlib
import re

from aiogram.exceptions import (AiogramError, TelegramAPIError, TelegramEntityTooLarge,
                               TelegramNetworkError, TelegramServerError, TelegramRetryAfter,
                               ClientDecodeError)
from aiogram.types import BufferedInputFile, InlineKeyboardButton, InlineKeyboardMarkup, ReplyParameters, LinkPreviewOptions

from common import MAX_BYTES, BOT_ATTRIBUTION, media_preference
from metadata_formats import chosen_format, export_metadata


class MetadataFiles:
    def __init__(self, runner):
        self.runner = runner

    def snapshot(self, jid):
        state = self.runner.state
        row = state.job(jid)
        if row['metadata_mode'] is None:
            state.change(jid,metadata_mode=media_preference(
                state.get(f"metadata:{row['user_id']}"),'off_no_button'))
        if row['metadata_format'] is None:
            state.change(jid,metadata_format=chosen_format(
                state.get(f"metadata_format:{row['user_id']}")))
        return media_preference(state.job(jid)['metadata_mode'],'off_no_button')

    def remember(self, jid, data, post_id):
        state = self.runner.state
        row = state.job(jid)
        mode = self.snapshot(jid)
        if (row['metadata_data'] is not None or row['audio_only'] or row['subtitles_only']
                or mode=='off_no_button' or not data):
            return
        post_id = str(post_id or '')
        if not re.fullmatch(r'[0-9]{1,32}',post_id):
            return
        try:
            raw = data.encode('utf-8') if isinstance(data,str) else json.dumps(
                data,ensure_ascii=False,allow_nan=False).encode('utf-8')
            if len(raw)>MAX_BYTES or not isinstance(json.loads(raw),dict):
                return
        except (ValueError,TypeError,UnicodeError):
            return
        state.change(jid,metadata_post_id=post_id,metadata_data=zlib.compress(raw),
                     metadata_button_pending=int(mode=='off'))

    def keyboard(self, user, jid):
        return InlineKeyboardMarkup(inline_keyboard=[[
            InlineKeyboardButton(text=self.runner.tr(user,'Send full metadata'),
                                 callback_data=f'metadata:{jid}')]])

    async def install(self, jid):
        r = self.runner
        row = r.state.job(jid)
        if row and self.snapshot(jid)!='off':
            return
        if (not row or not row['metadata_button_pending'] or not row['reply_message']
                or row['metadata_button_in_flight'] or r.stop.is_set()):
            return
        async def send_button():
            r.state.change(jid,metadata_button_in_flight=1)
            try:
                return await r.bot.send_message(
                    chat_id=row['chat_id'],message_thread_id=row['thread_id'],
                    text=BOT_ATTRIBUTION,parse_mode='HTML',
                    link_preview_options=LinkPreviewOptions(is_disabled=True),
                    reply_parameters=ReplyParameters(message_id=row['reply_message'],allow_sending_without_reply=True),
                    reply_markup=self.keyboard(row['user_id'],jid))
            except TelegramRetryAfter:
                r.state.change(jid,metadata_button_in_flight=0)
                raise
        try:
            message = await r.api(row['chat_id'],send_button)
        except TelegramEntityTooLarge:
            r.state.change(jid,metadata_button_in_flight=0)
            return
        except (TelegramNetworkError,TelegramServerError,ClientDecodeError):
            logging.info('Metadata button reply not confirmed for job %s',jid)
            return
        except TelegramAPIError:
            r.state.change(jid,metadata_button_in_flight=0)
            return
        except AiogramError:
            logging.info('Metadata button reply not confirmed for job %s',jid)
            return
        r.state.change(jid,metadata_button_message=message.message_id,
                       metadata_button_pending=0,metadata_button_in_flight=0)

    async def automatic(self, jid):
        r = self.runner
        row = r.state.job(jid)
        if (not row or self.snapshot(jid)!='on' or not row['metadata_data'] or not row['reply_message']
                or row['metadata_file_message'] or row['metadata_file_in_flight']
                or row['status']=='cancelled' or r.stop.is_set()):
            return
        await self.send_file(jid)

    async def callback(self, query):
        r = self.runner
        match = re.fullmatch(r'metadata:([0-9]{1,19})',query.data or '')
        row = r.state.job(int(match[1])) if match else None
        msg = query.message
        user = query.from_user.id
        if (not row or not msg or not row['metadata_data'] or not row['metadata_post_id']
                or self.snapshot(row['id'])!='off' or row['status']=='cancelled'
                or row['user_id']!=user or row['chat_id']!=msg.chat.id
                or row['thread_id']!=getattr(msg,'message_thread_id',None)):
            await query.answer(r.tr(user,'This metadata button belongs to the original requester'),show_alert=True)
            return
        jid = row['id']
        if row['metadata_button_message']!=msg.message_id:
            anchor = getattr(msg,'reply_to_message',None)
            if (row['metadata_button_pending'] and row['metadata_button_in_flight']
                    and getattr(anchor,'message_id',None)==row['reply_message']):
                # This click confirms an actual reply whose acknowledgement was lost.
                r.state.change(jid,metadata_button_message=msg.message_id,
                               metadata_button_pending=0,metadata_button_in_flight=0)
            else:
                await query.answer(r.tr(user,'This metadata button belongs to the original requester'),show_alert=True)
                return
        if r.stop.is_set():
            await query.answer(r.tr(user,'The bot is restarting, please send your links again shortly'),show_alert=True)
            return
        if await r.button_wait(query,jid,'metadata'):
            return
        await self.send_file(jid,query)

    async def send_file(self, jid, query=None):
        r = self.runner
        row = r.state.job(jid)
        user = row['user_id']
        if not query and row['metadata_file_message']:
            return
        if not query and row['metadata_file_in_flight']:
            return
        try:
            data = export_metadata(row['metadata_data'],row['metadata_format'])
        except (ValueError,TypeError,UnicodeError,zlib.error):
            if query:
                await query.answer(r.tr(user,'Metadata is unavailable for this post'),show_alert=True)
            return
        if len(data)>MAX_BYTES:
            if query:
                await query.answer(r.tr(user,'This metadata file is too large, the maximum size is 50 MB'),show_alert=True)
            return
        # Each eligible manual tap is an explicit new upload after its cooldown;
        # automatic delivery retains the original once-only receipt.
        token = query.id if query else row['metadata_request_token']
        if query:
            r.state.start_metadata_request(jid,token)
        else:
            r.state.change(jid,metadata_file_in_flight=1)
        started = False
        async def send_file():
            nonlocal started
            started = True
            try:
                return await r.bot.send_document(
                    chat_id=row['chat_id'],message_thread_id=row['thread_id'],
                    document=BufferedInputFile(data,filename=row['metadata_post_id']+'.metadata.'+chosen_format(row['metadata_format'])),
                    caption=BOT_ATTRIBUTION,parse_mode='HTML',
                    reply_parameters=ReplyParameters(message_id=row['reply_message'],allow_sending_without_reply=True))
            except TelegramRetryAfter:
                started = False
                raise
        try:
            if query:
                await query.answer(r.tr(user,'Sending metadata file...'))
            message = await r.api(row['chat_id'],send_file)
        except asyncio.CancelledError:
            if not started:
                r.state.metadata_request_result(jid,token)
            raise
        except TelegramEntityTooLarge:
            r.state.metadata_request_result(jid,token)
            if query:
                await r.tell(row['chat_id'],r.tr(user,'Could not send the metadata file, try the button again'),row['thread_id'])
            return
        except (TelegramNetworkError,TelegramServerError,ClientDecodeError):
            if not started:
                r.state.metadata_request_result(jid,token)
            logging.info('Metadata file delivery not confirmed for job %s',jid)
            if query:
                await r.tell(row['chat_id'],r.tr(user,'Metadata delivery is pending or unconfirmed, check the chat'),row['thread_id'])
            return
        except TelegramAPIError:
            r.state.metadata_request_result(jid,token)
            if query:
                await r.tell(row['chat_id'],r.tr(user,'Could not send the metadata file, try the button again'),row['thread_id'])
            return
        except AiogramError:
            if not started:
                r.state.metadata_request_result(jid,token)
            logging.info('Metadata file delivery not confirmed for job %s',jid)
            return
        r.state.metadata_request_result(jid,token,message.message_id)
