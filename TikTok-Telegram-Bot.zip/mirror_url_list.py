"""Periodically publish the download URL list to the mirror repository."""

import asyncio
import base64
import logging
import re
import time
from urllib.parse import quote, unquote

import aiohttp

from download_mirrors import CDN, GitHub, MirrorError, REQUEST_ERRORS, TARGET, github_settings, onlyfiles_link, sha


INTERVAL = 1800
LIST_PATH = '.github/liste.txt'
BRANCH_ROOTS = ('video','photo')
REGULAR_FILE = ('100644','100755')


def archive_path(path):
    parts = path.split('/')
    return (len(parts)>=3 and TARGET.fullmatch('/'.join(parts[:2]))
            and all(part and not part.startswith('.') and not re.search(r'[\x00-\x1f\x7f\\]',part)
                    for part in parts[2:]))


def saved_repo_url(url):
    if not isinstance(url,str) or not url.startswith(CDN) or any(c.isspace() for c in url):
        return None
    path = url[len(CDN):]
    if '?' in path or '#' in path:
        return None
    decoded = unquote(path)
    if archive_path(decoded.removesuffix('/')):
        return CDN+quote(decoded,safe='/')
    return None


def published_urls(paths):
    # The directory URL is the download link for release pages. Include a
    # standalone .html redirect when there is no matching directory URL.
    directories = {path.removesuffix('index.html') for path in paths
                   if path.endswith('/index.html') and '.' in path.split('/')[-2]}
    for directory in directories:
        yield CDN+quote(directory,safe='/')
    for path in paths:
        if not path.endswith('/index.html'):
            if path.endswith('.html'):
                stem = path.removesuffix('.html')
                parent,name = stem.rsplit('/',1)
                if stem+'/' in directories or parent+'/download/'+name+'/' in directories:
                    continue
            yield CDN+quote(path,safe='/')


async def branch_blobs(git,root):
    """Collect the index and archive files from one immutable tree snapshot."""
    tree = await git.api('GET','/git/trees/'+root,params={'recursive':'1'})
    if not tree.get('truncated'):
        nodes = tree_entries(tree)
    else:
        # GitHub truncates large recursive trees. Walk only the relevant
        # directories so a partial response never replaces the saved list.
        nodes = []
        pending = [('',root)]
        while pending:
            prefix,tree_id = pending.pop()
            subtree = await git.api('GET','/git/trees/'+tree_id)
            if subtree.get('truncated'):
                raise MirrorError()
            for entry in tree_entries(subtree):
                path = prefix+entry['path']
                nodes.append(dict(entry,path=path))
                if entry['type']=='tree' and (path in (*BRANCH_ROOTS,'.github')
                        or path.startswith(('video/','photo/'))):
                    pending.append((path+'/',sha(entry)))
    archive = set()
    index = None
    for entry in nodes:
        path = entry['path']
        regular = entry['type']=='blob' and entry.get('mode') in REGULAR_FILE
        if path=='.github' and entry['type']!='tree':
            raise MirrorError()
        if path==LIST_PATH:
            if not regular:
                raise MirrorError()
            index = sha(entry)
        elif regular and archive_path(path):
            archive.add(path)
    return archive,index


def tree_entries(tree):
    entries = tree.get('tree')
    if not isinstance(entries,list) or any(
            not isinstance(entry,dict) or not isinstance(entry.get('path'),str) or 'type' not in entry
            for entry in entries):
        raise MirrorError()
    return entries


async def read_existing(git,blob_sha):
    if blob_sha is None:
        return None
    data = await git.api('GET','/git/blobs/'+blob_sha)
    content = data.get('content')
    if data.get('encoding')!='base64' or not isinstance(content,str):
        raise MirrorError()
    return base64.b64decode(''.join(content.split()),validate=True).decode('utf-8')


class MirrorURLList:
    def __init__(self,runner):
        self.runner = runner

    async def sync(self,git):
        for attempt in range(3):
            parent,base = await git.branch_head()
            paths,index = await branch_blobs(git,base)
            previous = await read_existing(git,index)
            urls = set(published_urls(paths))
            # OnlyFiles has no listing endpoint. Keep its saved links even if
            # this session was restored from a backup older than the index.
            for line in (previous or '').removeprefix('\ufeff').splitlines():
                if url := onlyfiles_link(line.strip()):
                    urls.add(url)
            for only,repo in self.runner.state.mirror_urls():
                if url := onlyfiles_link(only):
                    urls.add(url)
                if url := saved_repo_url(repo):
                    urls.add(url)
            listing = ''.join(url+'\n' for url in sorted(urls))
            if listing==previous:
                return False
            async with git.lock:
                try:
                    return await git.commit_tree(parent,base,[
                        {'path':LIST_PATH,'mode':'100644','type':'blob','content':listing}],
                        'Update mirror URL list')
                except MirrorError as exc:
                    if exc.status not in (409,422) or attempt==2:
                        raise
                    # Re-read both the branch and existing list on conflict.

    async def run(self):
        settings = github_settings()
        if settings is None:
            return
        branch,headers = settings
        timeout = aiohttp.ClientTimeout(total=45,connect=12,sock_read=35)
        async with aiohttp.ClientSession(timeout=timeout,headers=headers) as session:
            git = GitHub(session,branch,self.runner.mirrors.git_lock)
            while not self.runner.stop.is_set():
                try:
                    async with asyncio.timeout(180):
                        if await self.sync(git):
                            logging.info('Updated the mirror URL list')
                except REQUEST_ERRORS as exc:
                    logging.warning('Could not update the mirror URL list, %s (HTTP %s)',
                                    type(exc).__name__,getattr(exc,'status',0) or 'unknown')
                # Refresh on startup, then at the next :00 or :30 while running.
                try:
                    await asyncio.wait_for(self.runner.stop.wait(),INTERVAL-time.time()%INTERVAL)
                except TimeoutError:
                    pass
