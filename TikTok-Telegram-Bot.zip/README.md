# TikTok Telegram Bot

Send TikTok links directly to download videos and photo posts with gallery-dl
There is no `/download` command and no yt-dlp or FFmpeg dependency

## Quick setup

1. Create a Telegram bot through [BotFather](https://t.me/BotFather) with `/newbot`, keep its token private
2. Create a GitHub repository and upload this ZIP's contents into its root, including `.github/workflows/tiktok.yml`, use a private repository because saved queue state includes Telegram chat and user IDs
3. Obtain your numeric Telegram ID and the numeric ID of `@Tog991`, run `python identify.py` locally, paste the token at its hidden prompt, and send `/id` to your bot from each account, match the displayed username to `Tog991` and stop the helper before starting the workflow
4. Add the configuration below through repository Settings → Secrets and variables → Actions
5. Open the bot in a private chat from the owner account and send `/start`, this lets it send owner notifications
6. Go to Actions → TikTok Telegram Bot → Run workflow, leave `continue` enabled for automatic session renewal
7. Send a public TikTok video or photo post link to the bot

Upload the project contents, not a ZIP file, to the repository
GitHub only discovers the workflow when `.github/workflows/tiktok.yml` is committed, put it on the default branch first

## Configuration

| Name | Location | Value |
|---|---|---|
| `TELEGRAM_BOT_TOKEN` | Secret | Token from BotFather |
| `OWNER_ID` | Variable or secret | Owner's numeric Telegram user ID, not the Discord owner ID |
| `QUEUE_BYPASS_USER_ID` | Variable or secret | Numeric Telegram ID verified as belonging to `@Tog991` |
| `R2_ACCOUNT_ID` | Variable or secret | Cloudflare account ID |
| `R2_ACCESS_KEY_ID` | Secret | R2 S3 access key |
| `R2_SECRET_ACCESS_KEY` | Secret | R2 S3 secret key |
| `R2_BUCKET_NAME` | Variable or secret | Existing R2 bucket with read, write, list, and delete access |
| `TIKTOK_COOKIES_BASE64` | Optional secret | Base64-encoded Netscape TikTok cookies file for the Chromium sound fallback only |
| `APP_ZIP_URL` | Optional secret | Direct HTTPS link to a trusted project ZIP |

No GitHub personal access token is needed, the workflow uses its automatic `GITHUB_TOKEN` with `actions: write` for its own cache management and workflow dispatch
Repository or organization policies must allow the workflow actions and dispatch

The queue exemption uses a numeric ID, it never grants rights to somebody merely because they adopt a matching username
If `QUEUE_BYPASS_USER_ID` is missing, everyone uses the normal limits until you set it and restart
Exemption does not grant owner commands, `OWNER_ID` controls those separately

## Queue behavior

- Each normal user has 4 active or reserved slots and 4 waiting slots
- Additional links are rejected with a message identifying them
- Multiple links in one message are accepted up to the available capacity
- One TikTok post counts as one request, including posts with many photos
- `@Tog991` has a separate single download slot with no four-request backlog limit, other users do not occupy that slot, its own requests run in order
- Slots cover downloading and Telegram delivery, Telegram's own message limits still apply
- Queue positions are shown on admission, `/queue` shows current states
- There is no fixed global four-download cap, each user's slots are separate, size and timeout checks keep individual jobs bounded

## Media behavior

Videos are sent as playable MP4 files when available, other supported video formats are sent as documents
Photos are sent in groups of up to 10, a final single photo is sent individually
Images that exceed Telegram's photo constraints or use unsupported photo formats are sent as original documents instead
Telegram may recompress photos displayed as photos, the bot itself does not re-encode them

The limit is **50,000,000 bytes per file**, 50 decimal MB, size is checked both from the HTTP header and while streaming
The bot rejects an oversized post before sending its media and displays:

> This video is too large, the maximum size is 50 MB

There is no compression, R2 media upload, expiring media link, or fallback to yt-dlp
Completed, cancelled, and failed downloads are deleted from the runner
Only single video/photo posts are accepted, profile and collection downloads are not enabled
Photos always receive their available soundtrack

## Commands

| Command | Access | Purpose |
|---|---|---|
| `/start`, `/help` | Everyone | Usage instructions |
| `/queue` | Everyone | List your active and waiting jobs |
| `/cancel <number>` | Requester or owner | Cancel a job |
| `/ping` | Everyone | Check responsiveness |
| `/id` | Everyone | Show your numeric Telegram ID |
| `/jobs` | Owner | List all outstanding jobs |
| `/restart` | Owner | Save, back up, and start a fresh workflow session |
| `/upload` | Owner | Save, back up, and start a fresh workflow session |
| `/shutdown` | Owner | Save, back up, and stop without another session |

`/restart` and `/upload` both force one replacement session even if `continue` was disabled, the replacement preserves your selected `continue` setting
`/shutdown` overrides continuation, start again manually from GitHub Actions
A cancellation cannot withdraw an upload Telegram has already accepted

## Hosting and backups

The workflow uses actions from `@main`, with Python 3.12 and a 5-hour-30-minute bot session inside a 355-minute job
Python package versions for gallery-dl and python-telegram-bot are pinned to the versions checked for this release, `@main` applies to GitHub actions

After a clean stop it:

1. Validates saved state
2. Creates a ZIP containing a consistent SQLite snapshot and allowed project source files
3. Uploads it to a dedicated `tiktok-bot-backups/` scope in R2
4. Reads the upload back and verifies SHA-256 and size
5. Deletes older backups only in that same workflow scope
6. Saves and verifies the GitHub cache, retaining one previous cache
7. Dispatches the next session if requested

Cookies, tokens, downloaded media, and raw request logs are excluded from backups and diagnostics
R2 backups restore automatically when the state cache is absent
The source ZIP is optional, by default the bot uses the checked-out repository files
With `APP_ZIP_URL`, source is cached under `app`, `force_reimport` imports an updated ZIP while retaining the separate queue database
Keep the repository workflow and helper files updated too, importing a ZIP does not rewrite the committed workflow

Only one workflow session runs at a time, there is a handover gap while GitHub allocates the next runner
Failed runs or failed backups do not automatically continue, inspect the sanitized workflow output before restarting
A manual force-cancel or runner crash can lose changes since the last completed session backup, the local SQLite writes do not make an ephemeral runner durable
Use `/shutdown` instead of GitHub's Cancel button for a clean stop

## Recovery and delivery tracking

Queued and interrupted downloads are recovered from saved state
Each confirmed media batch is recorded before the next batch starts
If Telegram times out or the bot stops during an upload, it cannot know for certain whether that upload arrived, the job is marked uncertain and is not automatically resent
The bot asks you to check the chat before sending that link again
This avoids blindly duplicating albums, Telegram does not provide an idempotency key for these sends

## Groups

To detect ordinary links in group chats, use BotFather's `/setprivacy` to disable privacy mode for this bot, then remove and re-add it to the group if needed
Grant the bot permission to send messages and media
The queue is per user across chats, forum-topic replies stay in the originating topic

## Optional cookies

Use a Netscape-format cookie file exported from a TikTok session you control
These saved cookies are used only inside the temporary Chromium fallback for direct sound links. Short-link resolution, video/photo downloads, automatic and manual post audio, and normal sound-page/detail requests do not load them. Cookies are not copied from Chromium into the HTTP audio or cover downloader.
Encode it locally, for example in PowerShell:

```powershell
[Convert]::ToBase64String([IO.File]::ReadAllBytes('C:\path\cookies.txt')) | Set-Clipboard
```

Paste that value into `TIKTOK_COOKIES_BASE64`, then use `/restart`
Secrets are loaded at session startup, editing a GitHub secret does not update an already-running process
A 403 does not prove cookies expired, it can also mean TikTok blocked the runner, the bot's owner message reflects that distinction

## Local execution

Requires Python 3.12 or newer on Linux, the hosting runner is Linux
Set the required bot environment variables, then:

```bash
python -m pip install -r requirements.txt
python bot.py
```

R2 is required by the GitHub workflow, direct local execution does not automatically invoke the backup and dispatch helpers
Local `/restart` and `/upload` stop cleanly, use a process manager or start the script again yourself

## Checks

```bash
python -m pip install pytest pytest-asyncio PyYAML
python -m pytest -q
```

See `VALIDATION.md` for the checks actually performed on this package

## References

- [gallery-dl configuration](https://gdl-org.github.io/docs/configuration.html)
- [Telegram Bot API](https://core.telegram.org/bots/api)
- [python-telegram-bot](https://docs.python-telegram-bot.org/)
- [GitHub Actions limits](https://docs.github.com/en/actions/reference/limits)


## Languages and commands

First-time users choose English, Spanish, Arabic, Russian or Chinese using buttons before sending links. The selected language is saved in the queue database and can be changed with /language. If a link was sent before choosing a language, send it again after selection.

/start only asks for a TikTok video or photo link. /help contains usage and commands, with owner commands included only for OWNER_ID. /ping reports the Telegram send-message round-trip time in milliseconds, excluding local pacing delays.


## Audio replies

Downloaded videos, photos, albums and document fallbacks reply to the message containing the TikTok link in the same chat/topic. If that message has been deleted while the download is queued, the media can still be sent without a reply. Audio accompanying a post continues to reply to the delivered video/photo, and direct sound-link audio replies to the link message.

Photo posts always receive TikTok's supplied sound track as an audio reply to the first delivered media message, once per album. Videos receive the sound automatically when Audio is On. When Audio is Off, videos instead have an **Extract audio** button. The audio caption is only @TikTokdownloaderbestbot. Original video/photo captions stay unchanged.

The audio filename uses the sound title when available, falling back to the TikTok post ID. Available title, artist, album, cover art, duration metadata, sound ID, post ID and source link are written into the MP3/M4A file with Mutagen. Telegram also receives the title, artist, duration and JPEG thumbnail. Missing metadata is omitted, the title falls back to the post ID. No FFmpeg or yt-dlp is used, and the audio stream is not re-encoded. TikTok's separate sound track can differ from the video's complete mixed audio.

If TikTok supplies no usable sound URL or audio format, the video/photos still arrive with an audio-unavailable notice. Audio above 50 MB, including added tags, is skipped with a size notice. Temporary audio and cover files are deleted with the request's other files. Saved delivery receipts prevent resending confirmed media/audio after restart, and an additive database migration preserves the existing queue and language choices.

To deploy, replace the ZIP hosted at APP_ZIP_URL and start a session with force_reimport enabled. The workflow installs Mutagen from the updated requirements automatically.

Cover art is embedded at its original resolution, preferring TikTok coverLarge. JPEG and PNG artwork is embedded byte-for-byte, other supported image formats are converted losslessly to PNG without resizing. A separate JPEG thumbnail, at most 320 × 320 and under 200 KB, is generated only for Telegram. The 50 MB audio limit still applies after embedding the full cover.

### Sound links and settings

Send a TikTok `/music/...` link or a `vt.tiktok.com` / `vm.tiktok.com` share link that redirects to a sound page. The bot sends the sound as a reply to your link, with its title, artist and full-resolution embedded cover when available, plus a separate Telegram preview thumbnail. The sound ID is the filename fallback when no title is available. The 50 MB limit still applies. Sound-page support uses gallery-dl's TikTok session and page-data parser with a local adapter; access depends on TikTok exposing playable sound data. No video search or bulk download is performed.

`/settings` opens buttons for **Language** and **Audio**. Language opens the five language buttons. Audio controls automatic sound replies for **videos only**, defaulting to On. On sends audio with the video; Off adds an **Extract audio** button to the delivered video, including videos delivered as documents. Photos always receive their audio regardless of this setting. **Back** returns to settings. Each user's preference persists and is applied when a download starts. Direct sound links always send audio. Buttons can only change the settings of the user who opened them.

The original requester can click **Extract audio** to enqueue the video's TikTok sound. It uses the existing four active/four waiting limits and exempt-user lane, replies to the delivered video in the same chat/topic, and downloads only the sound and cover art. Repeated clicks reuse the request rather than sending duplicate audio. Button mappings and pending audio jobs survive restarts and database backups, without retaining downloaded video files. The button uses the same separate TikTok sound track and metadata pipeline as automatic replies, which can differ from the video's full mixed audio. TikTok must still make that post and its sound available when the button is pressed.

After replacing your hosted ZIP, run the workflow with `force_reimport` enabled to load this update. Existing database preferences and queued requests are retained.


### Sound-download diagnostics

The workflow prints sanitized `Download diagnostic` lines for URL resolution, sound-page extraction, the sound-detail fallback, audio download, file format, and tagging. Cookie-file configuration and loading are checked only when Chromium starts. HTTP status codes and exception class names are included when available. Cookies, response bodies, signed media URLs, and exception messages are not logged. An empty sound-detail response or missing playable URL is reported separately from a failed audio download. Cookie presence does not establish that the login is valid.

Sound extraction accepts string and URL-list audio addresses and tries TikTok's music-detail endpoint if the page lacks playable metadata for the requested sound ID. These requests and short-link resolution use anonymous sessions without the configured cookie file. No alternative sound is substituted if the requested ID cannot be found. These changes improve extraction and diagnostics but cannot guarantee availability when TikTok returns no sound data.


### Chromium fallback for direct sound links

When normal sound-page and detail extraction provide no playable URL, the worker launches headless Chromium with Playwright. Only at this point does it read the configured cookie file and import unexpired TikTok cookies into an isolated context. A missing or unreadable cookie file is reported without exposing its contents, and the browser can still try anonymously. It allows the page's JavaScript to run and checks page data and music API responses for the requested sound ID. It can also request the detail endpoint through the page, using TikTok's own signing SDK when available. The browser closes after the attempt; its temporary session is not saved or copied into gallery-dl. Matching audio uses the existing metadata, cover-art, thumbnail and bounded download pipeline without the saved login cookies.

Only direct sound links use this fallback. Video/photo posts, manual video sound requests, and automatic audio replies continue through gallery-dl. The fallback runs one browser at a time with bounded waiting and extraction time. If TikTok still supplies no playable sound, the bot returns a specific message instead of repeating the same full attempt three times.

Update **both** your hosted application ZIP and `.github/workflows/tiktok.yml`, then run with `force_reimport` enabled. The standalone `tiktok.yml` still needs no application files committed to the repository. The workflow installs Chromium and its system dependencies, caching browser binaries in `~/.cache/ms-playwright`; no cookies, browser profiles, or downloaded media are cached there. A new dependency cache key is used when requirements change. Existing queue, settings and R2 backup behavior are preserved.

Local runs also need `python -m playwright install --with-deps --no-shell chromium`. TikTok may still refuse automated access, so the fallback is not a guarantee of sound availability.

### Owner broadcast command

In your **private chat with the bot**, send or forward the announcement, then reply to that message with `/broadcast`. Only `OWNER_ID` can use this command. The bot copies the selected message as a preview, shows the number of recipient chats, and offers **Send** and **Cancel** buttons. Nothing is sent to the audience until you select Send. Text, supported media, captions, and Telegram formatting are preserved by copying the preview; an album reply selects that individual message only. Unsupported messages produce an error before confirmation.

Each broadcast uses a snapshot of known active private chats and groups, including the owner's private chat if registered. Existing chat IDs are imported from the saved download history. New chats are recorded on messages and bot membership updates. Telegram does not supply a list of every past user/group, so older chats absent from the database must interact with the bot once to register. Users who only interacted in a group are not automatically messaged privately. Removed/blocked chats are deactivated and can be registered again after they return.

Delivery is paced alongside downloads. Receipts and the audience survive cached database/R2 restores. Confirmed sends are not repeated; interrupted or unconfirmed sends are reported as Unconfirmed instead of being retried blindly. A summary lists sent, failed/skipped, and unconfirmed recipients. Keep the bot's preview message until sending finishes. The owner interface supports all five languages; the announcement itself is sent exactly as previewed.

Replace the hosted ZIP and run with `force_reimport` enabled. The Chromium-enabled workflow from the previous update does not need another change for this feature.
