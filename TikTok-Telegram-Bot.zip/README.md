# TikTok Telegram Bot

Send TikTok links directly to download videos and photo posts with gallery-dl. Telegram uses aiogram 3.31.0.
There is no `/download` command or yt-dlp dependency. FFmpeg and ffprobe handle optional video compression.

## Quick setup

1. Create a Telegram bot through [BotFather](https://t.me/BotFather) with `/newbot`, keep its token private
2. Create a GitHub repository and upload this ZIP's contents into its root, including `.github/workflows/tik.yml`, use a private repository because saved queue state includes Telegram chat and user IDs
3. Obtain your numeric Telegram ID and the numeric ID of `@Tog991`: install this ZIP's dependencies with `python -m pip install -r requirements.txt`, run `python identify.py` locally, paste the token at its hidden prompt, and send `/id` to your bot from each account. Match the displayed username to `Tog991` and stop the helper before starting the workflow
4. Add the configuration below through repository Settings → Secrets and variables → Actions
5. Open the bot in a private chat from the owner account and send `/start`, this lets it send owner notifications
6. Go to Actions → TikTok Telegram Bot → Run workflow, leave `continue` enabled for automatic session renewal
7. Send a public TikTok video or photo post link to the bot

Upload the project contents, not a ZIP file, to the repository
GitHub only discovers the workflow when `.github/workflows/tik.yml` is committed, put it on the default branch first

## Configuration

| Name | Location | Value |
|---|---|---|
| `TELEGRAM_BOT_TOKEN` | Secret | Your existing token from BotFather |
| `TELEGRAM_API_ID` | Secret | Numeric `api_id` from my.telegram.org → API development tools |
| `TELEGRAM_API_HASH` | Secret | Matching `api_hash` from the same Telegram app |
| `TELE_OWNER_ID` | Variable or secret | Owner's numeric Telegram user ID; this custom workflow exports it as `OWNER_ID` |
| `QUEUE_BYPASS_USER_ID` | Variable or secret | Numeric Telegram ID verified as belonging to `@Tog991` |
| `R2_ACCOUNT_ID` | Variable or secret | Cloudflare account ID |
| `R2_ACCESS_KEY_ID` | Secret | R2 S3 access key |
| `R2_SECRET_ACCESS_KEY` | Secret | R2 S3 secret key |
| `R2_BUCKET_NAME` | Variable or secret | Existing R2 bucket with read, write, list, and delete access |
| `TIKTOK_COOKIES_BASE64` | Optional secret | Base64-encoded Netscape TikTok cookies file for the Chromium sound fallback only |
| `TELE_ZIP` | Secret | Direct HTTPS link to the updated trusted project ZIP; exported as `APP_ZIP_URL` |

No GitHub personal access token is needed, the workflow uses its automatic `GITHUB_TOKEN` with `actions: write` for its own cache management and workflow dispatch
Repository or organization policies must allow the workflow actions and dispatch

The queue exemption uses a numeric ID, it never grants rights to somebody merely because they adopt a matching username
If `QUEUE_BYPASS_USER_ID` is missing, everyone uses the normal limits until you set it and restart
Exemption does not grant owner commands, `OWNER_ID` controls those separately

## Local Telegram Bot API setup

Get `api_id` and `api_hash` from [my.telegram.org](https://my.telegram.org): sign in, open **API development tools**, and create an application. Add them as GitHub repository **Settings → Secrets and variables → Actions → New repository secret**, named exactly `TELEGRAM_API_ID` and `TELEGRAM_API_HASH`. Keep your existing bot token, owner, source ZIP and R2 secrets. These app credentials belong in Actions secrets, not in source files or messages to the bot.

Replace the hosted source ZIP and `.github/workflows/tik.yml` together, then run the workflow with `force_reimport` enabled (or choose ZIP reimport through `/restart`). The updated importer also refreshes a cached source tree missing either local API helper. No separate VPS, public domain or extra Telegram account login session is needed: the official server runs beside aiogram on `127.0.0.1:8081`, using your existing bot token. The first start calls Telegram's cloud `logOut` before connecting locally. Telegram blocks a return to the cloud endpoint for ten minutes after that logout.

The workflow resolves the official `tdlib/telegram-bot-api` source commit, builds it with its pinned TDLib submodule, and caches the compiled executable by Ubuntu version, architecture and commit. A cache hit reuses the executable; a new upstream commit builds again. The first cold build can take several minutes. The workflow reserves ten minutes for shutdown, backup and reporting within its 355-minute job limit, shortening the 20,400-second session if setup used too much time. Warm runs retain the requested session when that time is available.

On clean shutdown the native server is stopped before its authorization/update database is encrypted into `state/telegram-api.enc`; the matching queue database and encrypted native snapshot go together into the state cache and verified R2 backup. The native database and downloaded media stay in the runner's private temporary directory and are never stored as raw cache entries. The encryption key is derived from `TELEGRAM_API_HASH` and the bot's numeric ID. Keep that hash unchanged when restoring state; rotating the bot token for the same bot does not change the key. A migrated queue database without its matching encrypted state fails safely instead of creating a fresh native update history. The owner `/upload` ZIP continues to exclude native authorization state; standalone restoration of a migrated queue also requires the matching encrypted file from its workflow cache or R2 backup.

Cloud logout is idempotent: Telegram reporting that the bot is already logged out is accepted as a completed migration step. Telegram rate limits use the supplied `retry_after` delay, with bounded waits and progress messages; transient cloud transport/server failures are retried. Delays beyond the roughly eleven-minute setup wait budget stop with a safe status message instead of waiting indefinitely. Native authorization also respects declared cooldowns. Real authorization failures show the HTTP status and the relevant secret names, without printing the bot token, API hash, response body or token-bearing URL.

The startup helper creates the database, auxiliary files and temporary directories privately before launching the native server. If startup exits or times out, it prints the exit code when available and a bounded, redacted excerpt of the native startup log. The raw log stays in the private runner temporary directory and is excluded from caches and backups.

The bot, hourly logs, update notices and final diagnostics all use the selected local endpoint. An unexpected local-server exit stops the bot, reports the crash when Telegram is reachable, and blocks automatic continuation. `/dpend` and grouped `#update` notices include the native Bot API server version. If application setup fails before the local server is available, final diagnostics use the cloud endpoint and log out again so the next local start can migrate normally.

Manual runs without `TELEGRAM_API_BASE` retain the cloud endpoint and 50 MB upload cap. Merely installing aiogram does not start a local server; use the provided workflow for the complete setup.

## Queue behavior

- Every user can have **five active requests** by default, including the queue-bypass account
- `/settings` → **Queue** offers **Five at once** (default) or **One at a time** for the older sequential behavior
- The saved queue mode applies only to that user, including the owner/bypass account if they select it, and survives restarts/backups
- Switching to **One at a time** returns unstarted requests to the waiting queues in order, running downloads finish normally before another slot opens
- Switching back to **Five at once** makes available slots usable immediately
- The owner and queue-bypass account have an **unlimited regular waiting queue**, promoted in order whenever an active slot opens
- Normal users have **ten regular waiting slots**, then an **unlimited secondary queue**
- Secondary requests stay in order until that user has no active or regular waiting requests, then the next batch opens with the selected active limit (one or five) and up to ten regular waiting requests
- New links join behind an existing secondary backlog, so they cannot overtake older work or keep its current batch running indefinitely
- Multiple links in one message are accepted, with one TikTok post counting as one request even when it contains many photos
- Requests from different users have independent active slots
- Active slots cover downloading and Telegram delivery, while Telegram's message pacing still applies
- Queue positions are shown on admission, `/queue` shows current states, and `/cancel` can remove a request
- Saved queues and delivery receipts survive normal restarts and verified backups

## Media behavior

### Shared links and promoted posts

Short links use the link-preview user agent used by [gallery-dl's TikTok short-link extractor](https://github.com/mikf/gallery-dl/blob/master/gallery_dl/extractor/tiktok.py), with one anonymous desktop request as a fallback. Older mobile destinations such as `m.tiktok.com/v/{id}.html` are converted to TikTok's `/share/video/{id}` route, including links shared from promoted posts. This lets gallery-dl make its ID-only post request with an empty creator path, without inventing a creator username. A redirect already identifying the post is resolved without fetching the destination page twice.

If the share page returns HTML, the resolver can read its own canonical URL, Open Graph URL, recognized TikTok app links, meta refresh target or TikTok rehydration canonical field. It follows validated TikTok destinations and retains the original post ID instead of guessing from ad IDs or suggested posts. Redirect attempts and page size are limited, with a 45-second resolution budget. Direct post/music links retain their fast path. Saved cookies remain restricted to Chromium sound downloading.

Diagnostics distinguish link resolution, extractor selection and iteration, received post metadata, missing media and invalid video responses. Direct gallery-dl extraction uses a traceback-capable diagnostic logger, retaining exception classes and access-refusal categories without printing raw library messages, URL queries, response bodies or cookie values. A resolved numeric ID alone does not guarantee downloadable media: an ad may still have no publicly accessible post data. If TikTok does not expose a public post target, the original creator-post link is still needed.

TikTok's structured post status is retained in diagnostics before gallery-dl formats its error message: 10204 is post_unavailable, 10221 is account_not_found, 10222 is login_required and 10231 is region_locked. Other nonzero numeric codes use post_error with the original number. A region-locked result shows a translated notice about the bot server's region and stops that request without the usual three automatic attempts. The notice refers to the server's connection location. Reporting a regional restriction does not remove it; no proxy or saved-cookie fallback is added.

### Send as files

`/settings` → **Send as files** controls how TikTok videos and photos are delivered:

| Option | Behavior |
|---|---|
| **On** | Send videos and photos as Telegram documents automatically |
| **Off** | Send normal media, with a **Send as files** button in a reply to the first video/photo |
| **Off with no button** (default) | Send normal media without the file button |
| **Regular media and files** | Send normal media, then also send its files as a reply |

The choice is saved per user and snapshotted when a request starts, so retries retain the same delivery mode. The file button reply contains only the linked bot attribution, as with the caption/album controls. Only the original requester can use it in its original chat and topic. It creates a separate queued request with its own saved delivery receipts and 100-second cooldown, using the selected one-at-a-time or five-at-once queue mode. Button requests fetch the post again after temporary files are cleared, reuse the original request's video compression settings, and send just the videos/photos as documents replying to the first delivered video/photo. TikTok must still make the post available. Repeated accepted taps have separate identities, and unconfirmed uploads are never automatically repeated after a restart.

**Regular media and files** uses one download and one compression pass when compression is enabled. File copies reply to the first normal upload with just the linked bot attribution. Later file albums reply to the preceding file batch. If a video or photo already had to be delivered as a document, that document counts as its file copy. Audio, subtitles, full caption and metadata are handled once and still use the first media message as their reply target. The automatic file copies do not add a **Send as files** button.

By default, video documents and single-photo posts are named `{post_id}.{ext}`, where `post_id` is the numeric TikTok post ID. Posts with multiple photos use `{post_id}_01.{ext}`, `{post_id}_02.{ext}`, through `{post_id}_10.{ext}` and so on, numbered across the whole post even after batches or retries. A multi-photo post keeps its numbered filenames even when only one unsent photo remains. The naming also applies to manual **Send as files** requests and short links. The extension follows the actual delivered file, including the selected video compression output.

Photo documents retain their downloaded bytes. Video compression settings still apply; choose **None** in Compression to keep the downloaded video unchanged. File uploads use the existing 2 GBs local API cap. Photo posts split into groups of ten, later groups reply to the preceding group and use only the linked bot attribution. Automatic audio, subtitle, full-caption and metadata preferences continue to apply to ordinary post requests. Sound links remain audio posts. Manual file requests omit those extra attachments and do not add another file button.

### Media templates

Open `/settings` → **Media templates** to customize video and photo captions independently. Choose a caption, tap **Edit template**, and reply to the bot's prompt. The bot shows a sample **Preview**. Tap **Save template** to apply it or **Cancel** to keep your existing caption. The menu shows the placeholders available for that caption. Use **Reset to default** to restore the built-in layout. Saved templates apply to future jobs, and each job keeps its template choices if it resumes after a restart.

For example, a caption template of `@{{.Username}} — {{.Caption}}` displays the creator and the post's caption on one line. Captions can also contain line breaks. Placeholder values are inserted as text, and the bot adds its linked attribution. The template applies to the main video or first photo batch, including when you receive it as a file. Continuing albums and extra copies still use just the bot attribution. The **Full caption** setting still sends the original TikTok text when it is too long.

| Placeholder | Value |
|---|---|
| `{{.PostID}}` | Numeric TikTok post ID |
| `{{.Title}}`, `{{.Caption}}` | The post's text |
| `{{.Author}}`, `{{.Username}}` | Creator display name and username, the username has no leading @ |
| `{{.URL}}` | The cleaned TikTok link submitted to the bot |
| `{{.AuthorURL}}` | Creator profile, such as `https://www.tiktok.com/@creator` |
| `{{.PostURL}}` | Full creator post link with the numeric ID and the correct `/video/` or `/photo/` path |
| `{{.DurationSeconds}}` | Video duration in seconds, if available |
| `{{.Width}}`, `{{.Height}}` | Video or photo dimensions, using the first picture for a photo caption |
| `{{.PhotoCount}}` | The total number of photos |

Tap **Formatting** in either caption editor to see copyable examples. You can format your reply with Telegram's formatting menu or put `HTML:` on the first line and use caption HTML for bold, italic, underline, strikethrough, spoilers, code, quotes and links. For example:

```text
HTML:
<b>{{.Author}}</b>
<blockquote>{{.Caption}}</blockquote>
<a href="{{.PostURL}}">Open on TikTok</a>
```

Use `{{.URL}}`, `{{.AuthorURL}}` or `{{.PostURL}}` as the entire link target. If the link is unavailable, the label is shown as text. Plain text continues to work, and Markdown syntax is treated as text.

### Normal media delivery

In normal media mode, videos are sent as playable MP4 files when available, other supported video formats are sent as documents
Photos are sent in groups of up to 10, a final single photo is sent individually
The first photo batch replies to the link message with the post caption. Each additional batch replies to the previous batch with only `@TikTokdownloaderbestbot` as its caption, including a final single photo. This also applies to photos sent as documents, and the reply target is saved across restarts.
Images that exceed Telegram's photo constraints or use unsupported photo formats are sent as original documents instead
Telegram may recompress photos displayed as photos, the bot itself does not re-encode them

With the local Bot API workflow, the bot accepts files up to **2,000,000,000 bytes per file** (2 GBs). Compression **None** sends the original video within that limit. Larger inputs are rejected with the translated 2 GBs size error, and streamed downloads stop at the configured bound. Telegram's separate photo-display constraints still apply; unsupported or oversized photo-display formats use original-document delivery.

Compression remains **All videos** by default. **Over 50 MB** keeps its original 50,000,000-byte threshold, even though larger originals can now be uploaded. **None** skips video compression. Selected quality, resolution and FPS settings are applied when compression runs; size-fitting only runs when needed for the active upload cap. Local video inputs are bounded at 2 GBs. Cloud-mode manual runs retain the 50 MB upload cap and 1 GB processing-input bound. R2 stores source/state backups, not media files; there is no expiring media-link fallback or yt-dlp fallback.
Completed, cancelled, and failed downloads are deleted from the runner
Only single video/photo posts are accepted, profile and collection downloads are not enabled
Videos and photos receive their available soundtrack when Audio is On; Off shows an Extract audio button instead

## Dependency updates

At the start of every workflow run, pip upgrades the runtime packages to the newest compatible stable releases allowed by `requirements.txt`. aiogram, gallery-dl and Playwright now have minimum versions rather than exact pins. The existing boto3, Pillow and Mutagen compatibility ranges remain in place. Updates happen at startup, not while the bot is running. Pip downloads stay cached, and the Chromium cache follows the installed Playwright version. `/dpend` reports the versions actually installed in that session.

The workflow selects the latest available stable Python in the bot's supported range with `python-version: '>=3.12 <3.15'` and `check-latest: true`. Its pip download cache includes the selected Python version, runner OS and architecture.

## Commands

| Command | Access | Purpose |
|---|---|---|
| `/start`, `/help` | Everyone | Usage instructions |
| `/queue` | Everyone | List your active and waiting jobs |
| `/cancel <number>` | Requester or owner | Cancel a job |
| `/ping` | Everyone | Check responsiveness |
| `/specs` | Owner | Run neofetch and show ASCII art and current server specifications in a code block |
| `/dpend` | Owner | Show Python, runtime dependencies and installed tool versions in a code block |
| `/stats` | Owner | Show uptime, recorded users/chats, saved requests and the current queue |
| `/id` | Everyone | Show your numeric Telegram ID |
| `/settings` | Everyone | Language, audio, compression and subtitle preferences |
| `/jobs` | Owner | List all outstanding jobs |
| `/restart` | Owner | Choose restart with or without ZIP reimport, or cancel |
| `/upload` | Owner | Receive a private backup ZIP with shutdown/restart buttons |
| `/shutdown` | Owner | Save, back up, and stop without another session |

`/specs` is available only to the bot owner in private chats, groups and forum topics, including before language selection. It runs the cached neofetch executable on demand and replies to the command with the ASCII logo above fresh system information in Telegram code formatting. Terminal color/control sequences are removed and long results are split into code blocks. Other users receive the translated owner-only message without running neofetch. The command appears in owner help and is excluded from the public command menu. A missing, failed or timed-out neofetch command gets a translated error while the bot keeps running.

`/dpend` is owner-only and replies to the command in Telegram code formatting, including in groups and forum topics and before language selection. It reports the current Python version, installed versions of the runtime packages listed in `requirements.txt`, and FFmpeg, ffprobe, Playwright Chromium and neofetch versions. It uses the cached FFmpeg/neofetch executables when available and otherwise searches PATH. Chromium is checked locally without opening a browser or contacting TikTok. Missing, failed and timed-out tool probes are marked in the report; each subprocess has a five-second timeout. It appears in owner help in all ten languages and stays out of the public command menu. Version numbers retain their original dots.

`/stats` is owner-only and replies to the command in code formatting, including in groups and forum topics and before language selection. It shows session uptime, recorded users/chats, chats marked active, saved request totals by status, the current running/ready/waiting queue, and request/requester counts for the last 24 hours. Reports and owner help support all ten languages, and the command stays out of the public menu. Queue bypass users do not gain access. Counts use the saved database, including link requests and separate audio/subtitle jobs, so restored history is retained; caption/metadata file callbacks are not separate jobs. Recorded users combine requesters, saved language choices and private chat records, while active chats reflect stored membership records rather than a live reachability probe. Uptime resets each session. The report contains aggregate counts without user IDs, links, captions or metadata, and reads local state without downloading media or running system tools.

`/restart` shows **Restart and reimport ZIP**, **Restart without reimport** and **Cancel**. The bot keeps running until you choose. Reimport downloads the current application from `APP_ZIP_URL` for the next session and skips its cached source, retaining the separate queue database. Restart without reimport uses the usual source cache. Either restart starts one replacement session even when `continue` is disabled, and preserves that setting for later sessions. The reimport choice applies only to that replacement session. Only the owner can use the choices; old or already-used prompts cannot restart the bot again.

`/upload` prepares a consistent SQLite snapshot and sends a ZIP to the owner's private chat, even when the command was sent in a group. The ZIP contains `state/state.db` (queue, preferences, captions, delivery receipts and broadcast state) plus the running bot's source under `app/`. Cookies, credentials, downloaded media, and symbolic links are excluded. The ZIP message has **Shut down** and **Restart** buttons. Shut down saves the final progress, runs the usual workflow backup, and ends automatic continuation. Restart opens the same ZIP-reimport choices as `/restart`. Receiving the ZIP keeps the bot running until you choose an action. The ZIP reflects the snapshot taken during the command; the workflow saves its final state when the session ends. The selected API upload limit applies to the ZIP (2 GBs in the supplied local-server workflow). Open the bot privately and send `/start` first so it can deliver your backup.
`/shutdown` overrides continuation, start again manually from GitHub Actions
A cancellation cannot withdraw an upload Telegram has already accepted

## Hosting and backups

The workflow uses actions from `@main`, with the latest stable Python in the bot’s supported range (3.12 to below 3.15) and a 5-hour-40-minute bot session inside a 355-minute job
Python packages upgrade at startup within the supported requirements ranges, `@main` applies to GitHub actions

FFmpeg and ffprobe use the yt-dlp static Linux GPL build, installed in `~/.ffmpeg` and added to PATH. The workflow restores this directory before installation, downloads the archive only when either executable is missing, checks the required encoders and HDR filters, then saves a new cache immediately. Later sessions reuse that build. The cache is separate from pip and Chromium and is keyed by runner OS, architecture and build variant. To fetch a newer build, delete its FFmpeg cache in GitHub Actions or change the cache key suffix from `v1` to `v2`.

After a clean stop it:

1. Validates saved state
2. Creates a ZIP containing a consistent SQLite snapshot and allowed project source files
3. Uploads it to a dedicated `tiktok-bot-backups/` scope in R2
4. Reads the upload back and verifies SHA-256 and size
5. Deletes older backups only in that same workflow scope
6. Saves and verifies the GitHub cache, retaining one previous cache
7. Dispatches the next session if requested

Cookies, tokens, downloaded media, and raw request logs are excluded from backups and diagnostics
R2 backups restore automatically when the state cache is absent
The source ZIP is optional, by default the bot uses the checked-out repository files
With `APP_ZIP_URL`, source is cached under `app`, `force_reimport` imports an updated ZIP while retaining the separate queue database
Keep the repository workflow and helper files updated too, importing a ZIP does not rewrite the committed workflow

Only one workflow session runs at a time, there is a handover gap while GitHub allocates the next runner
Failed runs or failed backups do not automatically continue, inspect the sanitized workflow output before restarting
A manual force-cancel or runner crash can lose changes since the last completed session backup, the local SQLite writes do not make an ephemeral runner durable
Use `/shutdown` instead of GitHub's Cancel button for a clean stop

## Recovery and delivery tracking

Queued and interrupted downloads are recovered from saved state
Each confirmed media batch is recorded before the next batch starts
If Telegram times out or the bot stops during an upload, it cannot know for certain whether that upload arrived, the job is marked uncertain and is not automatically resent
The bot asks you to check the chat before sending that link again
This avoids blindly duplicating albums, Telegram does not provide an idempotency key for these sends

## Groups

To detect ordinary links in group chats, use BotFather's `/setprivacy` to disable privacy mode for this bot, then remove and re-add it to the group if needed
Grant the bot permission to send messages and media
The queue is per user across chats, forum-topic replies stay in the originating topic

## Optional cookies

Use a Netscape-format cookie file exported from a TikTok session you control
These saved cookies are used only inside the temporary Chromium fallback for direct sound links. Short-link resolution, video/photo downloads, automatic and manual post audio, and normal sound-page/detail requests do not load them. Cookies are not copied from Chromium into the HTTP audio or cover downloader.
Encode it locally, for example in PowerShell:

```powershell
[Convert]::ToBase64String([IO.File]::ReadAllBytes('C:\path\cookies.txt')) | Set-Clipboard
```

Paste that value into `TIKTOK_COOKIES_BASE64`, then use `/restart`
Secrets are loaded at session startup, editing a GitHub secret does not update an already-running process
A 403 does not prove cookies expired, it can also mean TikTok blocked the runner, the bot's owner message reflects that distinction

## Local execution

Requires Python 3.12 or newer on Linux, the hosting runner is Linux
Install neofetch to use `/specs` locally, for example `sudo apt-get install neofetch`; the workflow already installs and caches it.
Install FFmpeg and ffprobe with libx264, AAC, zscale and tonemap support, for example `sudo apt-get install ffmpeg` on Ubuntu.
Set the required bot environment variables, then:

```bash
python -m pip install --upgrade -r requirements.txt
python bot.py
```

R2 is required by the GitHub workflow, direct local execution does not automatically invoke the backup and dispatch helpers
For local runs, the restart/shutdown choices stop the process cleanly. Use a process manager or start the script again yourself; automatic session dispatch and ZIP reimport are handled by the GitHub workflow.

## aiogram migration

This release replaces `python-telegram-bot` with aiogram 3.31.0 for polling, commands, settings buttons, media uploads, broadcasts and the ID helper. Existing SQLite queue data, update cursor, languages, audio preferences, confirmed delivery receipts and broadcast records stay compatible. The saved polling cursor still advances only after the incoming request has been handled and admitted to the queue.

Uploads use aiogram's streamed `FSInputFile`, including albums and sound thumbnails. Rate-limit retries and video-to-document fallback reopen the file from its beginning. Network failures, server errors and unreadable upload responses remain unconfirmed and are not automatically resent. Definitive API rejections clear the pending upload intent.

Update both the application ZIP and the workflow, then run with `force_reimport` enabled so the cached source and dependencies are refreshed. Local installs should run `python -m pip install --upgrade -r requirements.txt` before restarting.

## Checks

```bash
python -m pip install pytest pytest-asyncio PyYAML
python -m pytest -q
```

See `VALIDATION.md` for the checks actually performed on this package

## References

- [gallery-dl configuration](https://gdl-org.github.io/docs/configuration.html)
- [Telegram Bot API](https://core.telegram.org/bots/api)
- [aiogram documentation](https://docs.aiogram.dev/en/latest/)
- [GitHub Actions limits](https://docs.github.com/en/actions/reference/limits)


## Languages and commands

First-time users choose English, Spanish, Arabic, Russian, Chinese, Persian (فارسی), Japanese (日本語), Portuguese (Português), French (Français) or German (Deutsch) using buttons before sending links. The selected language is saved in the queue database and can be changed through `/settings` → **Language**. The language menus show two choices per row. Settings, help, download messages and owner controls are translated. If a link was sent before choosing a language, send it again after selection.

/start only asks for a TikTok video or photo link. /help contains usage and commands, with owner commands included only for OWNER_ID. /ping reports the Telegram send-message round-trip time in milliseconds, excluding local pacing delays.


## Captions and media replies

When a TikTok caption is too long for the media caption, the bot keeps a shortened preview. **Full caption** in `/settings` controls the complete text:

- **On** automatically sends it as a text file replying to the first delivered video/photo.
- **Off** (default) adds one ordinary reply containing only the linked @TikTokdownloaderbestbot and a **Send full caption as text file** button, matching the album audio button reply.
- **Off with no button** sends neither the text file nor its button.

These choices apply to videos, single photos, albums and document fallbacks. Short captions produce no extra file or button. Only the original requester can use a caption button. The file is named `{numeric-post-id}.txt` and contains the complete original TikTok caption as UTF-8 text, including line breaks, hashtags and emojis. Short links use the resolved numeric ID. The file replies to the first delivered media in the same chat/topic, with only the linked bot attribution as its caption. Each job retains the choice saved when its download starts. Saved text, bindings and receipts survive restarts and database backups; clicking does not contact TikTok or retain downloaded media. Automatic sends skip confirmed receipts, retry definitive failures after restart, and leave unconfirmed uploads pending. Pending button replies are repaired after restart without resending confirmed media. Manual requests follow the 100-second cooldown described below.

Every bot-generated @TikTokdownloaderbestbot attribution is an HTML hyperlink to `https://t.me/TikTokdownloaderbestbot?start=welcome_hehehehaw==`, while displaying the same username. This applies to post captions, continuation photo batches, audio, subtitles, caption text files, and album/caption button replies. Button reply messages disable link previews. Caption limits count visible text rather than HTML markup or the hidden URL.

Downloaded videos and the first photo batch reply to the message containing the TikTok link in the same chat/topic, including document fallbacks. Additional photo batches reply to the previous batch. If a reply target has been deleted while the download is queued, the media can still be sent without a reply. Audio accompanying a post continues to reply to the first delivered video/photo, and direct sound-link audio replies to the link message.

Videos and photo posts receive TikTok's supplied sound track automatically when Audio is On, as an audio reply to the first delivered media message, once per album. When Audio is Off, videos and single photos carry an **Extract audio** button directly. Albums receive one short reply to the first photo with only @TikTokdownloaderbestbot and the **Extract audio** button. The audio caption is only @TikTokdownloaderbestbot. Videos and the first photo batch keep the post caption; additional photo batches have only @TikTokdownloaderbestbot.

The audio filename uses the sound title when available, falling back to the TikTok post ID. Available title, artist, album, cover art, duration metadata, sound ID, post ID and source link are written into the MP3/M4A file with Mutagen. Telegram also receives the title, artist, duration and JPEG thumbnail. Missing metadata is omitted, the title falls back to the post ID. Separate sound files do not use FFmpeg and their audio stream is not re-encoded. TikTok's separate sound track can differ from the video's complete mixed audio.

If TikTok supplies no usable sound URL or audio format, the video/photos still arrive with an audio-unavailable notice. Audio above the selected API upload limit (2 GBs locally), including added tags, is skipped with a size notice. Temporary audio and cover files are deleted with the request's other files. Saved delivery receipts prevent resending confirmed media/audio after restart, and an additive database migration preserves the existing queue and language choices.

To deploy, replace the ZIP hosted at APP_ZIP_URL and start a session with force_reimport enabled. The workflow installs Mutagen from the updated requirements automatically.

Cover art is embedded at its original resolution, preferring TikTok coverLarge. JPEG and PNG artwork is embedded byte-for-byte, other supported image formats are converted losslessly to PNG without resizing. A separate JPEG thumbnail, at most 320 × 320 and under 200 KB, is generated only for Telegram. The selected API upload limit still applies after embedding the full cover.

### Sound links and settings

Send a TikTok `/music/...` link or a `vt.tiktok.com` / `vm.tiktok.com` share link that redirects to a sound page. The bot sends the sound as a reply to your link, with its title, artist and full-resolution embedded cover when available, plus a separate Telegram preview thumbnail. The sound ID is the filename fallback when no title is available. The selected API upload limit still applies (2 GBs locally). Sound-page support uses gallery-dl's TikTok session and page-data parser with a local adapter; access depends on TikTok exposing playable sound data. No video search or bulk download is performed.

`/settings` opens buttons for **Language**, **Audio**, **Compression**, **Subtitles** and **Full caption**. Language opens the ten language buttons. Audio controls sound replies for **videos and photos**, defaulting to **On**. Audio, Subtitles and Full caption have **On**, **Off** and **Off with no button** choices. On automatically sends the corresponding files; Off skips the automatic download and offers its request button; Off with no button skips the automatic download and hides that button. Subtitles defaults to Off with no button; Full caption defaults to Off. Caption files are offered only when the complete text exceeds the media caption limit. The main settings page shows the full selected choice, and the selected option has a checkmark. **Back** returns to settings. Each user's preference persists and is saved when a download starts, including whether to show buttons, so retries and recovery retain the same choices. Direct sound links always send audio. Buttons can only change the settings of the user who opened them.

The original requester can click **Extract audio** to enqueue the video or photo post's TikTok sound. It uses the selected per-user active limit and the same regular/secondary queues described above, replies to the first delivered video/photo in the same chat/topic, and downloads only the sound and cover art. Button mappings and pending audio jobs survive restarts and database backups, without retaining downloaded media files. Album button replies have separate saved delivery intent and message IDs. Rejected sends or sends interrupted before reaching Telegram can be retried without resending confirmed photos. An unconfirmed send is not automatically duplicated; clicking its correctly routed button confirms the saved binding. A delivery failure keeps a status notice visible. On upgrade, older album photo bindings are migrated to pending button replies and repaired at startup, including completed jobs. The button uses the same separate TikTok sound track and metadata pipeline as automatic replies, which can differ from the video's full mixed audio. TikTok must still make that post and its sound available when the button is pressed.

**Extract audio**, **Extract subtitles** and **Send full caption as text file** each have a separate **100-second cooldown per original button**. The timer starts when a request is accepted, including a queued request. Extra taps show the remaining time as minutes:seconds and do not extend the timer or start duplicate work. Once 1 minute 40 seconds have elapsed, a new tap can request the files again; it has its own identity and delivery receipts. Caption files use the saved text, while audio/subtitles are fetched from TikTok again. Cooldowns survive restarts and backups. Settings, navigation and language buttons remain immediately usable. Invalid or unauthorized clicks and shutdown rejections do not start timers. An accepted request keeps its cooldown even if delivery fails or is cancelled. Older audio/subtitle requests use their saved admission timestamps; older caption receipts without timestamps get one 100-second timer when upgraded. Recovery never automatically repeats an unconfirmed upload, but an eligible new tap after the cooldown explicitly requests a new send.

After replacing your hosted ZIP, run the workflow with `force_reimport` enabled to load this update. Existing database preferences and queued requests are retained.

### Subtitle files

**Subtitles** defaults to **Off with no button**, so new users receive neither automatic subtitle files nor an extraction button. Saved user choices and existing job snapshots are retained. When On, the bot downloads all available TikTok video subtitle tracks, including automatic captions, creator captions and translations. Each original file is uploaded separately as a document replying to the delivered video in the same chat/topic, with only `@TikTokdownloaderbestbot` as its caption. This also works when the video is delivered as a document. Filenames include the post ID, language, caption source and version, retaining the supplied format such as VTT, SRT or creator-caption JSON.

When Subtitles is **Off**, videos have an **Extract subtitles** button. When Audio is also **Off**, **Extract audio** and **Extract subtitles** appear side by side in one row on the video, including document fallbacks. **Off with no button** removes the corresponding button from new deliveries. Photos never offer subtitle extraction.

The original requester can use **Extract subtitles** later to queue only the available subtitle files. The video, photos, audio and cover art are not downloaded again, and no converter or browser starts for subtitle extraction. Files reply to the original delivered video in the same chat/topic with only `@TikTokdownloaderbestbot` as their caption. Audio and subtitle clicks create independent requests, with separate cooldowns and delivery receipts. Each uses the existing queue limits and survives restarts/backups. TikTok must still expose the video and its tracks when the button is pressed. If there are no available tracks, the bot reports that no subtitle files are available.

Videos without available tracks are sent normally. A failed or oversized subtitle download does not prevent the video or other available tracks from arriving. The selected API upload limit (2 GBs locally) applies to each subtitle file, and incomplete files are removed. Photo posts and manual audio extraction do not download subtitles. A manual subtitle request that cannot fetch any track shows an unavailable or size error. Delivery receipts skip confirmed files after restart; an upload with no acknowledgement is left uncertain rather than automatically repeated. Upgrading the request uniqueness constraint preserves existing job IDs, queue records, preferences and receipts while allowing separate audio and subtitle requests from the same video.


### Sound-download diagnostics

The workflow prints sanitized `Download diagnostic` lines for URL resolution, sound-page extraction, the sound-detail fallback, audio download, file format, and tagging. Cookie-file configuration and loading are checked only when Chromium starts. HTTP status codes and exception class names are included when available. Cookies, response bodies, signed media URLs, and exception messages are not logged. An empty sound-detail response or missing playable URL is reported separately from a failed audio download. Cookie presence does not establish that the login is valid.

Sound extraction accepts string and URL-list audio addresses and tries TikTok's music-detail endpoint if the page lacks playable metadata for the requested sound ID. These requests and short-link resolution use anonymous sessions without the configured cookie file. No alternative sound is substituted if the requested ID cannot be found. These changes improve extraction and diagnostics but cannot guarantee availability when TikTok returns no sound data.


### Chromium fallback for direct sound links

When normal sound-page and detail extraction provide no playable URL, the worker launches headless Chromium with Playwright. Only at this point does it read the configured cookie file and import unexpired TikTok cookies into an isolated context. A missing or unreadable cookie file is reported without exposing its contents, and the browser can still try anonymously. It allows the page's JavaScript to run and checks page data and music API responses for the requested sound ID. It can also request the detail endpoint through the page, using TikTok's own signing SDK when available. The browser closes after the attempt; its temporary session is not saved or copied into gallery-dl. Matching audio uses the existing metadata, cover-art, thumbnail and bounded download pipeline without the saved login cookies.

Only direct sound links use this fallback. Video/photo posts, manual video sound requests, and automatic audio replies continue through gallery-dl. The fallback runs one browser at a time with bounded waiting and extraction time. If TikTok still supplies no playable sound, the bot returns a specific message instead of repeating the same full attempt three times.

Update **both** your hosted application ZIP and `.github/workflows/tik.yml`, then run with `force_reimport` enabled. The standalone `tik.yml` still needs no application files committed to the repository. The workflow installs Chromium and its system dependencies, caching browser binaries in `~/.cache/ms-playwright`; no cookies, browser profiles, or downloaded media are cached there. The browser cache key follows the installed Playwright version, runner OS and architecture, so a Playwright update gets a matching browser cache. Existing queue, settings and R2 backup behavior are preserved.

Local runs also need `python -m playwright install --with-deps --no-shell chromium`. TikTok may still refuse automated access, so the fallback is not a guarantee of sound availability.

### Owner broadcast command

In your **private chat with the bot**, send or forward the announcement, then reply to that message with `/broadcast`. Only `OWNER_ID` can use this command. The bot copies the selected message as a preview, shows the number of recipient chats, and offers **Send** and **Cancel** buttons. Nothing is sent to the audience until you select Send. Text, supported media, captions, and Telegram formatting are preserved by copying the preview; an album reply selects that individual message only. Unsupported messages produce an error before confirmation.

Each broadcast uses a snapshot of known active private chats and groups, including the owner's private chat if registered. Existing chat IDs are imported from the saved download history. New chats are recorded on messages and bot membership updates. Telegram does not supply a list of every past user/group, so older chats absent from the database must interact with the bot once to register. Users who only interacted in a group are not automatically messaged privately. Removed/blocked chats are deactivated and can be registered again after they return.

Delivery is paced alongside downloads. Receipts and the audience survive cached database/R2 restores. Confirmed sends are not repeated; interrupted or unconfirmed sends are reported as Unconfirmed instead of being retried blindly. A summary lists sent, failed/skipped, and unconfirmed recipients. Keep the bot's preview message until sending finishes. The owner interface supports all ten languages; the announcement itself is sent exactly as previewed.

Replace the hosted ZIP and run with `force_reimport` enabled. The Chromium-enabled workflow from the previous update does not need another change for this feature.


### Video compression

Open `/settings` → **Compression**:

| Mode | Behavior |
|---|---|
| **All videos** (default) | Try compression for every video, including videos already under 50 MB |
| **Over 50 MB** | Keep videos at or below 50 MB unchanged, compress larger videos |
| **None** | Keep originals up to the selected API upload cap, 2 GBs in this workflow |

**Advanced** offers these saved per-user choices. Its button shows `✓` when compression is enabled and any advanced value differs from its default. Selecting **None** hides the Advanced checkmark while keeping those values, so it returns when compression is enabled again. Resetting or restoring every default clears the mark:

| Option | Choices | Default |
|---|---|---|
| Maximum frame rate | Original, 24, 30, 60 fps | Original |
| Maximum resolution | Original, 1080p, 720p, 480p | 1080p |
| Quality | High quality, Balanced, Smaller files | Balanced |
| Encoding speed | Fast, Medium, Slow | Fast |
| Video audio bitrate | 64, 96, 128, 192 kbps | 128 kbps |

Frame rate caps only lower a higher source rate, they do not turn a 30 fps clip into 60 fps. Original preserves the source frame timestamps, including variable frame rates. Resolution caps preserve aspect ratio and never enlarge the source; portrait 1080p is bounded by 1080×1920. **Reset advanced defaults** resets these five controls while keeping the selected compression mode. The controls apply when the mode selects a video for compression. Photos and separate TikTok sound files keep their existing behavior.

The encoder uses H.264/libx264 video, 8-bit yuv420p, AAC audio and MP4 fast-start metadata. Quality choices use CRF 20/23/28 respectively. At the default advanced settings, an already-efficient compatible original is kept if encoding would make it larger without reducing its dimensions. HDR-tagged PQ/HLG sources are tone-mapped to standard BT.709 output, and rotation metadata is applied during encoding.

If quality-based encoding exceeds the upload limit, two-pass bitrate encoding targets 96% of the selected upload cap from the original download, with a second 88% target if necessary (1920/1760 MB locally, 48/44 MB on the cloud API). Audio bitrate and resolution may be lowered to fit, but the frame rate remains subject to the user's selected cap. The entire video must pass duration, codec and final-size validation before delivery; it is never cut short just to reach the size limit. These size-fitting passes take precedence over the quality preference. If a valid result cannot fit, the bot reports a compression error instead of uploading a partial file.

Two encoders run concurrently at most, with two threads each. Each encoding attempt has a 15-minute total budget after acquiring a slot, workers can wait up to 20 minutes for a slot, and compressed requests have a 40-minute overall worker limit. Input video downloads and output files are capped at 2 GBs in the local workflow; manual cloud runs retain the 1 GB input and 50 MB output caps. Cancel and restart stop the worker and its encoder processes, and temporary media and pass logs are removed. Requests snapshot their compression settings when they start, and delivery receipts use the source media hash to prevent resending a confirmed video after recovery.

Update both your hosted application ZIP and `.github/workflows/tik.yml`, then run with `force_reimport` enabled. The workflow installs and caches the static FFmpeg/ffprobe build, imports the new compression module, and retains the Chromium binary cache and cookie behavior. The local-server workflow additionally requires `TELEGRAM_API_ID` and `TELEGRAM_API_HASH` as described above.

References: [Telegram sendVideo](https://core.telegram.org/bots/api#sendvideo), [FFmpeg libx264](https://ffmpeg.org/ffmpeg-codecs.html#libx264_002c-libx264rgb), [two-pass encoding](https://ffmpeg.org/ffmpeg.html), [MP4 fast-start](https://ffmpeg.org/ffmpeg-formats.html), [HDR tone mapping](https://ffmpeg.org/ffmpeg-filters.html#tonemap).

## Telegram diagnostics and logs

Diagnostics are sent as a text document to `-1004434678187` at the end of each workflow run, instead of GitHub artifacts
While the bot runs, sanitized bot stdout and stderr are uploaded there every hour, followed by any remaining entries when the bot exits
The bot must be allowed to send documents to this chat, upload failures produce a safe warning and do not stop the bot
Failed hourly uploads retain entries for the next upload, with an 8 MiB buffer that discards the oldest entries if necessary
Environment credentials, Telegram token patterns and authorization/cookie headers are redacted, but avoid logging other private information
Logs stay outside application backups and caches, setup logs remain in GitHub Actions
A forcibly terminated runner cannot guarantee a final upload
The standalone workflow embeds the stdlib reporter so diagnostics can still upload when importing the application or installing dependencies fails

Crashes now send a separate **#crash** report to the same chat as soon as the bot process exits, including its exit code, exception type, stack locations, recent sanitized logs and a link to the workflow run
The TelegramConflictError shown in Actions is reported with a hint to stop the other polling instance, automatic continuation stays stopped after a failed session
Runtime warnings and errors send **#warning** or **#error** documents in the background within about five seconds, including failed downloads, unconfirmed uploads, unexpected job failures and background task errors
Repeated errors are grouped with occurrence counts and limited to one notice per matching error every five minutes, pending repeats are included at shutdown
Reports retain a separate bounded recent-log buffer after hourly uploads, so a later crash still includes context
Normal owner shutdowns, restarts and session renewal do not create crash reports
The final workflow reporting step also alerts about failed setup, dependency installation, state restore, backups and continuation steps, even if the bot never started, the failed step IDs and run link identify the setup logs in Actions
An already confirmed crash alert is not repeated by the final step, failed alert uploads leave the fallback available
Tracebacks include exception classes and file/function/line locations without exception strings, source lines, local variables or Telegram method representations
Reports redact configured credentials, token patterns, auth/cookie headers, URL credentials and sensitive query parameters
Both the updated hosted ZIP and workflow are needed, old source caches refresh automatically when crash_reports.py is missing

## Python 3.14 compression compatibility

The bot's video compression module is now `video_compression.py`, avoiding the `compression` standard-library package introduced in Python 3.14
Update the hosted ZIP referenced by `TELE_ZIP` and `.github/workflows/tik.yml` together before rerunning
Both importers automatically refresh cached source containing the old `compression.py` or missing the renamed module, while keeping queue state and settings in the separate state directory
Old hosted ZIPs are rejected with a message requesting the updated ZIP
Python remains on the latest stable release in the supported range, compression settings and encoding behavior are unchanged

## Dependency update notices

At startup the bot compares installed Python packages, including transitive dependencies, Python itself and available FFmpeg/ffprobe/Chromium/neofetch versions against the last saved baseline
The first run establishes that baseline without announcing fresh installs, later version changes detected in the same startup check are grouped into one message to `-1004434678187` in this format

```text
#update

{name}: {old_ver} ➡️ {new_ver}
{another_name}: {old_ver} ➡️ {new_ver}
```

Version-number dots are preserved and the notice is plain Telegram text
If a grouped notice exceeds Telegram’s 4096-character limit, it splits only between complete dependency lines, confirmed groups are not repeated when a failed group retries
Checks and notices run in the background, alongside downloading and polling
All lines in a confirmed notice update the baseline together, failed notices retain the old versions for a later session, unavailable tools do not produce version-change messages
The baseline lives in the existing SQLite state and follows queue caches, owner backups and R2 restores
Replace the hosted ZIP and workflow together, old cached applications missing `dependency_updates.py` automatically reimport the hosted ZIP
Compression remains **All videos** by default, saved choices and advanced compression behavior are unchanged

## Full post metadata

Settings includes **Metadata** with **On**, **Off** and **Off with no button**, the default is **Off with no button**
**Format** inside Metadata offers **JSON**, **XML** and **TXT**, defaulting to JSON
On automatically replies to the delivered video or first message of the photo album with the metadata document
Off adds a bot-name reply with **Send full metadata**, Off with no button neither retains an export nor offers a button
Each document has only the linked bot attribution as its caption

Metadata contains the full available TikTok post object exposed by gallery-dl, including nested author, statistics, music, video and photo fields when provided
It is captured during the existing anonymous extraction, before gallery-dl changes its per-file fields, without another TikTok request
JSON preserves nested structure and Unicode, XML uses typed fields and indexed items, TXT uses indented field/value entries
Gallery-dl dates are serialized as ISO strings, no request headers, browser cookies, credentials or bot diagnostics are included
Sound links and audio/subtitle-only extraction requests do not produce metadata documents

Filenames are `{numeric-id}.metadata.json`, `{numeric-id}.metadata.xml` or `{numeric-id}.metadata.txt`
Full caption files remain `{numeric-id}.txt`, both can be enabled together and keep independent delivery receipts and button cooldowns
The request button belongs to the original requester and chat/topic, with the existing 100-second cooldown
Metadata and selected preferences are retained in the backed-up SQLite state, so buttons work after restart without redownloading the post
The full JSON snapshot is compressed in SQLite, exported files retain the selected API upload cap (2 GBs locally)
An unconfirmed automatic upload is not blindly repeated, definitive rejections can retry after restart
Replace the hosted ZIP and workflow together, older application caches lacking the new metadata helpers automatically reimport the ZIP
