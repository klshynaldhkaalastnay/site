# TikTok Telegram Bot

Send TikTok links directly to download videos and photo posts with gallery-dl. Telegram uses aiogram 3.31.0.
There is no `/download` command or yt-dlp dependency. FFmpeg and ffprobe handle optional video compression.

## Quick setup

1. Create a Telegram bot through [BotFather](https://t.me/BotFather) with `/newbot`, keep its token private
2. Create a GitHub repository and upload this ZIP's contents into its root, including `.github/workflows/tik.yml`, use a private repository because saved queue state includes Telegram chat and user IDs
3. Obtain your numeric Telegram ID and the numeric ID of `@Tog991`: install this ZIP's dependencies with `python -m pip install -r requirements.txt`, run `python identify.py` locally, paste the token at its hidden prompt, and send `/id` to your bot from each account. Match the displayed username to `Tog991` and stop the helper before starting the workflow
4. Add the configuration below through repository Settings → Secrets and variables → Actions
5. Open the bot in a private chat from the owner account and send `/start`, this lets it send owner notifications
6. Go to Actions → TikTok Telegram Bot → Run workflow, leave `continue` enabled for automatic session renewal
7. Send a public TikTok video or photo post link to the bot

Upload the project contents, not a ZIP file, to the repository
GitHub only discovers the workflow when `.github/workflows/tik.yml` is committed, put it on the default branch first

## Configuration

| Name | Location | Value |
|---|---|---|
| `TELEGRAM_BOT_TOKEN` | Secret | Token from BotFather |
| `OWNER_ID` | Variable or secret | Owner's numeric Telegram user ID, not the Discord owner ID |
| `QUEUE_BYPASS_USER_ID` | Variable or secret | Numeric Telegram ID verified as belonging to `@Tog991` |
| `R2_ACCOUNT_ID` | Variable or secret | Cloudflare account ID |
| `R2_ACCESS_KEY_ID` | Secret | R2 S3 access key |
| `R2_SECRET_ACCESS_KEY` | Secret | R2 S3 secret key |
| `R2_BUCKET_NAME` | Variable or secret | Existing R2 bucket with read, write, list, and delete access |
| `TIKTOK_COOKIES_BASE64` | Optional secret | Base64-encoded Netscape TikTok cookies file for the Chromium sound fallback only |
| `APP_ZIP_URL` | Optional secret | Direct HTTPS link to a trusted project ZIP |

No GitHub personal access token is needed, the workflow uses its automatic `GITHUB_TOKEN` with `actions: write` for its own cache management and workflow dispatch
Repository or organization policies must allow the workflow actions and dispatch

The queue exemption uses a numeric ID, it never grants rights to somebody merely because they adopt a matching username
If `QUEUE_BYPASS_USER_ID` is missing, everyone uses the normal limits until you set it and restart
Exemption does not grant owner commands, `OWNER_ID` controls those separately

## Queue behavior

- Each normal user has 4 active or reserved slots and 4 waiting slots
- Additional links are rejected with a message identifying them
- Multiple links in one message are accepted up to the available capacity
- One TikTok post counts as one request, including posts with many photos
- `@Tog991` has a separate single download slot with no four-request backlog limit, other users do not occupy that slot, its own requests run in order
- Slots cover downloading and Telegram delivery, Telegram's own message limits still apply
- Queue positions are shown on admission, `/queue` shows current states
- There is no fixed global four-download cap, each user's slots are separate, size and timeout checks keep individual jobs bounded

## Media behavior

Videos are sent as playable MP4 files when available, other supported video formats are sent as documents
Photos are sent in groups of up to 10, a final single photo is sent individually
The first photo batch replies to the link message with the post caption. Each additional batch replies to the previous batch with only `@TikTokdownloaderbestbot` as its caption, including a final single photo. This also applies to photos sent as documents, and the reply target is saved across restarts.
Images that exceed Telegram's photo constraints or use unsupported photo formats are sent as original documents instead
Telegram may recompress photos displayed as photos, the bot itself does not re-encode them

The Telegram upload limit is **50,000,000 bytes per file**, 50 decimal MB. With Compression set to None, original downloads are checked both from the HTTP header and while streaming. Oversized videos retain the existing error:

> This video is too large, the maximum size is 50 MB

With video compression enabled, videos can be downloaded up to 1 GB for processing and are reduced to fit the 50 MB upload limit when possible. Photos and separate sound files retain their existing size limits. There is no R2 media upload, expiring media link, or fallback to yt-dlp.
Completed, cancelled, and failed downloads are deleted from the runner
Only single video/photo posts are accepted, profile and collection downloads are not enabled
Videos and photos receive their available soundtrack when Audio is On; Off shows an Extract audio button instead

## Commands

| Command | Access | Purpose |
|---|---|---|
| `/start`, `/help` | Everyone | Usage instructions |
| `/queue` | Everyone | List your active and waiting jobs |
| `/cancel <number>` | Requester or owner | Cancel a job |
| `/ping` | Everyone | Check responsiveness |
| `/id` | Everyone | Show your numeric Telegram ID |
| `/settings` | Everyone | Language, audio, compression and subtitle preferences |
| `/jobs` | Owner | List all outstanding jobs |
| `/restart` | Owner | Save, back up, and start a fresh workflow session |
| `/upload` | Owner | Save, back up, and start a fresh workflow session |
| `/shutdown` | Owner | Save, back up, and stop without another session |

`/restart` and `/upload` both force one replacement session even if `continue` was disabled, the replacement preserves your selected `continue` setting
`/shutdown` overrides continuation, start again manually from GitHub Actions
A cancellation cannot withdraw an upload Telegram has already accepted

## Hosting and backups

The workflow uses actions from `@main`, with Python 3.12 and a 5-hour-30-minute bot session inside a 355-minute job
Python package versions for gallery-dl, aiogram and Playwright are pinned to the versions checked for this release, `@main` applies to GitHub actions

FFmpeg and ffprobe use the yt-dlp static Linux GPL build, installed in `~/.ffmpeg` and added to PATH. The workflow restores this directory before installation, downloads the archive only when either executable is missing, checks the required encoders and HDR filters, then saves a new cache immediately. Later sessions reuse that build. The cache is separate from pip and Chromium and is keyed by runner OS, architecture and build variant. To fetch a newer build, delete its FFmpeg cache in GitHub Actions or change the cache key suffix from `v1` to `v2`.

After a clean stop it:

1. Validates saved state
2. Creates a ZIP containing a consistent SQLite snapshot and allowed project source files
3. Uploads it to a dedicated `tiktok-bot-backups/` scope in R2
4. Reads the upload back and verifies SHA-256 and size
5. Deletes older backups only in that same workflow scope
6. Saves and verifies the GitHub cache, retaining one previous cache
7. Dispatches the next session if requested

Cookies, tokens, downloaded media, and raw request logs are excluded from backups and diagnostics
R2 backups restore automatically when the state cache is absent
The source ZIP is optional, by default the bot uses the checked-out repository files
With `APP_ZIP_URL`, source is cached under `app`, `force_reimport` imports an updated ZIP while retaining the separate queue database
Keep the repository workflow and helper files updated too, importing a ZIP does not rewrite the committed workflow

Only one workflow session runs at a time, there is a handover gap while GitHub allocates the next runner
Failed runs or failed backups do not automatically continue, inspect the sanitized workflow output before restarting
A manual force-cancel or runner crash can lose changes since the last completed session backup, the local SQLite writes do not make an ephemeral runner durable
Use `/shutdown` instead of GitHub's Cancel button for a clean stop

## Recovery and delivery tracking

Queued and interrupted downloads are recovered from saved state
Each confirmed media batch is recorded before the next batch starts
If Telegram times out or the bot stops during an upload, it cannot know for certain whether that upload arrived, the job is marked uncertain and is not automatically resent
The bot asks you to check the chat before sending that link again
This avoids blindly duplicating albums, Telegram does not provide an idempotency key for these sends

## Groups

To detect ordinary links in group chats, use BotFather's `/setprivacy` to disable privacy mode for this bot, then remove and re-add it to the group if needed
Grant the bot permission to send messages and media
The queue is per user across chats, forum-topic replies stay in the originating topic

## Optional cookies

Use a Netscape-format cookie file exported from a TikTok session you control
These saved cookies are used only inside the temporary Chromium fallback for direct sound links. Short-link resolution, video/photo downloads, automatic and manual post audio, and normal sound-page/detail requests do not load them. Cookies are not copied from Chromium into the HTTP audio or cover downloader.
Encode it locally, for example in PowerShell:

```powershell
[Convert]::ToBase64String([IO.File]::ReadAllBytes('C:\path\cookies.txt')) | Set-Clipboard
```

Paste that value into `TIKTOK_COOKIES_BASE64`, then use `/restart`
Secrets are loaded at session startup, editing a GitHub secret does not update an already-running process
A 403 does not prove cookies expired, it can also mean TikTok blocked the runner, the bot's owner message reflects that distinction

## Local execution

Requires Python 3.12 or newer on Linux, the hosting runner is Linux
Install FFmpeg and ffprobe with libx264, AAC, zscale and tonemap support, for example `sudo apt-get install ffmpeg` on Ubuntu.
Set the required bot environment variables, then:

```bash
python -m pip install -r requirements.txt
python bot.py
```

R2 is required by the GitHub workflow, direct local execution does not automatically invoke the backup and dispatch helpers
Local `/restart` and `/upload` stop cleanly, use a process manager or start the script again yourself

## aiogram migration

This release replaces `python-telegram-bot` with aiogram 3.31.0 for polling, commands, settings buttons, media uploads, broadcasts and the ID helper. Existing SQLite queue data, update cursor, languages, audio preferences, confirmed delivery receipts and broadcast records stay compatible. The saved polling cursor still advances only after the incoming request has been handled and admitted to the queue.

Uploads use aiogram's streamed `FSInputFile`, including albums and sound thumbnails. Rate-limit retries and video-to-document fallback reopen the file from its beginning. Network failures, server errors and unreadable upload responses remain unconfirmed and are not automatically resent. Definitive API rejections clear the pending upload intent.

Update both the application ZIP and the workflow, then run with `force_reimport` enabled so the cached source and dependencies are refreshed. Local installs should run `python -m pip install -r requirements.txt` before restarting.

## Checks

```bash
python -m pip install pytest pytest-asyncio PyYAML
python -m pytest -q
```

See `VALIDATION.md` for the checks actually performed on this package

## References

- [gallery-dl configuration](https://gdl-org.github.io/docs/configuration.html)
- [Telegram Bot API](https://core.telegram.org/bots/api)
- [aiogram documentation](https://docs.aiogram.dev/en/latest/)
- [GitHub Actions limits](https://docs.github.com/en/actions/reference/limits)


## Languages and commands

First-time users choose English, Spanish, Arabic, Russian, Chinese or Persian (فارسی) using buttons before sending links. The selected language is saved in the queue database and can be changed through `/settings` → **Language**. If a link was sent before choosing a language, send it again after selection.

/start only asks for a TikTok video or photo link. /help contains usage and commands, with owner commands included only for OWNER_ID. /ping reports the Telegram send-message round-trip time in milliseconds, excluding local pacing delays.


## Captions and media replies

When a TikTok caption is too long for the media caption, the bot keeps a shortened preview. **Full caption** in `/settings` controls the complete text:

- **On** automatically sends it as a text file replying to the first delivered video/photo.
- **Off** (default) adds one ordinary reply containing only the linked @TikTokdownloaderbestbot and a **Send full caption as text file** button, matching the album audio button reply.
- **Off with no button** sends neither the text file nor its button.

These choices apply to videos, single photos, albums and document fallbacks. Short captions produce no extra file or button. Only the original requester can use a caption button. The file is named `{numeric-post-id}.txt` and contains the complete original TikTok caption as UTF-8 text, including line breaks, hashtags and emojis. Short links use the resolved numeric ID. The file replies to the first delivered media in the same chat/topic, with only the linked bot attribution as its caption. Each job retains the choice saved when its download starts. Saved text, bindings and receipts survive restarts and database backups; clicking does not contact TikTok or retain downloaded media. Automatic sends skip confirmed receipts, retry definitive failures after restart, and leave unconfirmed uploads pending. Pending button replies are repaired after restart without resending confirmed media. Manual requests follow the 100-second cooldown described below.

Every bot-generated @TikTokdownloaderbestbot attribution is an HTML hyperlink to `https://t.me/TikTokdownloaderbestbot?start=welcome_hehehehaw==`, while displaying the same username. This applies to post captions, continuation photo batches, audio, subtitles, caption text files, and album/caption button replies. Button reply messages disable link previews. Caption limits count visible text rather than HTML markup or the hidden URL.

Downloaded videos and the first photo batch reply to the message containing the TikTok link in the same chat/topic, including document fallbacks. Additional photo batches reply to the previous batch. If a reply target has been deleted while the download is queued, the media can still be sent without a reply. Audio accompanying a post continues to reply to the first delivered video/photo, and direct sound-link audio replies to the link message.

Videos and photo posts receive TikTok's supplied sound track automatically when Audio is On, as an audio reply to the first delivered media message, once per album. When Audio is Off, videos and single photos carry an **Extract audio** button directly. Albums receive one short reply to the first photo with only @TikTokdownloaderbestbot and the **Extract audio** button. The audio caption is only @TikTokdownloaderbestbot. Videos and the first photo batch keep the post caption; additional photo batches have only @TikTokdownloaderbestbot.

The audio filename uses the sound title when available, falling back to the TikTok post ID. Available title, artist, album, cover art, duration metadata, sound ID, post ID and source link are written into the MP3/M4A file with Mutagen. Telegram also receives the title, artist, duration and JPEG thumbnail. Missing metadata is omitted, the title falls back to the post ID. Separate sound files do not use FFmpeg and their audio stream is not re-encoded. TikTok's separate sound track can differ from the video's complete mixed audio.

If TikTok supplies no usable sound URL or audio format, the video/photos still arrive with an audio-unavailable notice. Audio above 50 MB, including added tags, is skipped with a size notice. Temporary audio and cover files are deleted with the request's other files. Saved delivery receipts prevent resending confirmed media/audio after restart, and an additive database migration preserves the existing queue and language choices.

To deploy, replace the ZIP hosted at APP_ZIP_URL and start a session with force_reimport enabled. The workflow installs Mutagen from the updated requirements automatically.

Cover art is embedded at its original resolution, preferring TikTok coverLarge. JPEG and PNG artwork is embedded byte-for-byte, other supported image formats are converted losslessly to PNG without resizing. A separate JPEG thumbnail, at most 320 × 320 and under 200 KB, is generated only for Telegram. The 50 MB audio limit still applies after embedding the full cover.

### Sound links and settings

Send a TikTok `/music/...` link or a `vt.tiktok.com` / `vm.tiktok.com` share link that redirects to a sound page. The bot sends the sound as a reply to your link, with its title, artist and full-resolution embedded cover when available, plus a separate Telegram preview thumbnail. The sound ID is the filename fallback when no title is available. The 50 MB limit still applies. Sound-page support uses gallery-dl's TikTok session and page-data parser with a local adapter; access depends on TikTok exposing playable sound data. No video search or bulk download is performed.

`/settings` opens buttons for **Language**, **Audio**, **Compression**, **Subtitles** and **Full caption**. Language opens the six language buttons. Audio controls sound replies for **videos and photos**, defaulting to **On**. Audio, Subtitles and Full caption have **On**, **Off** and **Off with no button** choices. On automatically sends the corresponding files; Off skips the automatic download and offers its request button; Off with no button skips the automatic download and hides that button. Subtitles defaults to Off with no button; Full caption defaults to Off. Caption files are offered only when the complete text exceeds the media caption limit. The main settings page shows the full selected choice, and the selected option has a checkmark. **Back** returns to settings. Each user's preference persists and is saved when a download starts, including whether to show buttons, so retries and recovery retain the same choices. Direct sound links always send audio. Buttons can only change the settings of the user who opened them.

The original requester can click **Extract audio** to enqueue the video or photo post's TikTok sound. It uses the existing four active/four waiting limits and exempt-user lane, replies to the first delivered video/photo in the same chat/topic, and downloads only the sound and cover art. Button mappings and pending audio jobs survive restarts and database backups, without retaining downloaded media files. Album button replies have separate saved delivery intent and message IDs. Rejected sends or sends interrupted before reaching Telegram can be retried without resending confirmed photos. An unconfirmed send is not automatically duplicated; clicking its correctly routed button confirms the saved binding. A delivery failure keeps a status notice visible. On upgrade, older album photo bindings are migrated to pending button replies and repaired at startup, including completed jobs. The button uses the same separate TikTok sound track and metadata pipeline as automatic replies, which can differ from the video's full mixed audio. TikTok must still make that post and its sound available when the button is pressed.

**Extract audio**, **Extract subtitles** and **Send full caption as text file** each have a separate **100-second cooldown per original button**. The timer starts when a request is accepted, including a queued request. Extra taps show the remaining time as minutes:seconds and do not extend the timer or start duplicate work. Once 1 minute 40 seconds have elapsed, a new tap can request the files again; it has its own identity and delivery receipts. Caption files use the saved text, while audio/subtitles are fetched from TikTok again. Cooldowns survive restarts and backups. Settings, navigation and language buttons remain immediately usable. Invalid or unauthorized clicks, a full download queue, and shutdown rejections do not start timers. An accepted request keeps its cooldown even if delivery fails or is cancelled. Older audio/subtitle requests use their saved admission timestamps; older caption receipts without timestamps get one 100-second timer when upgraded. Recovery never automatically repeats an unconfirmed upload, but an eligible new tap after the cooldown explicitly requests a new send.

After replacing your hosted ZIP, run the workflow with `force_reimport` enabled to load this update. Existing database preferences and queued requests are retained.

### Subtitle files

**Subtitles** defaults to **Off with no button**, so new users receive neither automatic subtitle files nor an extraction button. Saved user choices and existing job snapshots are retained. When On, the bot downloads all available TikTok video subtitle tracks, including automatic captions, creator captions and translations. Each original file is uploaded separately as a document replying to the delivered video in the same chat/topic, with only `@TikTokdownloaderbestbot` as its caption. This also works when the video is delivered as a document. Filenames include the post ID, language, caption source and version, retaining the supplied format such as VTT, SRT or creator-caption JSON.

When Subtitles is **Off**, videos have an **Extract subtitles** button. When Audio is also **Off**, **Extract audio** and **Extract subtitles** appear side by side in one row on the video, including document fallbacks. **Off with no button** removes the corresponding button from new deliveries. Photos never offer subtitle extraction.

The original requester can use **Extract subtitles** later to queue only the available subtitle files. The video, photos, audio and cover art are not downloaded again, and no converter or browser starts for subtitle extraction. Files reply to the original delivered video in the same chat/topic with only `@TikTokdownloaderbestbot` as their caption. Audio and subtitle clicks create independent requests, with separate cooldowns and delivery receipts. Each uses the existing queue limits and survives restarts/backups. TikTok must still expose the video and its tracks when the button is pressed. If there are no available tracks, the bot reports that no subtitle files are available.

Videos without available tracks are sent normally. A failed or oversized subtitle download does not prevent the video or other available tracks from arriving. The 50 MB limit applies to each subtitle file, and incomplete files are removed. Photo posts and manual audio extraction do not download subtitles. A manual subtitle request that cannot fetch any track shows an unavailable or size error. Delivery receipts skip confirmed files after restart; an upload with no acknowledgement is left uncertain rather than automatically repeated. Upgrading the request uniqueness constraint preserves existing job IDs, queue records, preferences and receipts while allowing separate audio and subtitle requests from the same video.


### Sound-download diagnostics

The workflow prints sanitized `Download diagnostic` lines for URL resolution, sound-page extraction, the sound-detail fallback, audio download, file format, and tagging. Cookie-file configuration and loading are checked only when Chromium starts. HTTP status codes and exception class names are included when available. Cookies, response bodies, signed media URLs, and exception messages are not logged. An empty sound-detail response or missing playable URL is reported separately from a failed audio download. Cookie presence does not establish that the login is valid.

Sound extraction accepts string and URL-list audio addresses and tries TikTok's music-detail endpoint if the page lacks playable metadata for the requested sound ID. These requests and short-link resolution use anonymous sessions without the configured cookie file. No alternative sound is substituted if the requested ID cannot be found. These changes improve extraction and diagnostics but cannot guarantee availability when TikTok returns no sound data.


### Chromium fallback for direct sound links

When normal sound-page and detail extraction provide no playable URL, the worker launches headless Chromium with Playwright. Only at this point does it read the configured cookie file and import unexpired TikTok cookies into an isolated context. A missing or unreadable cookie file is reported without exposing its contents, and the browser can still try anonymously. It allows the page's JavaScript to run and checks page data and music API responses for the requested sound ID. It can also request the detail endpoint through the page, using TikTok's own signing SDK when available. The browser closes after the attempt; its temporary session is not saved or copied into gallery-dl. Matching audio uses the existing metadata, cover-art, thumbnail and bounded download pipeline without the saved login cookies.

Only direct sound links use this fallback. Video/photo posts, manual video sound requests, and automatic audio replies continue through gallery-dl. The fallback runs one browser at a time with bounded waiting and extraction time. If TikTok still supplies no playable sound, the bot returns a specific message instead of repeating the same full attempt three times.

Update **both** your hosted application ZIP and `.github/workflows/tik.yml`, then run with `force_reimport` enabled. The standalone `tik.yml` still needs no application files committed to the repository. The workflow installs Chromium and its system dependencies, caching browser binaries in `~/.cache/ms-playwright`; no cookies, browser profiles, or downloaded media are cached there. A new dependency cache key is used when requirements change. Existing queue, settings and R2 backup behavior are preserved.

Local runs also need `python -m playwright install --with-deps --no-shell chromium`. TikTok may still refuse automated access, so the fallback is not a guarantee of sound availability.

### Owner broadcast command

In your **private chat with the bot**, send or forward the announcement, then reply to that message with `/broadcast`. Only `OWNER_ID` can use this command. The bot copies the selected message as a preview, shows the number of recipient chats, and offers **Send** and **Cancel** buttons. Nothing is sent to the audience until you select Send. Text, supported media, captions, and Telegram formatting are preserved by copying the preview; an album reply selects that individual message only. Unsupported messages produce an error before confirmation.

Each broadcast uses a snapshot of known active private chats and groups, including the owner's private chat if registered. Existing chat IDs are imported from the saved download history. New chats are recorded on messages and bot membership updates. Telegram does not supply a list of every past user/group, so older chats absent from the database must interact with the bot once to register. Users who only interacted in a group are not automatically messaged privately. Removed/blocked chats are deactivated and can be registered again after they return.

Delivery is paced alongside downloads. Receipts and the audience survive cached database/R2 restores. Confirmed sends are not repeated; interrupted or unconfirmed sends are reported as Unconfirmed instead of being retried blindly. A summary lists sent, failed/skipped, and unconfirmed recipients. Keep the bot's preview message until sending finishes. The owner interface supports all six languages; the announcement itself is sent exactly as previewed.

Replace the hosted ZIP and run with `force_reimport` enabled. The Chromium-enabled workflow from the previous update does not need another change for this feature.


### Video compression

Open `/settings` → **Compression**:

| Mode | Behavior |
|---|---|
| **All videos** (default) | Try compression for every video, including videos already under 50 MB |
| **Over 50 MB** | Keep videos at or below 50 MB unchanged, compress larger videos |
| **None** | Keep originals, reject videos over 50 MB with the existing error |

**Advanced** offers these saved per-user choices. Its button shows `✓` whenever any advanced value differs from its default, and resetting or restoring every default clears the mark:

| Option | Choices | Default |
|---|---|---|
| Maximum frame rate | Original, 24, 30, 60 fps | Original |
| Maximum resolution | Original, 1080p, 720p, 480p | 1080p |
| Quality | High quality, Balanced, Smaller files | Balanced |
| Encoding speed | Fast, Medium, Slow | Fast |
| Video audio bitrate | 64, 96, 128, 192 kbps | 128 kbps |

Frame rate caps only lower a higher source rate, they do not turn a 30 fps clip into 60 fps. Original preserves the source frame timestamps, including variable frame rates. Resolution caps preserve aspect ratio and never enlarge the source; portrait 1080p is bounded by 1080×1920. **Reset advanced defaults** resets these five controls while keeping the selected compression mode. The controls apply when the mode selects a video for compression. Photos and separate TikTok sound files keep their existing behavior.

The encoder uses H.264/libx264 video, 8-bit yuv420p, AAC audio and MP4 fast-start metadata. Quality choices use CRF 20/23/28 respectively. At the default advanced settings, an already-efficient compatible original is kept if encoding would make it larger without reducing its dimensions. HDR-tagged PQ/HLG sources are tone-mapped to standard BT.709 output, and rotation metadata is applied during encoding.

If quality-based encoding exceeds the upload limit, two-pass bitrate encoding targets 48 MB from the original download, with a second 44 MB target if necessary. Audio bitrate and resolution may be lowered to fit, but the frame rate remains subject to the user's selected cap. The entire video must pass duration, codec and final-size validation before delivery; it is never cut short just to reach the size limit. These size-fitting passes take precedence over the quality preference. If a valid result cannot fit, the bot reports a compression error instead of uploading a partial file.

Two encoders run concurrently at most, with two threads each. Each encoding attempt has a 15-minute total budget after acquiring a slot, workers can wait up to 20 minutes for a slot, and compressed requests have a 40-minute overall worker limit. Input video downloads are capped at 1 GB and output files at 50 MB. Cancel and restart stop the worker and its encoder processes, and temporary media and pass logs are removed. Requests snapshot their compression settings when they start, and delivery receipts use the source media hash to prevent resending a confirmed video after recovery.

Update both your hosted application ZIP and `.github/workflows/tik.yml`, then run with `force_reimport` enabled. The workflow installs and caches the static FFmpeg/ffprobe build, imports the new compression module, and retains the Chromium binary cache and cookie behavior. No new secrets are required.

References: [Telegram sendVideo](https://core.telegram.org/bots/api#sendvideo), [FFmpeg libx264](https://ffmpeg.org/ffmpeg-codecs.html#libx264_002c-libx264rgb), [two-pass encoding](https://ffmpeg.org/ffmpeg.html), [MP4 fast-start](https://ffmpeg.org/ffmpeg-formats.html), [HDR tone mapping](https://ffmpeg.org/ffmpeg-filters.html#tonemap).
