# TikTok Telegram Bot

Send TikTok links directly to download videos and photo posts with gallery-dl
There is no `/download` command and no yt-dlp or FFmpeg dependency

## Quick setup

1. Create a Telegram bot through [BotFather](https://t.me/BotFather) with `/newbot`, keep its token private
2. Create a GitHub repository and upload this ZIP's contents into its root, including `.github/workflows/tiktok.yml`, use a private repository because saved queue state includes Telegram chat and user IDs
3. Obtain your numeric Telegram ID and the numeric ID of `@Tog991`, run `python identify.py` locally, paste the token at its hidden prompt, and send `/id` to your bot from each account, match the displayed username to `Tog991` and stop the helper before starting the workflow
4. Add the configuration below through repository Settings → Secrets and variables → Actions
5. Open the bot in a private chat from the owner account and send `/start`, this lets it send owner notifications
6. Go to Actions → TikTok Telegram Bot → Run workflow, leave `continue` enabled for automatic session renewal
7. Send a public TikTok video or photo post link to the bot

Upload the project contents, not a ZIP file, to the repository
GitHub only discovers the workflow when `.github/workflows/tiktok.yml` is committed, put it on the default branch first

## Configuration

| Name | Location | Value |
|---|---|---|
| `TELEGRAM_BOT_TOKEN` | Secret | Token from BotFather |
| `OWNER_ID` | Variable or secret | Owner's numeric Telegram user ID, not the Discord owner ID |
| `QUEUE_BYPASS_USER_ID` | Variable or secret | Numeric Telegram ID verified as belonging to `@Tog991` |
| `R2_ACCOUNT_ID` | Variable or secret | Cloudflare account ID |
| `R2_ACCESS_KEY_ID` | Secret | R2 S3 access key |
| `R2_SECRET_ACCESS_KEY` | Secret | R2 S3 secret key |
| `R2_BUCKET_NAME` | Variable or secret | Existing R2 bucket with read, write, list, and delete access |
| `TIKTOK_COOKIES_BASE64` | Optional secret | Base64-encoded Netscape TikTok cookies file |
| `APP_ZIP_URL` | Optional secret | Direct HTTPS link to a trusted project ZIP |

No GitHub personal access token is needed, the workflow uses its automatic `GITHUB_TOKEN` with `actions: write` for its own cache management and workflow dispatch
Repository or organization policies must allow the workflow actions and dispatch

The queue exemption uses a numeric ID, it never grants rights to somebody merely because they adopt a matching username
If `QUEUE_BYPASS_USER_ID` is missing, everyone uses the normal limits until you set it and restart
Exemption does not grant owner commands, `OWNER_ID` controls those separately

## Queue behavior

- Each normal user has 4 active or reserved slots and 4 waiting slots
- Additional links are rejected with a message identifying them
- Multiple links in one message are accepted up to the available capacity
- One TikTok post counts as one request, including posts with many photos
- `@Tog991` has a separate single download slot with no four-request backlog limit, other users do not occupy that slot, its own requests run in order
- Slots cover downloading and Telegram delivery, Telegram's own message limits still apply
- Queue positions are shown on admission, `/queue` shows current states
- There is no fixed global four-download cap, each user's slots are separate, size and timeout checks keep individual jobs bounded

## Media behavior

Videos are sent as playable MP4 files when available, other supported video formats are sent as documents
Photos are sent in groups of up to 10, a final single photo is sent individually
Images that exceed Telegram's photo constraints or use unsupported photo formats are sent as original documents instead
Telegram may recompress photos displayed as photos, the bot itself does not re-encode them

The limit is **50,000,000 bytes per file**, 50 decimal MB, size is checked both from the HTTP header and while streaming
The bot rejects an oversized post before sending its media and displays:

> This video is too large, the maximum size is 50 MB

There is no compression, R2 media upload, expiring media link, or fallback to yt-dlp
Completed, cancelled, and failed downloads are deleted from the runner
Only single video/photo posts are accepted, profile and collection downloads are not enabled
Photo soundtrack extraction is disabled

## Commands

| Command | Access | Purpose |
|---|---|---|
| `/start`, `/help` | Everyone | Usage instructions |
| `/queue` | Everyone | List your active and waiting jobs |
| `/cancel <number>` | Requester or owner | Cancel a job |
| `/ping` | Everyone | Check responsiveness |
| `/id` | Everyone | Show your numeric Telegram ID |
| `/jobs` | Owner | List all outstanding jobs |
| `/restart` | Owner | Save, back up, and start a fresh workflow session |
| `/upload` | Owner | Save, back up, and start a fresh workflow session |
| `/shutdown` | Owner | Save, back up, and stop without another session |

`/restart` and `/upload` both force one replacement session even if `continue` was disabled, the replacement preserves your selected `continue` setting
`/shutdown` overrides continuation, start again manually from GitHub Actions
A cancellation cannot withdraw an upload Telegram has already accepted

## Hosting and backups

The workflow uses actions from `@main`, with Python 3.12 and a 5-hour-30-minute bot session inside a 355-minute job
Python package versions for gallery-dl and python-telegram-bot are pinned to the versions checked for this release, `@main` applies to GitHub actions

After a clean stop it:

1. Validates saved state
2. Creates a ZIP containing a consistent SQLite snapshot and allowed project source files
3. Uploads it to a dedicated `tiktok-bot-backups/` scope in R2
4. Reads the upload back and verifies SHA-256 and size
5. Deletes older backups only in that same workflow scope
6. Saves and verifies the GitHub cache, retaining one previous cache
7. Dispatches the next session if requested

Cookies, tokens, downloaded media, and raw request logs are excluded from backups and diagnostics
R2 backups restore automatically when the state cache is absent
The source ZIP is optional, by default the bot uses the checked-out repository files
With `APP_ZIP_URL`, source is cached under `app`, `force_reimport` imports an updated ZIP while retaining the separate queue database
Keep the repository workflow and helper files updated too, importing a ZIP does not rewrite the committed workflow

Only one workflow session runs at a time, there is a handover gap while GitHub allocates the next runner
Failed runs or failed backups do not automatically continue, inspect the sanitized workflow output before restarting
A manual force-cancel or runner crash can lose changes since the last completed session backup, the local SQLite writes do not make an ephemeral runner durable
Use `/shutdown` instead of GitHub's Cancel button for a clean stop

## Recovery and delivery tracking

Queued and interrupted downloads are recovered from saved state
Each confirmed media batch is recorded before the next batch starts
If Telegram times out or the bot stops during an upload, it cannot know for certain whether that upload arrived, the job is marked uncertain and is not automatically resent
The bot asks you to check the chat before sending that link again
This avoids blindly duplicating albums, Telegram does not provide an idempotency key for these sends

## Groups

To detect ordinary links in group chats, use BotFather's `/setprivacy` to disable privacy mode for this bot, then remove and re-add it to the group if needed
Grant the bot permission to send messages and media
The queue is per user across chats, forum-topic replies stay in the originating topic

## Optional cookies

Use a Netscape-format cookie file exported from a TikTok session you control
Encode it locally, for example in PowerShell:

```powershell
[Convert]::ToBase64String([IO.File]::ReadAllBytes('C:\path\cookies.txt')) | Set-Clipboard
```

Paste that value into `TIKTOK_COOKIES_BASE64`, then use `/restart`
Secrets are loaded at session startup, editing a GitHub secret does not update an already-running process
A 403 does not prove cookies expired, it can also mean TikTok blocked the runner, the bot's owner message reflects that distinction

## Local execution

Requires Python 3.12 or newer on Linux, the hosting runner is Linux
Set the required bot environment variables, then:

```bash
python -m pip install -r requirements.txt
python bot.py
```

R2 is required by the GitHub workflow, direct local execution does not automatically invoke the backup and dispatch helpers
Local `/restart` and `/upload` stop cleanly, use a process manager or start the script again yourself

## Checks

```bash
python -m pip install pytest pytest-asyncio PyYAML
python -m pytest -q
```

See `VALIDATION.md` for the checks actually performed on this package

## References

- [gallery-dl configuration](https://gdl-org.github.io/docs/configuration.html)
- [Telegram Bot API](https://core.telegram.org/bots/api)
- [python-telegram-bot](https://docs.python-telegram-bot.org/)
- [GitHub Actions limits](https://docs.github.com/en/actions/reference/limits)
