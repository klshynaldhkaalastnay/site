"""Render the allowlisted placeholders used by media captions."""
import re
from urllib.parse import quote, urlsplit

from html import escape

from common import BOT_ATTRIBUTION, BOT_NAME, POST_RE


FIELDS = {
    'video_caption': 'Video caption',
    'photo_caption': 'Photo caption',
}
EXAMPLES = {
    'video_caption': '@{{.Username}}\n{{.Title}}\n{{.URL}}',
    'photo_caption': '{{.PhotoCount}} photos by @{{.Username}}\n{{.Title}}',
}
POST_FIELDS = ('PostID','Title','Caption','Author','Username','URL','AuthorURL','PostURL')
DETAIL_FIELDS = {
    'video': ('DurationSeconds','Width','Height'),
    'photo': ('PhotoCount','Width','Height'),
}
TOKEN = re.compile(r'\{\{[ \t]*\.([A-Za-z][A-Za-z0-9]*)[ \t]*\}\}')
BRACES = re.compile(r'\{\{|\}\}')
CONTROL_TEXT = re.compile(r'[\x00-\x08\x0b\x0c\x0e-\x1f\x7f-\x9f\ud800-\udfff]')
CAPTION_LIMIT = 1024


class TemplateError(ValueError):
    pass


def tokens_for(field):
    return POST_FIELDS + DETAIL_FIELDS[field.removesuffix('_caption')]


def utf16_units(text):
    return len(text.encode('utf-16-le',errors='replace')) // 2


def validate(field, text):
    if not isinstance(text,str) or not text.strip():
        raise TemplateError('Send your template as a text message')
    text = text.strip().replace('\r\n','\n').replace('\r','\n')
    if utf16_units(text)>CAPTION_LIMIT:
        raise TemplateError('This template is too long, shorten it and reply again')
    if CONTROL_TEXT.search(text):
        raise TemplateError('This template contains unsupported characters')
    allowed = tokens_for(field)
    start = 0
    while marker := BRACES.search(text,start):
        token = TOKEN.match(text,marker.start())
        if not token:
            raise TemplateError('Use the placeholder format shown in the example')
        if token[1] not in allowed:
            raise TemplateError('Use only placeholders listed for this template')
        start = token.end()
    return text


def clean(value):
    if not isinstance(value,(str,int,float)) or isinstance(value,bool):
        return ''
    # Limit expansions per field, including data from an unusually large post.
    return CONTROL_TEXT.sub('',str(value)[:4096]).replace('\r\n','\n').replace('\r','\n').strip()


def render(template, values):
    # Replacement values are not interpreted as more placeholders.
    return TOKEN.sub(lambda match: clean(values.get(match[1])), template).strip()


def caption(template, values):
    text = render(template,values)
    budget = CAPTION_LIMIT-len(BOT_NAME)-2
    encoded = text.encode('utf-16-le')
    shortened = len(encoded)>budget*2
    if shortened:
        text = encoded[:(budget-1)*2].decode('utf-16-le',errors='ignore') + '…'
    return (escape(text,quote=False)+'\n\n' if text else '')+BOT_ATTRIBUTION, shortened


def post_values(row, post_id, title, author, username, kind, resolved_url=''):
    post_match = POST_RE.fullmatch(urlsplit(row['url']).path)
    candidates = (post_id,row['caption_post_id'],row['metadata_post_id'],post_match[1] if post_match else None)
    post_id = next((str(value) for value in candidates if re.fullmatch(r'[0-9]{1,32}',str(value or ''))),'')
    username = clean(username).lstrip('@')
    handle = username if re.fullmatch(r'[\w.-]{1,64}',username) else ''
    if not handle:
        for url in (resolved_url,row['url']):
            match = re.fullmatch(r'/@([\w.-]{1,64})/(?:video|photo)/([0-9]{1,32})/?',urlsplit(url).path)
            if match and match[2]==post_id:
                handle = match[1]
                break
    author_url = 'https://www.tiktok.com/@'+quote(handle,safe='') if handle else ''
    post_type = 'photo' if kind=='image' else 'video'
    post_url = f'{author_url}/{post_type}/{post_id}' if author_url and post_id else ''
    return {'PostID':post_id,'Title':title,'Caption':title,'Author':author,
            'Username':username,'URL':row['url'],'AuthorURL':author_url,'PostURL':post_url}


def details(record, photo_count=0):
    return {
        'DurationSeconds':record.get('duration') or '',
        'Width':record.get('width') or '',
        'Height':record.get('height') or '',
        'PhotoCount':photo_count,
    }
