"""Render the allowlisted placeholders used by media captions."""
import re
from urllib.parse import quote, urlsplit

from html import escape, unescape
from html.parser import HTMLParser

from common import BOT_ATTRIBUTION, BOT_NAME, POST_RE


FIELDS = {
    'video_caption': 'Video caption',
    'photo_caption': 'Photo caption',
}
EXAMPLES = {
    'video_caption': '@{{.Username}}\n{{.Title}}\n{{.URL}}',
    'photo_caption': '{{.PhotoCount}} photos by @{{.Username}}\n{{.Title}}',
}
POST_FIELDS = ('PostID','Title','Caption','Author','Username','URL','AuthorURL','PostURL')
DETAIL_FIELDS = {
    'video': ('DurationSeconds','Width','Height'),
    'photo': ('PhotoCount','Width','Height'),
}
TOKEN = re.compile(r'\{\{[ \t]*\.([A-Za-z][A-Za-z0-9]*)[ \t]*\}\}')
BRACES = re.compile(r'\{\{|\}\}')
CONTROL_TEXT = re.compile(r'[\x00-\x08\x0b\x0c\x0e-\x1f\x7f-\x9f\ud800-\udfff]')
CAPTION_LIMIT = 1024
HTML_PREFIX = 'HTML:\n'
HTML_LIMIT = 2048
URL_FIELDS = {'URL','AuthorURL','PostURL'}
STYLES = {'b','i','u','s','tg-spoiler'}
ALIASES = {'strong':'b','em':'i','ins':'u','strike':'s','del':'s'}
TAGS = STYLES | {'a','blockquote','code','pre'}
FORMATTED_ENTITIES = {
    'bold','italic','underline','strikethrough','spoiler','code','pre',
    'blockquote','expandable_blockquote','text_link',
}


class TemplateError(ValueError):
    pass


def tokens_for(field):
    return POST_FIELDS + DETAIL_FIELDS[field.removesuffix('_caption')]


def utf16_units(text):
    return len(text.encode('utf-16-le',errors='replace')) // 2


def placeholder_source(template):
    # HTMLParser decodes character references before text is substituted.
    return unescape(template[len(HTML_PREFIX):]) if template.startswith(HTML_PREFIX) else template


def validate(field, text):
    if not isinstance(text,str) or not text.strip():
        raise TemplateError('Send your template as a text message')
    text = text.strip().replace('\r\n','\n').replace('\r','\n')
    formatted = text.startswith(HTML_PREFIX)
    if utf16_units(text)>(HTML_LIMIT if formatted else CAPTION_LIMIT):
        raise TemplateError('This template is too long, shorten it and reply again')
    if CONTROL_TEXT.search(text):
        raise TemplateError('This template contains unsupported characters')
    allowed = tokens_for(field)
    if formatted:
        parse_html(text[len(HTML_PREFIX):])
    source = placeholder_source(text)
    start = 0
    while marker := BRACES.search(source,start):
        token = TOKEN.match(source,marker.start())
        if not token:
            raise TemplateError('Use the placeholder format shown in the example')
        if token[1] not in allowed:
            raise TemplateError('Use only placeholders listed for this template')
        start = token.end()
    return text


def clean(value):
    if not isinstance(value,(str,int,float)) or isinstance(value,bool):
        return ''
    # Limit expansions per field, including data from an unusually large post.
    return CONTROL_TEXT.sub('',str(value)[:4096]).replace('\r\n','\n').replace('\r','\n').strip()


def render(template, values):
    # Replacement values are not interpreted as more placeholders.
    return TOKEN.sub(lambda match: clean(values.get(match[1])), template).strip()


def web_link(url):
    if not url or len(url)>2048 or re.search(r'[\s\x00-\x1f\x7f<>\\]',url):
        return False
    try:
        parsed = urlsplit(url)
        return (parsed.scheme in ('https','http') and bool(parsed.hostname) and
                parsed.username is None and parsed.password is None and
                (parsed.port is None or parsed.port>0))
    except ValueError:
        return False


class CaptionHTML(HTMLParser):
    """Build a small tree of Telegram caption tags, before substituting post text."""
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.root = []
        self.stack = []

    @staticmethod
    def invalid(*args):
        raise TemplateError('Use supported formatting tags and valid links')

    handle_comment = handle_decl = unknown_decl = handle_pi = handle_startendtag = invalid

    def append(self, node):
        (self.stack[-1][2] if self.stack else self.root).append(node)

    def handle_data(self, data):
        if CONTROL_TEXT.search(data):
            self.invalid()
        self.append(data)

    def handle_starttag(self, tag, attrs):
        if tag=='span' and attrs==[('class','tg-spoiler')]:
            tag, attrs = 'tg-spoiler', []
        tag = ALIASES.get(tag,tag)
        parents = [item[0] for item in self.stack]
        pre_code = tag=='code' and parents==['pre'] and not self.stack[-1][2]
        if (tag not in TAGS or tag in parents or len(parents)>=8 or
                (tag=='pre' and parents) or (tag=='code' and parents and not pre_code) or
                ('code' in parents or ('pre' in parents and not pre_code)) or
                (tag=='blockquote' and parents) or ('a' in parents and tag not in STYLES)):
            self.invalid()
        if tag=='a':
            if len(attrs)!=1 or attrs[0][0]!='href' or not attrs[0][1]:
                self.invalid()
            href = attrs[0][1]
            token = TOKEN.fullmatch(href)
            if not (token and token[1] in URL_FIELDS) and (BRACES.search(href) or not web_link(href)):
                self.invalid()
        elif attrs and not (tag=='blockquote' and attrs==[('expandable',None)]):
            if not (pre_code and len(attrs)==1 and attrs[0][0]=='class' and
                    re.fullmatch(r'language-[a-zA-Z0-9_+.-]{1,32}',attrs[0][1] or '')):
                self.invalid()
        node = (tag,attrs,[])
        self.append(node)
        self.stack.append(node)

    def handle_endtag(self, tag):
        tag = 'tg-spoiler' if tag=='span' else ALIASES.get(tag,tag)
        if not self.stack or self.stack[-1][0]!=tag:
            self.invalid()
        self.stack.pop()


def parse_html(source):
    parser = CaptionHTML()
    parser.feed(source)
    parser.close()
    if parser.stack:
        parser.invalid()
    return parser.root


def html_caption(source, values, budget):
    tree = parse_html(source)
    def expand(nodes):
        for node in nodes:
            if isinstance(node,str):
                yield TOKEN.sub(lambda m: clean(values.get(m[1])),node)
            else:
                tag,attrs,children = node
                yield tag,attrs,list(expand(children))
    expanded = list(expand(tree))

    def visible(nodes):
        return ''.join(node if isinstance(node,str) else visible(node[2]) for node in nodes)
    plain = visible(expanded)
    if not plain.strip():
        return '', False
    shortened = utf16_units(plain)>budget
    remaining = budget-int(shortened)

    def produce(nodes):
        nonlocal remaining
        result = []
        for node in nodes:
            if remaining<=0:
                break
            if isinstance(node,str):
                part = node.encode('utf-16-le')[:remaining*2].decode('utf-16-le',errors='ignore')
                result.append(escape(part,quote=False))
                if len(part)<len(node):
                    remaining = 0
                else:
                    remaining -= utf16_units(part)
                continue
            tag,attrs,children = node
            content = produce(children)
            if not content:
                continue
            if tag=='a':
                href = render(attrs[0][1],values)
                if not web_link(href):
                    result.append(content)
                    continue
                attrs = [('href',href)]
            rendered_attrs = ''.join(f' {key}' if value is None else f' {key}="{escape(value)}"'
                                     for key,value in attrs)
            result.append(f'<{tag}{rendered_attrs}>{content}</{tag}>')
        return ''.join(result)
    return produce(expanded)+('…' if shortened else ''), shortened


def caption(template, values):
    budget = CAPTION_LIMIT-len(BOT_NAME)-2
    if template.startswith(HTML_PREFIX):
        html, shortened = html_caption(template[len(HTML_PREFIX):],values,budget)
        return (html+'\n\n' if html else '')+BOT_ATTRIBUTION, shortened
    text = render(template,values)
    encoded = text.encode('utf-16-le')
    shortened = len(encoded)>budget*2
    if shortened:
        text = encoded[:(budget-1)*2].decode('utf-16-le',errors='ignore') + '…'
    return (escape(text,quote=False)+'\n\n' if text else '')+BOT_ATTRIBUTION, shortened


def post_values(row, post_id, title, author, username, kind, resolved_url=''):
    post_match = POST_RE.fullmatch(urlsplit(row['url']).path)
    candidates = (post_id,row['caption_post_id'],row['metadata_post_id'],post_match[1] if post_match else None)
    post_id = next((str(value) for value in candidates if re.fullmatch(r'[0-9]{1,32}',str(value or ''))),'')
    username = clean(username).lstrip('@')
    handle = username if re.fullmatch(r'[\w.-]{1,64}',username) else ''
    if not handle:
        for url in (resolved_url,row['url']):
            match = re.fullmatch(r'/@([\w.-]{1,64})/(?:video|photo)/([0-9]{1,32})/?',urlsplit(url).path)
            if match and match[2]==post_id:
                handle = match[1]
                break
    author_url = 'https://www.tiktok.com/@'+quote(handle,safe='') if handle else ''
    post_type = 'photo' if kind=='image' else 'video'
    post_url = f'{author_url}/{post_type}/{post_id}' if author_url and post_id else ''
    return {'PostID':post_id,'Title':title,'Caption':title,'Author':author,
            'Username':username,'URL':row['url'],'AuthorURL':author_url,'PostURL':post_url}


def details(record, photo_count=0):
    return {
        'DurationSeconds':record.get('duration') or '',
        'Width':record.get('width') or '',
        'Height':record.get('height') or '',
        'PhotoCount':photo_count,
    }
