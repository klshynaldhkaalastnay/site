# Validation

## Visible album audio button replies, 2026-10-06

142 automated tests passed with aiogram 3.31.0 and gallery-dl 1.32.13. The earlier album path depended on editing an album photo's keyboard, and a rejected edit could leave no visible button. Albums now receive one ordinary text reply with @TikTokdownloaderbestbot and the Extract audio keyboard. Single photos and videos keep their direct keyboards. Native multipart checks cover 1, 2, 10, 11 and 23 images, photos and original documents, the ten-item limit, original bytes, continuation captions/replies, and chat/topic routing. Albums send no reply-markup edits. Only the requester can use the saved button; sound-only jobs reply to the first photo, and repeated clicks reuse the same audio job.

The upgrade migration replaces older album photo bindings with pending button replies, including completed jobs whose old edit was acknowledged. Startup repairs those replies without resending images. Confirmed button message IDs persist across restarts. Definitive HTTP 400/403/413 button rejections permit safe retry. Network errors, server errors and malformed responses retain separate uncertain button intent and do not duplicate replies. A correctly routed callback can confirm a button whose HTTP response was lost; ownership, chat, reply anchor and topic must match. Cancellation before the send or during rate-limit backoff preserves safe retry. Button failures keep the media job completed and show a translated status notice in all six languages.

Existing video audio buttons, compression, subtitles, Persian and other language settings, photo batching, cookie isolation, queues, backups and broadcasts passed. Dependency consistency, Python syntax, ZIP integrity and safe source import passed. No live Telegram upload, TikTok download or GitHub Actions run was performed for this fix.

## Photo audio buttons, 2026-10-05

133 automated tests passed with the pinned aiogram 3.31.0 and gallery-dl 1.32.13 versions. Audio On keeps automatic sound replies for videos and photos. Audio Off skips sound and cover downloads and marks either media type for manual extraction. Controlled gallery-dl responses verify both modes, original audio metadata, exclusion of subtitles from photos and sound-only requests, and unchanged direct sound-link behavior.

Native aiogram multipart and response checks cover 1, 2, 10, 11 and 23 photos, both photo uploads and original documents. Single photos carry their button in the send request. Albums receive one button on the last item of the first batch through a separate reply-markup edit, without passing unsupported keyboard fields to sendMediaGroup. All image bytes, ten-item batching, link/topic replies, continuation captions and replies are preserved. Only the original requester in the saved chat/message can use the button. Sound-only jobs reply to the first delivered media, including when the album button is on a different message. Repeated clicks before and after completion reuse the same job.

Receipt checks cover interruption after an album is confirmed but before its button is attached, restart recovery, unconfirmed keyboard edits, already-applied edits, and startup repair for completed jobs. Confirmed albums are not resent while repairing buttons. Additive database migration preserves older video buttons, queue receipts and Persian/audio preferences. Existing compression, subtitles, languages, cookie isolation, queues, backups and broadcasts passed. Dependency consistency, Python syntax, ZIP integrity and safe source import passed. No live Telegram upload, TikTok download or GitHub Actions run was performed for this update.

## Subtitle files, Persian and settings updates, 2026-10-05

118 automated tests passed with the pinned aiogram 3.31.0 and gallery-dl 1.32.13 versions. The real gallery-dl TikTok extractor runs against controlled post responses containing automatic, creator and translated subtitle tracks. Checks cover Off by default, original VTT/SRT/creator-caption JSON bytes, language/source/version filenames, duplicate track entries, videos with no tracks, exclusion for photos and manual audio extraction, partial failures, empty files and the per-file 50 MB limit. Optional subtitle failures preserve the video and other available tracks.

Native aiogram multipart/response checks verify separate document uploads replying to the delivered video, the exact @TikTokdownloaderbestbot caption, same chat/topic, original filenames and bytes, video-to-document fallback and independent audio behavior. Stable track receipts survive reordered results. Recovery skips confirmed video/subtitle files after cancellation; interrupted subtitle uploads retain uncertain delivery intent and are not automatically repeated. Additive database migration and per-job subtitle snapshots preserve older queues and choices across retries/restarts.

Persian appears in onboarding and Settings, with translations for every English message key, matching format placeholders and translated help/owner help. Settings ownership and persistence passed. /language is removed from registered commands, its handler and all help texts; language changes remain in Settings. The Advanced button shows a checkmark for saved values differing from defaults, and reset clears it. Existing compression, photo continuation, cookie isolation, audio, queue, backup and broadcast tests passed. Dependency checks, Python syntax, ZIP integrity and safe source import passed. No live Telegram upload, TikTok download or GitHub Actions run was performed for this update.

## Photo continuation replies, 2026-10-04

102 automated tests passed. Native aiogram multipart/response checks cover 10, 11, 20, 21 and 23 photos, both photo uploads and original-document delivery. The first batch replies to the link with the post caption; each additional batch replies to the preceding batch with only @TikTokdownloaderbestbot, including a final single photo. All photos remain in order in the same chat/topic. The soundtrack still replies once to the first batch, and confirmed batches/audio are skipped on repeat delivery.

Restart checks preserve the reply chain after two confirmed batches. An additive SQLite migration retains existing queue receipts, language and compression preferences; older photo receipts use their saved first-media target for the next reply. A rejected continuation retains the previous target for retry, while an interrupted upload stays uncertain and is not automatically resent. ZIP integrity and safe source import passed. No live Telegram upload or TikTok download was performed for this update.

## Static FFmpeg installation and cache, 2026-10-04

The workflow downloads the yt-dlp `ffmpeg-master-latest-linux64-gpl.tar.xz` archive into `~/.ffmpeg` when either ffmpeg or ffprobe is missing, restores/saves a separate OS/architecture/build cache, and exports its bin directory to PATH. Cache saving follows encoder/filter validation and precedes the bot session.

Controlled runs of the actual Bash installation block passed for cold installation, cached reuse without another download, missing-ffprobe repair, PATH export, failed-download cleanup and invalid-archive cleanup. These checks used local tar.xz fixtures containing real FFmpeg/ffprobe binaries and a controlled download transport. The existing workflow test, YAML parsing, all 11 shell blocks, embedded Python syntax and @main action references passed. The upstream release's archive name was checked against its published asset listing. No live GitHub download, cache restore/save or Actions run was performed for this update.

## Workflow filename, 2026-10-04

Renamed the standalone workflow and packaged workflow to `tik.yml`, including source import, backup paths, documentation and the workflow validation test. The 16 existing bot/queue/import/backup/workflow tests passed. Python syntax, workflow YAML and all embedded shell/Python syntax checks passed. The ZIP contains `.github/workflows/tik.yml`, and safe source import preserves that file. No GitHub Actions run was launched for this filename change.

## aiogram migration, video compression and advanced settings, 2026-10-04

88 automated tests passed with Python 3.12, aiogram 3.31.0, FFmpeg 6.1.1, gallery-dl 1.32.13 and Playwright 1.58.0 in an environment without python-telegram-bot installed. Real synthetic clips verify H.264/AAC MP4 output, fast-start metadata, preservation of 60 fps and variable frame timestamps, selected 30/24 fps limits, resolution and quality controls, silent portrait videos, rotation metadata, HDR-to-BT.709 tone mapping, and full decode after two-pass size fitting without truncation. The size-fitting test uses a reduced byte limit to exercise the same bitrate budgeting and final-size checks without an unnecessarily large fixture.

Native aiogram integration checks use its actual multipart builder, response decoder and bot-bound Update/CallbackQuery models with a controlled transport. They cover caption links and topic routing, durable admission before polling acknowledgement, command registration, clean shutdown and session closure, streamed photo/document albums, full-file video fallback, audio filename/metadata/thumbnail uploads, rate-limit retries, settings ownership and language selection, deduplicated manual audio jobs, group migration and blocked broadcast recipients. Network interruptions, HTTP 500 and malformed upload responses retain uncertain delivery intent; definitive HTTP 403/404/413 rejections clear it, with the existing 50 MB error for HTTP 413. The ID helper also closes its session without logging the token.

Controlled downloader/bot tests cover All as the default, the exact 50 MB boundary, unchanged small videos in Over 50 MB mode, the existing error with None, video-only larger input limits, per-user ownership and persistence, reset behavior, all five languages, job settings snapshots across retries/recovery, and stable delivery receipts when encoded bytes change. Existing queue, audio, cookie isolation, reply routing and broadcast tests passed. Dependency checks, Python compilation, workflow YAML parsing, all shell/Python block syntax checks and the workflow's encoder availability checks passed. No live Telegram upload, TikTok download or GitHub Actions run was performed for this update.

## Cookies limited to Chromium, 2026-10-03

54 automated tests passed with Python 3.12 and the pinned gallery-dl, Telegram and Playwright versions. Controlled requests verify that short links, video/photo downloads, automatic and manual post audio, and normal sound-page/detail extraction never load the saved cookie file or attach its login cookies. A simulated Chromium context verifies cookie import only after the fallback starts, no cookie export to the HTTP downloader, browser cleanup, and anonymous fallback when the file is absent or invalid. Existing delivery, queue, settings, restart and broadcast tests passed. Dependency consistency and Python compilation passed. No live TikTok or Telegram test was performed; the workflow and Chromium cache configuration are unchanged.

## Replies to link messages, 2026-10-02

43 automated tests passed. Existing delivery checks now verify replies to the originating link message for videos, photo albums, resumed album batches, and video-to-document fallback, including group topic routing. Audio still replies to the delivered media, and repeated manual extraction clicks remain deduplicated. Python compilation and dependency checks passed. No live Telegram upload was performed.

## Video audio controls, 2026-09-30

43 automated tests passed with Python 3.12, gallery-dl 1.32.13 and python-telegram-bot 22.8. Dependency consistency and Python compilation passed. Controlled responses cover videos with automatic audio, videos with the manual button, mandatory photo audio with Audio Off, sound-only downloading without fetching video/image bytes, document fallback with the button, callback ownership and chat validation, queue limits, repeated-click deduplication, reply-to-video and topic routing, database restart recovery, and the existing owner broadcast behavior. Telegram/TikTok sending was not verified live; no bot token was supplied.

Checked on 2026-09-25 with Python 3.12.14, gallery-dl 1.32.13, and python-telegram-bot 22.8

## Passed

- 16 automated tests using pytest, including the real gallery-dl TikTok extractor with controlled video and photo responses
- Four active slots and four waiting slots per normal user, queue advancement and independent users
- Separate exempt account slot, unlimited exempt backlog, replayed-update deduplication
- Recovery of pending work and preservation of confirmed upload receipts
- Ambiguous Telegram sends are not automatically repeated
- Photo batches retain all images and skip batches already confirmed as sent
- Owner-only shutdown and cancellation ownership checks
- Clean shutdown writes both the session receipt and Telegram update cursor
- Unsupported Telegram video delivery falls back to the unchanged file
- URL restrictions and rejection of non-post URLs
- Oversized response header and streaming-body checks, including exact boundary size
- Safe ZIP source import excludes queue data and credentials
- R2 backup verification occurs before deleting previous backups, credential files excluded
- Workflow action references use @main and shutdown blocks automatic continuation
- Actionlint 1.7.12 passed for the workflow, shellcheck was not available
- Python source compilation and dependency consistency checks passed

## Not verified live

Live public TikTok video, photo, and shortened-link attempts did not produce downloadable media in this execution environment
A follow-up diagnostic showed DNS resolution failures for TikTok hosts, so these attempts do not establish whether those posts work from a GitHub runner

Telegram sending was tested with controlled bot responses, no real bot token was provided
R2 backup operations were tested with a simulated S3 client, no live R2 credentials were provided
The workflow was checked with Actionlint but was not launched on GitHub

After configuring the secrets, first run with continue disabled and send one video and one photo post to verify access from your runner


## Audio update validation

25 automated tests passed, including real gallery-dl extractor fixtures for video and photo posts with music metadata, reading back embedded MP3 title/artist/album/cover/IDs/duration, preserving the audio payload, safe filenames and ID fallback, the post-tagging size limit, Telegram audio reply metadata, album replies, database migration, confirmed-delivery recovery and uncertain audio uploads. M4A tagging uses Mutagen's MP4 API but was not verified against a live TikTok M4A download. No live Telegram or TikTok upload test was performed for this update.

Full-resolution cover update: 27 tests passed, including exact embedded JPEG/PNG byte preservation, full-size WebP-to-PNG artwork, and separate Telegram thumbnail dimensions.
