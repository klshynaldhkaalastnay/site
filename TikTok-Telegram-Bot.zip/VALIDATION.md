# Validation

Checked on 2026-09-25 with Python 3.12.14, gallery-dl 1.32.13, and python-telegram-bot 22.8

## Passed

- 16 automated tests using pytest, including the real gallery-dl TikTok extractor with controlled video and photo responses
- Four active slots and four waiting slots per normal user, queue advancement and independent users
- Separate exempt account slot, unlimited exempt backlog, replayed-update deduplication
- Recovery of pending work and preservation of confirmed upload receipts
- Ambiguous Telegram sends are not automatically repeated
- Photo batches retain all images and skip batches already confirmed as sent
- Owner-only shutdown and cancellation ownership checks
- Clean shutdown writes both the session receipt and Telegram update cursor
- Unsupported Telegram video delivery falls back to the unchanged file
- URL restrictions and rejection of non-post URLs
- Oversized response header and streaming-body checks, including exact boundary size
- Safe ZIP source import excludes queue data and credentials
- R2 backup verification occurs before deleting previous backups, credential files excluded
- Workflow action references use @main and shutdown blocks automatic continuation
- Actionlint 1.7.12 passed for the workflow, shellcheck was not available
- Python source compilation and dependency consistency checks passed

## Not verified live

Live public TikTok video, photo, and shortened-link attempts did not produce downloadable media in this execution environment
A follow-up diagnostic showed DNS resolution failures for TikTok hosts, so these attempts do not establish whether those posts work from a GitHub runner

Telegram sending was tested with controlled bot responses, no real bot token was provided
R2 backup operations were tested with a simulated S3 client, no live R2 credentials were provided
The workflow was checked with Actionlint but was not launched on GitHub

After configuring the secrets, first run with continue disabled and send one video and one photo post to verify access from your runner
