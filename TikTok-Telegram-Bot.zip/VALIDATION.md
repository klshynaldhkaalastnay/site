# Validation

## Neofetch executable cache, 2026-10-07

The workflow restores ~/.neofetch before printing system information and saves a new cache immediately afterward, before checkout and the bot session. It caches the executable script only, so each run still reports its own current system details. A cache hit skips apt entirely; a miss copies an existing neofetch command or installs it once and copies it into the cache. The key is scoped to runner OS and architecture and is separate from the source/state caches targeted by rotation. YAML structure, matching restore/save paths, Bash syntax, isolated cache-hit, preinstalled and fresh-install branches, and repeated cached runs all passed. Existing workflow settings and bot steps are unchanged, and standalone and bundled workflow copies match. No live GitHub Actions run was performed for this change.

## WorldBox interface punctuation, 2026-10-07

Applied the interface punctuation rule to all ten languages: internal periods and semicolons become commas, and line-ending periods are removed. Japanese and fullwidth punctuation use the corresponding local commas. Messages ending in three dots remain completely unchanged. Updated 90 interface texts and help entries, retaining all 50 three-dot messages exactly. Styling applies to authored translation values before interpolation, leaving translation keys, command names, format placeholders, inserted numbers and URLs, TikTok captions and the bot attribution link intact. All 302 automated tests passed after this change, in addition to the catalog, placeholder, ellipsis and interpolation checks.

## Neofetch at workflow startup, 2026-10-07

The first bot job step installs neofetch with apt only when the command is missing, then runs it before checkout on every session. The standalone tik.yml and the workflow bundled in the source ZIP match. YAML structure and shell syntax were checked, and every existing workflow step remains unchanged. No live GitHub Actions run was performed for this change.

## Four additional languages, restart import choices and private owner ZIPs, 2026-10-07

302 automated tests passed with aiogram 3.31.0 and gallery-dl 1.32.13. Japanese, Portuguese, French and German are available in onboarding and Settings, bringing the total to ten languages. Each new language covers all 131 English message keys with matching format placeholders, translated help and owner help, saved preferences, setting choices and restart/backup controls. The menus use two buttons per row. Hindi and Urdu are not added.

The owner-only /restart command waits for Restart and reimport ZIP, Restart without reimport, or Cancel. Native aiogram tests cover user/chat/message/topic ownership, replaced and replayed prompts, cancelled decisions, shutdown conflicts, acknowledgement/edit failures, and correctly bound prompts with lost acknowledgements. A clean session receipt carries the import choice to the existing workflow dispatch helper. Controlled dispatch checks verify the next run's force_reimport input, preserved continue choice, and false defaults for older receipts or other stop reasons. Reimport is limited to the selected replacement session; a fresh Runner does not inherit the flag.

The owner-only /upload command sends a ZIP privately, including commands issued in groups, and waits for shutdown or restart. Native multipart checks verify actual ZIP bytes, a consistent SQLite snapshot containing saved queue/preferences/captions/receipts, running source and workflow files, linked bot attribution, and exclusion of credentials, cookies, media and symbolic links. ZIP restart opens the same reimport prompt. Checks cover private owner/message bindings, stale/replayed buttons, rejection and oversize handling, unconfirmed document acknowledgements, temporary-file cleanup, and confirmed private controls retained when a group acknowledgement fails. A native polling lifecycle verifies shutdown only after the private button and the existing backup/continuation gate. R2 uses the same archive builder; checksum verification still precedes deletion of earlier backups.

Existing media, compression, caption preferences, 100-second action cooldowns, queue recovery, broadcasts and workflow tests passed. Dependency consistency, Python syntax, safe source import and ZIP integrity were checked. No live Telegram upload, TikTok download, R2 backup or GitHub Actions run was performed for this update.

## Action-button cooldown set to 100 seconds, 2026-10-07

46 targeted tests passed. Audio, subtitle and caption request buttons use a 1-minute-40-second cooldown. Checks cover the 99/100-second boundary, minutes:seconds alerts in all six languages, saved start times across restarts, repeat requests with separate receipts, independent buttons, queue limits, ownership, migration, and caption failure/cancellation handling. Python syntax, archive integrity and safe source import passed. No live Telegram upload, TikTok download or GitHub Actions run was performed for this change.

## Action-button cooldown shortened to 90 seconds, 2026-10-07

46 targeted tests passed with aiogram 3.31.0 and gallery-dl 1.32.13. Audio, subtitle and caption request buttons now become available after 1 minute 30 seconds. Remaining-time alerts show minutes:seconds in all six languages. Checks cover the 89/90-second boundary, unchanged timers on repeated taps, persisted start times across restarts, independent buttons, new request identities and delivery receipts, legacy database migration, queue capacity, ownership, caption failures/cancellation and late acknowledgements. Existing saved timestamps use the shorter interval without resetting the timer. Settings buttons remain immediately usable. Dependency consistency, Python syntax, safe source import and archive integrity passed. No live Telegram upload, TikTok download or GitHub Actions run was performed for this change.

## Full caption settings and action-button cooldowns, 2026-10-07

263 automated tests passed with aiogram 3.31.0 and gallery-dl 1.32.13. Full caption has On, Off (default), and Off with no button, with saved choices, ownership checks, selected checkmarks and translations in all six languages. Tests cover every choice with short and long captions for videos, video documents, single photos, photo documents, albums and document albums. Automatic files retain the original UTF-8 bytes and numeric .txt filename and reply to the first delivered media with the linked bot attribution. Off keeps the existing ordinary button reply; Off with no button stores no full text and sends no extra file or button. Worker snapshots, legacy choices, restart repair, cancellation, definitive failures and unconfirmed automatic uploads are covered.

Audio, subtitle and caption action buttons have independent 30-minute timers saved in SQLite. Native aiogram checks verify admission before acknowledgement, remaining-time alerts in all six languages, unchanged timers on repeat taps, the exact expiry boundary, restart persistence, independent buttons/posts, continued settings navigation, queue limits and unauthorized/shutdown rejections. Eligible later audio/subtitle taps create new jobs with separate receipts, fetch only the requested files and reply to the original media. Caption taps reuse the saved exact text and retain a receipt for each accepted request. Old callback replays cannot create another request. Definite caption failures and cancellation keep their cooldown; unconfirmed sends are never automatically duplicated. A late caption acknowledgement cannot replace a newer request's state. Both older uniqueness constraints migrate without changing saved job IDs, receipts or preferences. Older extraction timestamps seed their timers; older caption receipts get a one-time timer on upgrade.

All existing media, compression, cookie isolation, queue, backup, broadcast and workflow tests passed. Dependency consistency, Python syntax, safe source import and ZIP integrity were checked. No live Telegram upload, TikTok download or GitHub Actions run was performed for this update.

## Full caption text-file replies and linked bot attribution, 2026-10-07

201 automated tests passed with aiogram 3.31.0 and gallery-dl 1.32.13. Following the final reply-style adjustment, the caption and photo audio tests were rerun. Caption boundaries count visible UTF-16 units and reserve account information, separators and the visible attribution. Checks cover ASCII, escaped HTML characters and emojis at the exact boundary; shortened previews fit the media limit without splitting surrogate pairs.

Native aiogram multipart checks cover videos, rejected-video document fallbacks, single photos, photo documents, eleven-photo albums and document albums. Oversized captions produce one ordinary reply with only the linked bot attribution and a text-file button. The original UTF-8 bytes, leading/trailing whitespace, line breaks, hashtags, emojis and numeric .txt filename are retained. Short links use the worker's resolved post ID. The file replies to the first delivered media in the original chat/topic. Existing audio/subtitle keyboards and ten-item photo batching are retained. Normal captions create no extra button or document. User, chat, message and topic ownership are checked.

Saved captions and bindings survive a real state/Runner restart after temporary media files are deleted. Confirmed repeated and simultaneous clicks produce one file upload. Definitive button/file rejections allow safe retry; interrupted button acknowledgements are bound by a correctly routed owned click; unconfirmed file sends are not automatically duplicated. Cancellation before an upload releases its claim. Every bot attribution uses the exact requested deep-link href and HTML parse mode, including continuation batches, audio/subtitles, caption files and album/caption replies; text replies disable previews. All new caption messages are translated into the six supported languages. Existing default Subtitles=Off with no button remains in place and media caching was not added.

Dependency consistency, Python syntax, safe source import and ZIP integrity were checked. No live Telegram upload, TikTok download or GitHub Actions run was performed for this update.

## Subtitle default without an extraction button, 2026-10-07

56 relevant subtitle, manual-extraction and language tests passed with aiogram 3.31.0 and gallery-dl 1.32.13. The default is Off with no button in the settings UI, new job preference snapshots, worker command line and direct download API. Default videos have no automatic subtitle files or subtitle extraction button. Explicit Off still offers extraction, On still uploads tracks, and saved preferences and existing job snapshots are retained. All nine audio/subtitle combinations and document fallbacks passed. Dependency consistency, Python syntax, ZIP integrity and source import were checked. Media caching was not added. No live Telegram upload, TikTok download or GitHub Actions run was performed for this change.

## Manual subtitle extraction and three-state preferences, 2026-10-06

180 automated tests passed with aiogram 3.31.0 and gallery-dl 1.32.13. Audio defaults to On and Subtitles to Off. Both settings offer On, Off, and Off with no button, show a checkmark on the selected choice, preserve ownership and saved values, and display the full choice on the main settings page. All new labels, button responses and errors are translated in English, Spanish, Arabic, Russian, Chinese and Persian. Per-job mode snapshots retain automatic-download and button choices across preference changes and restarts, including older saved subtitle booleans.

The real gallery-dl extractor runs against controlled posts. Native aiogram multipart checks exercise all nine audio/subtitle combinations, with playable video and original-document fallback delivery. Off adds its corresponding button; both Off choices produce one row with Extract audio beside Extract subtitles. Off with no button adds no corresponding button or automatic file. Photos offer only audio extraction. Confirmed repeated delivery does not resend video, audio or subtitles.

Manual subtitle requests fetch only the original tracks, excluding video/image/audio downloads, cover art, converters and browser startup. Checks cover original track bytes and names, no tracks, photo posts, partial failures, all-track failures and the per-file size limit. Subtitle files reply to the original video in the same chat/topic with only @TikTokdownloaderbestbot. Both click orders create independent audio and subtitle requests; repeated clicks before or after completion reuse the matching request. Requester/chat/message ownership, queue capacity, shutdown admission and extraction after restart without retained media files passed.

The older three-column request uniqueness constraint is replaced transactionally with a constraint that also identifies audio-only and subtitle-only requests. Existing columns, job IDs, pending audio jobs, preferences and delivery receipts are preserved. Recovery skips confirmed subtitle tracks; an unacknowledged upload remains uncertain and is not blindly resent. Existing album button repair, photo batching, compression, cookie isolation, language, queue, backup and broadcast checks passed. Dependency consistency, Python syntax, ZIP integrity and safe source import passed. No live Telegram upload, TikTok download or GitHub Actions run was performed for this update.

## Visible album audio button replies, 2026-10-06

142 automated tests passed with aiogram 3.31.0 and gallery-dl 1.32.13. The earlier album path depended on editing an album photo's keyboard, and a rejected edit could leave no visible button. Albums now receive one ordinary text reply with @TikTokdownloaderbestbot and the Extract audio keyboard. Single photos and videos keep their direct keyboards. Native multipart checks cover 1, 2, 10, 11 and 23 images, photos and original documents, the ten-item limit, original bytes, continuation captions/replies, and chat/topic routing. Albums send no reply-markup edits. Only the requester can use the saved button; sound-only jobs reply to the first photo, and repeated clicks reuse the same audio job.

The upgrade migration replaces older album photo bindings with pending button replies, including completed jobs whose old edit was acknowledged. Startup repairs those replies without resending images. Confirmed button message IDs persist across restarts. Definitive HTTP 400/403/413 button rejections permit safe retry. Network errors, server errors and malformed responses retain separate uncertain button intent and do not duplicate replies. A correctly routed callback can confirm a button whose HTTP response was lost; ownership, chat, reply anchor and topic must match. Cancellation before the send or during rate-limit backoff preserves safe retry. Button failures keep the media job completed and show a translated status notice in all six languages.

Existing video audio buttons, compression, subtitles, Persian and other language settings, photo batching, cookie isolation, queues, backups and broadcasts passed. Dependency consistency, Python syntax, ZIP integrity and safe source import passed. No live Telegram upload, TikTok download or GitHub Actions run was performed for this fix.

## Photo audio buttons, 2026-10-05

133 automated tests passed with the pinned aiogram 3.31.0 and gallery-dl 1.32.13 versions. Audio On keeps automatic sound replies for videos and photos. Audio Off skips sound and cover downloads and marks either media type for manual extraction. Controlled gallery-dl responses verify both modes, original audio metadata, exclusion of subtitles from photos and sound-only requests, and unchanged direct sound-link behavior.

Native aiogram multipart and response checks cover 1, 2, 10, 11 and 23 photos, both photo uploads and original documents. Single photos carry their button in the send request. Albums receive one button on the last item of the first batch through a separate reply-markup edit, without passing unsupported keyboard fields to sendMediaGroup. All image bytes, ten-item batching, link/topic replies, continuation captions and replies are preserved. Only the original requester in the saved chat/message can use the button. Sound-only jobs reply to the first delivered media, including when the album button is on a different message. Repeated clicks before and after completion reuse the same job.

Receipt checks cover interruption after an album is confirmed but before its button is attached, restart recovery, unconfirmed keyboard edits, already-applied edits, and startup repair for completed jobs. Confirmed albums are not resent while repairing buttons. Additive database migration preserves older video buttons, queue receipts and Persian/audio preferences. Existing compression, subtitles, languages, cookie isolation, queues, backups and broadcasts passed. Dependency consistency, Python syntax, ZIP integrity and safe source import passed. No live Telegram upload, TikTok download or GitHub Actions run was performed for this update.

## Subtitle files, Persian and settings updates, 2026-10-05

118 automated tests passed with the pinned aiogram 3.31.0 and gallery-dl 1.32.13 versions. The real gallery-dl TikTok extractor runs against controlled post responses containing automatic, creator and translated subtitle tracks. Checks cover Off by default, original VTT/SRT/creator-caption JSON bytes, language/source/version filenames, duplicate track entries, videos with no tracks, exclusion for photos and manual audio extraction, partial failures, empty files and the per-file 50 MB limit. Optional subtitle failures preserve the video and other available tracks.

Native aiogram multipart/response checks verify separate document uploads replying to the delivered video, the exact @TikTokdownloaderbestbot caption, same chat/topic, original filenames and bytes, video-to-document fallback and independent audio behavior. Stable track receipts survive reordered results. Recovery skips confirmed video/subtitle files after cancellation; interrupted subtitle uploads retain uncertain delivery intent and are not automatically repeated. Additive database migration and per-job subtitle snapshots preserve older queues and choices across retries/restarts.

Persian appears in onboarding and Settings, with translations for every English message key, matching format placeholders and translated help/owner help. Settings ownership and persistence passed. /language is removed from registered commands, its handler and all help texts; language changes remain in Settings. The Advanced button shows a checkmark for saved values differing from defaults, and reset clears it. Existing compression, photo continuation, cookie isolation, audio, queue, backup and broadcast tests passed. Dependency checks, Python syntax, ZIP integrity and safe source import passed. No live Telegram upload, TikTok download or GitHub Actions run was performed for this update.

## Photo continuation replies, 2026-10-04

102 automated tests passed. Native aiogram multipart/response checks cover 10, 11, 20, 21 and 23 photos, both photo uploads and original-document delivery. The first batch replies to the link with the post caption; each additional batch replies to the preceding batch with only @TikTokdownloaderbestbot, including a final single photo. All photos remain in order in the same chat/topic. The soundtrack still replies once to the first batch, and confirmed batches/audio are skipped on repeat delivery.

Restart checks preserve the reply chain after two confirmed batches. An additive SQLite migration retains existing queue receipts, language and compression preferences; older photo receipts use their saved first-media target for the next reply. A rejected continuation retains the previous target for retry, while an interrupted upload stays uncertain and is not automatically resent. ZIP integrity and safe source import passed. No live Telegram upload or TikTok download was performed for this update.

## Static FFmpeg installation and cache, 2026-10-04

The workflow downloads the yt-dlp `ffmpeg-master-latest-linux64-gpl.tar.xz` archive into `~/.ffmpeg` when either ffmpeg or ffprobe is missing, restores/saves a separate OS/architecture/build cache, and exports its bin directory to PATH. Cache saving follows encoder/filter validation and precedes the bot session.

Controlled runs of the actual Bash installation block passed for cold installation, cached reuse without another download, missing-ffprobe repair, PATH export, failed-download cleanup and invalid-archive cleanup. These checks used local tar.xz fixtures containing real FFmpeg/ffprobe binaries and a controlled download transport. The existing workflow test, YAML parsing, all 11 shell blocks, embedded Python syntax and @main action references passed. The upstream release's archive name was checked against its published asset listing. No live GitHub download, cache restore/save or Actions run was performed for this update.

## Workflow filename, 2026-10-04

Renamed the standalone workflow and packaged workflow to `tik.yml`, including source import, backup paths, documentation and the workflow validation test. The 16 existing bot/queue/import/backup/workflow tests passed. Python syntax, workflow YAML and all embedded shell/Python syntax checks passed. The ZIP contains `.github/workflows/tik.yml`, and safe source import preserves that file. No GitHub Actions run was launched for this filename change.

## aiogram migration, video compression and advanced settings, 2026-10-04

88 automated tests passed with Python 3.12, aiogram 3.31.0, FFmpeg 6.1.1, gallery-dl 1.32.13 and Playwright 1.58.0 in an environment without python-telegram-bot installed. Real synthetic clips verify H.264/AAC MP4 output, fast-start metadata, preservation of 60 fps and variable frame timestamps, selected 30/24 fps limits, resolution and quality controls, silent portrait videos, rotation metadata, HDR-to-BT.709 tone mapping, and full decode after two-pass size fitting without truncation. The size-fitting test uses a reduced byte limit to exercise the same bitrate budgeting and final-size checks without an unnecessarily large fixture.

Native aiogram integration checks use its actual multipart builder, response decoder and bot-bound Update/CallbackQuery models with a controlled transport. They cover caption links and topic routing, durable admission before polling acknowledgement, command registration, clean shutdown and session closure, streamed photo/document albums, full-file video fallback, audio filename/metadata/thumbnail uploads, rate-limit retries, settings ownership and language selection, deduplicated manual audio jobs, group migration and blocked broadcast recipients. Network interruptions, HTTP 500 and malformed upload responses retain uncertain delivery intent; definitive HTTP 403/404/413 rejections clear it, with the existing 50 MB error for HTTP 413. The ID helper also closes its session without logging the token.

Controlled downloader/bot tests cover All as the default, the exact 50 MB boundary, unchanged small videos in Over 50 MB mode, the existing error with None, video-only larger input limits, per-user ownership and persistence, reset behavior, all five languages, job settings snapshots across retries/recovery, and stable delivery receipts when encoded bytes change. Existing queue, audio, cookie isolation, reply routing and broadcast tests passed. Dependency checks, Python compilation, workflow YAML parsing, all shell/Python block syntax checks and the workflow's encoder availability checks passed. No live Telegram upload, TikTok download or GitHub Actions run was performed for this update.

## Cookies limited to Chromium, 2026-10-03

54 automated tests passed with Python 3.12 and the pinned gallery-dl, Telegram and Playwright versions. Controlled requests verify that short links, video/photo downloads, automatic and manual post audio, and normal sound-page/detail extraction never load the saved cookie file or attach its login cookies. A simulated Chromium context verifies cookie import only after the fallback starts, no cookie export to the HTTP downloader, browser cleanup, and anonymous fallback when the file is absent or invalid. Existing delivery, queue, settings, restart and broadcast tests passed. Dependency consistency and Python compilation passed. No live TikTok or Telegram test was performed; the workflow and Chromium cache configuration are unchanged.

## Replies to link messages, 2026-10-02

43 automated tests passed. Existing delivery checks now verify replies to the originating link message for videos, photo albums, resumed album batches, and video-to-document fallback, including group topic routing. Audio still replies to the delivered media, and repeated manual extraction clicks remain deduplicated. Python compilation and dependency checks passed. No live Telegram upload was performed.

## Video audio controls, 2026-09-30

43 automated tests passed with Python 3.12, gallery-dl 1.32.13 and python-telegram-bot 22.8. Dependency consistency and Python compilation passed. Controlled responses cover videos with automatic audio, videos with the manual button, mandatory photo audio with Audio Off, sound-only downloading without fetching video/image bytes, document fallback with the button, callback ownership and chat validation, queue limits, repeated-click deduplication, reply-to-video and topic routing, database restart recovery, and the existing owner broadcast behavior. Telegram/TikTok sending was not verified live; no bot token was supplied.

Checked on 2026-09-25 with Python 3.12.14, gallery-dl 1.32.13, and python-telegram-bot 22.8

## Passed

- 16 automated tests using pytest, including the real gallery-dl TikTok extractor with controlled video and photo responses
- Four active slots and four waiting slots per normal user, queue advancement and independent users
- Separate exempt account slot, unlimited exempt backlog, replayed-update deduplication
- Recovery of pending work and preservation of confirmed upload receipts
- Ambiguous Telegram sends are not automatically repeated
- Photo batches retain all images and skip batches already confirmed as sent
- Owner-only shutdown and cancellation ownership checks
- Clean shutdown writes both the session receipt and Telegram update cursor
- Unsupported Telegram video delivery falls back to the unchanged file
- URL restrictions and rejection of non-post URLs
- Oversized response header and streaming-body checks, including exact boundary size
- Safe ZIP source import excludes queue data and credentials
- R2 backup verification occurs before deleting previous backups, credential files excluded
- Workflow action references use @main and shutdown blocks automatic continuation
- Actionlint 1.7.12 passed for the workflow, shellcheck was not available
- Python source compilation and dependency consistency checks passed

## Not verified live

Live public TikTok video, photo, and shortened-link attempts did not produce downloadable media in this execution environment
A follow-up diagnostic showed DNS resolution failures for TikTok hosts, so these attempts do not establish whether those posts work from a GitHub runner

Telegram sending was tested with controlled bot responses, no real bot token was provided
R2 backup operations were tested with a simulated S3 client, no live R2 credentials were provided
The workflow was checked with Actionlint but was not launched on GitHub

After configuring the secrets, first run with continue disabled and send one video and one photo post to verify access from your runner


## Audio update validation

25 automated tests passed, including real gallery-dl extractor fixtures for video and photo posts with music metadata, reading back embedded MP3 title/artist/album/cover/IDs/duration, preserving the audio payload, safe filenames and ID fallback, the post-tagging size limit, Telegram audio reply metadata, album replies, database migration, confirmed-delivery recovery and uncertain audio uploads. M4A tagging uses Mutagen's MP4 API but was not verified against a live TikTok M4A download. No live Telegram or TikTok upload test was performed for this update.

Full-resolution cover update: 27 tests passed, including exact embedded JPEG/PNG byte preservation, full-size WebP-to-PNG artwork, and separate Telegram thumbnail dimensions.
