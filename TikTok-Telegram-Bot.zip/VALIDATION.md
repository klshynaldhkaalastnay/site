## Structured TikTok errors and region restrictions, 2026-10-27

587 automated tests passed on CPython 3.12.14, including 84 targeted extraction, share-link, language and cookie-isolation tests. Dependency consistency and all Python syntax passed.

The supplied screenshot confirms successful URL resolution and gallery-dl iteration, followed by reported_error and no_media. It does not include TikTok's underlying status. An anonymous live call through the real gallery-dl post extractor for the reported ad returned statusCode 10231 with no itemInfo. The current upstream gallery-dl implementation identifies this code as Region locked. A second live call through the updated per-extractor wrapper reproduced RegionLocked and the exact safe diagnostic stage=extractor reason=region_locked status=10231. These calls establish the response from this test environment, not necessarily the location or response of the user's GitHub runner. No live media was downloaded and no Telegram messages were sent.

The worker now preserves structured nonzero numeric post status codes before gallery-dl formats an error line. Known statuses identify an unavailable post (10204), missing account (10221), login requirement (10222) or region restriction (10231). Unknown numeric codes retain their number with post_error. The wrapper belongs to one extractor instance and restores its original status handler and logger afterward. Raw status messages, URLs, response bodies and credentials remain excluded from diagnostics. No extra network request is needed to capture the status.

A confirmed 10231 response returns region_locked to the bot. It ends that request without the ordinary three automatic retries and shows a translated message about the bot server's region in all ten supported languages. The existing WorldBox text rule, queue completion, temporary-file cleanup and other error handling remain intact. Fourteen additional cases cover safe worker result files for region/unavailable/unknown statuses, wrapper restoration and isolation, and native aiogram delivery in every language with one worker call and no media uploads. Existing ad/video/photo extraction, cookie isolation, audio/subtitle/caption/metadata modes, compression, queues, backups, owner commands and reports also passed.

ZIP integrity, packaged-source imports and the native gallery-dl ID-only route passed. The workflow is byte-identical to the previous ZIP and needs no update. No proxy or saved-cookie fallback is added, and this change does not remove a TikTok region restriction. No GitHub Actions, R2 or native Telegram API server operation was performed. Replace the hosted ZIP and run with force_reimport enabled to load this update.

## ID-only ad routes and extraction diagnostics, 2026-10-27

573 automated tests passed on CPython 3.12.14, including 68 targeted share-resolution, real gallery-dl extraction and cookie-isolation checks. Dependency consistency and Python syntax passed.

The supplied short link was verified to return a 301 redirect to m.tiktok.com/v/7699650081980484872.html with both preview and generic browser user agents. The screenshots confirm resolution succeeds in the deployed bot, but its previous last diagnostic, resolve/post followed by ValueError, cannot establish which later extraction or media step failed. Full live downloading of this ad remains unverified. Anonymous post-page probes mostly timed out; one ID-only page probe returned HTTP 200, without establishing usable post metadata. No live TikTok media was downloaded and no Telegram messages were sent.

Older mobile, app and embed targets now use TikTok's /share/video/{id} route. The real gallery-dl post extractor turns this into its native /@/video/{id} request, avoiding the previous invented underscore username. Empty-creator canonical page targets are recognized as well. Two added integration cases resolve a mobile redirect, exercise gallery-dl's real post extractor against controlled metadata marked isAd, download fixture video/photo bytes, and preserve the numeric ID, caption and full metadata. These fixtures demonstrate the bot's handling when TikTok exposes media; they do not prove live accessibility of an ad-only creative.

A separate error-handling bug was reproduced: calling the extractor directly leaves its ordinary Python logger without the traceback method gallery-dl expects on failure. A scoped diagnostic logger now supplies that method and retains safe exception classes and access-refusal categories without forwarding raw messages, signed URLs, page contents or cookie values. Diagnostics distinguish extractor selection, iteration, post metadata, no returned media and an invalid video response. Tests cover real extractor ValueError/KeyError/authorization failures, unavailable/deleted/private/region-blocked post responses, selection failures, HTML served as video and safe worker result files. The remaining settings, queue, file-delivery, compression, subtitle, caption, metadata, backup and reporting regressions passed.

ZIP integrity and packaged-source imports passed. The workflow is byte-identical to the previous ZIP and needs no update. No GitHub Actions, R2 or native Telegram API server operation was performed. Replace the hosted ZIP and enable force_reimport on the next workflow run, then retry the ad link. A resolved ID still cannot make inaccessible ad-only media public; the new diagnostics identify the next failure if TikTok withholds it.

## TikTok ad share links and older mobile redirects, 2026-10-27

560 automated tests passed on CPython 3.12.14 with aiogram 3.31.0, gallery-dl 1.32.18, Playwright 1.64.1, mutagen 1.48.1 and cryptography 50.0.2. Dependency consistency passed.

An anonymous HTTP request using gallery-dl's link-preview user agent verified that the supplied ad short link returns a 301 redirect to m.tiktok.com/v/{id}.html. The previous normalize_url rejects that older mobile path, matching the reported resolution-stage ValueError. The new conversion preserves the observed numeric post ID and reaches gallery-dl's single-post extractor. Full live resolution/download could not be verified in this execution environment: the normal browser probe and canonical-page probe timed out, while the worker's proxy-free session encountered unavailable DNS. No TikTok media was downloaded and no Telegram messages were sent.

The resolver now prefers the same link-preview user agent as gallery-dl, recognizes older mobile/share/embed URLs and explicit TikTok app targets, and converts them to ordinary post URLs. A post-identifying redirect is handled before a redundant final-page request. For share pages returning HTML, bounded parsing can recover the page's canonical/Open Graph/app/refresh target or its TikTok rehydration canonical field. A fresh anonymous desktop session is attempted if needed. Two user-agent attempts, finite redirect hops, a one-megabyte page cap and a 45-second resolution budget bound the fallback. Direct post and sound links retain their no-resolution-request path. Saved cookies are still read only by Chromium sound downloading.

Thirty-seven added cases cover valid targets and real redirect chains, mobile/photo/music/app/embed targets, canonical metadata and rehydration data, fresh cookie-free fallback sessions, access refusals and HTTP failures, foreign/private/credential-bearing/invalid-scheme destinations, spoofed domains, recommended-post false positives, redirect loops, page size/time budgets and unchanged media streaming. Existing filename, file-delivery, queue, compression, owner, backup and diagnostics checks also passed. Diagnostics retain controlled reasons and exception classes without URLs, page content or cookie values.

All Python syntax and ZIP integrity passed. The workflow is byte-identical to the previous ZIP and needs no update. No GitHub Actions or native Bot API server run was performed. Replace the hosted ZIP and enable force_reimport on the next workflow run.

## Single-photo document filenames, 2026-10-22

29 file-delivery tests passed. Six direct checks through aiogram's native multipart builder passed for video documents, a single photo, two-photo and 23-photo posts, an eleven-photo post resumed with only its final photo unsent, and a manual single-photo file request with a WebP extension.

Single-photo posts now use {post_id}.{ext} when sent as files, including manual file requests. Posts containing multiple photos retain {post_id}_{photo_number}.{ext}. The decision counts the complete post before filtering saved receipts, so a final unsent photo keeps its original numbered filename. Only the upload name changes, file bytes and delivery receipts are preserved.

Python syntax and ZIP integrity passed. The workflow and all unrelated source files remain unchanged. No live Telegram messages, TikTok downloads or GitHub Actions runs were performed. Replace the hosted ZIP and enable force_reimport on the next workflow run.

## Numeric post filenames for media documents, 2026-10-22

71 targeted automated tests passed, including file delivery, photo albums, action buttons and audio behavior. Nine direct checks through aiogram's native multipart builder passed for single videos/photos, 23-photo albums, MP4/WebM output extensions, compressed temporary filenames, numeric IDs returned for short links, resumed albums after ten saved receipts, manual file requests with mixed JPG/WebP photos and the ordinary media modes. Python syntax passed.

When Send as files is On, video documents use {post_id}.{ext} and photo documents use {post_id}_{photo_number}.{ext}. Photos are numbered from 1 across the complete post before filtering saved delivery receipts, preserving numbers through ten-file batches and recovery. Manual Send as files requests use the same names. The numeric ID comes from the extracted post metadata, with saved IDs and the canonical post URL as fallbacks. The delivered file's final extension is retained, including compressed MP4 output. Only the upload filename changes, downloaded bytes and receipt identities are preserved.

The workflow and all unrelated source files are unchanged. No live Telegram messages, TikTok downloads or GitHub Actions runs were performed for this update. Replace the hosted ZIP and enable force_reimport on the next workflow run.

## Send videos and photos as Telegram files, 2026-10-21

523 automated tests passed on CPython 3.12.14 with aiogram 3.31.0, gallery-dl 1.32.17, Playwright 1.64.0 and cryptography 50.0.2. Dependency consistency and syntax checks passed.

Settings now offers Send as files with On, Off and Off with no button, defaulting to Off with no button. The saved per-user choice is snapshotted when a request starts. On uploads videos/photos as documents; Off retains normal media and adds an owned Send as files reply to the first delivered video/photo; Off with no button retains normal media. All ten languages are covered. Existing compression choices still apply, and the unchanged local API upload bound is 2 GBs. Photo documents retain their downloaded bytes, groups split at ten and subsequent groups reply to the preceding group with only the linked bot attribution.

Twenty-nine added cases cover native aiogram multipart uploads and exact bytes, single videos/photos and 23-photo posts, all three modes, language settings and callback ownership, preference snapshots, source compression reuse, per-user concurrency, ordinary secondary queues and owner/bypass waiting exemptions. File button requests get independent identities, delivery receipts and durable 100-second cooldowns before acknowledgement. After cleanup/restart they fetch the post again and send only its videos/photos, replying to the original delivered media without extra audio, subtitle, caption or metadata attachments. Worker arguments omit auxiliary downloads. Original post requests retain those preferences, and sound links remain audio posts.

Tests also cover rejected versus unconfirmed button sends, confirmation from the correctly owned and routed reply, safe button retry, invalid requester/chat/message/topic, cancellation/shutdown, upload rejection versus unknown delivery, replayed callbacks, no duplicate media, and additive migration from a database without the new file fields. Existing queues, settings and delivery receipts are retained. The workflow remains byte-identical to the previous version and needs no update. No live Telegram messages, TikTok downloads, R2 operations, native Bot API server or GitHub Actions run was performed. Replace the hosted bot ZIP and enable force_reimport on the next workflow run.

## Per-user queue modes, compression checkmark and size labels, 2026-10-21

494 automated tests passed on CPython 3.12.14 with aiogram 3.31.0, gallery-dl 1.32.17, Playwright 1.64.0 and cryptography 50.0.2. Dependency consistency and syntax checks passed.

Settings now offers Queue with Five at once (default) or One at a time. The selected mode is saved per user, including owner/bypass users who choose it. Nine added regressions verify admission, independent users, FIFO completion through secondary batches, changing modes before or during running work, no dropped requests, restored settings and limits, owner/bypass waiting exemptions, uncertain delivery receipts, native aiogram callback ownership, translated menus and actual scheduler concurrency. Running downloads finish normally when the limit is reduced, while unstarted work is returned to the appropriate waiting queue. Normal users retain ten regular waiting slots and the unlimited secondary queue, and owner/bypass users retain unlimited regular waiting. Audio and subtitle extraction use the same admission path and saved active limit.

Selecting None hides the Advanced compression checkmark while retaining customized values. The mark returns when compression is enabled again. Direct checks covered all ten languages in both cloud and local API modes. Local size errors, help and startup output now use 2 GBs in English and corresponding gigabyte labels in translations, including Persian numerals and French unit variants. The actual 2,000,000,000-byte local upload/input limit, exact 50,000,000-byte compression threshold and All videos default remain unchanged. Cloud-mode labels and limits remain correct.

The bundled workflow is byte-identical to the existing standalone tik.yml. No live Telegram authorization, TikTok download, R2 operation, native C++ server or GitHub Actions run was performed. Replace the hosted bot ZIP and enable force_reimport on the next workflow run to load these changes.

## Idempotent cloud logout and safe control errors, 2026-10-21

485 automated tests passed on CPython 3.12.14 with aiogram 3.31.0, gallery-dl 1.32.17, Playwright 1.64.0 and cryptography 50.0.2. Dependency consistency passed.

The cloud migration step now treats Telegram's explicit HTTP 400 Logged out response as a completed logout. HTTP errors are parsed into safe status/retry fields, with no raw exception URL, response body or response description printed. Real bot-token authorization failures remain failures and show the HTTP status plus the relevant secret names. Local invalid api-id/api-hash responses identify the app credentials and stop the server immediately rather than polling until the readiness timeout. Error envelopes inside HTTP 200 responses are also rejected.

Cloud rate limits honor retry_after, transient server/transport failures retry, and both attempt count and total waiting are bounded. Pauses are at most 60 seconds each, with progress output during longer cooldowns. Native authorization rate limits also honor declared waits and may extend readiness within a bounded setup budget. Excessive retry delays fail with a useful safe status instead of waiting indefinitely. Sixteen additional regressions cover already-logged-out migration, status parsing, token/hash redaction, exact cooldown delays, transient recovery, invalid tokens, local rejection cleanup and bounded cloud/native waits. Earlier directory, encrypted state, queue and bot behavior tests remain passing.

All source syntax, workflow YAML, 23 shell blocks and eight embedded Python blocks passed. The bundled workflow remains byte-identical to the existing compiler-fixed standalone tik.yml. No live Telegram requests, TikTok downloads, native C++ server execution, R2 operations or GitHub Actions runs were performed. The supplied traceback identified cloud logOut but omitted its HTTP status, so its exact Telegram response was not confirmed. Replace the hosted bot ZIP and enable force_reimport on the next workflow run to load the corrected helper.

## Native startup directory fix and safe diagnostics, 2026-10-21

469 automated tests passed on CPython 3.12.14 with aiogram 3.31.0, gallery-dl 1.32.17, Playwright 1.64.0 and cryptography 50.0.2. Dependency consistency passed.

The startup helper now creates database, auxiliary files and temporary directories with mode 0700 before launching Telegram. The official native server canonicalizes the supplied files directory before creating it, so a missing files directory caused immediate startup failure. The controlled native-server fixture now performs strict path resolution on all three launch directories; first launch, clean checkpoint, restart and encrypted-state restore passed with that requirement. Copied app credentials are normalized before entering the child environment.

Native stdout/stderr now go to a mode-0600 file inside the private runner temporary directory, outside all cached and backed-up paths. Startup exit or readiness timeout prints only a bounded, redacted tail. New regressions verify a real child process exiting with code 23, useful error text, API-hash and bot-token redaction including surrounding whitespace, clearing the dead PID, bounded excerpts with partial first lines dropped, and refusing symlinked runtime directories. Existing two-stage queues, owner/bypass exemptions, extraction settings, delivery receipts, compression and Telegram reporting passed.

All Python sources, workflow YAML, 23 shell blocks and eight embedded Python blocks passed syntax checks. The bundled workflow matches the existing standalone workflow version that selects Clang for both C and C++; no new standalone workflow is required. The full C++ server and live Telegram authorization were not run here, and no live Telegram messages, TikTok downloads, R2 operations or GitHub Actions runs were sent. Replace the hosted bot ZIP and run with force_reimport enabled to load this helper update.

## Local Bot API and two-stage request queues, 2026-10-21

466 automated tests passed on CPython 3.14.8 with aiogram 3.31.0, gallery-dl 1.32.17, Playwright 1.64.0 and cryptography 50.0.2. Dependency consistency passed.

The local API checks cover 2 GBs upload and video-input bounds, the extended upload timeout, the unchanged exact 50 MB compression threshold and All videos default, native aiogram endpoint configuration, acceptance of an original video above 50 MB, translated local size errors/help, loopback endpoint validation, secret redaction, and native server version output on stderr. Encrypted native state roundtrips, tampering, a changed API hash, bot-token rotation, unsafe archive paths, process identity guards, matching R2 state restoration and missing-state rejection are exercised. A controlled local HTTP server subprocess verifies start, cloud deregistration, clean checkpoint, encrypted snapshot, restart and restore. Only process identity/liveness probes are adapted in that test because this execution environment exposes a host /proc from a different PID namespace; production retains strict Linux /proc identity checks. No real Telegram authorization was performed.

Actual scheduler tasks verify five simultaneous requests independently for multiple users, including the bypass account. Native aiogram update handling verifies that normal users get five active slots, ten regular waiting slots and an unlimited secondary backlog; owners and the bypass account get five active slots and unlimited regular waiting requests. Secondary work stays blocked until both active and regular waiting work have fully drained, then releases up to five active and ten regular waiting requests in order. New arrivals cannot overtake a secondary backlog. Restart recovery, repeated batches, completion/cancellation/failure, exemption changes, queue display/cancellation, aggregate stats, and audio/subtitle button cooldowns in both waiting queues passed. Existing settings, extraction, delivery receipts, metadata, captions, cookies, backups, owner commands and grouped dependency notices remain covered.

The log supervisor treats native-server death as a failed session even if the bot handles shutdown and exits zero. Existing hourly/final logging checks allow the last line to be acknowledged by either flush without duplication. Both source importers refresh older application caches missing either local API helper. The workflow keeps the custom 20,400-second session, TELE_ZIP source secret, TELE_OWNER_ID mapping, compatible Python range, original media-tool caches, receipt/backup/continuation gates, and Telegram-only diagnostics. It adds compiled native-binary caching and encrypted native state beside the queue snapshot. Source syntax, YAML parsing, 23 shell blocks, eight embedded Python blocks, the per-run-block size bound, and matching standalone/packaged workflows passed.

The official native source and pinned TDLib submodule were retrieved and its launch/version options checked. A real CMake configure found the compiler, OpenSSL and zlib but stopped at missing gperf. This container cannot install that system dependency, so the real C++ build remains unverified here; the workflow installs it on the Ubuntu runner before building. No live Telegram messages, TikTok requests, R2 calls or GitHub Actions runs were sent. First deployment must supply TELEGRAM_API_ID and TELEGRAM_API_HASH, replace both source ZIP and workflow, and reimport the updated source.

# Validation

## Owner statistics command, 2026-10-21

436 automated tests passed on CPython 3.14.8. Fifteen new cases verify owner access before language selection in private chats and forum topics, denial for ordinary and queue-exempt users, addressed-command filtering, saved-history/status/queue/24-hour totals, duplicate user records, aggregate-only output, read-only reporting, translated reports and owner help in all ten languages, safe report failures and history retained through SQLite backup and session restart. Statistics do not start dependency/system probes or media downloads, and remain absent from the public command menu.

The owner-only /stats command replies in code formatting with session uptime, recorded users and chats, stored active-chat records, saved request totals by status, running/ready/waiting counts and requests/requesters from the last 24 hours. Counts come from existing saved records, uptime resets each session, and no tracking migration or settings change was required. Crash reporting and workflow behavior from the same update remain covered by the full passing suite. ZIP integrity, actual imported source, matching workflows and unchanged compression/default settings also passed.

## Crash and error reporting, 2026-10-21

421 automated tests passed on CPython 3.14.8 with aiogram 3.31.0, gallery-dl 1.32.17, Playwright 1.64.0 and boto3 1.43.116. Nineteen additional cases cover the native polling conflict and actual bot entrypoint, original nonzero and signal exit codes, process-spawn failure, quiet normal shutdown, background runtime alerts, bounded error grouping and retry counts, credential redaction, context retained after hourly uploads, crash priority during a slow log upload, final workflow failures and cancellation, unavailable diagnostics and confirmed-crash deduplication. The native conflict leaves saved jobs available and does not write a clean-session receipt.

Crashes, runtime warnings/errors and failed workflow steps now report to -1004434678187 with #crash, #warning or #error, sanitized text attachments and workflow links. Runtime errors are sent by the supervisor in the background, repeated matching errors are grouped for five minutes, and pending groups are flushed on exit. Tracebacks include exception classes and stack locations without exception messages, source lines, local variables or Telegram request representations. Existing hourly/final logs, grouped dependency updates, settings and continuation failure gates remain intact.

The standalone workflow embeds both stdlib reporting helpers before application setup, every step has an ID for outcome reporting, and only outcome/ID fields enter failure reports. Both source importers refresh a cache missing the crash-report helper while preserving state. Workflow YAML, all shell blocks, five embedded Python blocks, source syntax, custom session/secret settings and matching workflow copies passed. Package integrity, imported source and unchanged-file checks also passed. The local Playwright driver executable bit was restored in the isolated test environment. No live Telegram messages, TikTok requests, R2 calls or GitHub Actions runs were sent. Complete runner termination, Telegram unavailability or invalid/missing credentials can prevent delivery.

## Grouped dependency update notices, 2026-10-14

402 automated tests passed on CPython 3.14.8. Changes from the same startup check now share one #update header, a blank line and one dependency/version transition per line. The native aiogram regression reproduces the screenshot's Playwright, pyee and Chromium changes in one message. Existing restart and failure checks now verify atomic confirmation of all versions within that message. A second new regression verifies complete-line splitting at Telegram's limit and retries only a failed group while retaining confirmed groups. Initial baselines, unchanged versions and new installs remain silent. No live Telegram messages, TikTok requests, R2 calls or GitHub Actions runs were sent.

Package consistency, changed Python syntax, ZIP integrity and actual packaged-source import passed. The workflow and every unrelated source file are unchanged. Replace the hosted ZIP and restart with ZIP reimport to load this code update.

## Full metadata in JSON, XML or TXT, 2026-10-13

400 automated tests passed on CPython 3.14.8, followed by targeted metadata/settings checks after the final recovery-message addition. Twenty-four new regressions cover complete gallery-dl directory metadata before mutation, disabled capture, Unicode/nested JSON/TXT and XML roundtrips, all ten languages, preference ownership and snapshots, automatic video/album document replies, full captions alongside TXT metadata, old database migration, compressed metadata backups, requester/chat/topic binding, 100-second cooldowns and duplicate callback protection, lost button acknowledgements and restart handling for rejected versus unconfirmed uploads. No live Telegram messages, TikTok requests, R2 calls or GitHub Actions runs were sent.

Metadata defaults to Off with no button and JSON format. Delivery and format are separate settings, with automatic files or an owned request button as selected. Files use the numeric post ID plus .metadata and the selected extension, leaving full-caption filenames unchanged. Source metadata comes from the existing anonymous extractor response, without another download request or reading cookies/credentials. Sound links and audio/subtitle-only requests do not export metadata. Compression remains All videos by default and existing dependency update notices and diagnostics/log uploads are retained.

Package consistency, Python syntax, workflow YAML, all shell blocks and five embedded Python blocks passed, with only new helper requirements added to the custom workflow. Both workflow copies match. ZIP integrity and actual packaged-source import passed, with metadata helpers present. The local Playwright driver executable bit was restored in the isolated test environment.

## Dependency update notices, 2026-10-12

376 automated tests passed on CPython 3.14.8 with aiogram 3.31.0, gallery-dl 1.32.16, Playwright 1.63.0 and boto3 1.43.112. Ten new regressions cover native aiogram text/target fields, initial baseline silence, changed versions and new installs, transitive packages and tool availability, corrupt baselines, failed-send retries without repeating confirmed notices, restart persistence, safe error logging, background cancellation and baseline retention inside a SQLite backup. No live Telegram messages, TikTok requests, R2 calls or GitHub Actions runs were sent.

The bot now checks versions in a background task each startup and sends one #update notice per changed dependency to -1004434678187. The baseline is stored in backed-up SQLite metadata, with unavailable tools omitted from comparison. Both importers require the new helper so older cached source refreshes from the hosted ZIP. The compression module is byte-for-byte unchanged and still defaults to All videos, following the user's cancellation of the requested default change.

Package consistency, Python syntax, workflow YAML, every shell block and five embedded Python blocks passed. The custom 20400-second session, secret names, latest compatible Python range and Telegram log reporting remain intact. ZIP integrity and actual source import passed, with identical embedded and standalone workflows and the new helper present. The local Playwright driver executable bit was restored in the test environment, as in the previous validation.

## Python 3.14 compression namespace fix, 2026-10-11

The exact compression._common startup error was reproduced on CPython 3.14.8 before the change. The application module was renamed from compression.py to video_compression.py, with bot/worker imports and both source-importer requirements updated. Legacy cached applications refresh automatically, and legacy hosted ZIPs are rejected before starting the bot. Existing compression settings and queue state remain unchanged.

366 automated tests passed on CPython 3.14.8 with aiogram 3.31.0, gallery-dl 1.32.16, Playwright 1.63.0 and boto3 1.43.111. Nine new regressions cover a fresh subprocess importing backup/boto3/bot/worker, gzip/bz2/lzma/ZIP roundtrips, both importers refreshing old or mixed source caches while preserving state, current-cache reuse and outdated ZIP rejection. The locally installed Playwright driver initially lacked its executable bit; it was corrected in the test environment before the complete passing run, with no corresponding application change.

Package consistency, workflow YAML, all shell blocks, five embedded Python blocks and custom workflow settings passed. ZIP integrity, actual packaged source import and the backup restore command against a saved state database passed on Python 3.14.8. The standalone workflow matches the ZIP workflow and retains Telegram diagnostics/hourly logs. No live Telegram messages, R2 calls or GitHub Actions runs were sent.

## Latest aiogram-compatible Python, 2026-10-11

Both workflow copies now select the latest stable Python in the range >=3.12 <3.15, with check-latest enabled, matching the application's minimum Python and aiogram 3.31.0's upper bound. The pip cache uses the resolved Python version to avoid mixing interpreter caches. Automatic package upgrades, the custom TELE_ZIP and TELE_OWNER_ID names, the 20400-second session and Telegram diagnostics/hourly log uploads are preserved.

A pip dry-run resolved all 33 packages for Python 3.14, including native CPython 3.14 wheels for Pillow, aiohttp, greenlet and pydantic-core. Two existing workflow checks passed, as did YAML, every shell block, five embedded Python blocks, unchanged custom setting comparison, ZIP integrity and importing the packaged project. Python 3.14 runtime execution and a live GitHub Actions run were not performed in the local Python 3.12 environment. No bot Python code or package version requirements changed.

## Telegram diagnostics and hourly logs, 2026-10-11

357 automated tests passed, including multipart document uploads to the configured chat, credential redaction, safe upload failures, bounded log retention, concurrent log appends during upload, hourly and final uploads, child exit codes and SIGTERM forwarding. No live Telegram messages or GitHub Actions runs were sent.

The custom workflow now embeds a stdlib-only reporter before setup steps, runs the bot under its hourly log supervisor and sends end-of-run diagnostics to -1004434678187 instead of GitHub artifacts. Runtime log upload failures do not stop the child bot or change its exit code. The custom TELE_ZIP and TELE_OWNER_ID secret names and 20400-second session are preserved. Both workflow copies match. YAML parsing, every shell block, five embedded Python blocks and package consistency passed. ZIP integrity and importing the packaged project passed. Forced runner termination and the destination chat's live posting permissions were not tested.

## Latest stable Python 3 workflow, 2026-10-11

Both workflow copies now use python-version 3.x with check-latest enabled. The setup step exposes its resolved Python version, which is included in the pip cache key and restore prefix alongside OS and architecture. Workflow YAML, step ordering, output references, all shell syntax and embedded Python syntax passed, as did ZIP integrity and the actual source importer. Only the workflow and documentation changed; no new bot tests were added. The latest Python selected by GitHub Actions was not executed in this local Python 3.12 environment, and no workflow run was launched.

## Automatic dependency upgrades, 2026-10-11

349 automated tests passed after upgrading against the updated requirements, resolving aiogram 3.31.0, gallery-dl 1.32.16 and Playwright 1.63.0. Exact pins for those three packages were replaced with minimum supported versions. Startup now uses pip install --upgrade, while the existing boto3, Pillow and Mutagen compatibility ranges remain unchanged. The dependency-report integration check now accepts the versions actually installed rather than asserting an old fixed release.

The workflow records the installed Playwright version and uses it with runner OS and architecture for the Chromium cache key, keeping cached browser binaries aligned with package upgrades. Package consistency, workflow YAML, all shell syntax and three embedded Python blocks passed. Executing the new version-output block produced the expected installed Playwright version. ZIP integrity and the actual source importer passed, and the standalone workflow matches the workflow inside the ZIP. No live Telegram messages, TikTok requests or GitHub Actions runs were sent for this update.

## Owner-only /dpend command, 2026-10-11

349 automated tests passed with aiogram 3.31.0 and gallery-dl 1.32.13. The dependency report reads installed runtime package metadata, the Python version and local FFmpeg, ffprobe, Chromium and neofetch versions. Cached executables are preferred, missing or failed probes leave a partial report, and five-second timeouts and cancellation terminate probe process groups. Version-number dots are preserved in escaped Telegram code blocks.

Native aiogram checks cover owner access before language selection, ordinary and queue-exempt user denial without probing, private/group/topic replies, commands addressed to another bot, long Unicode output, translated errors, owner-only help in all ten languages and exclusion from the public command list. A real Playwright driver resolved an isolated cached Chromium executable for the version-only probe; checks also cover a missing browser, cached FFmpeg/neofetch and stalled subprocess cleanup. A local report returned all six runtime package versions and the installed FFmpeg/ffprobe versions, with missing Chromium/neofetch marked correctly.

Dependency consistency, changed Python syntax, ZIP integrity and the actual ZIP source importer passed. The workflow and requirements are unchanged. No live Telegram messages, TikTok requests or GitHub Actions runs were sent for this update.

## Owner-only /specs with ASCII art, 2026-10-10

323 automated tests passed with aiogram 3.31.0 and gallery-dl 1.32.13. /specs now checks the sender against the configured owner before starting neofetch. Ordinary users and the queue-exempt account receive the translated owner-only denial, including before language selection and in groups or forum topics. The command is removed from the public command menu and public help, and appears in owner help in all ten languages.

The cached executable now runs with --config none --backend ascii --color_blocks off. Removing terminal color and cursor sequences leaves the distro ASCII logo above the current system details in the escaped Telegram code block. Native aiogram checks cover owner access before onboarding, ASCII whitespace and markup preservation, reply/topic fields, denial without starting the subprocess, owner-only help, and command registration. Existing Unicode splitting, installed fallback, missing/empty/nonzero results, timeout and cancellation cleanup checks passed.

The official cached neofetch script returned 20 ASCII lines and current OS, CPU and memory fields in one clean 953-character code block. Python syntax, translation keys and placeholders, ZIP integrity and the real source importer passed. The workflow is unchanged. No live Telegram messages or GitHub Actions runs were sent for this update.

## Public /specs command, 2026-10-10

317 automated tests passed with aiogram 3.31.0 and gallery-dl 1.32.13. /specs is registered as a public Telegram command and available to ordinary users, the owner and the queue-exempt account in private chats, groups and forum topics, including before language onboarding. It invokes the cached ~/.neofetch/neofetch executable with --stdout, with a PATH fallback for local installations. Results are escaped and sent in Telegram preformatted code blocks replying to the command in the originating topic. Terminal escapes are removed, Unicode output is split within Telegram's message limits, and raw system values retain their punctuation. Help and the generic failure message cover all ten interface languages.

Native aiogram checks cover public access, bot-addressed commands, ignored extra arguments, reply/topic fields, escaping, long Unicode output and advertised commands. Real subprocess checks cover cache preference, installed fallback, missing/empty/nonzero results, timeout handling and cancellation cleanup. The official neofetch script also ran successfully through the cached-path helper, returning clean OS, CPU and memory fields in one code block. Catalog keys and placeholders, Python syntax and pip dependency consistency passed. The workflow remains unchanged. No live Telegram messages or GitHub Actions runs were sent for this change.

## Neofetch executable cache, 2026-10-07

The workflow restores ~/.neofetch before printing system information and saves a new cache immediately afterward, before checkout and the bot session. It caches the executable script only, so each run still reports its own current system details. A cache hit skips apt entirely; a miss copies an existing neofetch command or installs it once and copies it into the cache. The key is scoped to runner OS and architecture and is separate from the source/state caches targeted by rotation. YAML structure, matching restore/save paths, Bash syntax, isolated cache-hit, preinstalled and fresh-install branches, and repeated cached runs all passed. Existing workflow settings and bot steps are unchanged, and standalone and bundled workflow copies match. No live GitHub Actions run was performed for this change.

## WorldBox interface punctuation, 2026-10-07

Applied the interface punctuation rule to all ten languages: internal periods and semicolons become commas, and line-ending periods are removed. Japanese and fullwidth punctuation use the corresponding local commas. Messages ending in three dots remain completely unchanged. Updated 90 interface texts and help entries, retaining all 50 three-dot messages exactly. Styling applies to authored translation values before interpolation, leaving translation keys, command names, format placeholders, inserted numbers and URLs, TikTok captions and the bot attribution link intact. All 302 automated tests passed after this change, in addition to the catalog, placeholder, ellipsis and interpolation checks.

## Neofetch at workflow startup, 2026-10-07

The first bot job step installs neofetch with apt only when the command is missing, then runs it before checkout on every session. The standalone tik.yml and the workflow bundled in the source ZIP match. YAML structure and shell syntax were checked, and every existing workflow step remains unchanged. No live GitHub Actions run was performed for this change.

## Four additional languages, restart import choices and private owner ZIPs, 2026-10-07

302 automated tests passed with aiogram 3.31.0 and gallery-dl 1.32.13. Japanese, Portuguese, French and German are available in onboarding and Settings, bringing the total to ten languages. Each new language covers all 131 English message keys with matching format placeholders, translated help and owner help, saved preferences, setting choices and restart/backup controls. The menus use two buttons per row. Hindi and Urdu are not added.

The owner-only /restart command waits for Restart and reimport ZIP, Restart without reimport, or Cancel. Native aiogram tests cover user/chat/message/topic ownership, replaced and replayed prompts, cancelled decisions, shutdown conflicts, acknowledgement/edit failures, and correctly bound prompts with lost acknowledgements. A clean session receipt carries the import choice to the existing workflow dispatch helper. Controlled dispatch checks verify the next run's force_reimport input, preserved continue choice, and false defaults for older receipts or other stop reasons. Reimport is limited to the selected replacement session; a fresh Runner does not inherit the flag.

The owner-only /upload command sends a ZIP privately, including commands issued in groups, and waits for shutdown or restart. Native multipart checks verify actual ZIP bytes, a consistent SQLite snapshot containing saved queue/preferences/captions/receipts, running source and workflow files, linked bot attribution, and exclusion of credentials, cookies, media and symbolic links. ZIP restart opens the same reimport prompt. Checks cover private owner/message bindings, stale/replayed buttons, rejection and oversize handling, unconfirmed document acknowledgements, temporary-file cleanup, and confirmed private controls retained when a group acknowledgement fails. A native polling lifecycle verifies shutdown only after the private button and the existing backup/continuation gate. R2 uses the same archive builder; checksum verification still precedes deletion of earlier backups.

Existing media, compression, caption preferences, 100-second action cooldowns, queue recovery, broadcasts and workflow tests passed. Dependency consistency, Python syntax, safe source import and ZIP integrity were checked. No live Telegram upload, TikTok download, R2 backup or GitHub Actions run was performed for this update.

## Action-button cooldown set to 100 seconds, 2026-10-07

46 targeted tests passed. Audio, subtitle and caption request buttons use a 1-minute-40-second cooldown. Checks cover the 99/100-second boundary, minutes:seconds alerts in all six languages, saved start times across restarts, repeat requests with separate receipts, independent buttons, queue limits, ownership, migration, and caption failure/cancellation handling. Python syntax, archive integrity and safe source import passed. No live Telegram upload, TikTok download or GitHub Actions run was performed for this change.

## Action-button cooldown shortened to 90 seconds, 2026-10-07

46 targeted tests passed with aiogram 3.31.0 and gallery-dl 1.32.13. Audio, subtitle and caption request buttons now become available after 1 minute 30 seconds. Remaining-time alerts show minutes:seconds in all six languages. Checks cover the 89/90-second boundary, unchanged timers on repeated taps, persisted start times across restarts, independent buttons, new request identities and delivery receipts, legacy database migration, queue capacity, ownership, caption failures/cancellation and late acknowledgements. Existing saved timestamps use the shorter interval without resetting the timer. Settings buttons remain immediately usable. Dependency consistency, Python syntax, safe source import and archive integrity passed. No live Telegram upload, TikTok download or GitHub Actions run was performed for this change.

## Full caption settings and action-button cooldowns, 2026-10-07

263 automated tests passed with aiogram 3.31.0 and gallery-dl 1.32.13. Full caption has On, Off (default), and Off with no button, with saved choices, ownership checks, selected checkmarks and translations in all six languages. Tests cover every choice with short and long captions for videos, video documents, single photos, photo documents, albums and document albums. Automatic files retain the original UTF-8 bytes and numeric .txt filename and reply to the first delivered media with the linked bot attribution. Off keeps the existing ordinary button reply; Off with no button stores no full text and sends no extra file or button. Worker snapshots, legacy choices, restart repair, cancellation, definitive failures and unconfirmed automatic uploads are covered.

Audio, subtitle and caption action buttons have independent 30-minute timers saved in SQLite. Native aiogram checks verify admission before acknowledgement, remaining-time alerts in all six languages, unchanged timers on repeat taps, the exact expiry boundary, restart persistence, independent buttons/posts, continued settings navigation, queue limits and unauthorized/shutdown rejections. Eligible later audio/subtitle taps create new jobs with separate receipts, fetch only the requested files and reply to the original media. Caption taps reuse the saved exact text and retain a receipt for each accepted request. Old callback replays cannot create another request. Definite caption failures and cancellation keep their cooldown; unconfirmed sends are never automatically duplicated. A late caption acknowledgement cannot replace a newer request's state. Both older uniqueness constraints migrate without changing saved job IDs, receipts or preferences. Older extraction timestamps seed their timers; older caption receipts get a one-time timer on upgrade.

All existing media, compression, cookie isolation, queue, backup, broadcast and workflow tests passed. Dependency consistency, Python syntax, safe source import and ZIP integrity were checked. No live Telegram upload, TikTok download or GitHub Actions run was performed for this update.

## Full caption text-file replies and linked bot attribution, 2026-10-07

201 automated tests passed with aiogram 3.31.0 and gallery-dl 1.32.13. Following the final reply-style adjustment, the caption and photo audio tests were rerun. Caption boundaries count visible UTF-16 units and reserve account information, separators and the visible attribution. Checks cover ASCII, escaped HTML characters and emojis at the exact boundary; shortened previews fit the media limit without splitting surrogate pairs.

Native aiogram multipart checks cover videos, rejected-video document fallbacks, single photos, photo documents, eleven-photo albums and document albums. Oversized captions produce one ordinary reply with only the linked bot attribution and a text-file button. The original UTF-8 bytes, leading/trailing whitespace, line breaks, hashtags, emojis and numeric .txt filename are retained. Short links use the worker's resolved post ID. The file replies to the first delivered media in the original chat/topic. Existing audio/subtitle keyboards and ten-item photo batching are retained. Normal captions create no extra button or document. User, chat, message and topic ownership are checked.

Saved captions and bindings survive a real state/Runner restart after temporary media files are deleted. Confirmed repeated and simultaneous clicks produce one file upload. Definitive button/file rejections allow safe retry; interrupted button acknowledgements are bound by a correctly routed owned click; unconfirmed file sends are not automatically duplicated. Cancellation before an upload releases its claim. Every bot attribution uses the exact requested deep-link href and HTML parse mode, including continuation batches, audio/subtitles, caption files and album/caption replies; text replies disable previews. All new caption messages are translated into the six supported languages. Existing default Subtitles=Off with no button remains in place and media caching was not added.

Dependency consistency, Python syntax, safe source import and ZIP integrity were checked. No live Telegram upload, TikTok download or GitHub Actions run was performed for this update.

## Subtitle default without an extraction button, 2026-10-07

56 relevant subtitle, manual-extraction and language tests passed with aiogram 3.31.0 and gallery-dl 1.32.13. The default is Off with no button in the settings UI, new job preference snapshots, worker command line and direct download API. Default videos have no automatic subtitle files or subtitle extraction button. Explicit Off still offers extraction, On still uploads tracks, and saved preferences and existing job snapshots are retained. All nine audio/subtitle combinations and document fallbacks passed. Dependency consistency, Python syntax, ZIP integrity and source import were checked. Media caching was not added. No live Telegram upload, TikTok download or GitHub Actions run was performed for this change.

## Manual subtitle extraction and three-state preferences, 2026-10-06

180 automated tests passed with aiogram 3.31.0 and gallery-dl 1.32.13. Audio defaults to On and Subtitles to Off. Both settings offer On, Off, and Off with no button, show a checkmark on the selected choice, preserve ownership and saved values, and display the full choice on the main settings page. All new labels, button responses and errors are translated in English, Spanish, Arabic, Russian, Chinese and Persian. Per-job mode snapshots retain automatic-download and button choices across preference changes and restarts, including older saved subtitle booleans.

The real gallery-dl extractor runs against controlled posts. Native aiogram multipart checks exercise all nine audio/subtitle combinations, with playable video and original-document fallback delivery. Off adds its corresponding button; both Off choices produce one row with Extract audio beside Extract subtitles. Off with no button adds no corresponding button or automatic file. Photos offer only audio extraction. Confirmed repeated delivery does not resend video, audio or subtitles.

Manual subtitle requests fetch only the original tracks, excluding video/image/audio downloads, cover art, converters and browser startup. Checks cover original track bytes and names, no tracks, photo posts, partial failures, all-track failures and the per-file size limit. Subtitle files reply to the original video in the same chat/topic with only @TikTokdownloaderbestbot. Both click orders create independent audio and subtitle requests; repeated clicks before or after completion reuse the matching request. Requester/chat/message ownership, queue capacity, shutdown admission and extraction after restart without retained media files passed.

The older three-column request uniqueness constraint is replaced transactionally with a constraint that also identifies audio-only and subtitle-only requests. Existing columns, job IDs, pending audio jobs, preferences and delivery receipts are preserved. Recovery skips confirmed subtitle tracks; an unacknowledged upload remains uncertain and is not blindly resent. Existing album button repair, photo batching, compression, cookie isolation, language, queue, backup and broadcast checks passed. Dependency consistency, Python syntax, ZIP integrity and safe source import passed. No live Telegram upload, TikTok download or GitHub Actions run was performed for this update.

## Visible album audio button replies, 2026-10-06

142 automated tests passed with aiogram 3.31.0 and gallery-dl 1.32.13. The earlier album path depended on editing an album photo's keyboard, and a rejected edit could leave no visible button. Albums now receive one ordinary text reply with @TikTokdownloaderbestbot and the Extract audio keyboard. Single photos and videos keep their direct keyboards. Native multipart checks cover 1, 2, 10, 11 and 23 images, photos and original documents, the ten-item limit, original bytes, continuation captions/replies, and chat/topic routing. Albums send no reply-markup edits. Only the requester can use the saved button; sound-only jobs reply to the first photo, and repeated clicks reuse the same audio job.

The upgrade migration replaces older album photo bindings with pending button replies, including completed jobs whose old edit was acknowledged. Startup repairs those replies without resending images. Confirmed button message IDs persist across restarts. Definitive HTTP 400/403/413 button rejections permit safe retry. Network errors, server errors and malformed responses retain separate uncertain button intent and do not duplicate replies. A correctly routed callback can confirm a button whose HTTP response was lost; ownership, chat, reply anchor and topic must match. Cancellation before the send or during rate-limit backoff preserves safe retry. Button failures keep the media job completed and show a translated status notice in all six languages.

Existing video audio buttons, compression, subtitles, Persian and other language settings, photo batching, cookie isolation, queues, backups and broadcasts passed. Dependency consistency, Python syntax, ZIP integrity and safe source import passed. No live Telegram upload, TikTok download or GitHub Actions run was performed for this fix.

## Photo audio buttons, 2026-10-05

133 automated tests passed with the pinned aiogram 3.31.0 and gallery-dl 1.32.13 versions. Audio On keeps automatic sound replies for videos and photos. Audio Off skips sound and cover downloads and marks either media type for manual extraction. Controlled gallery-dl responses verify both modes, original audio metadata, exclusion of subtitles from photos and sound-only requests, and unchanged direct sound-link behavior.

Native aiogram multipart and response checks cover 1, 2, 10, 11 and 23 photos, both photo uploads and original documents. Single photos carry their button in the send request. Albums receive one button on the last item of the first batch through a separate reply-markup edit, without passing unsupported keyboard fields to sendMediaGroup. All image bytes, ten-item batching, link/topic replies, continuation captions and replies are preserved. Only the original requester in the saved chat/message can use the button. Sound-only jobs reply to the first delivered media, including when the album button is on a different message. Repeated clicks before and after completion reuse the same job.

Receipt checks cover interruption after an album is confirmed but before its button is attached, restart recovery, unconfirmed keyboard edits, already-applied edits, and startup repair for completed jobs. Confirmed albums are not resent while repairing buttons. Additive database migration preserves older video buttons, queue receipts and Persian/audio preferences. Existing compression, subtitles, languages, cookie isolation, queues, backups and broadcasts passed. Dependency consistency, Python syntax, ZIP integrity and safe source import passed. No live Telegram upload, TikTok download or GitHub Actions run was performed for this update.

## Subtitle files, Persian and settings updates, 2026-10-05

118 automated tests passed with the pinned aiogram 3.31.0 and gallery-dl 1.32.13 versions. The real gallery-dl TikTok extractor runs against controlled post responses containing automatic, creator and translated subtitle tracks. Checks cover Off by default, original VTT/SRT/creator-caption JSON bytes, language/source/version filenames, duplicate track entries, videos with no tracks, exclusion for photos and manual audio extraction, partial failures, empty files and the per-file 50 MB limit. Optional subtitle failures preserve the video and other available tracks.

Native aiogram multipart/response checks verify separate document uploads replying to the delivered video, the exact @TikTokdownloaderbestbot caption, same chat/topic, original filenames and bytes, video-to-document fallback and independent audio behavior. Stable track receipts survive reordered results. Recovery skips confirmed video/subtitle files after cancellation; interrupted subtitle uploads retain uncertain delivery intent and are not automatically repeated. Additive database migration and per-job subtitle snapshots preserve older queues and choices across retries/restarts.

Persian appears in onboarding and Settings, with translations for every English message key, matching format placeholders and translated help/owner help. Settings ownership and persistence passed. /language is removed from registered commands, its handler and all help texts; language changes remain in Settings. The Advanced button shows a checkmark for saved values differing from defaults, and reset clears it. Existing compression, photo continuation, cookie isolation, audio, queue, backup and broadcast tests passed. Dependency checks, Python syntax, ZIP integrity and safe source import passed. No live Telegram upload, TikTok download or GitHub Actions run was performed for this update.

## Photo continuation replies, 2026-10-04

102 automated tests passed. Native aiogram multipart/response checks cover 10, 11, 20, 21 and 23 photos, both photo uploads and original-document delivery. The first batch replies to the link with the post caption; each additional batch replies to the preceding batch with only @TikTokdownloaderbestbot, including a final single photo. All photos remain in order in the same chat/topic. The soundtrack still replies once to the first batch, and confirmed batches/audio are skipped on repeat delivery.

Restart checks preserve the reply chain after two confirmed batches. An additive SQLite migration retains existing queue receipts, language and compression preferences; older photo receipts use their saved first-media target for the next reply. A rejected continuation retains the previous target for retry, while an interrupted upload stays uncertain and is not automatically resent. ZIP integrity and safe source import passed. No live Telegram upload or TikTok download was performed for this update.

## Static FFmpeg installation and cache, 2026-10-04

The workflow downloads the yt-dlp `ffmpeg-master-latest-linux64-gpl.tar.xz` archive into `~/.ffmpeg` when either ffmpeg or ffprobe is missing, restores/saves a separate OS/architecture/build cache, and exports its bin directory to PATH. Cache saving follows encoder/filter validation and precedes the bot session.

Controlled runs of the actual Bash installation block passed for cold installation, cached reuse without another download, missing-ffprobe repair, PATH export, failed-download cleanup and invalid-archive cleanup. These checks used local tar.xz fixtures containing real FFmpeg/ffprobe binaries and a controlled download transport. The existing workflow test, YAML parsing, all 11 shell blocks, embedded Python syntax and @main action references passed. The upstream release's archive name was checked against its published asset listing. No live GitHub download, cache restore/save or Actions run was performed for this update.

## Workflow filename, 2026-10-04

Renamed the standalone workflow and packaged workflow to `tik.yml`, including source import, backup paths, documentation and the workflow validation test. The 16 existing bot/queue/import/backup/workflow tests passed. Python syntax, workflow YAML and all embedded shell/Python syntax checks passed. The ZIP contains `.github/workflows/tik.yml`, and safe source import preserves that file. No GitHub Actions run was launched for this filename change.

## aiogram migration, video compression and advanced settings, 2026-10-04

88 automated tests passed with Python 3.12, aiogram 3.31.0, FFmpeg 6.1.1, gallery-dl 1.32.13 and Playwright 1.58.0 in an environment without python-telegram-bot installed. Real synthetic clips verify H.264/AAC MP4 output, fast-start metadata, preservation of 60 fps and variable frame timestamps, selected 30/24 fps limits, resolution and quality controls, silent portrait videos, rotation metadata, HDR-to-BT.709 tone mapping, and full decode after two-pass size fitting without truncation. The size-fitting test uses a reduced byte limit to exercise the same bitrate budgeting and final-size checks without an unnecessarily large fixture.

Native aiogram integration checks use its actual multipart builder, response decoder and bot-bound Update/CallbackQuery models with a controlled transport. They cover caption links and topic routing, durable admission before polling acknowledgement, command registration, clean shutdown and session closure, streamed photo/document albums, full-file video fallback, audio filename/metadata/thumbnail uploads, rate-limit retries, settings ownership and language selection, deduplicated manual audio jobs, group migration and blocked broadcast recipients. Network interruptions, HTTP 500 and malformed upload responses retain uncertain delivery intent; definitive HTTP 403/404/413 rejections clear it, with the existing 50 MB error for HTTP 413. The ID helper also closes its session without logging the token.

Controlled downloader/bot tests cover All as the default, the exact 50 MB boundary, unchanged small videos in Over 50 MB mode, the existing error with None, video-only larger input limits, per-user ownership and persistence, reset behavior, all five languages, job settings snapshots across retries/recovery, and stable delivery receipts when encoded bytes change. Existing queue, audio, cookie isolation, reply routing and broadcast tests passed. Dependency checks, Python compilation, workflow YAML parsing, all shell/Python block syntax checks and the workflow's encoder availability checks passed. No live Telegram upload, TikTok download or GitHub Actions run was performed for this update.

## Cookies limited to Chromium, 2026-10-03

54 automated tests passed with Python 3.12 and the pinned gallery-dl, Telegram and Playwright versions. Controlled requests verify that short links, video/photo downloads, automatic and manual post audio, and normal sound-page/detail extraction never load the saved cookie file or attach its login cookies. A simulated Chromium context verifies cookie import only after the fallback starts, no cookie export to the HTTP downloader, browser cleanup, and anonymous fallback when the file is absent or invalid. Existing delivery, queue, settings, restart and broadcast tests passed. Dependency consistency and Python compilation passed. No live TikTok or Telegram test was performed; the workflow and Chromium cache configuration are unchanged.

## Replies to link messages, 2026-10-02

43 automated tests passed. Existing delivery checks now verify replies to the originating link message for videos, photo albums, resumed album batches, and video-to-document fallback, including group topic routing. Audio still replies to the delivered media, and repeated manual extraction clicks remain deduplicated. Python compilation and dependency checks passed. No live Telegram upload was performed.

## Video audio controls, 2026-09-30

43 automated tests passed with Python 3.12, gallery-dl 1.32.13 and python-telegram-bot 22.8. Dependency consistency and Python compilation passed. Controlled responses cover videos with automatic audio, videos with the manual button, mandatory photo audio with Audio Off, sound-only downloading without fetching video/image bytes, document fallback with the button, callback ownership and chat validation, queue limits, repeated-click deduplication, reply-to-video and topic routing, database restart recovery, and the existing owner broadcast behavior. Telegram/TikTok sending was not verified live; no bot token was supplied.

Checked on 2026-09-25 with Python 3.12.14, gallery-dl 1.32.13, and python-telegram-bot 22.8

## Passed

- 16 automated tests using pytest, including the real gallery-dl TikTok extractor with controlled video and photo responses
- Four active slots and four waiting slots per normal user, queue advancement and independent users
- Separate exempt account slot, unlimited exempt backlog, replayed-update deduplication
- Recovery of pending work and preservation of confirmed upload receipts
- Ambiguous Telegram sends are not automatically repeated
- Photo batches retain all images and skip batches already confirmed as sent
- Owner-only shutdown and cancellation ownership checks
- Clean shutdown writes both the session receipt and Telegram update cursor
- Unsupported Telegram video delivery falls back to the unchanged file
- URL restrictions and rejection of non-post URLs
- Oversized response header and streaming-body checks, including exact boundary size
- Safe ZIP source import excludes queue data and credentials
- R2 backup verification occurs before deleting previous backups, credential files excluded
- Workflow action references use @main and shutdown blocks automatic continuation
- Actionlint 1.7.12 passed for the workflow, shellcheck was not available
- Python source compilation and dependency consistency checks passed

## Not verified live

Live public TikTok video, photo, and shortened-link attempts did not produce downloadable media in this execution environment
A follow-up diagnostic showed DNS resolution failures for TikTok hosts, so these attempts do not establish whether those posts work from a GitHub runner

Telegram sending was tested with controlled bot responses, no real bot token was provided
R2 backup operations were tested with a simulated S3 client, no live R2 credentials were provided
The workflow was checked with Actionlint but was not launched on GitHub

After configuring the secrets, first run with continue disabled and send one video and one photo post to verify access from your runner


## Audio update validation

25 automated tests passed, including real gallery-dl extractor fixtures for video and photo posts with music metadata, reading back embedded MP3 title/artist/album/cover/IDs/duration, preserving the audio payload, safe filenames and ID fallback, the post-tagging size limit, Telegram audio reply metadata, album replies, database migration, confirmed-delivery recovery and uncertain audio uploads. M4A tagging uses Mutagen's MP4 API but was not verified against a live TikTok M4A download. No live Telegram or TikTok upload test was performed for this update.

Full-resolution cover update: 27 tests passed, including exact embedded JPEG/PNG byte preservation, full-size WebP-to-PNG artwork, and separate Telegram thumbnail dimensions.
