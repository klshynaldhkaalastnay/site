"""User interface translations, captions preserve original TikTok text"""
LANGUAGES = {'en': 'English', 'es': 'Español', 'ar': 'العربية', 'ru': 'Русский', 'zh': '中文', 'fa': 'فارسی'}
TEXT = {'en': {'Send a TikTok video or photo link': 'Send a TikTok video or photo link', 'Downloading...': 'Downloading...', 'Uploading...': 'Uploading...', 'Send a TikTok video or photo post link': 'Send a TikTok video or photo post link', 'The bot is restarting, please send your links again shortly': 'The bot is restarting, please send your links again shortly', 'You have reached the limit of 4 active downloads and 4 waiting requests\nThese links were not accepted\n': 'You have reached the limit of 4 active downloads and 4 waiting requests\nThese links were not accepted\n', 'Only the bot owner can use this command': 'Only the bot owner can use this command', 'No active or queued requests': 'No active or queued requests', 'Use /cancel followed by one of your job numbers': 'Use /cancel followed by one of your job numbers', 'This request has already ended': 'This request has already ended', 'Cancelled, any upload already accepted by Telegram may still arrive': 'Cancelled, any upload already accepted by Telegram may still arrive', 'The bot is already stopping': 'The bot is already stopping', 'Saving progress and stopping': 'Saving progress and stopping', 'Saving progress and starting a fresh session': 'Saving progress and starting a fresh session', 'Send a TikTok link directly, use /help for available commands': 'Send a TikTok link directly, use /help for available commands', 'This video is too large, the maximum size is 50 MB': 'This video is too large, the maximum size is 50 MB', 'TikTok refused access to this post, please try again later': 'TikTok refused access to this post, please try again later', 'Could not download this post, it may be unavailable or TikTok may be blocking access': 'Could not download this post, it may be unavailable or TikTok may be blocking access', 'Telegram did not confirm delivery, check the chat before sending the link again': 'Telegram did not confirm delivery, check the chat before sending the link again', 'Could not send this post, please try again later': 'Could not send this post, please try again later', 'The previous upload was interrupted, check the chat before sending the link again': 'The previous upload was interrupted, check the chat before sending the link again', 'Queued, position {n}': 'Queued, position {n}', 'Your Telegram ID is {user}': 'Your Telegram ID is {user}', 'And {n} more': 'And {n} more', 'Job {id}, {status}': 'Job {id}, {status}', 'user {user}': 'user {user}', 'ready': 'ready', 'running': 'running', 'queued': 'queued'}, 'es': {'Send a TikTok video or photo link': 'Envía un enlace de un video o fotos de TikTok', 'Downloading...': 'Descargando...', 'Uploading...': 'Subiendo...', 'Send a TikTok video or photo post link': 'Envía un enlace de una publicación de TikTok', 'The bot is restarting, please send your links again shortly': 'El bot se está reiniciando, vuelve a enviar tus enlaces en breve', 'You have reached the limit of 4 active downloads and 4 waiting requests\nThese links were not accepted\n': 'Has alcanzado el límite de 4 descargas activas y 4 solicitudes en espera\nNo se aceptaron estos enlaces\n', 'Only the bot owner can use this command': 'Solo el propietario del bot puede usar este comando', 'No active or queued requests': 'No hay solicitudes activas ni en espera', 'Use /cancel followed by one of your job numbers': 'Usa /cancel seguido del número de tu solicitud', 'This request has already ended': 'Esta solicitud ya ha finalizado', 'Cancelled, any upload already accepted by Telegram may still arrive': 'Cancelado, los archivos ya aceptados por Telegram podrían llegar', 'The bot is already stopping': 'El bot ya se está deteniendo', 'Saving progress and stopping': 'Guardando el progreso y deteniendo', 'Saving progress and starting a fresh session': 'Guardando el progreso e iniciando una nueva sesión', 'Send a TikTok link directly, use /help for available commands': 'Envía un enlace de TikTok directamente, usa /help para ver los comandos', 'This video is too large, the maximum size is 50 MB': 'Este video es demasiado grande, el tamaño máximo es 50 MB', 'TikTok refused access to this post, please try again later': 'TikTok denegó el acceso a esta publicación, inténtalo más tarde', 'Could not download this post, it may be unavailable or TikTok may be blocking access': 'No se pudo descargar la publicación, puede no estar disponible o TikTok puede estar bloqueando el acceso', 'Telegram did not confirm delivery, check the chat before sending the link again': 'Telegram no confirmó la entrega, revisa el chat antes de reenviar el enlace', 'Could not send this post, please try again later': 'No se pudo enviar la publicación, inténtalo más tarde', 'The previous upload was interrupted, check the chat before sending the link again': 'La subida anterior se interrumpió, revisa el chat antes de reenviar el enlace', 'Queued, position {n}': 'En espera, posición {n}', 'Your Telegram ID is {user}': 'Tu ID de Telegram es {user}', 'And {n} more': 'Y {n} más', 'Job {id}, {status}': 'Solicitud {id}, {status}', 'user {user}': 'usuario {user}', 'ready': 'listo', 'running': 'en curso', 'queued': 'en espera'}, 'ar': {'Send a TikTok video or photo link': 'أرسل رابط فيديو أو صور من تيك توك', 'Downloading...': 'جارٍ التنزيل...', 'Uploading...': 'جارٍ الرفع...', 'Send a TikTok video or photo post link': 'أرسل رابط منشور فيديو أو صور من تيك توك', 'The bot is restarting, please send your links again shortly': 'تتم إعادة تشغيل البوت، أعد إرسال الروابط بعد قليل', 'You have reached the limit of 4 active downloads and 4 waiting requests\nThese links were not accepted\n': 'وصلت إلى الحد الأقصى، 4 تنزيلات نشطة و4 طلبات انتظار\nلم يتم قبول هذه الروابط\n', 'Only the bot owner can use this command': 'يمكن لمالك البوت فقط استخدام هذا الأمر', 'No active or queued requests': 'لا توجد طلبات نشطة أو في الانتظار', 'Use /cancel followed by one of your job numbers': 'استخدم /cancel متبوعًا برقم أحد طلباتك', 'This request has already ended': 'انتهى هذا الطلب بالفعل', 'Cancelled, any upload already accepted by Telegram may still arrive': 'تم الإلغاء، قد تصل الملفات التي قبلها تيليجرام بالفعل', 'The bot is already stopping': 'البوت يتوقف بالفعل', 'Saving progress and stopping': 'جارٍ حفظ التقدم والإيقاف', 'Saving progress and starting a fresh session': 'جارٍ حفظ التقدم وبدء جلسة جديدة', 'Send a TikTok link directly, use /help for available commands': 'أرسل رابط تيك توك مباشرة، استخدم /help لعرض الأوامر', 'This video is too large, the maximum size is 50 MB': 'هذا الفيديو كبير جدًا، الحد الأقصى هو 50 ميغابايت', 'TikTok refused access to this post, please try again later': 'رفض تيك توك الوصول إلى هذا المنشور، حاول لاحقًا', 'Could not download this post, it may be unavailable or TikTok may be blocking access': 'تعذر تنزيل المنشور، قد يكون غير متاح أو أن تيك توك يمنع الوصول', 'Telegram did not confirm delivery, check the chat before sending the link again': 'لم يؤكد تيليجرام التسليم، تحقق من المحادثة قبل إرسال الرابط مجددًا', 'Could not send this post, please try again later': 'تعذر إرسال المنشور، حاول لاحقًا', 'The previous upload was interrupted, check the chat before sending the link again': 'انقطع الرفع السابق، تحقق من المحادثة قبل إعادة إرسال الرابط', 'Queued, position {n}': 'في الانتظار، الترتيب {n}', 'Your Telegram ID is {user}': 'معرّف تيليجرام الخاص بك هو {user}', 'And {n} more': 'و{n} أخرى', 'Job {id}, {status}': 'الطلب {id}، {status}', 'user {user}': 'المستخدم {user}', 'ready': 'جاهز', 'running': 'قيد التنفيذ', 'queued': 'في الانتظار'}, 'ru': {'Send a TikTok video or photo link': 'Отправьте ссылку на видео или фото TikTok', 'Downloading...': 'Скачивание...', 'Uploading...': 'Загрузка...', 'Send a TikTok video or photo post link': 'Отправьте ссылку на публикацию TikTok', 'The bot is restarting, please send your links again shortly': 'Бот перезапускается, отправьте ссылки снова чуть позже', 'You have reached the limit of 4 active downloads and 4 waiting requests\nThese links were not accepted\n': 'Достигнут лимит: 4 активные загрузки и 4 запроса в очереди\nЭти ссылки не приняты\n', 'Only the bot owner can use this command': 'Эта команда доступна только владельцу бота', 'No active or queued requests': 'Нет активных запросов или запросов в очереди', 'Use /cancel followed by one of your job numbers': 'Используйте /cancel с номером своего запроса', 'This request has already ended': 'Этот запрос уже завершён', 'Cancelled, any upload already accepted by Telegram may still arrive': 'Отменено, файлы, уже принятые Telegram, могут ещё поступить', 'The bot is already stopping': 'Бот уже останавливается', 'Saving progress and stopping': 'Сохранение прогресса и остановка', 'Saving progress and starting a fresh session': 'Сохранение прогресса и запуск нового сеанса', 'Send a TikTok link directly, use /help for available commands': 'Отправьте ссылку TikTok, список команд доступен в /help', 'This video is too large, the maximum size is 50 MB': 'Видео слишком большое, максимальный размер 50 МБ', 'TikTok refused access to this post, please try again later': 'TikTok отказал в доступе к публикации, попробуйте позже', 'Could not download this post, it may be unavailable or TikTok may be blocking access': 'Не удалось скачать публикацию, она недоступна или TikTok блокирует доступ', 'Telegram did not confirm delivery, check the chat before sending the link again': 'Telegram не подтвердил доставку, проверьте чат перед повторной отправкой ссылки', 'Could not send this post, please try again later': 'Не удалось отправить публикацию, попробуйте позже', 'The previous upload was interrupted, check the chat before sending the link again': 'Предыдущая загрузка прервана, проверьте чат перед повторной отправкой ссылки', 'Queued, position {n}': 'В очереди, позиция {n}', 'Your Telegram ID is {user}': 'Ваш ID Telegram: {user}', 'And {n} more': 'И ещё {n}', 'Job {id}, {status}': 'Запрос {id}, {status}', 'user {user}': 'пользователь {user}', 'ready': 'готов', 'running': 'выполняется', 'queued': 'в очереди'}, 'zh': {'Send a TikTok video or photo link': '发送 TikTok 视频或图片链接', 'Downloading...': '正在下载...', 'Uploading...': '正在上传...', 'Send a TikTok video or photo post link': '请发送 TikTok 视频或图片帖子的链接', 'The bot is restarting, please send your links again shortly': '机器人正在重启，请稍后重新发送链接', 'You have reached the limit of 4 active downloads and 4 waiting requests\nThese links were not accepted\n': '已达到 4 个进行中下载和 4 个排队请求的上限\n以下链接未被接受\n', 'Only the bot owner can use this command': '只有机器人所有者可以使用此命令', 'No active or queued requests': '没有进行中或排队的请求', 'Use /cancel followed by one of your job numbers': '使用 /cancel 加上你的请求编号', 'This request has already ended': '此请求已结束', 'Cancelled, any upload already accepted by Telegram may still arrive': '已取消，Telegram 已接收的上传仍可能送达', 'The bot is already stopping': '机器人正在停止', 'Saving progress and stopping': '正在保存进度并停止', 'Saving progress and starting a fresh session': '正在保存进度并启动新会话', 'Send a TikTok link directly, use /help for available commands': '直接发送 TikTok 链接，使用 /help 查看命令', 'This video is too large, the maximum size is 50 MB': '视频太大，最大为 50 MB', 'TikTok refused access to this post, please try again later': 'TikTok 拒绝访问此帖子，请稍后重试', 'Could not download this post, it may be unavailable or TikTok may be blocking access': '无法下载此帖子，帖子可能不可用或 TikTok 阻止了访问', 'Telegram did not confirm delivery, check the chat before sending the link again': 'Telegram 未确认送达，请检查聊天后再发送链接', 'Could not send this post, please try again later': '无法发送此帖子，请稍后重试', 'The previous upload was interrupted, check the chat before sending the link again': '上次上传中断，请检查聊天后再发送链接', 'Queued, position {n}': '排队中，位置 {n}', 'Your Telegram ID is {user}': '你的 Telegram ID 是 {user}', 'And {n} more': '还有 {n} 个', 'Job {id}, {status}': '请求 {id}，{status}', 'user {user}': '用户 {user}', 'ready': '就绪', 'running': '进行中', 'queued': '排队中'}}
HELP = {'en': 'Send TikTok video or photo links, multiple links work too\n\nUp to 4 active downloads and 4 waiting requests per user\nEach photo post counts as one request\nMaximum file size is 50 MB\n\n/queue - Your requests\n/cancel <job> - Cancel a request\n/ping - Check response time\n/id - Your Telegram ID', 'es': 'Envía enlaces de videos o fotos de TikTok, puedes enviar varios\n\nHasta 4 descargas activas y 4 solicitudes en espera por usuario\nCada publicación de fotos cuenta como una solicitud\nTamaño máximo: 50 MB\n\n/queue - Tus solicitudes\n/cancel <job> - Cancelar una solicitud\n/ping - Ver tiempo de respuesta\n/id - Tu ID de Telegram', 'ar': 'أرسل روابط فيديوهات أو صور تيك توك، يمكنك إرسال عدة روابط\n\nحتى 4 تنزيلات نشطة و4 طلبات انتظار لكل مستخدم\nكل منشور صور يُحسب طلبًا واحدًا\nالحد الأقصى لحجم الملف 50 ميغابايت\n\n/queue - طلباتك\n/cancel <job> - إلغاء طلب\n/ping - قياس زمن الاستجابة\n/id - معرّف تيليجرام الخاص بك', 'ru': 'Отправляйте ссылки на видео или фото TikTok, можно несколько сразу\n\nДо 4 активных загрузок и 4 запросов в очереди на пользователя\nПубликация с фото считается одним запросом\nМаксимальный размер файла 50 МБ\n\n/queue - Ваши запросы\n/cancel <job> - Отменить запрос\n/ping - Время отклика\n/id - Ваш ID Telegram', 'zh': '发送 TikTok 视频或图片链接，也可一次发送多个\n\n每位用户最多 4 个进行中下载和 4 个排队请求\n每个图片帖子计为一个请求\n文件最大为 50 MB\n\n/queue - 你的请求\n/cancel <job> - 取消请求\n/ping - 查看响应时间\n/id - 你的 Telegram ID'}
OWNER_HELP = {'en': 'Owner commands\n/jobs - All jobs\n/restart - Start a fresh session\n/upload - Back up and restart\n/shutdown - Back up and stop', 'es': 'Comandos del propietario\n/jobs - Todas las solicitudes\n/restart - Iniciar una nueva sesión\n/upload - Copia de seguridad y reinicio\n/shutdown - Copia de seguridad y parada', 'ar': 'أوامر المالك\n/jobs - جميع الطلبات\n/restart - بدء جلسة جديدة\n/upload - نسخ احتياطي وإعادة تشغيل\n/shutdown - نسخ احتياطي وإيقاف', 'ru': 'Команды владельца\n/jobs - Все запросы\n/restart - Новый сеанс\n/upload - Резервная копия и перезапуск\n/shutdown - Резервная копия и остановка', 'zh': '所有者命令\n/jobs - 所有请求\n/restart - 启动新会话\n/upload - 备份并重启\n/shutdown - 备份并停止'}
TEXT['en']['Audio is unavailable for this post'] = 'Audio is unavailable for this post'
TEXT['es']['Audio is unavailable for this post'] = 'El audio no está disponible para esta publicación'
TEXT['ar']['Audio is unavailable for this post'] = 'الصوت غير متاح لهذا المنشور'
TEXT['ru']['Audio is unavailable for this post'] = 'Аудио для этой публикации недоступно'
TEXT['zh']['Audio is unavailable for this post'] = '此帖子的音频不可用'
TEXT['en']['This audio is too large, the maximum size is 50 MB'] = 'This audio is too large, the maximum size is 50 MB'
TEXT['es']['This audio is too large, the maximum size is 50 MB'] = 'Este audio es demasiado grande, el tamaño máximo es 50 MB'
TEXT['ar']['This audio is too large, the maximum size is 50 MB'] = 'هذا الصوت كبير جدًا، الحد الأقصى هو 50 ميغابايت'
TEXT['ru']['This audio is too large, the maximum size is 50 MB'] = 'Аудиофайл слишком большой, максимальный размер 50 МБ'
TEXT['zh']['This audio is too large, the maximum size is 50 MB'] = '音频太大，最大为 50 MB'

def translate(language, text, **values):
    result = TEXT.get(language, TEXT["en"]).get(text, text)
    return result.format(**values) if values else result

# Settings menus and sound-link support
TEXT['en']['Settings'] = 'Settings'
TEXT['en']['Language'] = 'Language'
TEXT['en']['Back'] = 'Back'
TEXT['en']['Send a TikTok video or photo link'] = 'Send a TikTok video, photo or sound link'
TEXT['en']['Send a TikTok video or photo post link'] = 'Send a TikTok video, photo or sound link'
HELP['en'] += '\n/settings - Settings\nSend a TikTok video, photo or sound link'
TEXT['es']['Settings'] = 'Ajustes'
TEXT['es']['Language'] = 'Idioma'
TEXT['es']['Back'] = 'Atrás'
TEXT['es']['Send a TikTok video or photo link'] = 'Envía un enlace de vídeo, fotos o sonido de TikTok'
TEXT['es']['Send a TikTok video or photo post link'] = 'Envía un enlace de vídeo, fotos o sonido de TikTok'
HELP['es'] += '\n/settings - Ajustes\nEnvía un enlace de vídeo, fotos o sonido de TikTok'
TEXT['ar']['Settings'] = 'الإعدادات'
TEXT['ar']['Language'] = 'اللغة'
TEXT['ar']['Back'] = 'رجوع'
TEXT['ar']['Send a TikTok video or photo link'] = 'أرسل رابط فيديو أو صور أو صوت من تيك توك'
TEXT['ar']['Send a TikTok video or photo post link'] = 'أرسل رابط فيديو أو صور أو صوت من تيك توك'
HELP['ar'] += '\n/settings - الإعدادات\nأرسل رابط فيديو أو صور أو صوت من تيك توك'
TEXT['ru']['Settings'] = 'Настройки'
TEXT['ru']['Language'] = 'Язык'
TEXT['ru']['Back'] = 'Назад'
TEXT['ru']['Send a TikTok video or photo link'] = 'Отправьте ссылку на видео, фото или звук TikTok'
TEXT['ru']['Send a TikTok video or photo post link'] = 'Отправьте ссылку на видео, фото или звук TikTok'
HELP['ru'] += '\n/settings - Настройки\nОтправьте ссылку на видео, фото или звук TikTok'
TEXT['zh']['Settings'] = '设置'
TEXT['zh']['Language'] = '语言'
TEXT['zh']['Back'] = '返回'
TEXT['zh']['Send a TikTok video or photo link'] = '发送 TikTok 视频、照片或声音链接'
TEXT['zh']['Send a TikTok video or photo post link'] = '发送 TikTok 视频、照片或声音链接'
HELP['zh'] += '\n/settings - 设置\n发送 TikTok 视频、照片或声音链接'
TEXT['en']['Audio'] = 'Audio'
TEXT['en']['On'] = 'On'
TEXT['en']['Off'] = 'Off'
TEXT['en']['Send sound with videos and photos'] = 'Send sound with videos and photos'
TEXT['es']['Audio'] = 'Audio'
TEXT['es']['On'] = 'Activado'
TEXT['es']['Off'] = 'Desactivado'
TEXT['es']['Send sound with videos and photos'] = 'Enviar sonido con vídeos y fotos'
TEXT['ar']['Audio'] = 'الصوت'
TEXT['ar']['On'] = 'تشغيل'
TEXT['ar']['Off'] = 'إيقاف'
TEXT['ar']['Send sound with videos and photos'] = 'إرسال الصوت مع الفيديوهات والصور'
TEXT['ru']['Audio'] = 'Аудио'
TEXT['ru']['On'] = 'Вкл'
TEXT['ru']['Off'] = 'Выкл'
TEXT['ru']['Send sound with videos and photos'] = 'Отправлять звук с видео и фото'
TEXT['zh']['Audio'] = '音频'
TEXT['zh']['On'] = '开启'
TEXT['zh']['Off'] = '关闭'
TEXT['zh']['Send sound with videos and photos'] = '随视频和照片发送音频'
TEXT['en']['TikTok did not provide this sound, try a video or photo post using it'] = 'TikTok did not provide this sound, try a video or photo post using it'
TEXT['es']['TikTok did not provide this sound, try a video or photo post using it'] = 'TikTok no proporcionó este sonido, prueba con un vídeo o una publicación de fotos que lo use'
TEXT['ar']['TikTok did not provide this sound, try a video or photo post using it'] = 'لم يوفر تيك توك هذا الصوت، جرّب رابط فيديو أو صور تستخدمه'
TEXT['ru']['TikTok did not provide this sound, try a video or photo post using it'] = 'TikTok не предоставил этот звук, попробуйте видео или фотопубликацию с ним'
TEXT['zh']['TikTok did not provide this sound, try a video or photo post using it'] = 'TikTok 未提供此声音，请尝试使用该声音的视频或照片帖子'
TEXT['en']['Use /broadcast in our private chat'] = 'Use /broadcast in our private chat'
TEXT['en']['Reply to the announcement message with /broadcast'] = 'Reply to the announcement message with /broadcast'
TEXT['en']['This message cannot be copied, try a text, photo, video or audio message'] = 'This message cannot be copied, try a text, photo, video or audio message'
TEXT['en']['Send'] = 'Send'
TEXT['en']['Cancel'] = 'Cancel'
TEXT['en']['Send the preview above to {n} chats?'] = 'Send the preview above to {n} chats?'
TEXT['en']['Broadcast queued'] = 'Broadcast queued'
TEXT['en']['Broadcast cancelled'] = 'Broadcast cancelled'
TEXT['en']['Broadcast finished\nSent: {sent}\nSkipped or failed: {failed}\nUnconfirmed: {uncertain}'] = 'Broadcast finished\nSent: {sent}\nSkipped or failed: {failed}\nUnconfirmed: {uncertain}'
OWNER_HELP['en'] += '\n/broadcast - Reply to a message to announce it to all known chats'
TEXT['es']['Use /broadcast in our private chat'] = 'Usa /broadcast en nuestro chat privado'
TEXT['es']['Reply to the announcement message with /broadcast'] = 'Responde al mensaje del anuncio con /broadcast'
TEXT['es']['This message cannot be copied, try a text, photo, video or audio message'] = 'No se puede copiar este mensaje, prueba con texto, foto, vídeo o audio'
TEXT['es']['Send'] = 'Enviar'
TEXT['es']['Cancel'] = 'Cancelar'
TEXT['es']['Send the preview above to {n} chats?'] = '¿Enviar la vista previa a {n} chats?'
TEXT['es']['Broadcast queued'] = 'Anuncio en cola'
TEXT['es']['Broadcast cancelled'] = 'Anuncio cancelado'
TEXT['es']['Broadcast finished\nSent: {sent}\nSkipped or failed: {failed}\nUnconfirmed: {uncertain}'] = 'Anuncio finalizado\nEnviado: {sent}\nOmitido o fallido: {failed}\nSin confirmar: {uncertain}'
OWNER_HELP['es'] += '\n/broadcast - Responde a un mensaje para anunciarlo a todos los chats conocidos'
TEXT['ar']['Use /broadcast in our private chat'] = 'استخدم /broadcast في المحادثة الخاصة معي'
TEXT['ar']['Reply to the announcement message with /broadcast'] = 'رد على رسالة الإعلان بالأمر /broadcast'
TEXT['ar']['This message cannot be copied, try a text, photo, video or audio message'] = 'لا يمكن نسخ هذه الرسالة، جرّب نصاً أو صورة أو فيديو أو صوتاً'
TEXT['ar']['Send'] = 'إرسال'
TEXT['ar']['Cancel'] = 'إلغاء'
TEXT['ar']['Send the preview above to {n} chats?'] = 'إرسال المعاينة أعلاه إلى {n} محادثات؟'
TEXT['ar']['Broadcast queued'] = 'تمت إضافة الإعلان إلى قائمة الإرسال'
TEXT['ar']['Broadcast cancelled'] = 'تم إلغاء الإعلان'
TEXT['ar']['Broadcast finished\nSent: {sent}\nSkipped or failed: {failed}\nUnconfirmed: {uncertain}'] = 'اكتمل إرسال الإعلان\nتم الإرسال: {sent}\nتم التخطي أو فشل: {failed}\nغير مؤكد: {uncertain}'
OWNER_HELP['ar'] += '\n/broadcast - رد على رسالة لإرسالها إلى جميع المحادثات المعروفة'
TEXT['ru']['Use /broadcast in our private chat'] = 'Используйте /broadcast в личном чате со мной'
TEXT['ru']['Reply to the announcement message with /broadcast'] = 'Ответьте на сообщение объявления командой /broadcast'
TEXT['ru']['This message cannot be copied, try a text, photo, video or audio message'] = 'Не удалось скопировать сообщение, попробуйте текст, фото, видео или аудио'
TEXT['ru']['Send'] = 'Отправить'
TEXT['ru']['Cancel'] = 'Отмена'
TEXT['ru']['Send the preview above to {n} chats?'] = 'Отправить показанное выше сообщение в {n} чатов?'
TEXT['ru']['Broadcast queued'] = 'Объявление добавлено в очередь'
TEXT['ru']['Broadcast cancelled'] = 'Объявление отменено'
TEXT['ru']['Broadcast finished\nSent: {sent}\nSkipped or failed: {failed}\nUnconfirmed: {uncertain}'] = 'Рассылка завершена\nОтправлено: {sent}\nПропущено или ошибка: {failed}\nНе подтверждено: {uncertain}'
OWNER_HELP['ru'] += '\n/broadcast - Ответьте на сообщение для рассылки во все известные чаты'
TEXT['zh']['Use /broadcast in our private chat'] = '请在与我的私聊中使用 /broadcast'
TEXT['zh']['Reply to the announcement message with /broadcast'] = '回复公告消息并发送 /broadcast'
TEXT['zh']['This message cannot be copied, try a text, photo, video or audio message'] = '无法复制此消息，请尝试文字、照片、视频或音频消息'
TEXT['zh']['Send'] = '发送'
TEXT['zh']['Cancel'] = '取消'
TEXT['zh']['Send the preview above to {n} chats?'] = '将上面的预览发送到 {n} 个聊天？'
TEXT['zh']['Broadcast queued'] = '公告已加入队列'
TEXT['zh']['Broadcast cancelled'] = '公告已取消'
TEXT['zh']['Broadcast finished\nSent: {sent}\nSkipped or failed: {failed}\nUnconfirmed: {uncertain}'] = '群发完成\n已发送：{sent}\n跳过或失败：{failed}\n未确认：{uncertain}'
OWNER_HELP['zh'] += '\n/broadcast - 回复消息以向所有已知聊天发送公告'

# Video auto-audio and manual extraction
TEXT["en"]["Automatically send audio with videos and photos, Off shows an Extract audio button"] = "Automatically send audio with videos and photos, Off shows an Extract audio button"
TEXT["es"]["Automatically send audio with videos and photos, Off shows an Extract audio button"] = "Enviar audio automáticamente con vídeos y fotos, Desactivado muestra Extraer audio"
TEXT["ar"]["Automatically send audio with videos and photos, Off shows an Extract audio button"] = "إرسال الصوت تلقائياً مع الفيديوهات والصور، عند الإيقاف يظهر زر استخراج الصوت"
TEXT["ru"]["Automatically send audio with videos and photos, Off shows an Extract audio button"] = "Автоматически отправлять аудио с видео и фото, при выключении появляется кнопка извлечения аудио"
TEXT["zh"]["Automatically send audio with videos and photos, Off shows an Extract audio button"] = "自动发送视频和照片的音频，关闭时显示提取音频按钮"
TEXT["en"]["Extract audio"] = "Extract audio"
TEXT["es"]["Extract audio"] = "Extraer audio"
TEXT["ar"]["Extract audio"] = "استخراج الصوت"
TEXT["ru"]["Extract audio"] = "Извлечь аудио"
TEXT["zh"]["Extract audio"] = "提取音频"
TEXT["en"]["This audio button belongs to the original requester"] = "This audio button belongs to the original requester"
TEXT["es"]["This audio button belongs to the original requester"] = "Este botón de audio pertenece al usuario que solicitó el vídeo"
TEXT["ar"]["This audio button belongs to the original requester"] = "زر الصوت هذا خاص بصاحب طلب الفيديو"
TEXT["ru"]["This audio button belongs to the original requester"] = "Эта кнопка доступна автору запроса видео"
TEXT["zh"]["This audio button belongs to the original requester"] = "此音频按钮仅限原请求者使用"
TEXT["en"]["Your download queue is full, try again later"] = "Your download queue is full, try again later"
TEXT["es"]["Your download queue is full, try again later"] = "Tu cola de descargas está llena, inténtalo más tarde"
TEXT["ar"]["Your download queue is full, try again later"] = "قائمة تنزيلاتك ممتلئة، حاول لاحقاً"
TEXT["ru"]["Your download queue is full, try again later"] = "Ваша очередь загрузок заполнена, попробуйте позже"
TEXT["zh"]["Your download queue is full, try again later"] = "下载队列已满，请稍后重试"
TEXT["en"]["Audio already requested, check the chat and /queue"] = "Audio already requested, check the chat and /queue"
TEXT["es"]["Audio already requested, check the chat and /queue"] = "Ya se solicitó el audio, revisa el chat y /queue"
TEXT["ar"]["Audio already requested, check the chat and /queue"] = "تم طلب الصوت بالفعل، تحقق من المحادثة و /queue"
TEXT["ru"]["Audio already requested, check the chat and /queue"] = "Аудио уже запрошено, проверьте чат и /queue"
TEXT["zh"]["Audio already requested, check the chat and /queue"] = "音频已请求，请检查聊天和 /queue"
TEXT["en"]["Audio requested"] = "Audio requested"
TEXT["es"]["Audio requested"] = "Audio solicitado"
TEXT["ar"]["Audio requested"] = "تم طلب الصوت"
TEXT["ru"]["Audio requested"] = "Аудио запрошено"
TEXT["zh"]["Audio requested"] = "已请求音频"

# Video compression menus and status messages
TEXT["en"]["Compression"] = "Compression"
TEXT["es"]["Compression"] = "Compresión"
TEXT["ar"]["Compression"] = "الضغط"
TEXT["ru"]["Compression"] = "Сжатие"
TEXT["zh"]["Compression"] = "压缩"
TEXT["en"]["All videos"] = "All videos"
TEXT["es"]["All videos"] = "Todos los vídeos"
TEXT["ar"]["All videos"] = "كل الفيديوهات"
TEXT["ru"]["All videos"] = "Все видео"
TEXT["zh"]["All videos"] = "所有视频"
TEXT["en"]["Over 50 MB"] = "Over 50 MB"
TEXT["es"]["Over 50 MB"] = "Más de 50 MB"
TEXT["ar"]["Over 50 MB"] = "أكبر من 50 ميغابايت"
TEXT["ru"]["Over 50 MB"] = "Больше 50 МБ"
TEXT["zh"]["Over 50 MB"] = "超过 50 MB"
TEXT["en"]["None"] = "None"
TEXT["es"]["None"] = "Ninguna"
TEXT["ar"]["None"] = "بدون ضغط"
TEXT["ru"]["None"] = "Без сжатия"
TEXT["zh"]["None"] = "不压缩"
TEXT["en"]["Advanced"] = "Advanced"
TEXT["es"]["Advanced"] = "Avanzado"
TEXT["ar"]["Advanced"] = "خيارات متقدمة"
TEXT["ru"]["Advanced"] = "Дополнительно"
TEXT["zh"]["Advanced"] = "高级选项"
TEXT["en"]["Reset advanced defaults"] = "Reset advanced defaults"
TEXT["es"]["Reset advanced defaults"] = "Restablecer opciones avanzadas"
TEXT["ar"]["Reset advanced defaults"] = "إعادة تعيين الخيارات المتقدمة"
TEXT["ru"]["Reset advanced defaults"] = "Сбросить дополнительные настройки"
TEXT["zh"]["Reset advanced defaults"] = "重置高级设置"
TEXT["en"]["Maximum frame rate"] = "Maximum frame rate"
TEXT["es"]["Maximum frame rate"] = "Frecuencia máxima de fotogramas"
TEXT["ar"]["Maximum frame rate"] = "معدل الإطارات الأقصى"
TEXT["ru"]["Maximum frame rate"] = "Максимальная частота кадров"
TEXT["zh"]["Maximum frame rate"] = "最高帧率"
TEXT["en"]["Maximum resolution"] = "Maximum resolution"
TEXT["es"]["Maximum resolution"] = "Resolución máxima"
TEXT["ar"]["Maximum resolution"] = "الدقة القصوى"
TEXT["ru"]["Maximum resolution"] = "Максимальное разрешение"
TEXT["zh"]["Maximum resolution"] = "最高分辨率"
TEXT["en"]["Quality"] = "Quality"
TEXT["es"]["Quality"] = "Calidad"
TEXT["ar"]["Quality"] = "الجودة"
TEXT["ru"]["Quality"] = "Качество"
TEXT["zh"]["Quality"] = "画质"
TEXT["en"]["Encoding speed"] = "Encoding speed"
TEXT["es"]["Encoding speed"] = "Velocidad de codificación"
TEXT["ar"]["Encoding speed"] = "سرعة الترميز"
TEXT["ru"]["Encoding speed"] = "Скорость кодирования"
TEXT["zh"]["Encoding speed"] = "编码速度"
TEXT["en"]["Video audio bitrate"] = "Video audio bitrate"
TEXT["es"]["Video audio bitrate"] = "Bitrate del audio del vídeo"
TEXT["ar"]["Video audio bitrate"] = "معدل بت الصوت داخل الفيديو"
TEXT["ru"]["Video audio bitrate"] = "Битрейт звука в видео"
TEXT["zh"]["Video audio bitrate"] = "视频内音频码率"
TEXT["en"]["Original"] = "Original"
TEXT["es"]["Original"] = "Original"
TEXT["ar"]["Original"] = "الأصلي"
TEXT["ru"]["Original"] = "Исходное"
TEXT["zh"]["Original"] = "原始"
TEXT["en"]["High quality"] = "High quality"
TEXT["es"]["High quality"] = "Alta calidad"
TEXT["ar"]["High quality"] = "جودة عالية"
TEXT["ru"]["High quality"] = "Высокое качество"
TEXT["zh"]["High quality"] = "高画质"
TEXT["en"]["Balanced"] = "Balanced"
TEXT["es"]["Balanced"] = "Equilibrada"
TEXT["ar"]["Balanced"] = "متوازن"
TEXT["ru"]["Balanced"] = "Сбалансированное"
TEXT["zh"]["Balanced"] = "均衡"
TEXT["en"]["Smaller files"] = "Smaller files"
TEXT["es"]["Smaller files"] = "Archivos más pequeños"
TEXT["ar"]["Smaller files"] = "ملفات أصغر"
TEXT["ru"]["Smaller files"] = "Меньше размер"
TEXT["zh"]["Smaller files"] = "更小文件"
TEXT["en"]["Fast"] = "Fast"
TEXT["es"]["Fast"] = "Rápida"
TEXT["ar"]["Fast"] = "سريع"
TEXT["ru"]["Fast"] = "Быстро"
TEXT["zh"]["Fast"] = "快速"
TEXT["en"]["Medium"] = "Medium"
TEXT["es"]["Medium"] = "Media"
TEXT["ar"]["Medium"] = "متوسط"
TEXT["ru"]["Medium"] = "Средне"
TEXT["zh"]["Medium"] = "中速"
TEXT["en"]["Slow"] = "Slow"
TEXT["es"]["Slow"] = "Lenta"
TEXT["ar"]["Slow"] = "بطيء"
TEXT["ru"]["Slow"] = "Медленно"
TEXT["zh"]["Slow"] = "慢速"
TEXT["en"]["Compressing..."] = "Compressing..."
TEXT["es"]["Compressing..."] = "Comprimiendo..."
TEXT["ar"]["Compressing..."] = "جارٍ الضغط..."
TEXT["ru"]["Compressing..."] = "Сжатие..."
TEXT["zh"]["Compressing..."] = "正在压缩..."
TEXT["en"]["Compress videos, None keeps the original and the 50 MB limit"] = "Compress videos, None keeps the original and the 50 MB limit"
TEXT["es"]["Compress videos, None keeps the original and the 50 MB limit"] = "Comprimir vídeos, Ninguna conserva el original y el límite de 50 MB"
TEXT["ar"]["Compress videos, None keeps the original and the 50 MB limit"] = "ضغط الفيديوهات، بدون ضغط يحتفظ بالملف الأصلي وحد 50 ميغابايت"
TEXT["ru"]["Compress videos, None keeps the original and the 50 MB limit"] = "Сжатие видео, Без сжатия сохраняет оригинал и лимит 50 МБ"
TEXT["zh"]["Compress videos, None keeps the original and the 50 MB limit"] = "压缩视频，不压缩保留原文件并遵守 50 MB 限制"
TEXT["en"]["Advanced compression options, frame rate and resolution are maximums, fitting to 50 MB may lower resolution, video audio bitrate does not change separate sound files"] = "Advanced compression options, frame rate and resolution are maximums, fitting to 50 MB may lower resolution, video audio bitrate does not change separate sound files"
TEXT["es"]["Advanced compression options, frame rate and resolution are maximums, fitting to 50 MB may lower resolution, video audio bitrate does not change separate sound files"] = "Opciones avanzadas, los fotogramas y la resolución son máximos, ajustar a 50 MB puede reducir la resolución, el bitrate del vídeo no cambia los archivos de audio separados"
TEXT["ar"]["Advanced compression options, frame rate and resolution are maximums, fitting to 50 MB may lower resolution, video audio bitrate does not change separate sound files"] = "خيارات الضغط المتقدمة، معدل الإطارات والدقة حدود قصوى، قد تنخفض الدقة ليلائم الفيديو حد 50 ميغابايت، معدل بت الصوت داخل الفيديو لا يغير ملفات الصوت المنفصلة"
TEXT["ru"]["Advanced compression options, frame rate and resolution are maximums, fitting to 50 MB may lower resolution, video audio bitrate does not change separate sound files"] = "Дополнительные настройки, частота кадров и разрешение задают максимум, для лимита 50 МБ разрешение может уменьшиться, битрейт звука в видео не меняет отдельные аудиофайлы"
TEXT["zh"]["Advanced compression options, frame rate and resolution are maximums, fitting to 50 MB may lower resolution, video audio bitrate does not change separate sound files"] = "高级设置，帧率和分辨率为上限，适配 50 MB 可能降低分辨率，视频音频码率不会改变单独的音频文件"
TEXT["en"]["Could not compress this video below 50 MB, try lower quality or resolution"] = "Could not compress this video below 50 MB, try lower quality or resolution"
TEXT["es"]["Could not compress this video below 50 MB, try lower quality or resolution"] = "No se pudo comprimir el vídeo a menos de 50 MB, prueba una calidad o resolución menor"
TEXT["ar"]["Could not compress this video below 50 MB, try lower quality or resolution"] = "تعذر ضغط الفيديو إلى أقل من 50 ميغابايت، جرّب جودة أو دقة أقل"
TEXT["ru"]["Could not compress this video below 50 MB, try lower quality or resolution"] = "Не удалось сжать видео до 50 МБ, попробуйте снизить качество или разрешение"
TEXT["zh"]["Could not compress this video below 50 MB, try lower quality or resolution"] = "无法将视频压缩到 50 MB 以下，请尝试降低画质或分辨率"
TEXT["en"]["Could not compress this video, try again or choose None in Compression settings"] = "Could not compress this video, try again or choose None in Compression settings"
TEXT["es"]["Could not compress this video, try again or choose None in Compression settings"] = "No se pudo comprimir el vídeo, inténtalo de nuevo o elige Ninguna en Compresión"
TEXT["ar"]["Could not compress this video, try again or choose None in Compression settings"] = "تعذر ضغط الفيديو، حاول مجدداً أو اختر بدون ضغط في إعدادات الضغط"
TEXT["ru"]["Could not compress this video, try again or choose None in Compression settings"] = "Не удалось сжать видео, повторите попытку или выберите Без сжатия в настройках"
TEXT["zh"]["Could not compress this video, try again or choose None in Compression settings"] = "无法压缩视频，请重试或在压缩设置中选择不压缩"
TEXT["en"]["This video is too large to process, the maximum download size is 1 GB"] = "This video is too large to process, the maximum download size is 1 GB"
TEXT["es"]["This video is too large to process, the maximum download size is 1 GB"] = "El vídeo es demasiado grande para procesarlo, el máximo de descarga es 1 GB"
TEXT["ar"]["This video is too large to process, the maximum download size is 1 GB"] = "الفيديو أكبر من حد المعالجة، الحد الأقصى للتنزيل 1 غيغابايت"
TEXT["ru"]["This video is too large to process, the maximum download size is 1 GB"] = "Видео слишком большое для обработки, максимальный размер загрузки 1 ГБ"
TEXT["zh"]["This video is too large to process, the maximum download size is 1 GB"] = "视频过大，无法处理，最大下载大小为 1 GB"
TEXT["en"]["24 fps"] = "24 fps"
TEXT["es"]["24 fps"] = "24 fps"
TEXT["ar"]["24 fps"] = "24 إطار/ث"
TEXT["ru"]["24 fps"] = "24 кадр/с"
TEXT["zh"]["24 fps"] = "24 帧/秒"
TEXT["en"]["30 fps"] = "30 fps"
TEXT["es"]["30 fps"] = "30 fps"
TEXT["ar"]["30 fps"] = "30 إطار/ث"
TEXT["ru"]["30 fps"] = "30 кадр/с"
TEXT["zh"]["30 fps"] = "30 帧/秒"
TEXT["en"]["60 fps"] = "60 fps"
TEXT["es"]["60 fps"] = "60 fps"
TEXT["ar"]["60 fps"] = "60 إطار/ث"
TEXT["ru"]["60 fps"] = "60 кадр/с"
TEXT["zh"]["60 fps"] = "60 帧/秒"
TEXT["en"]["64 kbps"] = "64 kbps"
TEXT["es"]["64 kbps"] = "64 kbps"
TEXT["ar"]["64 kbps"] = "64 كيلوبت/ث"
TEXT["ru"]["64 kbps"] = "64 кбит/с"
TEXT["zh"]["64 kbps"] = "64 kbps"
TEXT["en"]["96 kbps"] = "96 kbps"
TEXT["es"]["96 kbps"] = "96 kbps"
TEXT["ar"]["96 kbps"] = "96 كيلوبت/ث"
TEXT["ru"]["96 kbps"] = "96 кбит/с"
TEXT["zh"]["96 kbps"] = "96 kbps"
TEXT["en"]["128 kbps"] = "128 kbps"
TEXT["es"]["128 kbps"] = "128 kbps"
TEXT["ar"]["128 kbps"] = "128 كيلوبت/ث"
TEXT["ru"]["128 kbps"] = "128 кбит/с"
TEXT["zh"]["128 kbps"] = "128 kbps"
TEXT["en"]["192 kbps"] = "192 kbps"
TEXT["es"]["192 kbps"] = "192 kbps"
TEXT["ar"]["192 kbps"] = "192 كيلوبت/ث"
TEXT["ru"]["192 kbps"] = "192 кбит/с"
TEXT["zh"]["192 kbps"] = "192 kbps"

# Subtitle preferences and optional download notices
for code, values in {
    'en': ('Subtitles', 'Send available subtitle files as replies to videos',
           'Some subtitle files could not be downloaded', 'Some subtitle files are too large, the maximum size is 50 MB'),
    'es': ('Subtítulos', 'Enviar los archivos de subtítulos disponibles como respuestas a los vídeos',
           'No se pudieron descargar algunos subtítulos', 'Algunos subtítulos son demasiado grandes, el máximo es 50 MB'),
    'ar': ('الترجمة', 'إرسال ملفات الترجمة المتاحة كردود على الفيديوهات',
           'تعذر تنزيل بعض ملفات الترجمة', 'بعض ملفات الترجمة كبيرة جداً، الحد الأقصى 50 ميغابايت'),
    'ru': ('Субтитры', 'Отправлять доступные файлы субтитров в ответ на видео',
           'Не удалось скачать некоторые субтитры', 'Некоторые субтитры слишком большие, максимум 50 МБ'),
    'zh': ('字幕', '以回复视频的方式发送可用字幕文件',
           '部分字幕文件无法下载', '部分字幕文件过大，最大为 50 MB'),
}.items():
    for key,value in zip(('Subtitles', 'Send available subtitle files as replies to videos',
                          'Some subtitle files could not be downloaded',
                          'Some subtitle files are too large, the maximum size is 50 MB'), values):
        TEXT[code][key] = value

# Persian menus, statuses and help
HELP['fa'] = ('لینک ویدیو یا عکس تیک‌تاک را بفرستید، می‌توانید چند لینک بفرستید\n\n'
              'هر کاربر می‌تواند 4 دانلود فعال و 4 درخواست در صف داشته باشد\n'
              'هر پست عکس یک درخواست محسوب می‌شود\nحداکثر اندازه هر فایل 50 مگابایت است\n\n'
              '/queue - درخواست‌های شما\n/cancel <job> - لغو درخواست\n'
              '/ping - بررسی زمان پاسخ\n/id - شناسه تلگرام شما\n/settings - تنظیمات\n'
              'لینک ویدیو، عکس یا صدای تیک‌تاک را بفرستید')
OWNER_HELP['fa'] = ('دستورهای مالک\n/jobs - همه درخواست‌ها\n/restart - شروع نشست جدید\n'
                    '/upload - پشتیبان‌گیری و راه‌اندازی مجدد\n/shutdown - پشتیبان‌گیری و توقف\n'
                    '/broadcast - برای ارسال پیام به همه گفتگوهای شناخته‌شده، با این دستور به پیام پاسخ دهید')
TEXT['fa'] = {
    'Send a TikTok video or photo link': 'لینک ویدیو، عکس یا صدای تیک‌تاک را بفرستید',
    'Downloading...': 'در حال دانلود...',
    'Uploading...': 'در حال ارسال...',
    'Send a TikTok video or photo post link': 'لینک ویدیو، عکس یا صدای تیک‌تاک را بفرستید',
    'The bot is restarting, please send your links again shortly': 'ربات در حال راه‌اندازی مجدد است، کمی بعد لینک‌ها را دوباره بفرستید',
    'You have reached the limit of 4 active downloads and 4 waiting requests\nThese links were not accepted\n': 'به محدودیت 4 دانلود فعال و 4 درخواست در صف رسیده‌اید\nاین لینک‌ها پذیرفته نشدند\n',
    'Only the bot owner can use this command': 'فقط مالک ربات می‌تواند از این دستور استفاده کند',
    'No active or queued requests': 'هیچ درخواست فعال یا در صفی وجود ندارد',
    'Use /cancel followed by one of your job numbers': 'پس از /cancel شماره یکی از درخواست‌های خود را بنویسید',
    'This request has already ended': 'این درخواست قبلاً پایان یافته است',
    'Cancelled, any upload already accepted by Telegram may still arrive': 'لغو شد، فایل‌هایی که تلگرام قبلاً پذیرفته است ممکن است همچنان ارسال شوند',
    'The bot is already stopping': 'ربات در حال توقف است',
    'Saving progress and stopping': 'در حال ذخیره پیشرفت و توقف',
    'Saving progress and starting a fresh session': 'در حال ذخیره پیشرفت و شروع نشست جدید',
    'Send a TikTok link directly, use /help for available commands': 'لینک تیک‌تاک را مستقیم بفرستید، برای دیدن دستورها از /help استفاده کنید',
    'This video is too large, the maximum size is 50 MB': 'این ویدیو بیش از حد بزرگ است، حداکثر اندازه 50 مگابایت است',
    'TikTok refused access to this post, please try again later': 'تیک‌تاک اجازه دسترسی به این پست را نداد، بعداً دوباره امتحان کنید',
    'Could not download this post, it may be unavailable or TikTok may be blocking access': 'دانلود این پست ممکن نشد، شاید در دسترس نیست یا تیک‌تاک دسترسی را مسدود کرده است',
    'Telegram did not confirm delivery, check the chat before sending the link again': 'تلگرام ارسال را تأیید نکرد، قبل از فرستادن دوباره لینک، گفتگو را بررسی کنید',
    'Could not send this post, please try again later': 'ارسال این پست ممکن نشد، بعداً دوباره امتحان کنید',
    'The previous upload was interrupted, check the chat before sending the link again': 'ارسال قبلی قطع شد، قبل از فرستادن دوباره لینک، گفتگو را بررسی کنید',
    'Queued, position {n}': 'در صف، جایگاه {n}',
    'Your Telegram ID is {user}': 'شناسه تلگرام شما {user} است',
    'And {n} more': 'و {n} مورد دیگر',
    'Job {id}, {status}': 'درخواست {id}، {status}',
    'user {user}': 'کاربر {user}',
    'ready': 'آماده',
    'running': 'در حال اجرا',
    'queued': 'در صف',
    'Audio is unavailable for this post': 'صدا برای این پست در دسترس نیست',
    'This audio is too large, the maximum size is 50 MB': 'این فایل صوتی بیش از حد بزرگ است، حداکثر اندازه 50 مگابایت است',
    'Settings': 'تنظیمات',
    'Language': 'زبان',
    'Back': 'بازگشت',
    'Audio': 'صدا',
    'On': 'روشن',
    'Off': 'خاموش',
    'Send sound with videos and photos': 'ارسال صدا همراه ویدیوها و عکس‌ها',
    'TikTok did not provide this sound, try a video or photo post using it': 'تیک‌تاک این صدا را ارائه نکرد، لینک ویدیو یا عکسی را که از آن استفاده می‌کند امتحان کنید',
    'Use /broadcast in our private chat': 'در گفتگوی خصوصی با ربات از /broadcast استفاده کنید',
    'Reply to the announcement message with /broadcast': 'با دستور /broadcast به پیام اطلاع‌رسانی پاسخ دهید',
    'This message cannot be copied, try a text, photo, video or audio message': 'این پیام قابل کپی نیست، پیام متنی، عکس، ویدیو یا صدا را امتحان کنید',
    'Send': 'ارسال',
    'Cancel': 'لغو',
    'Send the preview above to {n} chats?': 'پیش‌نمایش بالا به {n} گفتگو ارسال شود؟',
    'Broadcast queued': 'پیام همگانی در صف قرار گرفت',
    'Broadcast cancelled': 'ارسال همگانی لغو شد',
    'Broadcast finished\nSent: {sent}\nSkipped or failed: {failed}\nUnconfirmed: {uncertain}': 'ارسال همگانی پایان یافت\nارسال‌شده: {sent}\nردشده یا ناموفق: {failed}\nتأییدنشده: {uncertain}',
    'Automatically send audio with videos and photos, Off shows an Extract audio button': 'ارسال خودکار صدا همراه ویدیوها و عکس‌ها، در حالت خاموش دکمه استخراج صدا نمایش داده می‌شود',
    'Extract audio': 'استخراج صدا',
    'This audio button belongs to the original requester': 'این دکمه صدا متعلق به درخواست‌کننده اصلی است',
    'Your download queue is full, try again later': 'صف دانلود شما پر است، بعداً دوباره امتحان کنید',
    'Audio already requested, check the chat and /queue': 'صدا قبلاً درخواست شده است، گفتگو و /queue را بررسی کنید',
    'Audio requested': 'صدا درخواست شد',
    'Compression': 'فشرده‌سازی',
    'All videos': 'همه ویدیوها',
    'Over 50 MB': 'بیش از 50 مگابایت',
    'None': 'بدون فشرده‌سازی',
    'Advanced': 'پیشرفته',
    'Reset advanced defaults': 'بازگرداندن تنظیمات پیشرفته به پیش‌فرض',
    'Maximum frame rate': 'حداکثر نرخ فریم',
    'Maximum resolution': 'حداکثر وضوح',
    'Quality': 'کیفیت',
    'Encoding speed': 'سرعت رمزگذاری',
    'Video audio bitrate': 'نرخ بیت صدای ویدیو',
    'Original': 'اصلی',
    'High quality': 'کیفیت بالا',
    'Balanced': 'متعادل',
    'Smaller files': 'فایل‌های کوچک‌تر',
    'Fast': 'سریع',
    'Medium': 'متوسط',
    'Slow': 'آهسته',
    'Compressing...': 'در حال فشرده‌سازی...',
    'Compress videos, None keeps the original and the 50 MB limit': 'فشرده‌سازی ویدیوها، حالت بدون فشرده‌سازی فایل اصلی و محدودیت 50 مگابایت را حفظ می‌کند',
    'Advanced compression options, frame rate and resolution are maximums, fitting to 50 MB may lower resolution, video audio bitrate does not change separate sound files': 'گزینه‌های پیشرفته فشرده‌سازی، نرخ فریم و وضوح سقف هستند، برای رسیدن به 50 مگابایت ممکن است وضوح کاهش یابد، نرخ بیت صدای ویدیو فایل‌های صوتی جداگانه را تغییر نمی‌دهد',
    'Could not compress this video below 50 MB, try lower quality or resolution': 'فشرده‌سازی این ویدیو به کمتر از 50 مگابایت ممکن نشد، کیفیت یا وضوح کمتری را امتحان کنید',
    'Could not compress this video, try again or choose None in Compression settings': 'فشرده‌سازی این ویدیو ممکن نشد، دوباره امتحان کنید یا در تنظیمات فشرده‌سازی حالت بدون فشرده‌سازی را انتخاب کنید',
    'This video is too large to process, the maximum download size is 1 GB': 'این ویدیو برای پردازش بیش از حد بزرگ است، حداکثر اندازه دانلود 1 گیگابایت است',
    '24 fps': '24 فریم بر ثانیه',
    '30 fps': '30 فریم بر ثانیه',
    '60 fps': '60 فریم بر ثانیه',
    '64 kbps': '64 کیلوبیت بر ثانیه',
    '96 kbps': '96 کیلوبیت بر ثانیه',
    '128 kbps': '128 کیلوبیت بر ثانیه',
    '192 kbps': '192 کیلوبیت بر ثانیه',
    'Subtitles': 'زیرنویس',
    'Send available subtitle files as replies to videos': 'ارسال فایل‌های زیرنویس موجود در پاسخ به ویدیوها',
    'Some subtitle files could not be downloaded': 'دانلود بعضی از فایل‌های زیرنویس ممکن نشد',
    'Some subtitle files are too large, the maximum size is 50 MB': 'بعضی از فایل‌های زیرنویس بیش از حد بزرگ هستند، حداکثر اندازه 50 مگابایت است',
}

for key,translations in {
    'Try this button again in {time} (min:sec)': {
        'en':'Try this button again in {time} (min:sec)',
        'es':'Vuelve a pulsar este botón en {time} (min:seg)',
        'ar':'يمكنك الضغط على هذا الزر مجدداً بعد {time} (دقيقة:ثانية)',
        'ru':'Нажмите эту кнопку снова через {time} (мин:сек)',
        'zh':'请在 {time} (分:秒) 后再次点击此按钮',
        'fa':'پس از {time} (دقیقه:ثانیه) دوباره این دکمه را بزنید',
    },
    'This request was already received, check the chat and /queue': {
        'en':'This request was already received, check the chat and /queue',
        'es':'Esta solicitud ya se recibió, revisa el chat y /queue',
        'ar':'تم استلام هذا الطلب بالفعل، تحقق من المحادثة و /queue',
        'ru':'Этот запрос уже получен, проверьте чат и /queue',
        'zh':'此请求已收到，请查看聊天和 /queue',
        'fa':'این درخواست قبلاً دریافت شده است، گفتگو و /queue را بررسی کنید',
    },
    'Full caption': {
        'en':'Full caption','es':'Descripción completa','ar':'الوصف الكامل',
        'ru':'Полное описание','zh':'完整说明','fa':'توضیحات کامل',
    },
    'Automatically send full captions as text files when too long, Off shows a text-file button': {
        'en':'Automatically send full captions as text files when too long, Off shows a text-file button',
        'es':'Enviar automáticamente las descripciones demasiado largas como archivos de texto, Desactivado muestra un botón',
        'ar':'إرسال الأوصاف الطويلة تلقائياً كملفات نصية، إيقاف يظهر زر إرسال الملف',
        'ru':'Автоматически отправлять длинные описания текстовыми файлами, Выключено показывает кнопку',
        'zh':'说明过长时自动发送文本文件，关闭时显示文本文件按钮',
        'fa':'ارسال خودکار توضیحات طولانی به صورت فایل متنی، حالت خاموش دکمه فایل متنی را نشان می‌دهد',
    },
    'Could not send the caption file, it will be retried after restart': {
        'en':'Could not send the caption file, it will be retried after restart',
        'es':'No se pudo enviar el archivo de descripción, se reintentará al reiniciar',
        'ar':'تعذر إرسال ملف الوصف، ستتم إعادة المحاولة بعد إعادة التشغيل',
        'ru':'Не удалось отправить файл описания, попытка повторится после перезапуска',
        'zh':'无法发送说明文件，将在重启后重试',
        'fa':'ارسال فایل توضیحات ممکن نشد، پس از راه‌اندازی مجدد دوباره تلاش می‌شود',
    },
    'Send full caption as text file': {
        'en':'Send full caption as text file','es':'Enviar descripción completa como archivo de texto',
        'ar':'إرسال الوصف الكامل كملف نصي','ru':'Отправить полное описание текстовым файлом',
        'zh':'将完整说明发送为文本文件','fa':'ارسال توضیحات کامل به صورت فایل متنی',
    },
    'The caption is too long, use the button to get the full text': {
        'en':'The caption is too long, use the button to get the full text',
        'es':'La descripción es demasiado larga, usa el botón para obtener el texto completo',
        'ar':'الوصف طويل جداً، استخدم الزر للحصول على النص الكامل',
        'ru':'Описание слишком длинное, нажмите кнопку, чтобы получить полный текст',
        'zh':'说明过长，请点击按钮获取完整文本',
        'fa':'توضیحات بیش از حد طولانی است، برای دریافت متن کامل از دکمه استفاده کنید',
    },
    'This caption button belongs to the original requester': {
        'en':'This caption button belongs to the original requester',
        'es':'Este botón de descripción pertenece al solicitante original',
        'ar':'زر الوصف هذا مخصص لصاحب الطلب الأصلي',
        'ru':'Эта кнопка описания доступна только автору запроса',
        'zh':'此说明按钮仅供原请求者使用','fa':'این دکمه توضیحات متعلق به درخواست‌کننده اصلی است',
    },
    'Caption file already sent, check the chat': {
        'en':'Caption file already sent, check the chat',
        'es':'El archivo de descripción ya se envió, revisa el chat',
        'ar':'تم إرسال ملف الوصف بالفعل، تحقق من المحادثة',
        'ru':'Файл описания уже отправлен, проверьте чат',
        'zh':'说明文件已发送，请查看聊天','fa':'فایل توضیحات قبلاً ارسال شده است، گفتگو را بررسی کنید',
    },
    'Caption delivery is pending or unconfirmed, check the chat': {
        'en':'Caption delivery is pending or unconfirmed, check the chat',
        'es':'El envío de la descripción está pendiente o sin confirmar, revisa el chat',
        'ar':'إرسال الوصف قيد الانتظار أو غير مؤكد، تحقق من المحادثة',
        'ru':'Отправка описания ожидается или не подтверждена, проверьте чат',
        'zh':'说明发送尚在等待或未确认，请查看聊天',
        'fa':'ارسال توضیحات در انتظار است یا تأیید نشده، گفتگو را بررسی کنید',
    },
    'This caption file is too large, the maximum size is 50 MB': {
        'en':'This caption file is too large, the maximum size is 50 MB',
        'es':'El archivo de descripción es demasiado grande, el máximo es de 50 MB',
        'ar':'ملف الوصف كبير جداً، الحد الأقصى هو 50 ميغابايت',
        'ru':'Файл описания слишком большой, максимальный размер 50 МБ',
        'zh':'说明文件过大，最大为50 MB','fa':'فایل توضیحات بیش از حد بزرگ است، حداکثر اندازه 50 مگابایت است',
    },
    'Sending caption file...': {
        'en':'Sending caption file...','es':'Enviando archivo de descripción...',
        'ar':'جارٍ إرسال ملف الوصف...','ru':'Отправка файла описания...',
        'zh':'正在发送说明文件...','fa':'در حال ارسال فایل توضیحات...',
    },
    'Could not send the caption file, try the button again': {
        'en':'Could not send the caption file, try the button again',
        'es':'No se pudo enviar el archivo de descripción, vuelve a pulsar el botón',
        'ar':'تعذر إرسال ملف الوصف، حاول استخدام الزر مرة أخرى',
        'ru':'Не удалось отправить файл описания, нажмите кнопку ещё раз',
        'zh':'无法发送说明文件，请重试按钮',
        'fa':'ارسال فایل توضیحات ممکن نشد، دوباره دکمه را امتحان کنید',
    },
    'Telegram did not confirm the caption button, check the chat before sending the link again': {
        'en':'Telegram did not confirm the caption button, check the chat before sending the link again',
        'es':'Telegram no confirmó el botón de descripción, revisa el chat antes de enviar el enlace otra vez',
        'ar':'لم يؤكد تيليغرام زر الوصف، تحقق من المحادثة قبل إرسال الرابط مرة أخرى',
        'ru':'Telegram не подтвердил кнопку описания, проверьте чат перед повторной отправкой ссылки',
        'zh':'Telegram未确认说明按钮，请检查聊天后再发送链接',
        'fa':'تلگرام دکمه توضیحات را تأیید نکرد، قبل از ارسال دوباره لینک گفتگو را بررسی کنید',
    },
    'Could not add the caption button yet, it will be retried after restart': {
        'en':'Could not add the caption button yet, it will be retried after restart',
        'es':'No se pudo añadir el botón de descripción, se reintentará al reiniciar',
        'ar':'تعذرت إضافة زر الوصف، ستتم إعادة المحاولة بعد إعادة التشغيل',
        'ru':'Не удалось добавить кнопку описания, попытка повторится после перезапуска',
        'zh':'暂时无法添加说明按钮，将在重启后重试',
        'fa':'افزودن دکمه توضیحات هنوز ممکن نشد، پس از راه‌اندازی مجدد دوباره تلاش می‌شود',
    },
    'Off with no button': {
        'en':'Off with no button','es':'Desactivado sin botón','ar':'إيقاف بدون زر',
        'ru':'Выключено без кнопки','zh':'关闭且不显示按钮','fa':'خاموش بدون دکمه',
    },
    'Extract subtitles': {
        'en':'Extract subtitles','es':'Extraer subtítulos','ar':'استخراج الترجمة',
        'ru':'Извлечь субтитры','zh':'提取字幕','fa':'استخراج زیرنویس',
    },
    'Automatically send subtitle files with videos, Off shows an Extract subtitles button': {
        'en':'Automatically send subtitle files with videos, Off shows an Extract subtitles button',
        'es':'Enviar subtítulos automáticamente con los vídeos, Desactivado muestra Extraer subtítulos',
        'ar':'إرسال ملفات الترجمة تلقائياً مع الفيديوهات، عند الإيقاف يظهر زر استخراج الترجمة',
        'ru':'Автоматически отправлять субтитры с видео, при выключении появляется кнопка извлечения субтитров',
        'zh':'自动发送视频字幕文件，关闭时显示提取字幕按钮',
        'fa':'ارسال خودکار فایل‌های زیرنویس همراه ویدیوها، در حالت خاموش دکمه استخراج زیرنویس نمایش داده می‌شود',
    },
    'This subtitle button belongs to the original requester': {
        'en':'This subtitle button belongs to the original requester',
        'es':'Este botón de subtítulos pertenece a quien solicitó el vídeo',
        'ar':'زر الترجمة هذا خاص بصاحب الطلب الأصلي',
        'ru':'Эта кнопка субтитров принадлежит автору запроса',
        'zh':'此字幕按钮仅供原请求者使用',
        'fa':'این دکمه زیرنویس متعلق به درخواست‌کننده اصلی است',
    },
    'Subtitles requested': {
        'en':'Subtitles requested','es':'Subtítulos solicitados','ar':'تم طلب الترجمة',
        'ru':'Субтитры запрошены','zh':'已请求字幕','fa':'زیرنویس درخواست شد',
    },
    'Subtitles already requested, check the chat and /queue': {
        'en':'Subtitles already requested, check the chat and /queue',
        'es':'Los subtítulos ya se solicitaron, revisa el chat y /queue',
        'ar':'تم طلب الترجمة بالفعل، تحقق من المحادثة و /queue',
        'ru':'Субтитры уже запрошены, проверьте чат и /queue',
        'zh':'已经请求过字幕，请检查聊天和 /queue',
        'fa':'زیرنویس قبلاً درخواست شده، گفتگو و /queue را بررسی کنید',
    },
    'No subtitle files are available for this video': {
        'en':'No subtitle files are available for this video',
        'es':'No hay archivos de subtítulos disponibles para este vídeo',
        'ar':'لا تتوفر ملفات ترجمة لهذا الفيديو',
        'ru':'Для этого видео нет доступных файлов субтитров',
        'zh':'此视频没有可用的字幕文件',
        'fa':'هیچ فایل زیرنویسی برای این ویدیو موجود نیست',
    },
    'Could not download subtitle files for this video': {
        'en':'Could not download subtitle files for this video',
        'es':'No se pudieron descargar los subtítulos de este vídeo',
        'ar':'تعذر تنزيل ملفات الترجمة لهذا الفيديو',
        'ru':'Не удалось скачать файлы субтитров для этого видео',
        'zh':'无法下载此视频的字幕文件',
        'fa':'دانلود فایل‌های زیرنویس این ویدیو ممکن نشد',
    },
    'The subtitle files are too large, the maximum size is 50 MB': {
        'en':'The subtitle files are too large, the maximum size is 50 MB',
        'es':'Los archivos de subtítulos son demasiado grandes, el máximo es 50 MB',
        'ar':'ملفات الترجمة كبيرة جداً، الحد الأقصى للحجم هو 50 ميغابايت',
        'ru':'Файлы субтитров слишком большие, максимальный размер 50 МБ',
        'zh':'字幕文件过大，最大大小为 50 MB',
        'fa':'فایل‌های زیرنویس بیش از حد بزرگ هستند، حداکثر اندازه 50 مگابایت است',
    },
    'Telegram did not confirm the audio button, check the chat before sending the link again': {
        'en':'Telegram did not confirm the audio button, check the chat before sending the link again',
        'es':'Telegram no confirmó el botón de audio, revisa el chat antes de volver a enviar el enlace',
        'ar':'لم يؤكد تيليجرام إرسال زر الصوت، تحقق من المحادثة قبل إرسال الرابط مرة أخرى',
        'ru':'Telegram не подтвердил отправку кнопки аудио, проверьте чат перед повторной отправкой ссылки',
        'zh':'Telegram 未确认音频按钮的发送，请检查聊天后再重新发送链接',
        'fa':'تلگرام ارسال دکمه صدا را تأیید نکرد، پیش از ارسال دوباره لینک گفتگو را بررسی کنید',
    },
    'Could not add the audio button yet, it will be retried after restart': {
        'en':'Could not add the audio button yet, it will be retried after restart',
        'es':'No se pudo añadir el botón de audio, se volverá a intentar después de reiniciar',
        'ar':'تعذرت إضافة زر الصوت الآن، ستتم المحاولة مرة أخرى بعد إعادة التشغيل',
        'ru':'Пока не удалось добавить кнопку аудио, попытка будет повторена после перезапуска',
        'zh':'暂时无法添加音频按钮，重启后会重试',
        'fa':'هنوز افزودن دکمه صدا ممکن نشد، پس از راه‌اندازی مجدد دوباره تلاش می‌شود',
    },
}.items():
    for language,value in translations.items():
        TEXT[language][key]=value

# Restart choices are available in all supported interface languages.
for key,values in {
    'Reimport the ZIP when restarting?': (
        'Reimport the ZIP when restarting?','¿Reimportar el ZIP al reiniciar?',
        'إعادة استيراد ملف ZIP عند إعادة التشغيل؟','Заново импортировать ZIP при перезапуске?',
        '重启时重新导入 ZIP？','هنگام راه‌اندازی مجدد فایل ZIP دوباره وارد شود؟'),
    'Restart and reimport ZIP': (
        'Restart and reimport ZIP','Reiniciar y reimportar ZIP',
        'إعادة التشغيل واستيراد ZIP','Перезапуск с импортом ZIP',
        '重启并重新导入 ZIP','راه‌اندازی مجدد و ورود دوباره ZIP'),
    'Restart without reimport': (
        'Restart without reimport','Reiniciar sin reimportar',
        'إعادة التشغيل دون استيراد','Перезапуск без импорта',
        '重启，不重新导入','راه‌اندازی مجدد بدون ورود دوباره'),
    'This restart prompt is no longer active, send /restart again': (
        'This restart prompt is no longer active, send /restart again',
        'Esta confirmación ya no está activa, envía /restart otra vez',
        'طلب إعادة التشغيل هذا لم يعد فعالاً، أرسل /restart مجدداً',
        'Это подтверждение больше не активно, отправьте /restart снова',
        '此重启确认已失效，请重新发送 /restart',
        'این درخواست راه‌اندازی مجدد دیگر فعال نیست، /restart را دوباره بفرستید'),
    'Restart cancelled': (
        'Restart cancelled','Reinicio cancelado','تم إلغاء إعادة التشغيل',
        'Перезапуск отменён','已取消重启','راه‌اندازی مجدد لغو شد'),
    'Saving progress and restarting with ZIP reimport': (
        'Saving progress and restarting with ZIP reimport',
        'Guardando el progreso y reiniciando con reimportación del ZIP',
        'جارٍ حفظ التقدم وإعادة التشغيل مع استيراد ZIP',
        'Сохраняем прогресс и перезапускаем с импортом ZIP',
        '正在保存进度并重启，将重新导入 ZIP',
        'ذخیره پیشرفت و راه‌اندازی مجدد همراه با ورود دوباره ZIP'),
}.items():
    for language,value in zip(('en','es','ar','ru','zh','fa'),values,strict=True):
        TEXT[language][key]=value

for language,description in {
    'en':'Restart, optionally reimporting the ZIP',
    'es':'Reiniciar, con opción de reimportar el ZIP',
    'ar':'إعادة التشغيل مع خيار استيراد ZIP',
    'ru':'Перезапуск с возможностью импорта ZIP',
    'zh':'重启，可选择重新导入 ZIP',
    'fa':'راه‌اندازی مجدد با گزینه ورود دوباره ZIP',
}.items():
    OWNER_HELP[language]='\n'.join('/restart - '+description if line.startswith('/restart ') else line
                                   for line in OWNER_HELP[language].splitlines())

from extra_languages import LANGUAGES as EXTRA_LANGUAGES, TEXT as EXTRA_TEXT, HELP as EXTRA_HELP, OWNER_HELP as EXTRA_OWNER_HELP
LANGUAGES.update(EXTRA_LANGUAGES)
TEXT.update(EXTRA_TEXT)
HELP.update(EXTRA_HELP)
OWNER_HELP.update(EXTRA_OWNER_HELP)

for key,values in {
    'Preparing backup ZIP...': ('Preparing backup ZIP...','Preparando ZIP de copia de seguridad...',
        'جارٍ إعداد نسخة احتياطية ZIP...','Готовим резервную копию ZIP...',
        '正在准备备份 ZIP...','در حال آماده‌سازی ZIP پشتیبان...'),
    'A backup ZIP is already being prepared': ('A backup ZIP is already being prepared',
        'Ya se está preparando una copia de seguridad ZIP','يجري إعداد نسخة احتياطية ZIP بالفعل',
        'Резервная копия ZIP уже готовится','备份 ZIP 已在准备中','یک ZIP پشتیبان در حال آماده‌سازی است'),
    'The backup ZIP is too large, the maximum size is 50 MB': (
        'The backup ZIP is too large, the maximum size is 50 MB',
        'El ZIP de copia de seguridad es demasiado grande, el límite es 50 MB',
        'ملف ZIP الاحتياطي كبير جداً، الحد الأقصى 50 ميغابايت',
        'Резервная копия ZIP слишком большая, максимум 50 МБ',
        '备份 ZIP 过大，最大为 50 MB','ZIP پشتیبان بیش از حد بزرگ است، حداکثر 50 مگابایت است'),
    'Backup ZIP sent. Shut down or restart?': ('Backup ZIP sent. Shut down or restart?',
        'Copia de seguridad ZIP enviada, ¿apagar o reiniciar?',
        'تم إرسال نسخة ZIP الاحتياطية، إيقاف أم إعادة تشغيل؟',
        'Резервная копия ZIP отправлена. Выключить или перезапустить?',
        '备份 ZIP 已发送，关闭还是重启？','ZIP پشتیبان ارسال شد، خاموش شود یا دوباره راه‌اندازی شود؟'),
    'Backup ZIP sent to your private chat': ('Backup ZIP sent to your private chat',
        'Copia de seguridad ZIP enviada a tu chat privado','تم إرسال نسخة ZIP الاحتياطية إلى محادثتك الخاصة',
        'Резервная копия ZIP отправлена в ваш личный чат','备份 ZIP 已发送到你的私聊',
        'ZIP پشتیبان به گفتگوی خصوصی شما ارسال شد'),
    'Could not send the backup ZIP, open our private chat and send /start, then try /upload again': (
        'Could not send the backup ZIP, open our private chat and send /start, then try /upload again',
        'No se pudo enviar el ZIP, abre nuestro chat privado, envía /start y vuelve a usar /upload',
        'تعذر إرسال ZIP الاحتياطي، افتح المحادثة الخاصة معي وأرسل /start ثم جرب /upload مجدداً',
        'Не удалось отправить ZIP, откройте личный чат, отправьте /start и повторите /upload',
        '无法发送备份 ZIP，请打开私聊，发送 /start，再尝试 /upload',
        'ارسال ZIP پشتیبان ممکن نشد، گفتگوی خصوصی را باز کنید، /start بفرستید و سپس /upload را دوباره امتحان کنید'),
    'This backup menu is no longer active, use /upload again': (
        'This backup menu is no longer active, use /upload again',
        'Este menú ya no está activo, usa /upload de nuevo',
        'قائمة النسخة الاحتياطية هذه لم تعد فعالة، استخدم /upload مجدداً',
        'Это меню резервной копии больше не активно, используйте /upload снова',
        '此备份菜单已失效，请再次使用 /upload','این منوی پشتیبان دیگر فعال نیست، /upload را دوباره بفرستید'),
    'Shut down': ('Shut down','Apagar','إيقاف','Выключить','关闭','خاموش کردن'),
    'Restart': ('Restart','Reiniciar','إعادة التشغيل','Перезапустить','重启','راه‌اندازی مجدد'),
    'Telegram did not confirm the backup ZIP, check your private chat before using /upload again': (
        'Telegram did not confirm the backup ZIP, check your private chat before using /upload again',
        'Telegram no confirmó el ZIP, revisa tu chat privado antes de usar /upload de nuevo',
        'لم يؤكد تيليجرام إرسال ZIP الاحتياطي، تحقق من محادثتك الخاصة قبل استخدام /upload مجدداً',
        'Telegram не подтвердил ZIP, проверьте личный чат перед повторным /upload',
        'Telegram 未确认备份 ZIP，请检查私聊后再使用 /upload',
        'تلگرام ارسال ZIP پشتیبان را تأیید نکرد، پیش از /upload دوباره گفتگوی خصوصی را بررسی کنید'),
}.items():
    for language,value in zip(('en','es','ar','ru','zh','fa'),values,strict=True):
        TEXT[language][key]=value

for language,description in {
    'en':'Send backup ZIP, choose shutdown or restart',
    'es':'Recibir copia ZIP y elegir apagar o reiniciar',
    'ar':'إرسال نسخة ZIP احتياطية واختيار إيقاف أو إعادة تشغيل',
    'ru':'Получить резервную копию ZIP и выбрать выключение или перезапуск',
    'zh':'接收备份 ZIP，选择关闭或重启',
    'fa':'دریافت ZIP پشتیبان و انتخاب خاموش کردن یا راه‌اندازی مجدد',
}.items():
    OWNER_HELP[language]='\n'.join('/upload - '+description if line.startswith('/upload ') else line
                                   for line in OWNER_HELP[language].splitlines())


def _interface_text(text):
    """Style authored interface prose before inserting user data or links."""
    if text.rstrip().endswith('...'):
        return text
    punctuation = str.maketrans({'.': ',', ';': ',', '。': '、', '．': '，',
                                 '；': '，', '؛': '،'})
    lines = []
    for line in text.splitlines(keepends=True):
        content = line.rstrip()
        whitespace = line[len(content):]
        lines.append(content.rstrip('.。．').translate(punctuation)+whitespace)
    return ''.join(lines)


# Keep lookup keys intact, and never alter captions or other user-supplied text.
for messages in TEXT.values():
    for key, text in messages.items():
        messages[key] = _interface_text(text)
for messages in (HELP, OWNER_HELP):
    for language, text in messages.items():
        messages[language] = _interface_text(text)
