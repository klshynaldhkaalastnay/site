"""Workflow dispatch, scoped cache rotation, and non-sensitive diagnostics"""
import importlib.metadata
import json
import os
import subprocess
import sys
from pathlib import Path


def gh(*args):
    process = subprocess.run(['gh',*args],capture_output=True,text=True)
    if process.returncode:
        raise RuntimeError('GitHub operation failed')
    return process.stdout


def prune():
    repo,ref = os.environ['GITHUB_REPOSITORY'],os.environ['GITHUB_REF']
    branch = os.environ['GITHUB_REF_NAME']
    run = os.environ['GITHUB_RUN_ID']+'-'+os.environ['GITHUB_RUN_ATTEMPT']
    kinds = ['state']
    if os.environ['BOT_SOURCE_DIR'] != os.environ['GITHUB_WORKSPACE']:
        kinds.append('source')
    for kind in kinds:
        prefix = f"tiktok-{kind}-{os.environ['RUNNER_OS']}-{branch}-"
        current = prefix+run
        pages = json.loads(gh('api','--paginate','--slurp','--method','GET',f'/repos/{repo}/actions/caches',
                             '-f',f'key={prefix}','-f',f'ref={ref}','-f','per_page=100'))
        entries = [e for p in pages for e in p['actions_caches'] if e['key'].startswith(prefix) and e['ref']==ref]
        if not any(e['key']==current for e in entries):
            raise RuntimeError('New cache not found, retaining all previous caches')
        older = sorted((e for e in entries if e['key']!=current),key=lambda e:e['created_at'],reverse=True)
        for entry in older[1:]:
            try:
                gh('api','--method','DELETE',f"/repos/{repo}/actions/caches/{entry['id']}")
            except RuntimeError:
                print('An old cache could not be removed')
    print('New cache verified, retained one previous cache')


def dispatch():
    repo = os.environ['GITHUB_REPOSITORY']
    run = json.loads(gh('api',f"/repos/{repo}/actions/runs/{os.environ['GITHUB_RUN_ID']}"))
    payload = {'ref':os.environ['GITHUB_REF_NAME'],'inputs':{
        'continue':os.getenv('CONTINUE_SESSIONS','true').lower(),'force_reimport':'false'}}
    request = Path(os.environ['RUNNER_TEMP'])/'tiktok-next-session.json'
    request.write_text(json.dumps(payload))
    gh('api','--method','POST',f"/repos/{repo}/actions/workflows/{run['workflow_id']}/dispatches",'--input',str(request))
    print('Next bot session queued')


def diagnostics():
    # No URLs, chat IDs, tokens, cookies, exception messages, or database contents
    lines = ['TikTok bot diagnostics','Session completed: '+os.getenv('SESSION_OK',''),
             'Stop reason: '+os.getenv('SESSION_REASON','')]
    for package in ('gallery-dl','aiogram','boto3','Pillow'):
        try:
            lines.append(package+': '+importlib.metadata.version(package))
        except importlib.metadata.PackageNotFoundError:
            lines.append(package+': not installed')
    Path('diagnostics.txt').write_text('\n'.join(lines)+'\n')


if __name__=='__main__':
    try:
        {'prune':prune,'dispatch':dispatch,'diagnostics':diagnostics}[sys.argv[1]]()
    except Exception as exc:
        print(f'Workflow operation failed, {type(exc).__name__}',file=sys.stderr)
        sys.exit(1)
