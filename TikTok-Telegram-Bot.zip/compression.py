"""Telegram-compatible video encoding with bounded CPU, time and output size."""
from contextlib import contextmanager
import fcntl
from fractions import Fraction
import hashlib
import json
import math
import os
from pathlib import Path
import shutil
import subprocess
import tempfile
import time

from common import MAX_BYTES

MAX_VIDEO_INPUT_BYTES = 1_000_000_000
DEFAULTS = {'mode':'all', 'fps':'original', 'resolution':'1080',
            'quality':'balanced', 'preset':'fast', 'audio':'128'}
CHOICES = {
    'mode': {'all':'All videos', 'large':'Over 50 MB', 'none':'None'},
    'fps': {'original':'Original', '24':'24 fps', '30':'30 fps', '60':'60 fps'},
    'resolution': {'original':'Original', '1080':'1080p', '720':'720p', '480':'480p'},
    'quality': {'high':'High quality', 'balanced':'Balanced', 'small':'Smaller files'},
    'preset': {'fast':'Fast', 'medium':'Medium', 'slow':'Slow'},
    'audio': {'64':'64 kbps', '96':'96 kbps', '128':'128 kbps', '192':'192 kbps'},
}
LABELS = {'fps':'Maximum frame rate', 'resolution':'Maximum resolution',
          'quality':'Quality', 'preset':'Encoding speed', 'audio':'Video audio bitrate'}
CRF = {'high':20, 'balanced':23, 'small':28}


class CompressionError(Exception):
    pass


class CompressionTooLarge(CompressionError):
    pass


def options(value=None):
    if isinstance(value,str):
        try:
            value = json.loads(value)
        except (ValueError,TypeError):
            value = None
    result = dict(DEFAULTS)
    if isinstance(value,dict):
        for key,choices in CHOICES.items():
            selected = value.get(key)
            if isinstance(selected,str) and selected in choices:
                result[key] = selected
    return result


def should_compress(size, settings):
    return settings['mode']=='all' or settings['mode']=='large' and size>MAX_BYTES


def probe(path):
    try:
        result = subprocess.run([
            'ffprobe','-v','error','-protocol_whitelist','file,pipe',
            '-show_entries','format=duration:stream=codec_type,codec_name,pix_fmt,width,height,avg_frame_rate,r_frame_rate,sample_aspect_ratio,duration,color_transfer,color_primaries,color_space:stream_side_data=rotation',
            '-of','json',str(path)],capture_output=True,timeout=30,check=True)
        if len(result.stdout)>1_000_000:
            raise CompressionError('Invalid media metadata')
        data = json.loads(result.stdout)
        video = next(s for s in data['streams'] if s.get('codec_type')=='video')
        width,height = int(video['width']),int(video['height'])
        rotation = next((float(s.get('rotation',0)) for s in video.get('side_data_list',[])),0)
        if round(rotation)%180:
            width,height = height,width
        if not (0<width<=8192 and 0<height<=8192 and width*height<=33_554_432):
            raise CompressionError('Unsupported dimensions')
        duration = float(data.get('format',{}).get('duration') or video.get('duration') or 0)
        if not math.isfinite(duration) or duration<=0:
            raise CompressionError('Invalid duration')
        try:
            fps = float(Fraction(video.get('avg_frame_rate','0/1')))
        except (ValueError,ZeroDivisionError):
            fps = 0
        if not math.isfinite(fps) or fps<0 or fps>240:
            raise CompressionError('Unsupported frame rate')
        try:
            nominal_fps = float(Fraction(video.get('r_frame_rate','0/1')))
        except (ValueError,ZeroDivisionError):
            nominal_fps = fps
        audio = next((s for s in data['streams'] if s.get('codec_type')=='audio'),None)
        return {'width':width,'height':height,'duration':duration,'fps':fps,'nominal_fps':nominal_fps,
                'codec':video.get('codec_name'),'pix_fmt':video.get('pix_fmt'),
                'transfer':video.get('color_transfer'),'primaries':video.get('color_primaries'),
                'color_space':video.get('color_space'),
                'audio_codec':audio.get('codec_name') if audio else None,
                'has_audio':audio is not None}
    except (OSError,subprocess.SubprocessError,ValueError,KeyError,StopIteration) as exc:
        raise CompressionError('Could not inspect video') from exc


@contextmanager
def encoding_slot():
    # Two two-thread encoders share the runner; workers retain their normal queue.
    deadline = time.monotonic()+1200
    locks = [open(Path(tempfile.gettempdir())/f'tiktok-encoding-{i}.lock','a') for i in range(2)]
    acquired = None
    try:
        while acquired is None:
            for lock in locks:
                try:
                    fcntl.flock(lock,fcntl.LOCK_EX | fcntl.LOCK_NB)
                    acquired = lock
                    break
                except BlockingIOError:
                    pass
            if acquired is None:
                if time.monotonic()>=deadline:
                    raise CompressionError('Encoding queue timeout')
                time.sleep(0.25)
        yield
    finally:
        for lock in locks:
            lock.close()


def run_encoder(args, output, deadline):
    # FFmpeg stays in the worker's process group, so cancel/restart kills it too.
    try:
        with subprocess.Popen(args,stdin=subprocess.DEVNULL,stdout=subprocess.DEVNULL,
                              stderr=subprocess.DEVNULL) as process:
            try:
                while process.poll() is None:
                    if time.monotonic()>=deadline:
                        raise CompressionError('Encoding timeout')
                    if shutil.disk_usage(Path(args[args.index('-i')+1]).parent).free<100_000_000:
                        raise CompressionError('Insufficient disk space')
                    if output is not None and output.exists() and output.stat().st_size>MAX_BYTES:
                        raise CompressionTooLarge('Encoded video is too large')
                    time.sleep(0.1)
                if process.returncode:
                    raise CompressionError('Encoder failed')
                if output is not None and (not output.is_file() or not output.stat().st_size):
                    raise CompressionError('Empty encoded video')
                if output is not None and output.stat().st_size>MAX_BYTES:
                    raise CompressionTooLarge('Encoded video is too large')
            finally:
                if process.poll() is None:
                    process.terminate()
                    try:
                        process.wait(timeout=3)
                    except subprocess.TimeoutExpired:
                        process.kill()
                        process.wait()
    except OSError as exc:
        raise CompressionError('FFmpeg is unavailable') from exc


def video_filters(info, settings, fit_side=None):
    filters = []
    side = None if settings['resolution']=='original' else int(settings['resolution'])
    if fit_side:
        side = min(side,fit_side) if side else fit_side
    if side:
        # A portrait 1080p cap is 1080x1920, landscape is 1920x1080.
        long_side = side*16//9
        filters.append(f"scale=w='if(gte(iw,ih),min(iw,{long_side}),min(iw,{side}))':"
                       f"h='if(gte(iw,ih),min(ih,{side}),min(ih,{long_side}))':"
                       'force_original_aspect_ratio=decrease:force_divisible_by=2')
    else:
        filters.append('scale=trunc(iw/2)*2:trunc(ih/2)*2')
    filters.append('setsar=1')
    if info.get('transfer') in ('smpte2084','arib-std-b67'):
        # Standard 8-bit H.264 output needs HDR tone mapping rather than just
        # dropping bit depth, which would wash out phone HDR recordings.
        filters += ['zscale=t=linear:npl=100','format=gbrpf32le','zscale=p=bt709',
                    'tonemap=mobius','zscale=t=bt709:m=bt709:r=tv','format=yuv420p',
                    'sidedata=mode=delete:type=MASTERING_DISPLAY_METADATA',
                    'sidedata=mode=delete:type=CONTENT_LIGHT_LEVEL']
    if settings['fps']!='original' and (not info['fps'] or max(info['fps'],info.get('nominal_fps',0))>int(settings['fps'])):
        filters.append('fps='+settings['fps'])
    return ','.join(filters)


def encoder_args(source, info, settings, fit_side=None):
    args = ['ffmpeg','-hide_banner','-loglevel','error','-nostdin','-y',
            '-threads','2','-filter_threads','1','-protocol_whitelist','file,pipe',
            '-i',str(source),'-map','0:v:0','-map_metadata','-1','-map_chapters','-1',
            '-sn','-dn','-vf',video_filters(info,settings,fit_side),
            '-c:v','libx264','-preset',settings['preset'],'-pix_fmt','yuv420p',
            '-threads','2','-fps_mode','passthrough']
    if info.get('transfer') in ('smpte2084','arib-std-b67'):
        args += ['-color_primaries','bt709','-color_trc','bt709','-colorspace','bt709']
    return args


def audio_args(bitrate):
    return ['-map','0:a:0?','-c:a','aac','-profile:a','aac_low','-b:a',str(bitrate),'-ac','2']


def fit_budget(info, settings, target):
    total = int(target*8/info['duration']*0.97)
    audio = min(int(settings['audio'])*1000,max(32000,total//5//1000*1000)) if info['has_audio'] else 0
    video = total-audio
    if video<40000:
        raise CompressionTooLarge('Video cannot fit the upload limit')
    fps = info['fps'] or 30
    if settings['fps']!='original':
        fps = min(fps,int(settings['fps']))
    rate = video/max(1,fps/30)
    side = 360 if rate<350000 else 480 if rate<800000 else 720 if rate<1700000 else 1080
    return video,audio,side


def digest_file(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream,'sha256').hexdigest()


def compress_video(source, settings, note=lambda *a,**kw:None):
    settings = options(settings)
    source = Path(source).resolve()
    original = probe(source)
    with encoding_slot(), tempfile.TemporaryDirectory(prefix='encode-',dir=source.parent) as temp:
        output = Path(temp)/'video.mp4'
        deadline = time.monotonic()+900
        note('compression','quality_encoding')
        try:
            run_encoder(encoder_args(source,original,settings)+['-crf',str(CRF[settings['quality']])]
                        +audio_args(int(settings['audio'])*1000)
                        +['-movflags','+faststart',str(output)],output,deadline)
        except CompressionTooLarge:
            output.unlink(missing_ok=True)
        if not output.exists():
            # Size fitting always reads the original, avoiding repeated lossy encoding.
            for margin in (0.96,0.88):
                note('compression','size_fitting')
                video,audio,side = fit_budget(original,settings,int(MAX_BYTES*margin))
                prefix = Path(temp)/'pass'
                args = encoder_args(source,original,settings,side)+['-b:v',str(video),'-passlogfile',str(prefix)]
                run_encoder(args+['-pass','1','-an','-f','null',os.devnull],None,deadline)
                try:
                    run_encoder(args+['-pass','2']+audio_args(audio)
                                +['-movflags','+faststart',str(output)],output,deadline)
                    break
                except CompressionTooLarge:
                    output.unlink(missing_ok=True)
            else:
                raise CompressionTooLarge('Video cannot fit the upload limit')
        encoded = probe(output)
        if abs(encoded['duration']-original['duration'])>max(0.5,original['duration']*0.01):
            raise CompressionError('Incomplete encoded video')
        if encoded['codec']!='h264' or encoded['pix_fmt']!='yuv420p' or (original['has_audio'] and encoded['audio_codec']!='aac'):
            raise CompressionError('Invalid encoded video')
        # Avoid making already-efficient compatible videos larger at the defaults.
        default_profile = all(settings[k]==DEFAULTS[k] for k in DEFAULTS if k!='mode')
        if (default_profile and source.suffix=='.mp4' and source.stat().st_size<=MAX_BYTES
                and source.stat().st_size<=output.stat().st_size and original['codec']=='h264'
                and original['pix_fmt']=='yuv420p' and original['audio_codec'] in (None,'aac')
                and original['width']==encoded['width'] and original['height']==encoded['height']):
            note('compression','original_already_smaller')
            return source,original
        final = source.with_name(source.stem+'.compressed.mp4')
        output.replace(final)
        source.unlink()
        note('compression','completed')
        return final,encoded
