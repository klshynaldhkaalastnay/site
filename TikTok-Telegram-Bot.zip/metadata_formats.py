"""Lossless JSON/TXT and typed XML exports of available TikTok post data."""
import json
import re
import zlib
from xml.etree import ElementTree as ET

from common import MAX_BYTES

FORMATS = {'json':'JSON','xml':'XML','txt':'TXT'}
XML_INVALID = re.compile('[\x00-\x08\x0b\x0c\x0e-\x1f\ud800-\udfff\ufffe\uffff]')


def chosen_format(value):
    return value if isinstance(value,str) and value in FORMATS else 'json'


def export_metadata(compressed, format):
    decoder = zlib.decompressobj()
    raw = decoder.decompress(compressed,MAX_BYTES+1)
    if len(raw)>MAX_BYTES or not decoder.eof:
        raise ValueError('Metadata too large or incomplete')
    data = json.loads(raw)
    format = chosen_format(format)
    if format=='json':
        return (json.dumps(data,ensure_ascii=False,allow_nan=False,indent=2)+'\n').encode('utf-8')
    if format=='txt':
        lines=[]
        def visit(value,indent=''):
            if isinstance(value,dict):
                if not value:lines.append(indent+'{}')
                for key,item in value.items():
                    label=json.dumps(key,ensure_ascii=False)
                    if isinstance(item,(dict,list)):
                        lines.append(indent+label+':')
                        visit(item,indent+'  ')
                    else:lines.append(indent+label+': '+json.dumps(item,ensure_ascii=False))
            elif isinstance(value,list):
                if not value:lines.append(indent+'[]')
                for index,item in enumerate(value):
                    lines.append(indent+f'[{index}]:')
                    visit(item,indent+'  ')
            else:lines.append(indent+json.dumps(value,ensure_ascii=False))
        visit(data)
        return ('\n'.join(lines)+'\n').encode('utf-8')
    root = ET.Element('metadata')
    def visit(node,value):
        kind = ('object' if isinstance(value,dict) else 'array' if isinstance(value,list)
                else 'null' if value is None else 'boolean' if isinstance(value,bool)
                else 'number' if isinstance(value,(int,float)) else 'string')
        node.set('type',kind)
        if isinstance(value,dict):
            for key,item in value.items():
                child=ET.SubElement(node,'field',name=key if not XML_INVALID.search(key) else json.dumps(key,ensure_ascii=True))
                if XML_INVALID.search(key):child.set('name_encoding','json')
                visit(child,item)
        elif isinstance(value,list):
            for index,item in enumerate(value):visit(ET.SubElement(node,'item',index=str(index)),item)
        elif value is not None:
            text=value if isinstance(value,str) else json.dumps(value)
            if XML_INVALID.search(text):
                text=json.dumps(value,ensure_ascii=True)
                node.set('encoding','json')
            node.text=text
    visit(root,data)
    ET.indent(root,space='  ')
    return ET.tostring(root,encoding='utf-8',xml_declaration=True)+b'\n'
