from types import SimpleNamespace as NS
import pytest
from common import normalize_url
from bot import Runner
from state import State
import worker
from test_audio import Response, FakeBot


def test_sound_urls_and_metadata(tmp_path,monkeypatch):
    from gallery_dl.extractor.tiktok import TiktokExtractor
    from mutagen.id3 import ID3
    short='https://vt.tiktok.com/ZS9AKmQ4p54pE-qDCxo/'
    assert normalize_url(short)==short
    assert normalize_url('https://www.tiktok.com/music/A-song-12345?x=1')=='https://www.tiktok.com/music/A-song-12345'
    data={'webapp.music-detail':{'musicInfo':{'music':{'id':'12345','title':'Song','authorName':'Artist','playUrl':'https://cdn.example/a.mp3'}}}}
    monkeypatch.setattr(TiktokExtractor,'_extract_rehydration_data',lambda *a,**k:data)
    monkeypatch.setattr(worker,'get',lambda *a,**k:Response(b'\xff\xfb\x90\x00'+b'\0'*2000))
    result=worker.download('https://www.tiktok.com/music/12345',tmp_path,include_audio=False)
    assert result['ok'] and result['media'][0]['reply_to_source']
    tags=ID3(tmp_path/result['media'][0]['file'])
    assert str(tags['TXXX:TikTok Sound ID'])=='12345'
    assert 'TXXX:TikTok Post ID' not in tags
    assert worker.music_from_page(data,'999') is None

@pytest.mark.asyncio
async def test_settings_ownership_persistence_and_audio_reply(tmp_path):
    state=State(tmp_path/'state.db');bot=FakeBot();r=Runner(state,bot,tmp_path,7,99)
    async def fast(chat,op): return await op()
    r.api=fast
    class Query:
        data='settings:1:audio-off'; from_user=NS(id=2); message=NS(chat=NS(id=1),message_id=42)
        async def answer(self): pass
    q=Query();await r.settings_callback(q)
    assert state.get('audio:1') is None
    q.from_user=NS(id=1);await r.settings_callback(q)
    assert state.get('audio:1')=='off'
    assert len(r.settings_view(1)[1].inline_keyboard)==3
    assert len(r.settings_view(1,'language')[1].inline_keyboard)==4
    assert r.settings_view(1,'audio')[1].inline_keyboard[0][1].text=='✓ Off'
    jid,_=state.submit(1,1,777,None,'https://www.tiktok.com/music/12345')
    folder=r.work/'sound';folder.mkdir();(folder/'sound.mp3').write_bytes(b'audio')
    await r.deliver(jid,[{'file':'sound.mp3','kind':'audio','sha256':'abc','reply_to_source':True}],folder)
    assert bot.audios[0]['reply_parameters'].message_id==777
    state.close();state=State(tmp_path/'state.db');assert state.get('audio:1')=='off';state.close()


def test_sound_detail_fallback_and_nested_url(tmp_path,monkeypatch):
    import json
    from gallery_dl.extractor.tiktok import TiktokExtractor
    monkeypatch.setattr(TiktokExtractor,'_extract_rehydration_data',lambda *a,**k:{'webapp.music-detail':{}})
    music={'id':'12345','title':'Fallback song','playUrl':{'UrlList':['https://cdn.example/audio']}}
    requested=[]
    def get(session,url,**kwargs):
        requested.append(url)
        return Response(json.dumps({'musicInfo':{'music':music}}).encode() if '/api/music/detail/' in url else b'\xff\xfb\x90\x00'+b'\0'*2000)
    monkeypatch.setattr(worker,'get',get)
    worker.DIAGNOSTICS.clear()
    result=worker.download('https://www.tiktok.com/music/12345',tmp_path)
    assert result['ok'] and result['media'][0]['filename']=='Fallback song.mp3'
    assert len(requested)==2
    assert any(d['stage']=='sound_detail' and d['reason']=='play_url_found' for d in worker.DIAGNOSTICS)


def test_diagnostics_explain_failure_without_secrets(tmp_path,monkeypatch,caplog):
    import logging,requests
    worker.DIAGNOSTICS.clear()
    def failed(*a,**k):
        response=NS(status_code=403)
        raise requests.HTTPError('SECRET-cookie https://cdn.example/?token=SECRET',response=response)
    monkeypatch.setattr(worker,'get',failed)
    record,error=worker.download_sound(None,{'playUrl':'https://cdn.example/a'},'123',tmp_path)
    assert record is None and error=='unavailable'
    with caplog.at_level(logging.INFO):
        Runner.log_diagnostics({'ok':False,'diagnostics':worker.DIAGNOSTICS+[{'reason':'SECRET https://foo'}]})
    assert 'stage=audio_download' in caplog.text and 'status=403' in caplog.text
    assert 'SECRET' not in caplog.text and 'https://' not in caplog.text
