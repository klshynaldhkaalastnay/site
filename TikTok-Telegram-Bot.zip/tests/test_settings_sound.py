from types import SimpleNamespace as NS
import pytest
from common import normalize_url
from bot import Runner
from state import State
import worker
from test_audio import Response, FakeBot


def test_sound_urls_and_metadata(tmp_path,monkeypatch):
    from gallery_dl.extractor.tiktok import TiktokExtractor
    from mutagen.id3 import ID3
    short='https://vt.tiktok.com/ZS9AKmQ4p54pE-qDCxo/'
    assert normalize_url(short)==short
    assert normalize_url('https://www.tiktok.com/music/A-song-12345?x=1')=='https://www.tiktok.com/music/12345'
    data={'webapp.music-detail':{'musicInfo':{'music':{'id':'12345','title':'Song','authorName':'Artist','playUrl':'https://cdn.example/a.mp3'}}}}
    monkeypatch.setattr(TiktokExtractor,'_extract_rehydration_data',lambda *a,**k:data)
    monkeypatch.setattr(worker,'get',lambda *a,**k:Response(b'\xff\xfb\x90\x00'+b'\0'*2000))
    result=worker.download('https://www.tiktok.com/music/12345',tmp_path,include_audio=False)
    assert result['ok'] and result['media'][0]['reply_to_source']
    tags=ID3(tmp_path/result['media'][0]['file'])
    assert str(tags['TXXX:TikTok Sound ID'])=='12345'
    assert 'TXXX:TikTok Post ID' not in tags
    assert worker.music_from_page(data,'999') is None

@pytest.mark.asyncio
async def test_settings_ownership_persistence_and_audio_reply(tmp_path):
    state=State(tmp_path/'state.db');bot=FakeBot();r=Runner(state,bot,tmp_path,7,99)
    async def fast(chat,op): return await op()
    r.api=fast
    class Query:
        data='settings:1:audio-off'; from_user=NS(id=2); message=NS(chat=NS(id=1))
        async def answer(self): pass
        async def edit_message_text(self,*a,**k): pass
    q=Query();await r.settings_callback(q)
    assert state.get('audio:1') is None
    q.from_user=NS(id=1);await r.settings_callback(q)
    assert state.get('audio:1')=='off'
    assert len(r.settings_view(1)[1].inline_keyboard)==2
    assert len(r.settings_view(1,'language')[1].inline_keyboard)==4
    assert r.settings_view(1,'audio')[1].inline_keyboard[0][1].text=='✓ Off'
    jid,_=state.submit(1,1,777,None,'https://www.tiktok.com/music/12345')
    folder=r.work/'sound';folder.mkdir();(folder/'sound.mp3').write_bytes(b'audio')
    await r.deliver(jid,[{'file':'sound.mp3','kind':'audio','sha256':'abc','reply_to_source':True}],folder)
    assert bot.audios[0]['reply_parameters'].message_id==777
    state.close();state=State(tmp_path/'state.db');assert state.get('audio:1')=='off';state.close()
