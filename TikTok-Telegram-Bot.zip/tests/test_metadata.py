"""Metadata formats, full extractor payloads and durable native Telegram replies."""
import asyncio
import copy
from datetime import datetime
import io
import json
from pathlib import Path
from xml.etree import ElementTree as ET
import zlib

import pytest
from PIL import Image
from gallery_dl.extractor.tiktok import TiktokExtractor
from aiogram.exceptions import TelegramNetworkError

from bot import Runner
from common import BOT_ATTRIBUTION
from i18n import LANGUAGES, TEXT
import metadata_formats
from metadata_formats import export_metadata
from state import State
from test_aiogram import setup, callback, message
from test_bot import Response
import worker

POST_ID='1234567890'
POST_URL='https://www.tiktok.com/@example/video/'+POST_ID
DATA={'id':POST_ID,'desc':'Full caption <hello> & سلام 😀\nSecond line',
      'author':{'nickname':'Example','uniqueId':'example'},'stats':{'diggCount':10,'playCount':20},
      'music':{'id':'567','title':'Song'},'images':[{'url':'https://cdn.example/a'},{'url':'https://cdn.example/b'}],
      'privateItem':False,'ratio':1.25,'extra':None,'empty':{},'array':[]}


def documents(session):
    return [request for request in session.calls('sendDocument')
            if any('.metadata.' in file['filename'] for file in request['files'].values())]


def decode_xml(node):
    type=node.get('type')
    if type=='object':
        return {json.loads(child.get('name')) if child.get('name_encoding') else child.get('name'):decode_xml(child) for child in node}
    if type=='array':return [decode_xml(child) for child in node]
    if type=='null':return None
    if type in ('number','boolean') or node.get('encoding')=='json':return json.loads(node.text)
    return node.text or ''


@pytest.mark.parametrize('format',['json','xml','txt'])
def test_format_contains_complete_data_unicode_and_nested_values(format):
    data=dict(DATA,control='A\x00B',**{'bad\x00key':'value'})
    file=export_metadata(zlib.compress(json.dumps(data,ensure_ascii=False).encode()),format)
    if format=='json':assert json.loads(file)==data
    elif format=='xml':assert decode_xml(ET.fromstring(file))==data
    else:
        for text in ('"diggCount": 10','"privateItem": false','"extra": null','سلام 😀','https://cdn.example/b','A\\u0000B'):
            assert text in file.decode()


async def test_settings_defaults_formats_ownership_translations_and_snapshots(tmp_path):
    state,session,bot,r=setup(tmp_path)
    assert r.settings_view(1)[1].inline_keyboard[5][0].text=='Metadata: Off with no button'
    assert r.settings_view(1,'metadata')[1].inline_keyboard[1][0].text=='✓ Off with no button'
    assert r.settings_view(1,'metadata-format')[1].inline_keyboard[0][0].text=='✓ JSON'
    async with bot.context():
        await r.handle(callback(bot,'settings:1:metadata-on',user=2))
        assert state.get('metadata:1') is None
        for language in LANGUAGES:
            state.set('language:1',language)
            assert TEXT[language]['Metadata'] in r.settings_view(1)[1].inline_keyboard[5][0].text
            assert TEXT[language]['Metadata format']==r.settings_view(1,'metadata-format')[0]
        state.set('language:1','en')
        for format in ('xml','txt','json'):
            await r.handle(callback(bot,'settings:1:metadata-format-'+format))
            assert state.get('metadata_format:1')==format
        for mode in ('on','off','off_no_button'):
            await r.handle(callback(bot,'settings:1:metadata-'+mode))
            assert state.get('metadata:1')==mode
        await r.handle(callback(bot,'settings:1:metadata-format-pdf'))
        assert state.get('metadata_format:1')=='json'
        state.set('metadata:1','on');state.set('metadata_format:1','xml')
        jid,_=state.submit(1,-10,77,12,POST_URL)
        r.metadata_files.snapshot(jid)
        state.set('metadata:1','off_no_button');state.set('metadata_format:1','txt')
        assert state.job(jid)['metadata_mode']=='on' and state.job(jid)['metadata_format']=='xml'
        state.close();state=State(tmp_path/'state.db');r.state=state
        assert state.job(jid)['metadata_mode']=='on' and state.job(jid)['metadata_format']=='xml'
    state.close()


@pytest.mark.parametrize('format',['json','xml','txt'])
@pytest.mark.parametrize('photos',[0,12])
async def test_automatic_file_replies_to_media_once_and_keeps_format(tmp_path,format,photos):
    state,session,bot,r=setup(tmp_path)
    state.set('metadata:1','on');state.set('metadata_format:1',format)
    jid,_=state.submit(1,-10,77,12,POST_URL)
    folder=tmp_path/'files';folder.mkdir()
    records=[]
    for index in range(photos or 1):
        name=f'{index}.jpg' if photos else 'video.mp4';(folder/name).write_bytes(b'media')
        records.append({'file':name,'kind':'image' if photos else 'video','sha256':str(index),'width':40,'height':60})
    async with bot.context():
        await r.deliver(jid,records,folder,post_id=POST_ID,full_metadata=DATA)
        await r.deliver(jid,records,folder,post_id=POST_ID,full_metadata=DATA)
    assert len(documents(session))==1
    file_request=documents(session)[0]
    assert next(iter(file_request['files'].values()))['filename']==POST_ID+'.metadata.'+format
    assert file_request['fields']['caption']==BOT_ATTRIBUTION
    assert json.loads(file_request['fields']['reply_parameters'])['message_id']==state.job(jid)['reply_message']
    assert file_request['fields']['message_thread_id']=='12'
    assert state.job(jid)['metadata_file_message'] and not state.job(jid)['metadata_file_in_flight']
    state.close()


async def test_full_caption_and_txt_metadata_have_separate_files_and_receipts(tmp_path):
    state,session,bot,r=setup(tmp_path)
    state.set('caption:1','on');state.set('metadata:1','on');state.set('metadata_format:1','txt')
    jid,_=state.submit(1,-10,77,12,POST_URL)
    folder=tmp_path/'files';folder.mkdir();(folder/'video.mp4').write_bytes(b'media')
    title='full caption سلام 😀 '*100
    async with bot.context():await r.deliver(jid,[{'file':'video.mp4','kind':'video','sha256':'v'}],folder,title,post_id=POST_ID,full_metadata=DATA)
    files=[file for request in session.calls('sendDocument') for file in request['files'].values()]
    assert {file['filename'] for file in files}=={POST_ID+'.txt',POST_ID+'.metadata.txt'}
    assert next(file['data'] for file in files if file['filename']==POST_ID+'.txt')==title.encode()
    assert state.job(jid)['caption_file_message']!=state.job(jid)['metadata_file_message']
    assert len({json.loads(request['fields']['reply_parameters'])['message_id'] for request in session.calls('sendDocument')})==1
    state.close()


async def test_off_button_ownership_restart_cooldown_and_repeated_clicks(tmp_path,monkeypatch):
    state,session,bot,r=setup(tmp_path)
    state.set('metadata:1','off')
    jid,_=state.submit(1,-10,77,12,POST_URL)
    r.metadata_files.remember(jid,DATA,POST_ID)
    state.change(jid,status='done',reply_message=301)
    async with bot.context():
        await r.metadata_files.install(jid)
        mid=state.job(jid)['metadata_button_message']
        assert session.calls('sendMessage')[0]['fields']['text']==BOT_ATTRIBUTION
        for user,chat,thread,binding in ((2,-10,12,mid),(1,-11,12,mid),(1,-10,13,mid),(1,-10,12,mid+1)):
            await r.handle(callback(bot,f'metadata:{jid}',user=user,chat=chat,mid=binding,message_thread_id=thread))
        assert not documents(session)
        state.close();state=State(tmp_path/'state.db');r.state=state
        query=callback(bot,f'metadata:{jid}',chat=-10,mid=mid,message_thread_id=12)
        await r.handle(query)
        assert len(documents(session))==1
        assert state.button_remaining(jid,'metadata')>99
        await r.handle(query)
        assert len(documents(session))==1
        state.db.execute("UPDATE button_presses SET created=created-101 WHERE source_job=? AND kind='metadata'",(jid,));state.db.commit()
        await r.handle(query)
        assert len(documents(session))==1
        await r.handle(callback(bot,f'metadata:{jid}',chat=-10,mid=mid,message_thread_id=12))
        assert len(documents(session))==2
    state.close()


@pytest.mark.parametrize('failure',[400,413,'network'])
async def test_automatic_recovery_does_not_repeat_uncertain_upload(tmp_path,failure):
    state,session,bot,r=setup(tmp_path)
    state.set('metadata:1','on')
    jid,_=state.submit(1,-10,77,12,POST_URL)
    r.metadata_files.remember(jid,DATA,POST_ID);state.change(jid,status='done',reply_message=301)
    if failure=='network':
        session.responses['sendDocument'].append((200,lambda method:TelegramNetworkError(method=method,message='lost acknowledgement')))
    else:session.queue('sendDocument',status=failure,description='Rejected')
    async with bot.context():
        await r.metadata_files.automatic(jid)
        assert bool(state.job(jid)['metadata_file_in_flight'])==(failure=='network')
        state.close();state=State(tmp_path/'state.db');r.state=state
        await r.metadata_files.automatic(jid)
        assert len(documents(session))==(1 if failure=='network' else 2)
    state.close()


async def test_off_no_button_and_extraction_jobs_store_no_metadata(tmp_path):
    state,session,bot,r=setup(tmp_path)
    jid,_=state.submit(1,-10,77,12,POST_URL)
    r.metadata_files.remember(jid,DATA,POST_ID);state.change(jid,status='done',reply_message=301)
    async with bot.context():
        await r.metadata_files.install(jid);await r.metadata_files.automatic(jid)
    assert state.job(jid)['metadata_data'] is None and not documents(session) and not session.calls('sendMessage')
    state.set('metadata:1','on')
    for audio,subtitle in ((True,False),(False,True)):
        jid,_=state.submit(1,-10,78+int(audio),12,POST_URL,audio_only=audio,subtitles_only=subtitle)
        r.metadata_files.remember(jid,DATA,POST_ID)
        assert state.job(jid)['metadata_data'] is None
    state.close()


@pytest.mark.parametrize('photos',[False,True])
@pytest.mark.parametrize('enabled',[False,True])
def test_real_gallery_metadata_is_complete_and_copied_before_mutation(tmp_path,monkeypatch,photos,enabled):
    post=copy.deepcopy(DATA)
    post['createTime']=1
    if photos:
        post['imagePost']={'images':[{'imageURL':{'urlList':[f'https://cdn.example/{index}.jpg']},'imageWidth':40,'imageHeight':60} for index in range(3)]}
    else:post['video']={'playAddr':'https://cdn.example/video.mp4','width':40,'height':60,'duration':3}
    body={'webapp.video-detail':{'statusCode':0,'itemInfo':{'itemStruct':post}}}
    monkeypatch.setattr(TiktokExtractor,'_extract_rehydration_data',lambda *a,**k:copy.deepcopy(body))
    image=io.BytesIO();Image.new('RGB',(40,60),'red').save(image,format='JPEG')
    content=image.getvalue() if photos else b'\x00\x00\x00\x18ftypisom'+b'0'*100
    class Media(Response):
        def __enter__(self):return self
        def __exit__(self,*args):pass
    monkeypatch.setattr(worker,'get',lambda *a,**k:Media([content]))
    result=worker.download(POST_URL,tmp_path,include_audio=False,include_metadata=enabled,compression={'mode':'none'})
    assert result['ok']
    if not enabled:
        assert result['full_metadata'] is None
        return
    full=json.loads(result['full_metadata'])
    for key,value in post.items():assert full[key]==value
    assert 'date' in full and isinstance(full['date'],str)
    assert 'filename' not in full and '_fallback' not in full and 'num' not in full
    assert full['post_type']==('image' if photos else 'video')
    assert worker.post_metadata({'date':datetime(2026,10,13)})=='{"date": "2026-10-13T00:00:00"}'


def test_bounded_metadata_decode_and_invalid_format():
    assert metadata_formats.chosen_format(['xml'])=='json'
    with pytest.raises(zlib.error):export_metadata(b'broken','json')


async def test_caption_and_metadata_manual_buttons_have_independent_cooldowns(tmp_path):
    state,session,bot,r=setup(tmp_path)
    state.set('caption:1','off');state.set('metadata:1','off');state.set('metadata_format:1','txt')
    jid,_=state.submit(1,-10,77,12,POST_URL)
    r.caption_files.remember(jid,'caption'*300,POST_ID,True)
    r.metadata_files.remember(jid,DATA,POST_ID)
    state.change(jid,status='done',reply_message=301)
    async with bot.context():
        await r.caption_files.install(jid);await r.metadata_files.install(jid)
        row=state.job(jid)
        await r.handle(callback(bot,f'caption:{jid}',chat=-10,mid=row['caption_button_message'],message_thread_id=12))
        assert state.button_remaining(jid,'metadata')==0
        await r.handle(callback(bot,f'metadata:{jid}',chat=-10,mid=row['metadata_button_message'],message_thread_id=12))
        assert state.button_remaining(jid,'metadata')>99 and state.button_remaining(jid,'caption')>99
    assert {file['filename'] for request in session.calls('sendDocument') for file in request['files'].values()}=={POST_ID+'.txt',POST_ID+'.metadata.txt'}
    state.close()


async def test_lost_button_acknowledgement_can_be_bound_by_owned_click(tmp_path):
    state,session,bot,r=setup(tmp_path)
    state.set('metadata:1','off')
    jid,_=state.submit(1,-10,77,12,POST_URL)
    r.metadata_files.remember(jid,DATA,POST_ID);state.change(jid,status='done',reply_message=301)
    session.responses['sendMessage'].append((200,lambda method:TelegramNetworkError(method=method,message='lost ack')))
    async with bot.context():
        await r.metadata_files.install(jid)
        assert state.job(jid)['metadata_button_in_flight']
        await r.metadata_files.install(jid)
        assert len(session.calls('sendMessage'))==1
        await r.handle(callback(bot,f'metadata:{jid}',chat=-10,mid=500,message_thread_id=12,
            reply_to_message=message(-10,301,message_thread_id=12)))
    assert state.job(jid)['metadata_button_message']==500 and not state.job(jid)['metadata_button_in_flight']
    assert len(documents(session))==1
    state.close()


async def test_schema_upgrade_preserves_queue_and_backups_include_compressed_metadata(tmp_path):
    import backup
    import sqlite3
    import zipfile
    state,session,bot,r=setup(tmp_path)
    state.set('metadata:1','on');state.set('metadata_format:1','xml')
    jid,_=state.submit(1,-10,77,12,POST_URL)
    state.close()
    with sqlite3.connect(tmp_path/'state.db') as db:
        for column in list(db.execute('PRAGMA table_info(jobs)')):
            if column[1].startswith('metadata_'):db.execute('ALTER TABLE jobs DROP COLUMN '+column[1])
    state=State(tmp_path/'state.db');r.state=state
    assert state.job(jid)['status']=='ready' and state.get('metadata:1')=='on'
    r.metadata_files.remember(jid,DATA,POST_ID)
    before=state.job(jid)['metadata_data']
    assert isinstance(before,bytes) and json.loads(zlib.decompress(before))==DATA
    source=tmp_path/'app';source.mkdir();(source/'bot.py').write_text('# source')
    backup.create_archive(tmp_path,source,tmp_path/'backup.zip')
    restored=tmp_path/'restored';restored.mkdir()
    with zipfile.ZipFile(tmp_path/'backup.zip') as archive:(restored/'state.db').write_bytes(archive.read('state/state.db'))
    copy=State(restored/'state.db')
    assert copy.job(jid)['metadata_data']==before and copy.job(jid)['metadata_format']=='xml'
    copy.close();state.close()
