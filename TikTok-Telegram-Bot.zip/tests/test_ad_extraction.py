"""Exercise share resolution through the real gallery-dl post extractor."""
import copy
import io
import json
import logging
import sys

import pytest
from PIL import Image
from gallery_dl.exception import AuthorizationError
from gallery_dl.extractor.common import Message
from gallery_dl.extractor.tiktok import TiktokExtractor

import worker
from test_share_resolver import network, redirect, SHORT


POST_ID = '7699650081980484872'
ID_URL = 'https://www.tiktok.com/@/video/'+POST_ID


@pytest.mark.parametrize('photos',[False,True])
def test_ad_mobile_redirect_reaches_the_real_gallery_post_and_downloads_media(
        network,tmp_path,monkeypatch,photos):
    pending,calls,sessions = network
    redirect(pending,'https://m.tiktok.com/v/'+POST_ID+'.html')
    image = io.BytesIO()
    Image.new('RGB',(40,60),'red').save(image,'JPEG')
    payload = image.getvalue() if photos else b'\0\0\0\x18ftypisom'+b'0'*100
    media_url = 'https://cdn.example/post.jpg' if photos else 'https://cdn.example/post.mp4'
    post = {'id':POST_ID,'author':{'uniqueId':'advertiser','nickname':'Advertiser'},
            'createTime':1,'desc':'Ad caption','isAd':True}
    if photos:
        post['imagePost'] = {'images':[{'imageURL':{'urlList':[media_url]},
                                      'imageWidth':40,'imageHeight':60}]}
    else:
        post['video'] = {'playAddr':media_url,'width':40,'height':60,'duration':3}
    extracted = []
    def data(ex,url,*args,**kwargs):
        extracted.append(url)
        assert url == ID_URL
        assert not ex.session.cookies
        return {'webapp.video-detail':{'statusCode':0,'itemInfo':{'itemStruct':copy.deepcopy(post)}}}
    monkeypatch.setattr(TiktokExtractor,'_extract_rehydration_data',data)
    pending.append((media_url,200,{},payload))
    result = worker.download(SHORT,tmp_path,include_audio=False,include_metadata=True,
                             compression={'mode':'none'})
    assert result['ok'] and result['post_id'] == POST_ID
    assert result['title'] == 'Ad caption'
    assert json.loads(result['full_metadata'])['isAd'] is True
    assert len(result['media']) == 1
    assert result['media'][0]['kind'] == ('image' if photos else 'video')
    assert (tmp_path/result['media'][0]['file']).read_bytes() == payload
    assert extracted == [ID_URL]
    assert [call[0] for call in calls] == [SHORT,media_url]
    assert not pending
    assert {'stage':'extractor','reason':'metadata_received'} in worker.DIAGNOSTICS
    assert {'stage':'extractor','reason':'completed'} in worker.DIAGNOSTICS


@pytest.mark.parametrize('failure',[ValueError,KeyError,AuthorizationError])
def test_real_gallery_failures_keep_their_cause_without_logger_attribute_errors(
        tmp_path,monkeypatch,caplog,failure):
    worker.DIAGNOSTICS.clear()
    def failed(*args,**kwargs):
        raise failure('SECRET https://cdn.example/?token=PRIVATE')
    monkeypatch.setattr(TiktokExtractor,'_extract_rehydration_data',failed)
    monkeypatch.setattr(worker,'resolve',lambda url:'https://www.tiktok.com/share/video/'+POST_ID)
    error = worker.Authentication if failure is AuthorizationError else ValueError
    with pytest.raises(error):
        worker.download(SHORT,tmp_path,include_audio=False,compression={'mode':'none'})
    assert any(item.get('exception') == failure.__name__ for item in worker.DIAGNOSTICS)
    assert not any(item.get('exception') == 'AttributeError' for item in worker.DIAGNOSTICS)
    assert ('no_media' in [item['reason'] for item in worker.DIAGNOSTICS]) == (failure is not AuthorizationError)
    assert 'SECRET' not in json.dumps(worker.DIAGNOSTICS)+caplog.text
    assert 'PRIVATE' not in json.dumps(worker.DIAGNOSTICS)+caplog.text


@pytest.mark.parametrize('status,refused',[(10204,False),(10221,False),(10222,True),(10231,False)])
def test_real_gallery_unavailable_and_login_only_posts_are_distinguished(
        tmp_path,monkeypatch,status,refused):
    worker.DIAGNOSTICS.clear()
    monkeypatch.setattr(worker,'resolve',lambda url:'https://www.tiktok.com/share/video/'+POST_ID)
    monkeypatch.setattr(TiktokExtractor,'_extract_rehydration_data',lambda *args,**kwargs:{
        'webapp.video-detail':{'statusCode':status}})
    with pytest.raises(worker.Authentication if refused else ValueError):
        worker.download(SHORT,tmp_path,include_audio=False,compression={'mode':'none'})
    reasons = [item['reason'] for item in worker.DIAGNOSTICS]
    assert ('access_refused' in reasons) == refused
    assert ('no_media' in reasons) == (not refused)
    assert 'metadata_received' not in reasons


def test_extractor_selection_failure_has_a_separate_diagnostic(tmp_path,monkeypatch):
    worker.DIAGNOSTICS.clear()
    def failed(url):raise ValueError('private internal data')
    monkeypatch.setattr(worker.extractor,'find',failed)
    with pytest.raises(ValueError):
        worker.download('https://www.tiktok.com/share/video/'+POST_ID,tmp_path,include_audio=False)
    assert {'stage':'extractor','reason':'selection_failed','exception':'ValueError'} in worker.DIAGNOSTICS
    assert 'private' not in json.dumps(worker.DIAGNOSTICS)


def test_video_payload_failure_is_not_reported_as_missing_post_metadata(network,tmp_path,monkeypatch):
    pending,calls,sessions = network
    post = {'id':POST_ID,'author':{'uniqueId':'advertiser'},'createTime':1,'desc':'Ad',
            'video':{'playAddr':'https://cdn.example/video.mp4','width':40,'height':60,'duration':3}}
    monkeypatch.setattr(TiktokExtractor,'_extract_rehydration_data',lambda *args,**kwargs:{
        'webapp.video-detail':{'statusCode':0,'itemInfo':{'itemStruct':copy.deepcopy(post)}}})
    pending.append(('https://cdn.example/video.mp4',200,{},b'<html>Not a video</html>'))
    with pytest.raises(ValueError):
        worker.download('https://www.tiktok.com/share/video/'+POST_ID,tmp_path,include_audio=False)
    assert {'stage':'media','reason':'unsupported_video'} in worker.DIAGNOSTICS
    assert {'stage':'extractor','reason':'metadata_received'} in worker.DIAGNOSTICS
    assert not any(item['reason']=='no_media' for item in worker.DIAGNOSTICS)


def test_worker_result_retains_safe_extraction_diagnostics(tmp_path,monkeypatch):
    worker.DIAGNOSTICS.clear()
    def failed(*args,**kwargs):raise ValueError('SECRET token=PRIVATE')
    monkeypatch.setattr(TiktokExtractor,'_extract_rehydration_data',failed)
    monkeypatch.setattr(sys,'argv',['worker.py','https://www.tiktok.com/share/video/'+POST_ID,str(tmp_path)])
    root = logging.getLogger()
    handlers,level,disabled = root.handlers[:],root.level,logging.root.manager.disable
    try:
        assert worker.main() == 1
    finally:
        root.handlers = handlers
        root.setLevel(level)
        logging.disable(disabled)
    result = json.loads((tmp_path/'result.json').read_text())
    assert not result['ok'] and result['error']=='unavailable'
    assert any(item['reason']=='no_media' for item in result['diagnostics'])
    assert any(item.get('exception')=='ValueError' and item['stage']=='extractor' for item in result['diagnostics'])
    assert 'SECRET' not in json.dumps(result) and 'PRIVATE' not in json.dumps(result)
