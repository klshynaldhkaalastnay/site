"""Per-user queue choices preserve waiting work, delivery receipts and recovery."""
import asyncio
import json

import pytest
from aiogram.types import Update

from i18n import LANGUAGES, TEXT
from state import State
from test_aiogram import setup, callback, message
from test_bot import submit, FakeBot
from bot import Runner


@pytest.mark.parametrize('privileged',[False,True])
def test_sequential_admission_fifo_secondary_batches_and_independent_users(tmp_path,privileged):
    state=State(tmp_path/'state.db')
    try:
        state.set_queue_mode(1,'sequential')
        ids=[submit(state,index=i,privileged=privileged) for i in range(1,46)]
        rows=state.outstanding(1)
        assert [row['status'] for row in rows]==['ready']+(['queued']*44 if privileged else ['queued']*10+['deferred']*34)
        assert state.queue_position(ids[1])==1
        other=[submit(state,user=2,index=100+i) for i in range(7)]
        assert [state.job(jid)['status'] for jid in other]==['ready']*5+['queued']*2
        finished=[]
        while len(finished)<len(ids):
            active=[row for row in state.outstanding(1) if row['status']=='ready']
            assert len(active)==1
            jid=active[0]['id']
            finished.append(jid)
            state.change(jid,status='done')
            state.promote()
        assert finished==ids
        assert len(state.outstanding(2))==7
    finally:
        state.close()


def test_switching_limits_requeues_unstarted_work_without_losing_or_reordering_it(tmp_path):
    state=State(tmp_path/'state.db')
    try:
        ids=[submit(state,index=i) for i in range(1,26)]
        state.set_queue_mode(1,'sequential')
        assert [row['id'] for row in state.ready()]==ids[:1]
        assert [state.job(jid)['status'] for jid in ids]==['ready']+['queued']*10+['deferred']*14
        state.set_queue_mode(1,'parallel')
        assert [row['id'] for row in state.ready()]==ids[:5]
        assert [row['id'] for row in state.outstanding(1)]==ids
        with pytest.raises(ValueError):state.set_queue_mode(1,'invalid')
        assert state.queue_mode(1)=='parallel'
    finally:
        state.close()


def test_lower_limit_allows_running_downloads_to_finish_before_starting_another(tmp_path):
    state=State(tmp_path/'state.db')
    try:
        ids=[submit(state,index=i) for i in range(1,19)]
        for jid in ids[:5]:state.change(jid,status='running')
        state.set_queue_mode(1,'sequential')
        assert [row['id'] for row in state.outstanding(1) if row['status']=='running']==ids[:5]
        for jid in ids[:4]:
            state.change(jid,status='done')
            state.promote()
            assert not state.ready()
        newest=submit(state,index=19)
        assert state.job(newest)['status']=='deferred'
        state.change(ids[4],status='done')
        state.promote()
        assert [row['id'] for row in state.ready()]==ids[5:6]
        assert len(state.outstanding(1))==14
    finally:
        state.close()


@pytest.mark.parametrize('user',[1,7,99])
def test_recovery_preserves_selected_limit_exemptions_and_uncertain_delivery(tmp_path,user):
    state=State(tmp_path/'state.db')
    ids=[submit(state,user=user,index=i,privileged=user!=1) for i in range(1,26)]
    for jid in ids[:5]:state.change(jid,status='running')
    state.change(ids[0],in_flight='["unconfirmed"]')
    state.change(ids[1],sent='["confirmed"]')
    state.set_queue_mode(user,'sequential')
    state.close()
    state=State(tmp_path/'state.db')
    try:
        state.queue_exemptions(7,99)
        state.recover()
        assert state.queue_mode(user)=='sequential'
        assert state.job(ids[0])['status']=='uncertain'
        assert [row['id'] for row in state.ready()]==ids[1:2]
        assert json.loads(state.job(ids[1])['sent'])==['confirmed']
        assert len(state.outstanding(user))==24
        assert sum(row['status']=='queued' for row in state.outstanding(user))==(23 if user!=1 else 10)
        assert sum(row['status']=='deferred' for row in state.outstanding(user))==(0 if user!=1 else 13)
    finally:
        state.close()


@pytest.mark.asyncio
async def test_native_queue_settings_ownership_languages_admission_and_persistence(tmp_path):
    state,session,bot,runner=setup(tmp_path)
    async with bot.context():
        assert state.queue_mode(1)=='parallel'
        await runner.handle(callback(bot,'settings:1:queue-sequential',user=2))
        assert state.queue_mode(1)=='parallel'
        await runner.handle(callback(bot,'settings:1:queue-sequential'))
        assert state.queue_mode(1)=='sequential'
        for language in LANGUAGES:
            state.set('language:1',language)
            await runner.handle(callback(bot,'settings:1:queue'))
            fields=session.calls('editMessageText')[-1]['fields']
            buttons=json.loads(fields['reply_markup'])['inline_keyboard']
            assert buttons[1][0]['text']=='✓ '+TEXT[language]['One at a time']
            assert not buttons[0][0]['text'].startswith('✓ ')
            assert all(len(button['callback_data'].encode())<=64 for row in buttons for button in row)
            queue_button=next(button for row in runner.settings_view(1)[1].inline_keyboard for button in row
                              if button.callback_data.endswith(':queue'))
            assert queue_button.text==TEXT[language]['Queue']+': '+TEXT[language]['One at a time']
        update=Update.model_validate({'update_id':123,'message':message(text=
            'https://www.tiktok.com/@x/video/123 https://www.tiktok.com/@x/video/456')},context={'bot':bot})
        await runner.handle(update)
        assert [row['status'] for row in state.outstanding(1)]==['ready','queued']
        await runner.handle(callback(bot,'settings:1:queue-unknown'))
        assert state.queue_mode(1)=='sequential'
        assert state.queue_mode(2)=='parallel'
    state.close()
    state=State(tmp_path/'state.db')
    try:
        assert state.queue_mode(1)=='sequential'
        state.recover()
        assert len(state.ready())==1
        state.set('queue_mode:2','obsolete')
        assert state.queue_mode(2)=='parallel'
    finally:
        state.close()


@pytest.mark.asyncio
async def test_scheduler_runs_one_sequential_request_alongside_five_for_another_user(tmp_path):
    state=State(tmp_path/'state.db')
    runner=Runner(state,FakeBot(),tmp_path,7,99)
    state.set_queue_mode(1,'sequential')
    ids={user:[submit(state,user=user,index=user*100+i) for i in range(7)] for user in (1,2)}
    started=set()
    release={jid:asyncio.Event() for group in ids.values() for jid in group}
    first=asyncio.Event()
    next_job=asyncio.Event()
    async def job(jid):
        started.add(jid)
        assert sum(row['status']=='running' for row in state.outstanding(1))<=1
        assert sum(row['status']=='running' for row in state.outstanding(2))<=5
        if len(started)==6:first.set()
        if ids[1][1] in started:next_job.set()
        await release[jid].wait()
        state.change(jid,status='done')
    runner.run_job=job
    scheduler=asyncio.create_task(runner.scheduler())
    try:
        await asyncio.wait_for(first.wait(),2)
        assert started=={ids[1][0],*ids[2][:5]}
        release[ids[1][0]].set()
        await asyncio.wait_for(next_job.wait(),2)
        assert ids[1][2] not in started
    finally:
        runner.stop.set()
        scheduler.cancel()
        for task in runner.tasks.values():task.cancel()
        await asyncio.gather(scheduler,*runner.tasks.values(),return_exceptions=True)
        state.close()
