"""Owner access, installed versions, missing tools and bounded subprocesses."""
import asyncio
from html import unescape
import json
from pathlib import Path

import pytest
from aiogram.types import Update

import bot as bot_module
from bot import COMMANDS
import dependency_versions as dependencies
from i18n import HELP, LANGUAGES, OWNER_HELP, TEXT
from test_aiogram import setup, message

ERROR = 'Could not read dependency versions, please try again later'


@pytest.mark.parametrize('chat',[7,-10])
async def test_owner_dependency_report_before_onboarding_replies_in_code(tmp_path,monkeypatch,chat):
    output = 'Python: 3.12.14\naiogram: 3.31.0\nFFmpeg: N-1234-g<build> & release'
    async def report(): return output
    monkeypatch.setattr(bot_module,'read_dependencies',report)
    state,session,bot,r = setup(tmp_path)
    r.username = 'testbot'
    update = Update.model_validate({'update_id':42,'message':message(chat,user=7,
        text='/DpEnD@testbot',message_thread_id=12 if chat<0 else None)},context={'bot':bot})
    async with bot.context():
        await r.handle(update)
    fields = session.calls('sendMessage')[-1]['fields']
    assert fields['text']=='<pre>Python: 3.12.14\naiogram: 3.31.0\nFFmpeg: N-1234-g&lt;build&gt; &amp; release</pre>'
    assert fields['parse_mode']=='HTML' and fields['chat_id']==str(chat)
    assert json.loads(fields['reply_parameters'])=={'message_id':77,'allow_sending_without_reply':True}
    assert fields.get('message_thread_id')==('12' if chat<0 else None)
    assert state.get('language:7') is None and not state.outstanding(7)
    state.close()


@pytest.mark.parametrize('user',[1,99])
@pytest.mark.parametrize('chat',[1,-10])
@pytest.mark.parametrize('language',[None,'ar'])
async def test_nonowners_cannot_probe_dependencies(tmp_path,monkeypatch,user,chat,language):
    async def unexpected(): pytest.fail('Non-owner started a dependency probe')
    monkeypatch.setattr(bot_module,'read_dependencies',unexpected)
    state,session,bot,r = setup(tmp_path)
    if language:
        state.set(f'language:{user}',language)
    update = Update.model_validate({'update_id':42,'message':message(chat,user=user,
        text='/dpend',message_thread_id=12 if chat<0 else None)},context={'bot':bot})
    async with bot.context():
        await r.handle(update)
    calls = session.calls('sendMessage')
    assert len(calls)==1
    assert calls[0]['fields']['text']==TEXT[language or 'en']['Only the bot owner can use this command']
    assert 'reply_markup' not in calls[0]['fields']
    assert not r.stop.is_set() and not state.outstanding(user)
    state.close()


async def test_dependency_command_addressed_to_another_bot_is_ignored(tmp_path,monkeypatch):
    async def unexpected(): pytest.fail('Another bot was addressed')
    monkeypatch.setattr(bot_module,'read_dependencies',unexpected)
    state,session,bot,r = setup(tmp_path)
    r.username = 'testbot'
    update = Update.model_validate({'update_id':42,'message':message(user=7,text='/dpend@otherbot')},context={'bot':bot})
    async with bot.context():
        await r.handle(update)
    assert not session.calls('sendMessage')
    state.close()


async def test_long_dependency_reports_are_split_without_changing_versions(tmp_path,monkeypatch):
    output = '3.31.0\n'+'\U0001f9e0'*2100+'\n<x> & </pre>'
    async def report(): return output
    monkeypatch.setattr(bot_module,'read_dependencies',report)
    state,session,bot,r = setup(tmp_path)
    update = Update.model_validate({'update_id':42,'message':message(user=7,text='/dpend')},context={'bot':bot})
    async with bot.context():
        await r.handle(update)
    pieces = [unescape(call['fields']['text'][5:-6]) for call in session.calls('sendMessage')]
    assert len(pieces)==2 and ''.join(pieces)==output
    assert all(len(piece.encode('utf-16-le'))//2<=4096 for piece in pieces)
    state.close()


@pytest.mark.parametrize('failure',[OSError,ValueError])
async def test_report_failures_are_translated_and_keep_the_bot_running(tmp_path,monkeypatch,failure):
    async def unavailable(): raise failure('local probe failed')
    monkeypatch.setattr(bot_module,'read_dependencies',unavailable)
    state,session,bot,r = setup(tmp_path)
    state.set('language:7','ar')
    update = Update.model_validate({'update_id':42,'message':message(user=7,text='/dpend')},context={'bot':bot})
    async with bot.context():
        await r.handle(update)
    assert session.calls('sendMessage')[-1]['fields']['text']==TEXT['ar'][ERROR]
    assert not r.stop.is_set()
    state.close()


@pytest.mark.parametrize('user',[1,7])
async def test_dependency_help_is_owner_only(tmp_path,user):
    assert 'dpend' not in dict(COMMANDS)
    for language in LANGUAGES:
        assert '/dpend' not in HELP[language] and '/dpend - ' in OWNER_HELP[language]
        assert ERROR in TEXT[language] and TEXT[language][ERROR].strip()
    state,session,bot,r = setup(tmp_path)
    state.set(f'language:{user}','en')
    update = Update.model_validate({'update_id':42,'message':message(user=user,text='/help')},context={'bot':bot})
    async with bot.context():
        await r.handle(update)
    assert ('/dpend - ' in session.calls('sendMessage')[-1]['fields']['text'])==(user==7)
    state.close()


def test_package_versions_come_from_installed_metadata_not_requirement_pins(tmp_path,monkeypatch):
    requirements = tmp_path/'requirements.txt'
    requirements.write_text('# Runtime only\naiogram==0.0.1\nPillow>=1,<2\nMissing-package==1\nAIogram==0.0.1\n')
    monkeypatch.setattr(dependencies,'REQUIREMENTS',requirements)
    def installed(name):
        if name=='Missing-package': raise dependencies.PackageNotFoundError(name)
        return {'aiogram':'3.31.0','Pillow':'12.3.0'}[name]
    monkeypatch.setattr(dependencies,'version',installed)
    text = '\n'.join(dependencies.python_versions())
    assert 'aiogram: 3.31.0' in text and 'Pillow: 12.3.0' in text
    assert '0.0.1' not in text and text.count('aiogram:')==1
    assert 'Missing-package: Not installed' in text


def executable(tmp_path,name,body):
    path = tmp_path/name
    path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text('#!/bin/sh\n'+body)
    path.chmod(0o755)
    return path


async def test_cached_tool_versions_and_partial_report(tmp_path,monkeypatch):
    monkeypatch.setattr(dependencies.Path,'home',lambda:tmp_path)
    executable(tmp_path,'.ffmpeg/bin/ffmpeg',"[ \"$1\" = '-version' ] || exit 9\nprintf '\033[32mffmpeg version N-1234-gabcd Copyright\033[0m\\n'\n")
    executable(tmp_path,'.neofetch/neofetch',"[ \"$1\" = '--version' ] || exit 9\nprintf 'Neofetch 7.1.0\\n'\n")
    monkeypatch.setattr(dependencies.shutil,'which',lambda _:None)
    # Simulate the local Chromium version probe in a child process.
    monkeypatch.setattr(dependencies,'CHROMIUM_PROBE',"print('Chromium 145.0.1.2')")
    text = await dependencies.read_dependencies()
    assert 'FFmpeg: N-1234-gabcd' in text and 'neofetch: 7.1.0' in text
    assert 'ffprobe: Not installed' in text and 'Chromium: 145.0.1.2' in text
    assert 'aiogram: 3.31.0' in text and 'gallery-dl: 1.32.13' in text
    assert '\x1b' not in text


@pytest.mark.parametrize('body,expected',[
    ('exit 0\n','Unavailable'),
    ("printf 'unexpected output\\n'\n",'Unavailable'),
    ("printf 'Neofetch 99.0\\n'; exit 7\n",'Unavailable'),
    ('exit 3\n','Not installed'),
])
async def test_failed_or_missing_tool_versions_are_not_reported_as_success(tmp_path,body,expected):
    path = executable(tmp_path,'probe',body)
    assert await dependencies.probe_version(str(path),[],r'^Neofetch (\S+)',missing_exit=3)==expected


async def test_chromium_probe_reads_the_playwright_cache_without_launching_a_browser(tmp_path,monkeypatch):
    from playwright.async_api import async_playwright
    cache = tmp_path/'browser cache'
    monkeypatch.setenv('PLAYWRIGHT_BROWSERS_PATH',str(cache))
    async with async_playwright() as pw:
        path = Path(pw.chromium.executable_path)
    assert path.is_relative_to(cache)
    target = executable(cache,str(path.relative_to(cache)),
        "[ \"$#\" -eq 1 ] && [ \"$1\" = '--version' ] || exit 9\nprintf 'Chromium 145.0.9.8\\n'\n")
    args = [dependencies.sys.executable,['-c',dependencies.CHROMIUM_PROBE],r'^Chromium (\S+)']
    assert await dependencies.probe_version(*args,missing_exit=3)=='145.0.9.8'
    target.unlink()
    assert await dependencies.probe_version(*args,missing_exit=3)=='Not installed'


async def test_missing_executable_is_a_partial_report_status(tmp_path):
    assert await dependencies.probe_version(None,[],r'(.*)')=='Not installed'
    assert await dependencies.probe_version(str(tmp_path/'absent'),[],r'(.*)')=='Unavailable'


@pytest.mark.parametrize('cancel',[False,True])
async def test_timeout_and_cancellation_stop_probe_processes(tmp_path,monkeypatch,cancel):
    path = executable(tmp_path,'slow-probe','/bin/sleep 60\n')
    started = asyncio.Event()
    processes = []
    create = asyncio.create_subprocess_exec
    async def record(*args,**kwargs):
        process = await create(*args,**kwargs)
        processes.append(process)
        started.set()
        return process
    monkeypatch.setattr(dependencies.asyncio,'create_subprocess_exec',record)
    monkeypatch.setattr(dependencies,'TIMEOUT_SECONDS',0.05 if not cancel else 60)
    task = asyncio.create_task(dependencies.probe_version(str(path),[],r'(.*)'))
    await asyncio.wait_for(started.wait(),1)
    if cancel:
        task.cancel()
        with pytest.raises(asyncio.CancelledError):
            await asyncio.wait_for(task,2)
    else:
        assert await asyncio.wait_for(task,2)=='Timed out'
    assert processes[0].returncode is not None
