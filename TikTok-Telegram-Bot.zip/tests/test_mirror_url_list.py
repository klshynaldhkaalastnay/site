import asyncio
import base64
from types import SimpleNamespace

import pytest

from download_mirrors import CDN, GitHub, MirrorError
import mirror_url_list as index
from state import State


def blob(path,digest='b'*40,mode='100644'):
    return {'path':path,'type':'blob','mode':mode,'sha':digest}


def directory(path,digest):
    return {'path':path,'type':'tree','mode':'040000','sha':digest}


@pytest.mark.asyncio
async def test_url_list_keeps_previous_uploads_and_merges_after_a_branch_conflict(tmp_path,monkeypatch):
    state = State(tmp_path/'state.db')
    try:
        direct = 'video/123/'+'a'*16+'/123.mp4'
        player = 'video/456/'+'b'*16+'/456.mp4'
        legacy = 'photo/789/789_01.jpg.html'
        previous = 'https://onlyfiles.com/Old\nhttps://other.example/private\n'
        state.save_mirror(1,'123.mp4','one','onlyfiles','https://onlyfiles.com/New/123.mp4')
        state.save_mirror(1,'123.mp4','one','github',CDN+direct)
        state.save_mirror(2,'123.mp4','one','onlyfiles','https://onlyfiles.com/New/123.mp4')
        state.claim_onlyfiles(3,'pending.mp4','two')
        listing = index.MirrorURLList(SimpleNamespace(state=state))
        git = GitHub(None,'pages/live',asyncio.Lock())
        parent,tree,index_sha = 'a'*40,'b'*40,'c'*40
        index_blobs = {index_sha:previous}
        snapshots,new_contents,parents = [],[],[]
        branch_patches = []
        async def api(method,path,**params):
            nonlocal parent,tree,index_sha
            if method=='GET' and path=='/git/ref/heads/pages/live':
                return {'object':{'sha':parent}}
            if method=='GET' and path=='/git/commits/'+parent:
                return {'tree':{'sha':tree}}
            if method=='GET' and path=='/git/trees/'+tree:
                assert params=={'params':{'recursive':'1'}}
                snapshots.append(tree)
                return {'truncated':False,'tree':[
                    blob(index.LIST_PATH,index_sha),blob(direct),blob(player+'.html'),
                    blob(player+'/index.html'),blob(legacy),blob('photo/789/my photo.jpg'),
                    blob('.github/workflows/example.yml'),blob('index.html'),
                    blob('video/123/private.mp4',mode='120000')]}
            if method=='GET' and path=='/git/blobs/'+index_sha:
                return {'content':base64.b64encode(index_blobs[index_sha].encode()).decode(),'encoding':'base64'}
            if method=='POST' and path=='/git/trees':
                assert params['json']['base_tree']==tree
                entry, = params['json']['tree']
                assert entry['path']=='.github/liste.txt' and entry['type']=='blob'
                new_contents.append(entry['content'])
                return {'sha':'e'*40}
            if method=='POST' and path=='/git/commits':
                parents.extend(params['json']['parents'])
                return {'sha':'f'*40}
            if method=='PATCH' and path=='/git/refs/heads/pages/live':
                branch_patches.append(params['json'])
                if len(branch_patches)==1:
                    parent,tree,index_sha = '1'*40,'2'*40,'3'*40
                    index_blobs[index_sha] = previous+'https://onlyfiles.com/OtherRunner\n'
                    raise MirrorError(409)
                parent,tree,index_sha = 'f'*40,'e'*40,'4'*40
                index_blobs[index_sha] = new_contents[-1]
                return {}
            raise AssertionError((method,path))
        monkeypatch.setattr(git,'api',api)
        assert await listing.sync(git)
        assert not await listing.sync(git)
        assert parents==['a'*40,'1'*40] and snapshots==['b'*40,'2'*40,'e'*40]
        assert branch_patches==[{'sha':'f'*40,'force':False}]*2
        assert new_contents[-1].splitlines()==sorted([
            'https://onlyfiles.com/Old','https://onlyfiles.com/OtherRunner',
            'https://onlyfiles.com/New/123.mp4',CDN+direct,CDN+player+'/',CDN+legacy,
            CDN+'photo/789/my%20photo.jpg'])
        assert new_contents[-1].endswith('\n')
    finally:
        state.close()


@pytest.mark.asyncio
async def test_large_repo_walks_subtrees_instead_of_using_truncated_result():
    archive,photos,post,dotgithub = (character*40 for character in 'abcd')
    async def api(method,path,**kwargs):
        assert method=='GET'
        if kwargs:
            assert path=='/git/trees/'+archive
            return {'truncated':True,'tree':[blob('video/123/partial.mp4')]}
        return {'truncated':False,'tree':{
            archive:[directory('photo',photos),directory('.github',dotgithub),directory('site','e'*40)],
            photos:[directory('123',post)],
            post:[blob('123_01.jpg'),blob('123_02.jpg')],
            dotgithub:[blob('liste.txt','f'*40),directory('workflows','0'*40)],
        }[path.split('/')[-1]]}
    files,sha = await index.branch_blobs(SimpleNamespace(api=api),archive)
    assert files=={'photo/123/123_01.jpg','photo/123/123_02.jpg'} and sha=='f'*40


@pytest.mark.asyncio
async def test_refresh_runs_at_startup_and_recovers_on_next_tick(monkeypatch):
    assert index.INTERVAL==1800
    monkeypatch.setattr(index,'INTERVAL',0.02)
    monkeypatch.setenv('TIKCDN_TOKEN','test-only')
    monkeypatch.setenv('TIKCDN_BRANCH','pages')
    runner = SimpleNamespace(stop=asyncio.Event(),mirrors=SimpleNamespace(git_lock=asyncio.Lock()))
    listing = index.MirrorURLList(runner)
    attempts = []
    async def sync(git):
        assert git.branch=='pages' and git.lock is runner.mirrors.git_lock
        attempts.append(git)
        if len(attempts)==1:
            raise MirrorError(503)
        runner.stop.set()
    monkeypatch.setattr(listing,'sync',sync)
    await asyncio.wait_for(listing.run(),2)
    assert len(attempts)==2
