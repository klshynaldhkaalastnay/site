"""Exercise aiogram's real multipart builder, response decoder and bound updates."""
import asyncio
from collections import defaultdict, deque
import json
from itertools import count

import pytest
from aiogram import Bot
from aiogram.client.session.aiohttp import AiohttpSession
from aiogram.exceptions import TelegramAPIError, TelegramNetworkError
from aiogram.types import Update

from bot import Runner
from common import BOT_ATTRIBUTION
from state import State
import identify

TOKEN = '123456:LOCAL_TEST_ONLY'
CALLBACK_IDS = count()


def message(chat=1, mid=77, user=1, **values):
    return {'message_id':mid,'date':1750000000,
            'chat':{'id':chat,'type':'supergroup' if chat<0 else 'private'},
            'from':{'id':user,'is_bot':False,'first_name':'Tester'},**values}


def callback(bot, data, user=1, chat=1, mid=88, **values):
    return Update.model_validate({'update_id':101,'callback_query':{
        'id':str(next(CALLBACK_IDS)),'from':{'id':user,'is_bot':False,'first_name':'Tester'},
        'chat_instance':'instance','data':data,'message':message(chat,mid,user,**values)}},
        context={'bot':bot})


class Session(AiohttpSession):
    def __init__(self):
        super().__init__(timeout=150,limit=64)
        self.requests=[]
        self.responses=defaultdict(deque)
        self.closed=False
        self.next_message=400

    def queue(self, api, result=None, *, status=200, description=None, parameters=None):
        body={'ok':True,'result':result} if status==200 else {
            'ok':False,'error_code':status,'description':description or 'controlled failure'}
        if parameters:
            body['parameters']=parameters
        self.responses[api].append((status,body))

    async def make_request(self, bot, method, timeout=None):
        fields={};files={}
        # Consume precisely the fields/streams aiogram would send through aiohttp.
        for options,headers,value in self.build_form_data(bot,method)._fields:
            name=options['name']
            if hasattr(value,'__aiter__'):
                files[name]={'filename':options['filename'],
                             'data':b''.join([part async for part in value])}
            else:
                fields[name]=value
        api=method.__api_method__
        self.requests.append({'api':api,'fields':fields,'files':files,'timeout':timeout})
        if self.responses[api]:
            status,body=self.responses[api].popleft()
            if callable(body):
                body=body(method)
            if isinstance(body,BaseException):
                raise body
        else:
            status=200
            if api=='getMe':
                result={'id':123456,'is_bot':True,'first_name':'Bot','username':'testbot'}
            elif api=='getUpdates':
                result=[]
            elif api in ('deleteWebhook','setMyCommands','answerCallbackQuery','deleteMessage'):
                result=True
            elif api=='copyMessage':
                self.next_message+=1;result={'message_id':self.next_message}
            elif api=='sendMediaGroup':
                result=[]
                for _ in json.loads(fields['media']):
                    self.next_message+=1
                    result.append(message(int(fields['chat_id']),self.next_message))
            elif api=='editMessageReplyMarkup':
                result=message(int(fields['chat_id']),int(fields['message_id']),
                               reply_markup=json.loads(fields['reply_markup']))
            elif api in ('sendMessage','editMessageText','sendVideo','sendPhoto','sendDocument','sendAudio'):
                self.next_message+=1
                result=message(int(fields['chat_id']),self.next_message,text=fields.get('text','delivered'))
            else:
                raise AssertionError(f'Unexpected request: {api}')
            body={'ok':True,'result':result}
        content=body if isinstance(body,str) else json.dumps(body)
        return self.check_response(bot,method,status,content).result

    async def close(self):
        self.closed=True
        await super().close()

    def calls(self, api):
        return [request for request in self.requests if request['api']==api]


def setup(tmp_path):
    state=State(tmp_path/'state.db');session=Session();bot=Bot(token=TOKEN,session=session)
    runner=Runner(state,bot,tmp_path,7,99)
    async def fast(chat,operation):return await operation()
    runner.api=fast
    return state,session,bot,runner


@pytest.mark.asyncio
async def test_native_polling_commits_admission_before_next_ack_and_closes(tmp_path):
    state,session,bot,r=setup(tmp_path)
    state.set('language:1','en');state.set('language:7','en')
    session.queue('getUpdates',[{'update_id':42,'message':message(-10,user=1,
        message_thread_id=12,caption='hidden post',caption_entities=[{
            'type':'text_link','offset':0,'length':11,'url':'https://www.tiktok.com/@a/video/123'}])}])
    def next_poll(method):
        assert method.offset==43 and state.get('offset')=='43'
        row=state.outstanding(1)[0]
        assert row['chat_id']==-10 and row['message_id']==77 and row['thread_id']==12
        return {'ok':True,'result':[{'update_id':43,'message':message(7,user=7,text='/shutdown')}]}
    session.responses['getUpdates'].append((200,next_poll))
    async def idle():await r.stop.wait()
    r.scheduler=idle
    async with bot.context():
        await asyncio.wait_for(r.run(),3)
    assert session.closed
    assert state.get('offset')=='44'
    assert json.loads((tmp_path/'receipt.json').read_text())['reason']=='shutdown'
    commands=json.loads(session.calls('setMyCommands')[0]['fields']['commands'])
    assert any(command['command']=='settings' for command in commands)
    assert all(command['command']!='specs' for command in commands)
    assert all(request['timeout']==35 for request in session.calls('getUpdates'))
    assert json.loads(session.calls('deleteWebhook')[0]['fields']['drop_pending_updates']) is False
    state.close()


@pytest.mark.asyncio
async def test_native_video_fallback_audio_metadata_streams_and_receipts(tmp_path):
    state,session,bot,r=setup(tmp_path)
    jid,_=state.submit(1,-10,77,12,'https://www.tiktok.com/@x/video/123')
    folder=r.work/'media';folder.mkdir()
    original=b'original media'*11000
    (folder/'video.mp4').write_bytes(original)
    (folder/'sound.mp3').write_bytes(b'original soundtrack')
    (folder/'cover.jpg').write_bytes(b'preview')
    records=[{'file':'video.mp4','kind':'video','sha256':'video','manual_audio':True,
              'width':480,'height':852,'duration':3,'supports_streaming':True},
             {'file':'sound.mp3','kind':'audio','sha256':'audio','filename':'Song.mp3',
              'title':'Song','performer':'Artist','duration':3,'thumbnail':'cover.jpg'}]
    session.queue('sendVideo',status=400,description='Unsupported video')
    async with bot.context():
        await r.deliver(jid,records,folder,'Title','Account','user')
        await r.deliver(jid,records,folder,'Title','Account','user')
    video=session.calls('sendVideo')[0];document=session.calls('sendDocument')[0]
    assert next(iter(video['files'].values()))['data']==original
    assert next(iter(document['files'].values()))['data']==original
    assert video['fields']['supports_streaming']=='true'
    assert video['fields']['width']=='480' and 'width' not in document['fields']
    assert '<blockquote>Title</blockquote>' in document['fields']['caption']
    assert json.loads(document['fields']['reply_parameters'])['message_id']==77
    assert document['fields']['message_thread_id']=='12'
    assert json.loads(document['fields']['reply_markup'])['inline_keyboard'][0][0]['callback_data']==f'extract:{jid}'
    audio=session.calls('sendAudio')[0]
    attachment=audio['files'][audio['fields']['audio'].removeprefix('attach://')]
    assert attachment=={'filename':'Song.mp3','data':b'original soundtrack'}
    assert audio['files'][audio['fields']['thumbnail'].removeprefix('attach://')]['data']==b'preview'
    assert audio['fields']['title']=='Song' and audio['fields']['performer']=='Artist'
    assert json.loads(audio['fields']['reply_parameters'])['message_id']==state.job(jid)['reply_message']
    assert len(session.calls('sendDocument'))==len(session.calls('sendAudio'))==1
    assert state.job(jid)['in_flight'] is None
    state.close()


@pytest.mark.asyncio
@pytest.mark.parametrize('album,document',[(False,False),(True,False),(True,True)])
async def test_native_photo_and_document_albums(tmp_path,album,document):
    state,session,bot,r=setup(tmp_path)
    jid,_=state.submit(1,-10,77,12,'https://www.tiktok.com/@x/photo/123')
    folder=r.work/'images';folder.mkdir();records=[]
    for index in range(2 if album else 1):
        name=f'{index}.webp' if document else f'{index}.jpg'
        (folder/name).write_bytes(f'image {index}'.encode())
        records.append({'file':name,'kind':'image','sha256':str(index),'width':40,'height':60})
    async with bot.context():await r.deliver(jid,records,folder)
    request=session.calls('sendMediaGroup' if album else 'sendPhoto')[0]
    assert len(request['files'])==len(records)
    assert {f['data'] for f in request['files'].values()}=={f'image {i}'.encode() for i in range(len(records))}
    assert json.loads(request['fields']['reply_parameters'])['message_id']==77
    assert request['fields']['message_thread_id']=='12'
    if album:
        media=json.loads(request['fields']['media'])
        assert all(item['type']==('document' if document else 'photo') for item in media)
        assert media[0]['caption']==BOT_ATTRIBUTION and 'caption' not in media[1]
    state.close()


def photo_records(folder, count, document=False):
    records=[]
    for index in range(count):
        name=f'{index}.webp' if document else f'{index}.jpg'
        (folder/name).write_bytes(f'image {index}'.encode())
        records.append({'file':name,'kind':'image','sha256':str(index),'width':40,'height':60})
    return records


@pytest.mark.asyncio
@pytest.mark.parametrize('count',[10,11,20,21,23])
@pytest.mark.parametrize('document',[False,True])
async def test_native_photo_overflow_replies_to_previous_batch(tmp_path,count,document):
    state,session,bot,r=setup(tmp_path)
    state.set('audio:1','on')
    jid,_=state.submit(1,-10,77,12,'https://www.tiktok.com/@x/photo/123')
    folder=r.work/'images';folder.mkdir()
    records=photo_records(folder,count,document)
    (folder/'sound.mp3').write_bytes(b'soundtrack')
    records.append({'file':'sound.mp3','kind':'audio','sha256':'audio'})
    sizes=[min(10,count-offset) for offset in range(0,count,10)]
    first_ids=[201+100*index for index in range(len(sizes))]
    for size,mid in zip(sizes,first_ids):
        if size>1:
            session.queue('sendMediaGroup',[message(-10,mid+i) for i in range(size)])
        else:
            session.queue('sendDocument' if document else 'sendPhoto',message(-10,mid))
    async with bot.context():
        await r.deliver(jid,records,folder,'Post title','Account','user')
        await r.deliver(jid,records,folder,'Post title','Account','user')
    requests=[request for request in session.requests
              if request['api'] in ('sendMediaGroup','sendPhoto','sendDocument')]
    assert len(requests)==len(sizes)
    assert [len(request['files']) for request in requests]==sizes
    expected_replies=[77,*first_ids[:-1]]
    for index,request in enumerate(requests):
        fields=request['fields']
        assert fields['chat_id']=='-10' and fields['message_thread_id']=='12'
        assert json.loads(fields['reply_parameters'])=={
            'message_id':expected_replies[index],'allow_sending_without_reply':True}
        if request['api']=='sendMediaGroup':
            media=json.loads(fields['media'])
            assert all(item['type']==('document' if document else 'photo') for item in media)
            assert all('caption' not in item for item in media[1:])
            caption=media[0]['caption']
        else:
            caption=fields['caption']
        assert caption==(r.media_caption('Post title','Account','user') if index==0
                         else BOT_ATTRIBUTION)
    assert {file['data'] for request in requests for file in request['files'].values()}=={
        f'image {index}'.encode() for index in range(count)}
    audio=session.calls('sendAudio')
    assert len(audio)==1
    assert json.loads(audio[0]['fields']['reply_parameters'])['message_id']==first_ids[0]
    row=state.job(jid)
    assert row['reply_message']==first_ids[0] and row['photo_reply_message']==first_ids[-1]
    assert row['in_flight'] is None and len(json.loads(row['sent']))==count+1
    state.close()


@pytest.mark.asyncio
async def test_native_photo_reply_chain_resumes_after_second_batch(tmp_path):
    state,session,bot,r=setup(tmp_path)
    jid,_=state.submit(1,-10,77,12,'https://www.tiktok.com/@x/photo/123')
    state.change(jid,status='running')
    folder=r.work/'images';folder.mkdir()
    records=photo_records(folder,23)
    (folder/'sound.mp3').write_bytes(b'soundtrack')
    records.append({'file':'sound.mp3','kind':'audio','sha256':'audio'})
    session.queue('sendMediaGroup',[message(-10,201+i) for i in range(10)])
    def stop_after_second(method):
        r.stop.set()
        return {'ok':True,'result':[message(-10,301+i) for i in range(10)]}
    session.responses['sendMediaGroup'].append((200,stop_after_second))
    session.queue('sendMediaGroup',[message(-10,401+i) for i in range(3)])
    async with bot.context():
        with pytest.raises(asyncio.CancelledError):
            await r.deliver(jid,records,folder,'Post title')
        row=state.job(jid)
        assert row['reply_message']==201 and row['photo_reply_message']==301
        assert row['in_flight'] is None and len(json.loads(row['sent']))==20
        state.close();state=State(tmp_path/'state.db');r.state=state
        state.recover();r.stop.clear()
        assert state.job(jid)['status']=='ready'
        await r.deliver(jid,records,folder,'Post title')
        await r.deliver(jid,records,folder,'Post title')
    requests=session.calls('sendMediaGroup')
    assert [len(json.loads(request['fields']['media'])) for request in requests]==[10,10,3]
    assert [json.loads(request['fields']['reply_parameters'])['message_id']
            for request in requests]==[77,201,301]
    assert json.loads(requests[-1]['fields']['media'])[0]['caption']==BOT_ATTRIBUTION
    assert len(session.calls('sendAudio'))==1
    assert json.loads(session.calls('sendAudio')[0]['fields']['reply_parameters'])['message_id']==201
    assert state.job(jid)['photo_reply_message']==401
    state.close()


@pytest.mark.asyncio
async def test_native_photo_continuation_migrates_older_receipts(tmp_path):
    state,session,bot,r=setup(tmp_path)
    jid,_=state.submit(1,-10,77,12,'https://www.tiktok.com/@x/photo/123')
    state.set('language:1','ar');state.set('compression:1','{"mode":"large"}')
    state.change(jid,status='running',reply_message=201,
                 sent=json.dumps([f'{index}:{index}' for index in range(10)]))
    # Simulate the database schema from before continuation reply targets existed.
    state.db.execute('ALTER TABLE jobs DROP COLUMN photo_reply_message')
    state.close();state=State(tmp_path/'state.db');r.state=state;state.recover()
    assert state.job(jid)['photo_reply_message'] is None
    assert state.get('language:1')=='ar' and state.get('compression:1')=='{"mode":"large"}'
    folder=r.work/'images';folder.mkdir();records=photo_records(folder,13)
    session.queue('sendMediaGroup',[message(-10,301+i) for i in range(3)])
    async with bot.context():await r.deliver(jid,records,folder,'Post title')
    request=session.calls('sendMediaGroup')[0]
    assert len(request['files'])==3
    assert json.loads(request['fields']['reply_parameters'])['message_id']==201
    assert json.loads(request['fields']['media'])[0]['caption']==BOT_ATTRIBUTION
    assert state.job(jid)['reply_message']==201 and state.job(jid)['photo_reply_message']==301
    assert len(json.loads(state.job(jid)['sent']))==13
    state.close()


@pytest.mark.asyncio
@pytest.mark.parametrize('ambiguous',[False,True])
async def test_native_failed_continuation_preserves_previous_batch(tmp_path,ambiguous):
    state,session,bot,r=setup(tmp_path)
    jid,_=state.submit(1,-10,77,12,'https://www.tiktok.com/@x/photo/123')
    state.change(jid,status='running')
    folder=r.work/'images';folder.mkdir();records=photo_records(folder,13)
    session.queue('sendMediaGroup',[message(-10,201+i) for i in range(10)])
    if ambiguous:
        def failed(method):raise TelegramNetworkError(method=method,message='response interrupted')
        session.responses['sendMediaGroup'].append((200,failed))
    else:
        session.queue('sendMediaGroup',status=400,description='controlled rejection')
    async with bot.context():
        with pytest.raises(TelegramAPIError):await r.deliver(jid,records,folder,'Post title')
        row=state.job(jid)
        assert row['reply_message']==201 and row['photo_reply_message']==201
        assert len(json.loads(row['sent']))==10
        assert bool(row['in_flight'])==ambiguous
        state.recover()
        assert state.job(jid)['status']==('uncertain' if ambiguous else 'ready')
        if not ambiguous:
            session.queue('sendMediaGroup',[message(-10,301+i) for i in range(3)])
            await r.deliver(jid,records,folder,'Post title')
            retry=session.calls('sendMediaGroup')[-1]['fields']
            assert json.loads(retry['reply_parameters'])['message_id']==201
            assert json.loads(retry['media'])[0]['caption']==BOT_ATTRIBUTION
            assert state.job(jid)['photo_reply_message']==301
    assert len(session.calls('sendMediaGroup'))==(2 if ambiguous else 3)
    state.close()


@pytest.mark.asyncio
async def test_native_bound_callbacks_settings_language_and_queued_audio(tmp_path):
    state,session,bot,r=setup(tmp_path)
    jid,_=state.submit(1,-10,77,12,'https://www.tiktok.com/@x/video/123')
    state.change(jid,status='done',manual_audio=1,reply_message=88)
    async with bot.context():
        await r.handle(callback(bot,'settings:1:audio-off',user=2))
        assert state.get('audio:1') is None and not session.calls('editMessageText')
        for data in ('settings:1:audio-off','settings:1:compress-fps-30',
                     'settings:1:compress-mode-large','lang:1:ar'):
            await r.handle(callback(bot,data))
        assert state.get('audio:1')=='off'
        assert json.loads(state.get('compression:1'))['fps']=='30'
        assert json.loads(state.get('compression:1'))['mode']=='large'
        assert state.get('language:1')=='ar'
        query=callback(bot,f'extract:{jid}',chat=-10)
        await r.handle(query);await r.handle(query)
    row=state.outstanding(1)[0]
    assert row['audio_only'] and row['message_id']==88 and row['thread_id']==12
    assert len(state.outstanding(1))==1
    assert len(session.calls('answerCallbackQuery'))==7
    assert len(session.calls('editMessageText'))==4
    state.close()


@pytest.mark.asyncio
@pytest.mark.parametrize('failure',['network','server','decode'])
async def test_native_ambiguous_upload_is_not_retried_or_fallen_back(tmp_path,failure):
    state,session,bot,r=setup(tmp_path)
    jid,_=state.submit(1,1,77,None,'https://www.tiktok.com/@x/video/123')
    state.change(jid,status='running')
    async def download(row,folder):
        folder.mkdir();(folder/'video.mp4').write_bytes(b'video')
        return {'ok':True,'media':[{'file':'video.mp4','kind':'video','sha256':'video'}]}
    r.worker=download
    if failure=='network':
        def failed(method):raise TelegramNetworkError(method=method,message='response interrupted')
        session.responses['sendVideo'].append((200,failed))
    elif failure=='server':
        session.queue('sendVideo',status=500,description='Internal Server Error')
    else:
        session.responses['sendVideo'].append((200,'response interrupted'))
    async with bot.context():await r.run_job(jid)
    assert state.job(jid)['status']=='uncertain' and state.job(jid)['in_flight']
    state.recover()
    assert state.job(jid)['status']=='uncertain'
    assert len(session.calls('sendVideo'))==1 and not session.calls('sendDocument')
    state.close()


@pytest.mark.asyncio
@pytest.mark.parametrize('status',[403,404,413])
async def test_native_definitive_rejection_clears_upload_intent(tmp_path,status):
    state,session,bot,r=setup(tmp_path)
    jid,_=state.submit(1,1,77,None,'https://www.tiktok.com/@x/video/123')
    state.change(jid,status='running')
    async def download(row,folder):
        folder.mkdir();(folder/'video.mp4').write_bytes(b'video')
        return {'ok':True,'media':[{'file':'video.mp4','kind':'video','sha256':'video'}]}
    r.worker=download
    session.queue('sendVideo',status=status)
    async with bot.context():await r.run_job(jid)
    assert state.job(jid)['status']=='failed' and state.job(jid)['in_flight'] is None
    assert len(session.calls('sendVideo'))==1 and not session.calls('sendDocument')
    if status==413:
        assert '50 MB' in session.calls('editMessageText')[-1]['fields']['text']
    state.close()


@pytest.mark.asyncio
async def test_native_flood_retry_rereads_complete_file(tmp_path,monkeypatch):
    state,session,bot,r=setup(tmp_path)
    r.api=Runner.api.__get__(r,Runner)
    delays=[]
    async def sleep(seconds):delays.append(seconds)
    monkeypatch.setattr(asyncio,'sleep',sleep)
    jid,_=state.submit(1,1,77,None,'https://www.tiktok.com/@x/video/123')
    folder=r.work/'media';folder.mkdir();original=b'video'*40000
    (folder/'video.mp4').write_bytes(original)
    session.queue('sendVideo',status=429,description='Too Many Requests',parameters={'retry_after':1})
    async with bot.context():
        await r.deliver(jid,[{'file':'video.mp4','kind':'video','sha256':'video'}],folder)
    requests=session.calls('sendVideo')
    assert len(requests)==2 and 2 in delays
    assert all(next(iter(request['files'].values()))['data']==original for request in requests)
    assert state.job(jid)['in_flight'] is None
    assert json.loads(state.job(jid)['sent'])==['0:video']
    state.close()


@pytest.mark.asyncio
async def test_native_broadcast_migration_server_and_blocked_chat(tmp_path):
    state,session,bot,r=setup(tmp_path)
    r.broadcasts.track(-20,'group');r.broadcasts.track(3)
    source=Update.model_validate({'update_id':1,'message':message(7,user=7,text='/broadcast',
        reply_to_message=message(7,11,7,text='Announcement'))},context={'bot':bot}).message
    async with bot.context():
        await r.broadcasts.command(source,7)
        await r.handle(callback(bot,'broadcast:1:send',user=7,chat=7))
        session.queue('copyMessage',status=400,description='group migrated',
                      parameters={'migrate_to_chat_id':-1002})
        await r.broadcasts.step()
        session.queue('copyMessage',status=500,description='Internal Server Error')
        await r.broadcasts.step()
        session.queue('copyMessage',status=403,description='bot was blocked')
        await r.broadcasts.step()
        for _ in range(3):await r.broadcasts.step()
    targets={row['chat_id']:row['status'] for row in state.db.execute('SELECT * FROM broadcast_targets')}
    assert targets=={-20:'skipped',-1002:'uncertain',3:'failed'}
    assert state.db.execute('SELECT active FROM known_chats WHERE chat_id=-20').fetchone()[0]==0
    assert state.db.execute('SELECT active FROM known_chats WHERE chat_id=3').fetchone()[0]==0
    assert len(session.calls('copyMessage'))==4
    state.close()


@pytest.mark.asyncio
async def test_native_identify_helper_closes_without_logging_token(monkeypatch,capsys):
    session=Session()
    session.queue('getUpdates',[{'update_id':1,'message':message(7,user=7,text='/id')}])
    session.responses['getUpdates'].append((200,asyncio.CancelledError()))
    monkeypatch.setenv('TELEGRAM_BOT_TOKEN',TOKEN)
    monkeypatch.setattr(identify,'AiohttpSession',lambda **kwargs:session)
    with pytest.raises(asyncio.CancelledError):await identify.main()
    output=capsys.readouterr().out
    assert 'Telegram ID: 7' in output and TOKEN not in output
    assert session.closed and session.calls('getUpdates')[1]['fields']['offset']=='2'
