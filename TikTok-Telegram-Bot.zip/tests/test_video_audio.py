from types import SimpleNamespace as NS

import pytest
from gallery_dl.extractor.common import Message
from telegram.error import BadRequest
from bot import Runner
from state import State
import worker
from test_audio import FakeBot, Response


@pytest.mark.parametrize('photos', [False, True])
def test_manual_audio_does_not_download_post_media(tmp_path, monkeypatch, photos):
    music = {'title':'Sound', 'playUrl':'https://cdn.example/sound.mp3'}
    metadata = {'type':'image' if photos else 'video', 'music':music}
    class Extractor:
        category='tiktok'; subcategory='post'; session=None
        def __iter__(self):
            yield Message.Url, 'https://cdn.example/media', metadata
    monkeypatch.setattr(worker.extractor,'find',lambda url:Extractor())
    requested=[]
    def get(session,url,**kwargs):
        requested.append(url)
        assert url.endswith('sound.mp3')
        return Response(b'\xff\xfb\x90\x00'+b'\0'*2000)
    monkeypatch.setattr(worker,'get',get)
    result=worker.download('https://www.tiktok.com/@x/video/123',tmp_path,
                           include_audio=False,audio_only=True)
    assert result['ok'] and len(result['media'])==1
    assert result['media'][0]['reply_to_source']
    assert requested==['https://cdn.example/sound.mp3']


@pytest.mark.asyncio
@pytest.mark.parametrize('manual,fallback', [(True,False),(False,False),(True,True)])
async def test_video_button_and_persistent_queued_extraction(tmp_path, manual, fallback):
    state=State(tmp_path/'state.db'); bot=FakeBot(); r=Runner(state,bot,tmp_path,7,99)
    async def fast(chat,op): return await op()
    r.api=fast
    if fallback:
        async def rejected(**kwargs): raise BadRequest('unsupported video')
        bot.send_video=rejected
        bot.send_document=FakeBot.send_video.__get__(bot,FakeBot)
    jid,_=state.submit(1,-1,10,12,'https://www.tiktok.com/@x/video/123')
    state.change(jid,status='running')
    folder=r.work/'files';folder.mkdir();(folder/'video.mp4').write_bytes(b'video')
    await r.deliver(jid,[{'file':'video.mp4','kind':'video','sha256':'a','manual_audio':manual}],folder)
    state.change(jid,status='done')
    markup=bot.media[0].get('reply_markup')
    assert bool(markup)==manual
    if not manual:
        state.close()
        return
    assert markup.inline_keyboard[0][0].text=='Extract audio'
    class Query:
        data=f'extract:{jid}';from_user=NS(id=1);message=NS(chat=NS(id=-1),message_id=100)
        def __init__(self):self.answers=[]
        async def answer(self,*a,**kw): self.answers.append((a,kw))
    query=Query()
    query.from_user=NS(id=2)
    await r.extract_audio_callback(query)
    assert not state.outstanding()
    query.from_user=NS(id=1);query.message.chat.id=-2
    await r.extract_audio_callback(query)
    assert not state.outstanding()
    query.message.chat.id=-1
    for i in range(4): state.submit(1,-1,200+i,None,f'https://www.tiktok.com/@x/video/{200+i}')
    state.close();r.state=state=State(tmp_path/'state.db')
    await r.handle(NS(callback_query=query))
    audio_job=state.outstanding(1)[-1]
    assert audio_job['audio_only']==1 and audio_job['status']=='queued'
    assert audio_job['message_id']==100 and audio_job['thread_id']==12
    await r.extract_audio_callback(query)
    assert len(state.outstanding(1))==5
    audio_id=audio_job['id']
    state.close();r.state=state=State(tmp_path/'state.db');state.recover()
    assert state.job(audio_id)['audio_only']==1
    state.change(audio_id,status='running')
    (folder/'sound.mp3').write_bytes(b'audio')
    await r.deliver(audio_id,[{'file':'sound.mp3','kind':'audio','sha256':'sound','reply_to_source':True}],folder)
    state.change(audio_id,status='done')
    assert bot.audios[0]['reply_parameters'].message_id==100
    await r.extract_audio_callback(query)
    assert len(bot.audios)==1 and len(state.outstanding(1))==4
    state.close()


@pytest.mark.asyncio
async def test_audio_button_full_queue_and_stopping(tmp_path):
    state=State(tmp_path/'state.db');r=Runner(state,FakeBot(),tmp_path,7,99)
    jid,_=state.submit(1,1,1,None,'https://www.tiktok.com/@x/video/123')
    state.change(jid,status='done',reply_message=100,manual_audio=1)
    for i in range(8): state.submit(1,1,200+i,None,f'https://www.tiktok.com/@x/video/{200+i}')
    class Query:
        data=f'extract:{jid}';from_user=NS(id=1);message=NS(chat=NS(id=1),message_id=100)
        async def answer(self,text,**kw):self.text=text
    query=Query();await r.extract_audio_callback(query)
    assert query.text=='Your download queue is full, try again later'
    assert len(state.outstanding())==8
    r.stop.set();await r.extract_audio_callback(query)
    assert 'restarting' in query.text
    state.close()
