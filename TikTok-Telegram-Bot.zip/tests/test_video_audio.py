import json
import subprocess
from types import SimpleNamespace as NS

import pytest
from mutagen.mp4 import MP4
from gallery_dl.extractor.common import Message
from aiogram.exceptions import TelegramBadRequest
from aiogram.methods import SendVideo
from bot import Runner
from common import BOT_ATTRIBUTION
from state import State
import worker
from test_audio import FakeBot, Response
from test_aiogram import callback, setup


@pytest.mark.parametrize('photos', [False, True])
def test_manual_audio_does_not_download_post_media(tmp_path, monkeypatch, photos):
    music = {'title':'Sound', 'playUrl':'https://cdn.example/sound.mp3'}
    metadata = {'type':'image' if photos else 'video', 'music':music}
    class Extractor:
        category='tiktok'; subcategory='post'; session=None
        def __iter__(self):
            yield Message.Url, 'https://cdn.example/media', metadata
    monkeypatch.setattr(worker.extractor,'find',lambda url:Extractor())
    requested=[]
    def get(session,url,**kwargs):
        requested.append(url)
        assert url.endswith('sound.mp3')
        return Response(b'\xff\xfb\x90\x00'+b'\0'*2000)
    monkeypatch.setattr(worker,'get',get)
    result=worker.download('https://www.tiktok.com/@x/video/123',tmp_path,
                           include_audio=False,audio_only=True)
    assert result['ok'] and len(result['media'])==1
    assert result['media'][0]['reply_to_source']
    assert requested==['https://cdn.example/sound.mp3']


@pytest.fixture(scope='module')
def sample_videos(tmp_path_factory):
    folder = tmp_path_factory.mktemp('embed-audio')
    files = {}
    for kind,ext,video_codec,audio_codec in (
        ('aac','mp4','libx264','aac'),('opus','webm','libvpx','libopus'),
        ('silent','mp4','libx264',None),
    ):
        path = folder/f'{kind}.{ext}'
        args = ['ffmpeg','-v','error','-f','lavfi','-i','color=c=black:s=32x32:r=10']
        if audio_codec:
            args += ['-f','lavfi','-i','sine=frequency=500:sample_rate=48000','-c:a',audio_codec]
        subprocess.run(args+['-t','1','-c:v',video_codec,'-threads','1',str(path)],
                       check=True,capture_output=True,timeout=20)
        files[kind] = path
    return files


def serve_post(monkeypatch, video, *, missing_music=False, kind='video'):
    media_url = 'https://cdn.example/post'
    sound_url = 'https://cdn.example/separate-sound'
    metadata = {'type':kind,'music':None if missing_music else {'playUrl':sound_url}}
    requested = []
    class Extractor:
        category='tiktok'; subcategory='post'; session=None
        def __iter__(self):
            yield Message.Url, media_url, metadata
    def get(session,url,**kwargs):
        requested.append(url)
        if url==sound_url:
            raise worker.Authentication('controlled CDN failure')
        assert url==media_url and kind=='video'
        return Response(video)
    monkeypatch.setattr(worker.extractor,'find',lambda url:Extractor())
    monkeypatch.setattr(worker,'get',get)
    return requested


@pytest.mark.asyncio
@pytest.mark.parametrize('kind',['aac','opus','silent'])
async def test_video_button_extracts_embedded_audio_or_reports_a_silent_video(tmp_path,monkeypatch,sample_videos,kind):
    state,session,bot,r = setup(tmp_path)
    url = 'https://www.tiktok.com/@x/video/123'
    source, _ = state.submit(1,-10,77,12,url)
    state.change(source,status='done',reply_message=88,manual_audio=1)
    video = sample_videos[kind]
    requested = serve_post(monkeypatch,video.read_bytes(),missing_music=kind=='opus')

    async def offline_worker(row,folder):
        folder.mkdir()
        assert row['audio_only']
        return worker.download(row['url'],folder,include_audio=False,audio_only=True,
                               compression={'mode':'none'})
    monkeypatch.setattr(r,'worker',offline_worker)
    async with bot.context():
        await r.handle(callback(bot,f'extract:{source}',chat=-10,mid=88,message_thread_id=12))
        job, = state.outstanding(1)
        await r.run_job(job['id'])
    assert requested==(['https://cdn.example/post'] if kind=='opus' else
                       ['https://cdn.example/separate-sound','https://cdn.example/post'])
    assert not (r.work/str(job['id'])).exists()
    assert not session.calls('sendVideo')
    if kind=='silent':
        assert not session.calls('sendAudio')
        assert state.job(job['id'])['status']=='failed'
        assert session.calls('editMessageText')[-1]['fields']['text']=='Audio is unavailable for this post'
    else:
        assert state.job(job['id'])['status']=='done'
        upload, = session.calls('sendAudio')
        fields = upload['fields']
        assert fields['caption']==BOT_ATTRIBUTION and fields['message_thread_id']=='12'
        assert json.loads(fields['reply_parameters'])['message_id']==88
        audio = upload['files'][fields['audio'].removeprefix('attach://')]
        assert audio['filename']=='123.m4a'
        extracted = tmp_path/audio['filename']
        extracted.write_bytes(audio['data'])
        assert 0.9 < MP4(extracted).info.length < 1.2
        streams = subprocess.check_output(['ffprobe','-v','error','-show_entries','stream=codec_name,codec_type',
                                           '-of','json',str(extracted)],timeout=15)
        assert json.loads(streams)['streams']==[{'codec_name':'aac','codec_type':'audio'}]
        if kind=='aac':
            def aac_bytes(path):
                return subprocess.check_output(['ffmpeg','-v','error','-i',str(path),'-map','0:a:0',
                                                '-c:a','copy','-f','adts','-'],timeout=15)
            assert aac_bytes(extracted)==aac_bytes(video)
    state.close()


@pytest.mark.parametrize('case',['photo','video_too_large','audio_too_large'])
def test_embedded_audio_fallback_preserves_photo_behavior_and_enforces_limits(tmp_path,monkeypatch,sample_videos,case):
    video = sample_videos['aac'].read_bytes()
    requested = serve_post(monkeypatch,video,missing_music=True,kind='image' if case=='photo' else 'video')
    if case=='video_too_large':
        monkeypatch.setattr(worker,'MAX_VIDEO_INPUT_BYTES',len(video)-1)
    elif case=='audio_too_large':
        monkeypatch.setattr(worker,'MAX_BYTES',100)
    url = 'https://www.tiktok.com/@x/video/123'
    if case=='video_too_large':
        with pytest.raises(worker.VideoInputTooLarge):
            worker.download(url,tmp_path,include_audio=False,audio_only=True)
    else:
        error = 'audio_unavailable' if case=='photo' else 'audio_too_large'
        assert worker.download(url,tmp_path,include_audio=False,audio_only=True)=={'ok':False,'error':error}
    assert requested==([] if case=='photo' else ['https://cdn.example/post'])
    assert not list(tmp_path.iterdir())


@pytest.mark.asyncio
@pytest.mark.parametrize('manual,fallback', [(True,False),(False,False),(True,True)])
async def test_video_button_and_persistent_queued_extraction(tmp_path, manual, fallback):
    state=State(tmp_path/'state.db'); bot=FakeBot(); r=Runner(state,bot,tmp_path,7,99)
    async def fast(chat,op): return await op()
    r.api=fast
    if fallback:
        async def rejected(**kwargs): raise TelegramBadRequest(method=SendVideo(chat_id=-1,video=kwargs['video']),message='unsupported video')
        bot.send_video=rejected
        bot.send_document=FakeBot.send_video.__get__(bot,FakeBot)
    jid,_=state.submit(1,-1,10,12,'https://www.tiktok.com/@x/video/123')
    state.change(jid,status='running')
    folder=r.work/'files';folder.mkdir();(folder/'video.mp4').write_bytes(b'video')
    await r.deliver(jid,[{'file':'video.mp4','kind':'video','sha256':'a','manual_audio':manual}],folder)
    state.change(jid,status='done')
    assert bot.media[0]['reply_parameters'].message_id==10
    assert bot.media[0]['chat_id']==-1 and bot.media[0]['message_thread_id']==12
    markup=bot.media[0].get('reply_markup')
    assert bool(markup)==manual
    if not manual:
        state.close()
        return
    assert markup.inline_keyboard[0][0].text=='Extract audio'
    class Query:
        id='queued-audio'
        data=f'extract:{jid}';from_user=NS(id=1);message=NS(chat=NS(id=-1),message_id=100)
        def __init__(self):self.answers=[]
        async def answer(self,*a,**kw): self.answers.append((a,kw))
    query=Query()
    query.from_user=NS(id=2)
    await r.extract_audio_callback(query)
    assert not state.outstanding()
    query.from_user=NS(id=1);query.message.chat.id=-2
    await r.extract_audio_callback(query)
    assert not state.outstanding()
    query.message.chat.id=-1
    for i in range(5): state.submit(1,-1,200+i,None,f'https://www.tiktok.com/@x/video/{200+i}')
    state.close();r.state=state=State(tmp_path/'state.db')
    await r.handle(NS(callback_query=query))
    audio_job=state.outstanding(1)[-1]
    assert audio_job['audio_only']==1 and audio_job['status']=='queued'
    assert audio_job['message_id']==100 and audio_job['thread_id']==12
    await r.extract_audio_callback(query)
    assert len(state.outstanding(1))==6
    audio_id=audio_job['id']
    state.close();r.state=state=State(tmp_path/'state.db');state.recover()
    assert state.job(audio_id)['audio_only']==1
    state.change(audio_id,status='running')
    (folder/'sound.mp3').write_bytes(b'audio')
    await r.deliver(audio_id,[{'file':'sound.mp3','kind':'audio','sha256':'sound','reply_to_source':True}],folder)
    state.change(audio_id,status='done')
    assert bot.audios[0]['reply_parameters'].message_id==100
    await r.extract_audio_callback(query)
    assert len(bot.audios)==1 and len(state.outstanding(1))==5
    state.close()


@pytest.mark.asyncio
async def test_audio_button_unlimited_queue_and_stopping(tmp_path):
    state=State(tmp_path/'state.db');r=Runner(state,FakeBot(),tmp_path,7,99)
    jid,_=state.submit(1,1,1,None,'https://www.tiktok.com/@x/video/123')
    state.change(jid,status='done',reply_message=100,manual_audio=1)
    for i in range(8): state.submit(1,1,200+i,None,f'https://www.tiktok.com/@x/video/{200+i}')
    class Query:
        id='full-queue-audio'
        data=f'extract:{jid}';from_user=NS(id=1);message=NS(chat=NS(id=1),message_id=100)
        async def answer(self,text,**kw):self.text=text
    query=Query();await r.extract_audio_callback(query)
    assert query.text=='Audio requested'
    assert len(state.outstanding())==9
    assert state.outstanding()[-1]['status']=='queued'
    r.stop.set();await r.extract_audio_callback(query)
    assert 'restarting' in query.text
    assert len(state.outstanding())==9
    state.close()
