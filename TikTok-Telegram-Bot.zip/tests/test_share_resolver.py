"""Anonymous, bounded recovery of original posts from TikTok share redirects."""
from collections import deque
import json
import socket
from urllib.parse import urlsplit

import pytest
import requests

import worker

SHORT='https://vt.tiktok.com/example/'
POST='https://www.tiktok.com/@creator/video/1234567890'
RequestsSession=requests.Session


@pytest.fixture
def network(monkeypatch):
    pending=deque()
    calls=[]
    sessions=[]
    def dns(host,port,type):
        address='127.0.0.1' if host in ('127.0.0.1','private.test') else '93.184.216.34'
        return [(socket.AF_INET,socket.SOCK_STREAM,6,'',(address,port))]
    monkeypatch.setattr(worker.socket,'getaddrinfo',dns)
    class Session(RequestsSession):
        def __init__(self):
            super().__init__()
            sessions.append(self)
        def get(self,url,**kwargs):
            if urlsplit(url).hostname in worker.LINK_HOSTS:
                assert self.trust_env is False
            assert self.cookies.get('sessionid') is None
            assert kwargs['stream'] and kwargs['allow_redirects'] is False
            calls.append((url,self.headers['User-Agent'],kwargs))
            expected,status,headers,body=pending.popleft()
            assert url==expected
            if callable(body):body=body(self)
            response=requests.Response()
            response.url=url
            response.status_code=status
            response.headers.update(headers)
            response._content=body.encode() if isinstance(body,str) else body
            response._content_consumed=True
            return response
    monkeypatch.setattr(worker.requests,'Session',Session)
    worker.DIAGNOSTICS.clear()
    return pending,calls,sessions


def redirect(pending,target,source=SHORT):
    pending.append((source,302,{'Location':target},b''))


@pytest.mark.parametrize('target,expected',[
    (POST,POST),
    (POST.replace('/video/','/photo/')+'?sender_device=phone',POST),
    ('https://www.tiktok.com/music/title-12345','https://www.tiktok.com/music/title-12345'),
    ('snssdk1233://aweme/detail/1234567890','https://www.tiktok.com/share/video/1234567890'),
    ('snssdk1180://aweme/detail/1234567890','https://www.tiktok.com/share/video/1234567890'),
    ('https://m.tiktok.com/v/1234567890.html','https://www.tiktok.com/share/video/1234567890'),
    ('https://www.tiktok.com/i18n/share/photo/1234567890','https://www.tiktok.com/share/video/1234567890'),
    ('https://www.tiktok.com/embed/v2/1234567890','https://www.tiktok.com/share/video/1234567890'),
    ('https://www.tiktok.com/@/video/1234567890','https://www.tiktok.com/share/video/1234567890'),
    ('http://www.tiktok.com/@creator/video/1234567890',POST),
    ('https://www.tiktok.com/redirect?url=https%3A%2F%2Fwww.tiktok.com%2F%40creator%2Fvideo%2F1234567890',POST),
])
def test_explicit_post_locations_stop_before_fetching_the_final_page(network,target,expected):
    pending,calls,sessions=network
    redirect(pending,target)
    assert worker.resolve(SHORT)==expected
    assert len(calls)==1 and len(sessions)==1
    assert calls[0][1]=='facebookexternalhit/1.1'
    assert not pending


def test_plain_post_and_sound_links_need_no_resolution_requests(network):
    pending,calls,sessions=network
    assert worker.resolve(POST+'?share=1')==POST
    assert worker.resolve('https://www.tiktok.com/music/title-12345')=='https://www.tiktok.com/music/title-12345'
    assert not calls and not sessions


def test_two_hop_short_links_follow_only_the_intermediate_share_page(network):
    pending,calls,sessions=network
    intermediate='https://www.tiktok.com/t/another/'
    redirect(pending,intermediate)
    redirect(pending,POST,intermediate)
    assert worker.resolve(SHORT)==POST
    assert [call[0] for call in calls]==[SHORT,intermediate]


@pytest.mark.parametrize('body,expected',[
    ('<link rel="canonical" href="'+POST+'">',POST),
    ('<LINK REL="CANONICAL" HREF="https://www.tiktok.com/@creator/photo/1234567890?x=1&amp;y=2">',POST),
    ('<meta property="og:url" content="'+POST+'">',POST),
    ('<meta property="al:ios:url" content="snssdk1233://aweme/detail/1234567890">','https://www.tiktok.com/share/video/1234567890'),
    ('<meta property="al:android:url" content="snssdk1180://aweme/detail/1234567890">','https://www.tiktok.com/share/video/1234567890'),
    ('<meta http-equiv="refresh" content="0; URL=\''+POST+'\'">',POST),
    ('<link rel="canonical" href="/@creator/photo/1234567890">',POST),
    ('<script id="__UNIVERSAL_DATA_FOR_REHYDRATION__" type="application/json">'+json.dumps({
        '__DEFAULT_SCOPE__':{'seo.abtest':{'canonical':POST}}})+'</script>',POST),
])
def test_share_pages_use_their_own_canonical_metadata(network,body,expected):
    pending,calls,sessions=network
    intermediate='https://www.tiktok.com/share/'
    redirect(pending,intermediate)
    pending.append((intermediate,200,{},body))
    assert worker.resolve(SHORT)==expected
    assert len(calls)==2
    assert any(note['reason']=='page_post_target' for note in worker.DIAGNOSTICS)


@pytest.mark.parametrize('status',[200,403,404])
def test_browser_fallback_uses_a_fresh_session_and_does_not_load_saved_cookies(network,tmp_path,monkeypatch,status):
    pending,calls,sessions=network
    cookie_file=tmp_path/'cookies.txt'
    cookie_file.write_text('saved-cookie-secret')
    monkeypatch.setenv('TIKTOK_COOKIE_FILE',str(cookie_file))
    def forbidden(*args,**kwargs):raise AssertionError('Saved cookies must not enter short-link resolution')
    monkeypatch.setattr('http.cookiejar.MozillaCookieJar.load',forbidden)
    pending.append((SHORT,status,{},'<html>Open in the app</html>'))
    redirect(pending,POST)
    assert worker.resolve(SHORT)==POST
    assert len(sessions)==2
    assert calls[0][1]=='facebookexternalhit/1.1'
    assert calls[1][1].startswith('Mozilla/5.0')
    assert all('sessionid' not in session.cookies for session in sessions)
    assert cookie_file.read_text()=='saved-cookie-secret'


@pytest.mark.parametrize('target',[
    'https://advertiser.example/product',
    'https://127.0.0.1/internal',
    'https://private.test/internal',
    'https://www.tiktok.com.evil.example/@creator/video/1234567890',
    'https://secret:password@www.tiktok.com/@creator/video/1234567890',
    'https://www.tiktok.com:9999/@creator/video/1234567890',
    'intent://aweme/detail/1234567890',
    'file:///etc/passwd',
])
def test_off_platform_or_unsafe_redirects_are_not_requested(network,target):
    pending,calls,sessions=network
    for _ in range(2):redirect(pending,target)
    with pytest.raises(ValueError):worker.resolve(SHORT)
    assert [call[0] for call in calls]==[SHORT,SHORT]
    assert all(target not in json.dumps(note) and 'password' not in json.dumps(note) for note in worker.DIAGNOSTICS)


def test_page_metadata_cannot_redirect_downloads_to_foreign_sites_or_suggested_posts(network):
    pending,calls,sessions=network
    body=('<link rel="canonical" href="https://evil.example/@creator/video/1234567890">'
          '<a href="'+POST+'">Suggested post</a>'
          '<script>{"advertisement_id":"1234567890","item_id":"1234567890"}</script>')
    for _ in range(2):pending.append((SHORT,200,{},body))
    with pytest.raises(ValueError):worker.resolve(SHORT)
    assert len(calls)==2
    assert worker.DIAGNOSTICS[-1]=={'stage':'resolve','reason':'unresolved_share_link'}


def test_resolution_redirect_loops_have_a_finite_attempt_limit(network):
    pending,calls,sessions=network
    for _ in range(16):redirect(pending,SHORT)
    with pytest.raises(ValueError):worker.resolve(SHORT)
    assert len(calls)==16 and len(sessions)==2 and not pending


def test_resolution_page_size_is_bounded(network,monkeypatch):
    pending,calls,sessions=network
    monkeypatch.setattr(worker,'LINK_PAGE_BYTES',100)
    for _ in range(2):pending.append((SHORT,200,{},'x'*101+'<link rel="canonical" href="'+POST+'">'))
    with pytest.raises(ValueError):worker.resolve(SHORT)
    assert len(calls)==2
    assert sum(note['reason']=='page_too_large' for note in worker.DIAGNOSTICS)==2


def test_expired_time_budget_stops_before_another_request(network,monkeypatch):
    pending,calls,sessions=network
    now=[0]
    monkeypatch.setattr(worker.time,'monotonic',lambda:now[0])
    def slow(session):
        now[0]=worker.LINK_SECONDS+1
        return b'<html>Open in app</html>'
    pending.append((SHORT,200,{},slow))
    with pytest.raises(requests.Timeout):worker.resolve(SHORT)
    assert len(calls)==1 and len(sessions)==1


def test_refusal_from_first_attempt_does_not_override_a_later_dead_end(network):
    pending,calls,sessions=network
    pending.append((SHORT,403,{},b''))
    pending.append((SHORT,200,{},'<html>No post target</html>'))
    with pytest.raises(ValueError):worker.resolve(SHORT)
    assert len(calls)==2


def test_media_download_redirects_keep_the_existing_streaming_behavior(network):
    pending,calls,sessions=network
    first='https://cdn.example/first.mp4'
    final='https://cdn.example/final.mp4'
    redirect(pending,final,first)
    pending.append((final,200,{},b'original-video-bytes'))
    with worker.requests.Session() as session:
        session.trust_env=False
        with worker.get(session,first) as response:
            assert b''.join(response.iter_content(100))==b'original-video-bytes'
    assert [call[0] for call in calls]==[first,final]
