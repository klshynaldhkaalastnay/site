"""Caption limits, original UTF-8 downloads and native Telegram delivery receipts."""
import asyncio
from html import unescape
import json
import re

import pytest
from aiogram.exceptions import TelegramNetworkError
from gallery_dl.extractor.tiktok import TiktokExtractor

from bot import Runner
from common import BOT_ATTRIBUTION
from state import State
from test_aiogram import setup, message, callback
from test_subtitles import extracted_post, POST_URL
import worker

POST_ID='1234567890'
FULL_TEXT=' \nOriginal <caption> & 😀 سلام\n#tiktok\n' * 80


def visible(html):
    return unescape(re.sub(r'<[^>]+>','',html))


def caption_buttons(session):
    return [request for request in session.calls('sendMessage')
            if 'reply_markup' in request['fields']
            and json.loads(request['fields']['reply_markup'])['inline_keyboard'][0][0]['callback_data'].startswith('caption:')]


def caption_documents(session):
    return [request for request in session.calls('sendDocument')
            if any(file['filename'].endswith('.txt') for file in request['files'].values())]


@pytest.mark.parametrize('symbol',['a','&','😀'])
@pytest.mark.parametrize('header',[False,True])
def test_caption_boundary_counts_visible_text_not_escaped_html(symbol,header):
    name,username=('Account','tester') if header else ('','')
    rendered=Runner.media_caption('x',name,username)
    overhead=len(visible(rendered).encode('utf-16-le'))//2-1
    width=len(symbol.encode('utf-16-le'))//2
    title=symbol*((1024-overhead)//width)
    preview,overflow=Runner.caption_content(title,name,username)
    assert not overflow and title in visible(preview)
    preview,overflow=Runner.caption_content(title+symbol,name,username)
    assert overflow and len(visible(preview).encode('utf-16-le'))//2<=1024
    assert preview.endswith('<a href="https://t.me/TikTokdownloaderbestbot?start=welcome_hehehehaw==">@TikTokdownloaderbestbot</a>')
    assert '…' in visible(preview) and not any(0xD800<=ord(c)<=0xDFFF for c in preview)


@pytest.mark.asyncio
@pytest.mark.parametrize('mode',['video','video_document','photo','photo_document','album','album_documents'])
async def test_caption_button_full_file_ownership_and_restart(tmp_path,mode):
    state,session,bot,r=setup(tmp_path)
    url='https://vt.tiktok.com/ABC/'
    jid,_=state.submit(1,-10,77,12,url)
    folder=r.work/'files';folder.mkdir()
    count=11 if mode.startswith('album') else 1
    photo=mode not in ('video','video_document')
    document=mode in ('photo_document','album_documents')
    records=[]
    for i in range(count):
        file=f'{i}.jpg' if photo else 'video.mp4'
        (folder/file).write_bytes(b'original media')
        records.append({'file':file,'kind':'image' if photo else 'video','sha256':str(i),
                        'width':12000 if document else 40,'height':60,
                        'manual_audio':True,'manual_subtitles':not photo})
    if mode=='video_document':session.queue('sendVideo',status=400,description='Unsupported video')
    async with bot.context():
        await r.deliver(jid,records,folder,FULL_TEXT,'Account','tester',POST_ID)
        await r.deliver(jid,records,folder,FULL_TEXT,'Account','tester',POST_ID)
        buttons=caption_buttons(session)
        assert len(buttons)==1
        row=state.job(jid);anchor=row['reply_message'];mid=row['caption_button_message']
        fields=buttons[0]['fields']
        assert fields['text']==BOT_ATTRIBUTION and fields['parse_mode']=='HTML'
        assert json.loads(fields['link_preview_options'])['is_disabled']
        assert fields['message_thread_id']=='12'
        assert json.loads(fields['reply_parameters'])['message_id']==anchor
        assert row['caption_text']==FULL_TEXT and row['caption_post_id']==POST_ID
        assert not caption_documents(session)
        if not photo:
            request=session.calls('sendDocument' if mode=='video_document' else 'sendVideo')[-1]
            assert [b['text'] for b in json.loads(request['fields']['reply_markup'])['inline_keyboard'][0]]==[
                'Extract audio','Extract subtitles']
        state.change(jid,status='done');state.close()
        state=State(tmp_path/'state.db')
        restored=Runner(state,bot,tmp_path,7,99);restored.api=r.api;r=restored
        assert not folder.exists()
        for changes in ({'user':2},{'chat':-20},{'mid':mid+100},{'message_thread_id':13}):
            values={'chat':-10,'mid':mid,'message_thread_id':12};values.update(changes)
            await r.handle(callback(bot,f'caption:{jid}',**values))
        assert not caption_documents(session)
        query=callback(bot,f'caption:{jid}',chat=-10,mid=mid,message_thread_id=12)
        await r.handle(query);await r.handle(query)
        documents=caption_documents(session)
        assert len(documents)==1
        request=documents[0];file=next(iter(request['files'].values()))
        assert file=={'filename':POST_ID+'.txt','data':FULL_TEXT.encode('utf-8')}
        assert request['fields']['caption']==BOT_ATTRIBUTION
        assert request['fields']['parse_mode']=='HTML'
        assert request['fields']['message_thread_id']=='12'
        assert json.loads(request['fields']['reply_parameters'])['message_id']==anchor
        assert state.job(jid)['caption_file_message'] and not state.job(jid)['caption_file_in_flight']
        assert len(caption_buttons(session))==1
    state.close()


@pytest.mark.asyncio
async def test_normal_caption_has_no_extra_button(tmp_path):
    state,session,bot,r=setup(tmp_path)
    jid,_=state.submit(1,1,77,None,POST_URL)
    folder=r.work/'files';folder.mkdir();(folder/'video.mp4').write_bytes(b'media')
    async with bot.context():
        await r.deliver(jid,[{'file':'video.mp4','kind':'video','sha256':'video'}],folder,'Short caption')
        assert not caption_buttons(session) and not caption_documents(session)
        await r.handle(callback(bot,f'caption:{jid}'))
        assert not caption_documents(session)
    assert state.job(jid)['caption_text']=='' and not state.job(jid)['caption_button_pending']
    state.close()


def test_worker_returns_post_id_after_short_link_resolution(tmp_path,monkeypatch):
    extracted_post(monkeypatch)
    original=TiktokExtractor._extract_rehydration_data
    def page(*args,**kw):
        data=original(*args,**kw)
        data['webapp.video-detail']['itemInfo']['itemStruct']['desc']=FULL_TEXT
        return data
    monkeypatch.setattr(TiktokExtractor,'_extract_rehydration_data',page)
    monkeypatch.setattr(worker,'resolve',lambda url:POST_URL)
    result=worker.download('https://vt.tiktok.com/ABC/',tmp_path,include_audio=False,compression={'mode':'none'})
    assert result['ok'] and result['post_id']==POST_ID and result['title']==FULL_TEXT


def source(state,r):
    jid,_=state.submit(1,-10,77,12,POST_URL)
    r.caption_files.remember(jid,FULL_TEXT,None,True)
    state.change(jid,status='done',reply_message=301)
    return jid


@pytest.mark.asyncio
@pytest.mark.parametrize('uncertain',[False,True])
async def test_caption_notice_repair_and_unconfirmed_binding(tmp_path,uncertain):
    state,session,bot,r=setup(tmp_path);jid=source(state,r)
    if uncertain:
        session.responses['sendMessage'].append((200,lambda method:TelegramNetworkError(method=method,message='lost acknowledgement')))
    else:session.queue('sendMessage',status=400,description='Rejected notice')
    async with bot.context():
        await r.caption_files.install(jid)
        assert state.job(jid)['caption_button_pending'] and bool(state.job(jid)['caption_button_in_flight'])==uncertain
        state.close();state=State(tmp_path/'state.db')
        restored=Runner(state,bot,tmp_path,7,99);restored.api=r.api;r=restored
        await r.caption_files.install(jid)
        if uncertain:
            assert len(caption_buttons(session))==1
            await r.handle(callback(bot,f'caption:{jid}',chat=-10,mid=401,message_thread_id=12,
                                    reply_to_message=message(-10,999)))
            assert not caption_documents(session)
            await r.handle(callback(bot,f'caption:{jid}',chat=-10,mid=401,message_thread_id=12,
                                    reply_to_message=message(-10,301)))
            assert state.job(jid)['caption_button_message']==401
            assert len(caption_documents(session))==1
        else:
            assert len(caption_buttons(session))==2 and state.job(jid)['caption_button_message']
        assert not state.job(jid)['caption_button_pending'] and not state.job(jid)['caption_button_in_flight']
    state.close()


@pytest.mark.asyncio
@pytest.mark.parametrize('status',[400,413,'network'])
async def test_caption_file_rejection_or_uncertain_acknowledgement(tmp_path,monkeypatch,status):
    now=[2000000000.0];monkeypatch.setattr('state.time.time',lambda:now[0])
    state,session,bot,r=setup(tmp_path);jid=source(state,r)
    async with bot.context():
        await r.caption_files.install(jid);mid=state.job(jid)['caption_button_message']
        if status=='network':
            session.responses['sendDocument'].append((200,lambda method:TelegramNetworkError(method=method,message='lost acknowledgement')))
        else:session.queue('sendDocument',status=status,description='Rejected upload')
        query=callback(bot,f'caption:{jid}',chat=-10,mid=mid,message_thread_id=12)
        await r.handle(query)
        assert not state.job(jid)['caption_file_message']
        assert bool(state.job(jid)['caption_file_in_flight'])==(status=='network')
        state.close();state=State(tmp_path/'state.db')
        restored=Runner(state,bot,tmp_path,7,99);restored.api=r.api;r=restored
        await r.handle(query)
        assert len(caption_documents(session))==1
        assert not state.job(jid)['caption_file_message']
        now[0]+=100
        await r.handle(callback(bot,f'caption:{jid}',chat=-10,mid=mid,message_thread_id=12))
        assert len(caption_documents(session))==2
        assert state.job(jid)['caption_file_message'] and not state.job(jid)['caption_file_in_flight']
        assert bool(state.button_press(query.callback_query.id)['in_flight'])==(status=='network')
    state.close()


@pytest.mark.asyncio
async def test_simultaneous_caption_clicks_share_one_upload(tmp_path):
    state,session,bot,r=setup(tmp_path);jid=source(state,r)
    async with bot.context():
        await r.caption_files.install(jid)
        query=callback(bot,f'caption:{jid}',chat=-10,mid=state.job(jid)['caption_button_message'],message_thread_id=12)
        entered=asyncio.Event();release=asyncio.Event()
        async def wait(chat,operation):
            entered.set();await release.wait();return await operation()
        r.api=wait
        first=asyncio.create_task(r.handle(query))
        await asyncio.wait_for(entered.wait(),1)
        await r.handle(query)
        assert not caption_documents(session)
        release.set();await first
        assert len(caption_documents(session))==1
    state.close()


@pytest.mark.asyncio
async def test_caption_cancel_before_upload_allows_retry(tmp_path,monkeypatch):
    now=[2000000000.0];monkeypatch.setattr('state.time.time',lambda:now[0])
    state,session,bot,r=setup(tmp_path);jid=source(state,r)
    async with bot.context():
        await r.caption_files.install(jid)
        query=callback(bot,f'caption:{jid}',chat=-10,mid=state.job(jid)['caption_button_message'],message_thread_id=12)
        api=r.api
        async def cancel(chat,operation):raise asyncio.CancelledError()
        r.api=cancel
        with pytest.raises(asyncio.CancelledError):await r.handle(query)
        assert not state.job(jid)['caption_file_in_flight'] and not caption_documents(session)
        r.api=api;await r.handle(query)
        assert not caption_documents(session)
        now[0]+=100
        await r.handle(callback(bot,f'caption:{jid}',chat=-10,mid=state.job(jid)['caption_button_message'],message_thread_id=12))
        assert len(caption_documents(session))==1
    state.close()
