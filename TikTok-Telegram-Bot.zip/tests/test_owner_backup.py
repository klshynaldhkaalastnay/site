"""Owner-only ZIP snapshots and explicit shutdown/restart controls."""
import asyncio
import io
import json
import sqlite3
import zipfile

import pytest
from aiogram.exceptions import TelegramNetworkError

from common import BOT_ATTRIBUTION
from i18n import TEXT
from test_aiogram import setup, callback, message
from test_restart_languages import restart_button
import backup
import owner_backup


def source_fixture(tmp_path,r):
    source=tmp_path/'app';source.mkdir()
    for name in ('bot.py','worker.py','extra_languages.py','owner_backup.py','requirements.txt','README.md'):
        (source/name).write_text('# fixture\n')
    workflow=source/'.github/workflows/tik.yml';workflow.parent.mkdir(parents=True);workflow.write_text('name: fixture\n')
    for name in ('.env','cookies.txt','state.db','private.json'):(source/name).write_text('must not be uploaded')
    (source/'bad.py').symlink_to(source/'cookies.txt')
    (r.data/'cookies.txt').write_text('private cookie')
    r.owner_backup.source=source


def command_message(bot,chat=-10,user=7):
    return callback(bot,'unused',user=user,chat=chat,mid=77,
                    **({'message_thread_id':12} if chat<0 else {})).callback_query.message


def zip_request(session):return session.calls('sendDocument')[-1]


def zip_button(session,mode):
    rows=json.loads(zip_request(session)['fields']['reply_markup'])['inline_keyboard']
    return next(button for row in rows for button in row if button['callback_data'].endswith(':'+mode))


def press(bot,r,session,mode,**changes):
    values={'user':7,'chat':7,'mid':r.owner_backup.pending['message']};values.update(changes)
    return callback(bot,zip_button(session,mode)['callback_data'],**values)


@pytest.mark.asyncio
@pytest.mark.parametrize('chat',[-10,7])
async def test_private_zip_has_consistent_state_source_and_no_credentials(tmp_path,monkeypatch,chat):
    state,session,bot,r=setup(tmp_path);source_fixture(tmp_path,r)
    state.set('language:7','de');state.set('caption:1','on')
    jid,_=state.submit(1,-10,100,12,'https://www.tiktok.com/@x/video/123')
    state.change(jid,reply_message=301,sent='["video:receipt"]',caption_text='Full original caption',caption_post_id='123')
    def forbidden():raise AssertionError('Telegram ZIP preparation must not require R2')
    monkeypatch.setattr(backup,'connection',forbidden)
    async with bot.context():await r.command(command_message(bot,chat=chat),7,'/upload',[])
    assert not r.stop.is_set() and not r.owner_backup.building and r.owner_backup.pending
    request=zip_request(session);fields=request['fields'];file=next(iter(request['files'].values()))
    assert fields['chat_id']=='7' and 'message_thread_id' not in fields
    assert fields['caption']==TEXT['de']['Backup ZIP sent. Shut down or restart?']+'\n'+BOT_ATTRIBUTION
    assert fields['parse_mode']=='HTML' and file['filename'].startswith('TikTok-Bot-Backup-')
    assert file['filename'].endswith('.zip') and ('reply_parameters' in fields)==(chat==7)
    assert [button['text'] for button in json.loads(fields['reply_markup'])['inline_keyboard'][0]]==[
        TEXT['de']['Shut down'],TEXT['de']['Restart']]
    with zipfile.ZipFile(io.BytesIO(file['data'])) as z:
        assert z.testzip() is None
        assert set(z.namelist())=={'state/state.db','app/bot.py','app/worker.py','app/extra_languages.py',
            'app/owner_backup.py','app/requirements.txt','app/README.md','app/.github/workflows/tik.yml'}
        path=tmp_path/'downloaded.db';path.write_bytes(z.read('state/state.db'))
    with sqlite3.connect(path) as db:
        assert db.execute('PRAGMA quick_check').fetchone()[0]=='ok'
        assert db.execute('SELECT value FROM meta WHERE key="language:7"').fetchone()[0]=='de'
        assert db.execute('SELECT value FROM meta WHERE key="caption:1"').fetchone()[0]=='on'
        assert db.execute('SELECT sent,caption_text FROM jobs WHERE id=?',(jid,)).fetchone()==('["video:receipt"]','Full original caption')
    assert not list(tmp_path.glob('owner-backup-*')) and state.job(jid)['status']=='ready'
    state.close()


@pytest.mark.asyncio
async def test_backup_shutdown_is_owner_bound_and_consumed_once(tmp_path):
    state,session,bot,r=setup(tmp_path);source_fixture(tmp_path,r)
    async with bot.context():
        await r.command(command_message(bot),1,'/upload',[])
        assert not session.calls('sendDocument') and not r.owner_backup.pending
        await r.command(command_message(bot),7,'/upload',[])
        for changes in ({'user':2},{'chat':-10},{'mid':999},{'message_thread_id':12}):
            await r.handle(press(bot,r,session,'shutdown',**changes))
            assert not r.stop.is_set() and r.owner_backup.pending
        query=press(bot,r,session,'shutdown');await r.handle(query)
        assert r.stop.is_set() and r.reason=='shutdown' and not r.force_reimport and r.owner_backup.pending is None
        assert json.loads(session.calls('editMessageReplyMarkup')[-1]['fields']['reply_markup'])=={'inline_keyboard':[]}
        await r.handle(query)
        assert len(session.calls('editMessageReplyMarkup'))==1
        assert 'no longer active' in session.calls('answerCallbackQuery')[-1]['fields']['text']
    state.close()


@pytest.mark.asyncio
async def test_failed_group_acknowledgement_keeps_confirmed_private_controls(tmp_path):
    state,session,bot,r=setup(tmp_path);source_fixture(tmp_path,r)
    session.queue('sendMessage',message(-10,401))
    session.queue('sendMessage',status=403,description='group access revoked')
    async with bot.context():
        await r.command(command_message(bot),7,'/upload',[])
        assert r.owner_backup.pending and r.owner_backup.pending['message']
        assert len(session.calls('sendDocument'))==1 and not r.stop.is_set()
        await r.handle(press(bot,r,session,'shutdown'))
        assert r.stop.is_set() and r.reason=='shutdown'
    state.close()


@pytest.mark.asyncio
@pytest.mark.parametrize('mode',['keep','reimport','cancel'])
async def test_backup_restart_opens_zip_reimport_choices(tmp_path,mode):
    state,session,bot,r=setup(tmp_path);source_fixture(tmp_path,r)
    async with bot.context():
        await r.command(command_message(bot,chat=7),7,'/upload',[])
        mid=r.owner_backup.pending['message'];await r.handle(press(bot,r,session,'restart'))
        assert not r.stop.is_set() and r.owner_backup.pending is None and r.pending_restart
        assert r.pending_restart['anchor']==mid and r.pending_restart['chat']==7
        await r.handle(callback(bot,restart_button(session,mode)['callback_data'],user=7,chat=7,mid=r.pending_restart['message']))
        assert r.stop.is_set()==(mode!='cancel') and r.force_reimport==(mode=='reimport')
    state.close()


@pytest.mark.asyncio
@pytest.mark.parametrize('case',['too_large','blocked','build_failed'])
async def test_backup_failure_keeps_bot_running_and_cleans_temporary_files(tmp_path,monkeypatch,case):
    state,session,bot,r=setup(tmp_path);source_fixture(tmp_path,r)
    if case=='too_large':monkeypatch.setattr(owner_backup,'MAX_BYTES',10)
    elif case=='blocked':session.queue('sendDocument',status=403,description='Forbidden')
    else:
        def fail(*args):raise ValueError('private error must not be exposed')
        monkeypatch.setattr(owner_backup,'create_archive',fail)
    async with bot.context():await r.command(command_message(bot),7,'/upload',[])
    assert not r.stop.is_set() and not r.owner_backup.building and r.owner_backup.pending is None
    assert not list(tmp_path.glob('owner-backup-*')) and len(session.calls('sendDocument'))==int(case=='blocked')
    assert 'private error' not in session.calls('sendMessage')[-1]['fields']['text']
    if case=='too_large':assert '50 MB' in session.calls('sendMessage')[-1]['fields']['text']
    state.close()


@pytest.mark.asyncio
async def test_uncertain_zip_ack_only_binds_to_the_private_backup_document(tmp_path):
    state,session,bot,r=setup(tmp_path);source_fixture(tmp_path,r)
    session.responses['sendDocument'].append((200,lambda method:TelegramNetworkError(method=method,message='lost')))
    async with bot.context():
        await r.command(command_message(bot),7,'/upload',[])
        pending=r.owner_backup.pending
        assert pending and pending['message'] is None and not r.stop.is_set()
        doc={'file_id':'backup','file_unique_id':'backup-id','file_name':'wrong.zip'}
        data=zip_button(session,'shutdown')['callback_data']
        await r.handle(callback(bot,data,user=7,chat=7,mid=900,document=doc));assert not r.stop.is_set()
        doc['file_name']=pending['filename']
        await r.handle(callback(bot,data,user=7,chat=7,mid=900,document=doc))
        assert r.stop.is_set() and r.reason=='shutdown'
    assert not list(tmp_path.glob('owner-backup-*'))
    state.close()


@pytest.mark.asyncio
async def test_upload_lifecycle_stops_only_after_the_private_button(tmp_path,monkeypatch):
    state,session,bot,r=setup(tmp_path);source_fixture(tmp_path,r);state.set('language:7','en')
    jid,_=state.submit(1,1,100,None,'https://www.tiktok.com/@x/video/123')
    session.queue('getUpdates',[{'update_id':42,'message':message(-10,77,user=7,text='/upload',message_thread_id=12)}])
    def shutdown(method):
        assert method.offset==43 and not r.stop.is_set() and r.owner_backup.pending
        return {'ok':True,'result':[press(bot,r,session,'shutdown').model_dump(mode='json',exclude_none=True)]}
    session.responses['getUpdates'].append((200,shutdown))
    async def idle():await r.stop.wait()
    r.scheduler=idle;r.broadcasts.run=idle
    async with bot.context():await asyncio.wait_for(r.run(),3)
    receipt=json.loads((tmp_path/'receipt.json').read_text())
    assert receipt['reason']=='shutdown' and receipt['ok'] and not receipt['force_reimport']
    assert state.get('offset')=='102' and state.job(jid)['status']=='ready'
    monkeypatch.setenv('GITHUB_OUTPUT',str(tmp_path/'outputs.txt'));backup.receipt(tmp_path)
    assert (tmp_path/'outputs.txt').read_text()=='reason=shutdown\nok=true\n'
    assert len(session.calls('sendDocument'))==1 and not list(tmp_path.glob('owner-backup-*'))
    state.close()
