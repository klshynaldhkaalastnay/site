"""Public specs commands, native Telegram formatting and subprocess cleanup."""
import asyncio
from html import unescape
import json

import pytest
from aiogram.types import Update

import bot as bot_module
from bot import COMMANDS
from i18n import HELP, LANGUAGES, OWNER_HELP, TEXT
import system_specs
from test_aiogram import setup, message

ERROR = 'Could not read system specifications, please try again later'


def executable(tmp_path,monkeypatch,body):
    home = tmp_path/'runner home'
    target = home/'.neofetch/neofetch'
    target.parent.mkdir(parents=True,exist_ok=True)
    target.write_text('#!/bin/sh\n'+body)
    target.chmod(0o755)
    monkeypatch.setattr(system_specs.Path,'home',lambda:home)
    return target


@pytest.mark.asyncio
@pytest.mark.parametrize('user',[1,7,99])
@pytest.mark.parametrize('chat',[1,-10])
async def test_native_specs_is_public_before_onboarding_and_replies_in_code(tmp_path,monkeypatch,user,chat):
    executable(tmp_path,monkeypatch,
        '[ "$#" -eq 1 ] && [ "$1" = --stdout ] || exit 9\n'
        "printf '\033]0;discard title\007\033[32mOS: Ubuntu <24> & Linux\033[0m\r\nCPU: 3.100GHz\n'\n")
    monkeypatch.setattr(system_specs.shutil,'which',lambda _:pytest.fail('Cache was not used'))
    state,session,bot,r = setup(tmp_path)
    r.username = 'testbot'
    update = Update.model_validate({'update_id':42,'message':message(chat,user=user,
        text='/SpEcS@testbot ignored arguments',message_thread_id=12 if chat<0 else None)},
        context={'bot':bot})
    async with bot.context():
        await r.handle(update)
    request = session.calls('sendMessage')[-1]['fields']
    assert request['text']=='<pre>OS: Ubuntu &lt;24&gt; &amp; Linux\nCPU: 3.100GHz</pre>'
    assert request['parse_mode']=='HTML' and request['chat_id']==str(chat)
    assert json.loads(request['reply_parameters'])=={'message_id':77,'allow_sending_without_reply':True}
    assert request.get('message_thread_id')==('12' if chat<0 else None)
    assert 'reply_markup' not in request and state.get(f'language:{user}') is None
    assert not r.stop.is_set() and not state.outstanding(user)
    state.close()


@pytest.mark.asyncio
async def test_specs_ignores_commands_for_other_bots(tmp_path,monkeypatch):
    state,session,bot,r = setup(tmp_path)
    r.username = 'testbot'
    async def unexpected():pytest.fail('Another bot was addressed')
    monkeypatch.setattr(bot_module,'read_specs',unexpected)
    update = Update.model_validate({'update_id':42,'message':message(text='/specs@otherbot')},context={'bot':bot})
    async with bot.context():
        await r.handle(update)
    assert not session.calls('sendMessage')
    state.close()


@pytest.mark.asyncio
async def test_specs_splits_long_output_and_escapes_each_code_block(tmp_path,monkeypatch):
    output = '\U0001f9e0'*2100+'\nCPU: <x> & </pre><b>literal</b> 3.100GHz'
    async def current_specs():return output
    monkeypatch.setattr(bot_module,'read_specs',current_specs)
    state,session,bot,r = setup(tmp_path)
    update = Update.model_validate({'update_id':42,'message':message(text='/specs')},context={'bot':bot})
    async with bot.context():
        await r.handle(update)
    requests = session.calls('sendMessage')
    assert len(requests)==2
    pieces = []
    for request in requests:
        text = request['fields']['text']
        assert text.startswith('<pre>') and text.endswith('</pre>') and text.count('<pre>')==1
        piece = unescape(text[5:-6])
        assert len(piece.encode('utf-16-le'))//2<=4096
        pieces.append(piece)
    assert ''.join(pieces)==output
    state.close()


@pytest.mark.asyncio
@pytest.mark.parametrize('failure',['missing','empty','nonzero','timeout'])
async def test_specs_failures_are_translated_and_do_not_stop_the_session(tmp_path,monkeypatch,failure):
    monkeypatch.setattr(system_specs.Path,'home',lambda:tmp_path)
    monkeypatch.setattr(system_specs.shutil,'which',lambda _:None)
    if failure!='missing':
        body = {'empty':'exit 0\n','nonzero':"printf 'unconfirmed output'; exit 7\n",
                'timeout':'/bin/sleep 60\n'}[failure]
        executable(tmp_path,monkeypatch,body)
    if failure=='timeout':
        monkeypatch.setattr(system_specs,'TIMEOUT_SECONDS',0.05)
    state,session,bot,r = setup(tmp_path)
    state.set('language:1','ar')
    update = Update.model_validate({'update_id':42,'message':message(text='/specs')},context={'bot':bot})
    async with bot.context():
        await asyncio.wait_for(r.handle(update),2)
    assert session.calls('sendMessage')[-1]['fields']['text']==TEXT['ar'][ERROR]
    assert not r.stop.is_set()
    state.close()


@pytest.mark.asyncio
async def test_specs_uses_installed_neofetch_when_no_cache_is_present(tmp_path,monkeypatch):
    monkeypatch.setattr(system_specs.Path,'home',lambda:tmp_path)
    target = tmp_path/'installed-neofetch'
    target.write_text("#!/bin/sh\nprintf 'OS: installed neofetch\\n'\n")
    target.chmod(0o755)
    monkeypatch.setattr(system_specs.shutil,'which',lambda _:str(target))
    assert await system_specs.read_specs()=='OS: installed neofetch'


@pytest.mark.asyncio
async def test_cancelling_specs_terminates_the_neofetch_process(tmp_path,monkeypatch):
    executable(tmp_path,monkeypatch,'/bin/sleep 60\n')
    created = asyncio.Event()
    processes = []
    create = asyncio.create_subprocess_exec
    async def record(*args,**kwargs):
        process = await create(*args,**kwargs)
        processes.append(process)
        created.set()
        return process
    monkeypatch.setattr(system_specs.asyncio,'create_subprocess_exec',record)
    task = asyncio.create_task(system_specs.read_specs())
    await asyncio.wait_for(created.wait(),1)
    task.cancel()
    with pytest.raises(asyncio.CancelledError):
        await asyncio.wait_for(task,2)
    assert processes[0].returncode is not None


def test_specs_is_a_public_command_with_translated_help_and_errors():
    assert 'specs' in dict(COMMANDS)
    for language in LANGUAGES:
        assert '/specs - ' in HELP[language] and '/specs' not in OWNER_HELP[language]
        assert ERROR in TEXT[language] and TEXT[language][ERROR].strip()
