"""Three-state media preferences and independent subtitle-only extraction jobs."""
import asyncio
import hashlib
import json
import logging
from pathlib import Path
import sys

import pytest
from aiogram.exceptions import TelegramNetworkError
from gallery_dl import config

from bot import Runner
from common import MEDIA_CHOICES
from i18n import LANGUAGES, TEXT
from state import State
from test_aiogram import setup, message, callback
from test_subtitles import POST_URL, TRACKS, PAYLOADS, extracted_post
import worker


def preferences(audio, subtitles):
    return {'include_audio':audio=='on','audio_button':audio=='off',
            'include_subtitles':subtitles=='on','subtitle_button':subtitles=='off',
            'compression':{'mode':'none'}}


@pytest.mark.asyncio
@pytest.mark.parametrize('audio',MEDIA_CHOICES)
@pytest.mark.parametrize('subtitles',MEDIA_CHOICES)
@pytest.mark.parametrize('fallback',[False,True])
async def test_video_buttons_match_all_preference_combinations(tmp_path,monkeypatch,audio,subtitles,fallback):
    extracted_post(monkeypatch)
    state,session,bot,r=setup(tmp_path)
    state.set('audio:1',audio);state.set('subtitles:1',subtitles)
    jid,_=state.submit(1,-10,77,12,POST_URL)
    folder=r.work/'post';folder.mkdir()
    result=worker.download(POST_URL,folder,**preferences(audio,subtitles))
    assert result['ok']
    assert sum(record['kind']=='audio' for record in result['media'])==int(audio=='on')
    assert sum(record['kind']=='subtitle' for record in result['media'])==3*int(subtitles=='on')
    if fallback:
        session.queue('sendVideo',status=400,description='Unsupported video')
        session.queue('sendDocument',message(-10,201))
    else:session.queue('sendVideo',message(-10,201))
    async with bot.context():
        await r.deliver(jid,result['media'],folder,result['title'])
        await r.deliver(jid,result['media'],folder,result['title'])
    video=session.calls('sendDocument' if fallback else 'sendVideo')[0]['fields']
    expected=[]
    if audio=='off':expected.append({'text':'Extract audio','callback_data':f'extract:{jid}'})
    if subtitles=='off':expected.append({'text':'Extract subtitles','callback_data':f'extract_subtitles:{jid}'})
    if expected:assert json.loads(video['reply_markup'])=={'inline_keyboard':[expected]}
    else:assert 'reply_markup' not in video
    assert video['message_thread_id']=='12' and json.loads(video['reply_parameters'])['message_id']==77
    row=state.job(jid)
    assert bool(row['manual_audio'])==(audio=='off')
    assert bool(row['manual_subtitles'])==(subtitles=='off')
    assert row['audio_button_message']==(201 if audio=='off' else None)
    assert row['subtitle_button_message']==(201 if subtitles=='off' else None)
    assert len(session.calls('sendAudio'))==int(audio=='on')
    assert len(session.calls('sendDocument'))==int(fallback)+3*int(subtitles=='on')
    state.close()


@pytest.mark.asyncio
@pytest.mark.parametrize('audio',MEDIA_CHOICES)
async def test_photo_audio_modes_never_offer_subtitles(tmp_path,monkeypatch,audio):
    extracted_post(monkeypatch,photos=True)
    state,session,bot,r=setup(tmp_path)
    jid,_=state.submit(1,-10,77,12,POST_URL)
    folder=r.work/'photo';folder.mkdir()
    result=worker.download(POST_URL,folder,**preferences(audio,'off'))
    assert all(not record.get('manual_subtitles') and record['kind']!='subtitle' for record in result['media'])
    async with bot.context():await r.deliver(jid,result['media'],folder)
    fields=session.calls('sendPhoto')[0]['fields']
    assert ('reply_markup' in fields)==(audio=='off')
    if audio=='off':assert len(json.loads(fields['reply_markup'])['inline_keyboard'][0])==1
    assert len(session.calls('sendAudio'))==int(audio=='on')
    assert not state.job(jid)['manual_subtitles'] and state.job(jid)['subtitle_button_message'] is None
    state.close()


@pytest.mark.asyncio
async def test_defaults_third_setting_ownership_and_translations(tmp_path):
    state,session,bot,r=setup(tmp_path)
    assert r.settings_view(1)[1].inline_keyboard[1][0].text=='Audio: On'
    assert r.settings_view(1)[1].inline_keyboard[3][0].text=='Subtitles: Off'
    assert r.settings_view(1,'audio')[1].inline_keyboard[0][0].text=='✓ On'
    assert r.settings_view(1,'subtitles')[1].inline_keyboard[0][1].text=='✓ Off'
    async with bot.context():
        for page in ('audio','subtitles'):
            await r.handle(callback(bot,f'settings:1:{page}-off_no_button',user=2))
            assert state.get(f'{page}:1') is None
            await r.handle(callback(bot,f'settings:1:{page}-off_no_button'))
            assert state.get(f'{page}:1')=='off_no_button'
            assert r.settings_view(1,page)[1].inline_keyboard[1][0].text=='✓ Off with no button'
        for language in LANGUAGES:
            state.set('language:1',language)
            for page in ('audio','subtitles'):
                assert r.settings_view(1,page)[1].inline_keyboard[1][0].text=='✓ '+TEXT[language]['Off with no button']
            buttons=r.extraction_keyboard(1,99,audio=True,subtitles=True).inline_keyboard
            assert len(buttons)==1 and [button.text for button in buttons[0]]==[
                TEXT[language]['Extract audio'],TEXT[language]['Extract subtitles']]
    state.close();state=State(tmp_path/'state.db');r.state=state
    assert state.get('audio:1')==state.get('subtitles:1')=='off_no_button'
    state.close()


@pytest.mark.asyncio
@pytest.mark.parametrize('order',[('audio','subtitles'),('subtitles','audio')])
async def test_both_buttons_have_independent_owned_jobs_and_reply_after_restart(tmp_path,monkeypatch,order):
    extracted_post(monkeypatch)
    state,session,bot,r=setup(tmp_path)
    jid,_=state.submit(1,-10,77,12,POST_URL)
    folder=r.work/'post';folder.mkdir()
    result=worker.download(POST_URL,folder,**preferences('off','off'))
    session.queue('sendVideo',message(-10,201))
    async with bot.context():
        await r.deliver(jid,result['media'],folder)
        state.change(jid,status='done')
        state.close();state=State(tmp_path/'state.db')
        restored=Runner(state,bot,tmp_path,7,99);restored.api=r.api;r=restored
        assert not folder.exists()
        for user,chat,mid in ((2,-10,201),(1,-20,201),(1,-10,202)):
            await r.handle(callback(bot,f'extract_subtitles:{jid}',user=user,chat=chat,mid=mid))
            assert not state.outstanding(1) and not state.outstanding(2)
        queries={kind:callback(bot,f'{"extract" if kind=="audio" else "extract_subtitles"}:{jid}',chat=-10,mid=201)
                 for kind in order}
        for kind in order:
            await r.handle(queries[kind]);await r.handle(queries[kind])
        jobs=state.outstanding(1)
        assert len(jobs)==2 and len({row['id'] for row in jobs})==2
        assert all(row['message_id']==201 and row['thread_id']==12 for row in jobs)
        assert sum(row['audio_only'] for row in jobs)==sum(row['subtitles_only'] for row in jobs)==1
        for row in jobs:
            target=r.work/str(row['id']);target.mkdir()
            payload=worker.download(POST_URL,target,audio_only=bool(row['audio_only']),
                                    subtitles_only=bool(row['subtitles_only']),compression={'mode':'none'})
            assert payload['ok']
            await r.deliver(row['id'],payload['media'],target)
            state.change(row['id'],status='done')
        for query in queries.values():await r.handle(query)
    assert len(session.calls('sendVideo'))==1 and len(session.calls('sendAudio'))==1
    assert len(session.calls('sendDocument'))==3 and not state.outstanding(1)
    for request in [*session.calls('sendAudio'),*session.calls('sendDocument')]:
        fields=request['fields']
        assert fields['caption']=='@TikTokdownloaderbestbot'
        assert fields['chat_id']=='-10' and fields['message_thread_id']=='12'
        assert json.loads(fields['reply_parameters'])['message_id']==201
        assert 'reply_markup' not in fields
    state.close()


@pytest.mark.asyncio
async def test_subtitle_queue_capacity_and_stopping(tmp_path):
    state,session,bot,r=setup(tmp_path)
    jid,_=state.submit(1,-10,77,12,POST_URL)
    state.change(jid,status='done',manual_subtitles=1,reply_message=201,subtitle_button_message=201)
    for i in range(8):state.submit(1,1,300+i,None,POST_URL+str(i))
    query=callback(bot,f'extract_subtitles:{jid}',chat=-10,mid=201)
    async with bot.context():
        await r.handle(query)
        assert len(state.outstanding(1))==8
        assert session.calls('answerCallbackQuery')[-1]['fields']['text']=='Your download queue is full, try again later'
        r.stop.set();await r.handle(query)
        assert len(state.outstanding(1))==8
        assert 'restarting' in session.calls('answerCallbackQuery')[-1]['fields']['text']
    state.close()


@pytest.mark.parametrize('case',['tracks','no_tracks','photos','partial_failure','all_failed','all_too_large'])
def test_subtitles_only_fetches_tracks_without_media_or_converters(tmp_path,monkeypatch,case):
    tracks=[] if case=='no_tracks' else [TRACKS[0]] if case in ('all_failed','all_too_large') else None
    requested=extracted_post(monkeypatch,tracks=tracks,photos=case=='photos',
                             failure='request' if case in ('partial_failure','all_failed') else 'too_large' if case=='all_too_large' else None)
    if case=='all_too_large':monkeypatch.setattr(worker,'MAX_BYTES',200)
    def forbidden(*args,**kwargs):raise AssertionError('Subtitle-only requests must not download audio or compress video')
    monkeypatch.setattr(worker,'download_sound',forbidden);monkeypatch.setattr(worker,'compress_video',forbidden)
    result=worker.download(POST_URL,tmp_path,subtitles_only=True)
    assert config.get(('extractor','tiktok'),'subtitles')=='all'
    assert all(url in PAYLOADS for url in requested)
    assert not list(tmp_path.glob('*.mp4')) and not list(tmp_path.glob('*.mp3'))
    if case in ('no_tracks','photos','all_failed','all_too_large'):
        assert not result['ok'] and result['error']==('subtitles_unavailable' if case=='all_failed' else
                                                      'subtitles_too_large' if case=='all_too_large' else 'no_subtitles')
        assert not list(tmp_path.iterdir())
    else:
        assert result['ok']
        assert len(result['media'])==(2 if case=='partial_failure' else 3)
        assert all(record['kind']=='subtitle' and record['reply_to_source'] for record in result['media'])
        for record in result['media']:
            assert hashlib.sha256((tmp_path/record['file']).read_bytes()).hexdigest()==record['sha256']


@pytest.mark.asyncio
async def test_modes_snapshot_and_auxiliary_worker_arguments(tmp_path,monkeypatch):
    state,session,bot,r=setup(tmp_path)
    jid,_=state.submit(1,1,77,None,POST_URL)
    state.set('audio:1','off_no_button');state.set('subtitles:1','off')
    captured=[]
    async def start(*args,**kwargs):
        captured.append(args)
        (Path(args[3])/'result.json').write_text('{"ok":true,"media":[]}')
        class Process:
            returncode=0
            async def wait(self):return 0
        return Process()
    monkeypatch.setattr(asyncio,'create_subprocess_exec',start)
    await r.worker(state.job(jid),r.work/'one')
    state.set('audio:1','on');state.set('subtitles:1','off_no_button')
    state.close();state=State(tmp_path/'state.db');r.state=state
    await r.worker(state.job(jid),r.work/'two')
    audio,_=state.submit(1,1,201,None,POST_URL,audio_only=True)
    subtitles,_=state.submit(1,1,201,None,POST_URL,subtitles_only=True)
    await r.worker(state.job(audio),r.work/'audio')
    await r.worker(state.job(subtitles),r.work/'subtitles')
    assert all('--audio=off_no_button' in args and '--subtitles=off' in args for args in captured[:2])
    assert '--audio-only' in captured[2] and '--subtitles=off' in captured[2]
    assert '--subtitles-only' in captured[3] and '--subtitles=on' in captured[3]
    assert state.job(subtitles)['subtitles']==1 and state.job(audio)['subtitles']==0
    state.close()


@pytest.mark.parametrize('audio,subtitles',[(None,None),('off','off'),('off_no_button','off_no_button')])
def test_worker_cli_passes_three_state_choices(tmp_path,monkeypatch,audio,subtitles):
    captured=[]
    def download(url,directory,**values):captured.append(values);return {'ok':True,'media':[]}
    monkeypatch.setattr(worker,'download',download)
    args=['worker.py',POST_URL,str(tmp_path)]
    if audio:args.append('--audio='+audio)
    if subtitles:args.append('--subtitles='+subtitles)
    monkeypatch.setattr(sys,'argv',args)
    root=logging.getLogger();handlers=root.handlers[:];level=root.level;disabled=logging.root.manager.disable
    try:worker.main()
    finally:
        root.handlers=handlers;root.setLevel(level);logging.disable(disabled)
    values=captured[0]
    assert values['include_audio']==(audio is None)
    assert not values['include_subtitles']
    assert values['audio_button']==(audio=='off')
    assert values['subtitle_button']==(subtitles in (None,'off'))
    assert json.loads((tmp_path/'result.json').read_text())['ok']


def test_older_request_uniqueness_migrates_all_receipts_and_allows_both_extractions(tmp_path):
    state=State(tmp_path/'state.db')
    jid,_=state.submit(1,-10,77,12,POST_URL)
    state.change(jid,status='done',manual_audio=1,reply_message=201,audio_button_message=201,
                 sent='["video:receipt"]',compression='{"mode":"large"}',subtitles=0)
    audio,_=state.submit(1,-10,201,12,POST_URL,audio_only=True)
    state.change(audio,status='running',sent='["audio:receipt"]',reply_message=201)
    state.set('language:1','fa');state.set('audio:1','off')
    before=[dict(row) for row in state.db.execute('SELECT * FROM jobs ORDER BY id')]
    definition=state.db.execute("SELECT sql FROM sqlite_master WHERE name='jobs'").fetchone()[0]
    legacy=definition.replace('UNIQUE(chat_id,message_id,url,audio_only,subtitles_only)','UNIQUE(chat_id,message_id,url)')
    legacy=legacy.replace('CREATE TABLE jobs','CREATE TABLE old_jobs',1)
    with state.db:
        state.db.execute('BEGIN');state.db.execute(legacy)
        state.db.execute('INSERT INTO old_jobs SELECT * FROM jobs')
        state.db.execute('DROP TABLE jobs');state.db.execute('ALTER TABLE old_jobs RENAME TO jobs')
    additions=('subtitles_only','manual_subtitles','subtitle_button_message','audio_mode','subtitle_mode')
    for column in additions:state.db.execute('ALTER TABLE jobs DROP COLUMN '+column)
    state.db.commit();state.close();state=State(tmp_path/'state.db')
    for original,row in zip(before,state.db.execute('SELECT * FROM jobs ORDER BY id')):
        assert all(row[key]==value for key,value in original.items() if key not in additions)
    assert state.get('language:1')=='fa' and state.get('audio:1')=='off'
    assert state.submit(1,-10,201,12,POST_URL,audio_only=True)==(audio,False)
    subtitles,fresh=state.submit(1,-10,201,12,POST_URL,subtitles_only=True)
    assert fresh and subtitles!=audio
    assert state.submit(1,-10,201,12,POST_URL,subtitles_only=True)==(subtitles,False)
    state.recover()
    assert state.job(audio)['status']=='ready' and state.job(jid)['sent']=='["video:receipt"]'
    state.close()


@pytest.mark.asyncio
@pytest.mark.parametrize('ambiguous',[False,True])
async def test_manual_subtitle_resume_preserves_confirmed_tracks(tmp_path,monkeypatch,ambiguous):
    extracted_post(monkeypatch)
    state,session,bot,r=setup(tmp_path)
    jid,_=state.submit(1,-10,201,12,POST_URL,subtitles_only=True)
    state.change(jid,status='running')
    async def download(row,folder):
        folder.mkdir()
        return worker.download(POST_URL,folder,subtitles_only=True)
    r.worker=download
    def first_track(method):
        if not ambiguous:r.stop.set()
        return {'ok':True,'result':message(-10,301)}
    session.responses['sendDocument'].append((200,first_track))
    if ambiguous:
        def interrupted(method):raise TelegramNetworkError(method=method,message='response interrupted')
        session.responses['sendDocument'].append((200,interrupted))
    async with bot.context():
        if ambiguous:await r.run_job(jid)
        else:
            with pytest.raises(asyncio.CancelledError):await r.run_job(jid)
        row=state.job(jid)
        assert len(json.loads(row['sent']))==1 and bool(row['in_flight'])==ambiguous
        state.recover()
        assert state.job(jid)['status']==('uncertain' if ambiguous else 'ready')
        if not ambiguous:
            r.stop.clear();await r.run_job(jid)
            assert state.job(jid)['status']=='done' and len(session.calls('sendDocument'))==3
    assert not session.calls('sendVideo') and not session.calls('sendAudio')
    for request in session.calls('sendDocument'):
        assert json.loads(request['fields']['reply_parameters'])['message_id']==201
    state.close()
