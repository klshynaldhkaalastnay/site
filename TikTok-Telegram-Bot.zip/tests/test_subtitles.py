"""Original subtitle tracks, native Telegram reply uploads and saved user choices."""
import asyncio
import copy
import hashlib
import json
from pathlib import Path
from string import Formatter

import pytest
import requests
from aiogram.exceptions import TelegramNetworkError
from gallery_dl import config
from gallery_dl.extractor.tiktok import TiktokExtractor

from bot import COMMANDS
from i18n import LANGUAGES, HELP, OWNER_HELP, TEXT
from state import State
from test_aiogram import setup, message, callback
from test_audio import Response, jpeg
import worker


POST_URL='https://www.tiktok.com/@tester/video/1234567890'
VIDEO=b'\0\0\0\x18ftypisom'+b'0'*100
TRACKS=[
    {'LanguageID':1,'LanguageCodeName':'eng-US','Format':'WEBVTT','Version':'1',
     'Source':'ASR','Url':'https://cdn.example/track.vtt'},
    {'LanguageID':2,'LanguageCodeName':'fa-IR','Format':'creator_caption','Version':'2',
     'Source':'LC','Url':'https://cdn.example/?track=creator'},
    {'LanguageID':3,'LanguageCodeName':'ara-SA','Format':'SRT','Version':'1',
     'Source':'MT','Url':'https://cdn.example/track.srt'},
]
PAYLOADS={
    TRACKS[0]['Url']:b'WEBVTT\n\n00:00:00.000 --> 00:00:01.000\nHello\n',
    TRACKS[1]['Url']:'{"captions":[{"text":"سلام"}]}'.encode(),
    TRACKS[2]['Url']:b'1\n00:00:00,000 --> 00:00:01,000\nHello\n',
}


def extracted_post(monkeypatch, *, tracks=None, photos=False, failure=None):
    post={'id':'1234567890','author':{'uniqueId':'tester','nickname':'Tester'},
          'createTime':1,'desc':'Post title',
          'music':{'id':'555','playUrl':'https://cdn.example/sound.mp3'},
          'video':{'playAddr':'https://cdn.example/video.mp4','width':40,'height':60,
                   'duration':3,'subtitleInfos':copy.deepcopy(TRACKS if tracks is None else tracks)}}
    if photos:
        post['imagePost']={'images':[{'imageURL':{'urlList':['https://cdn.example/photo.jpg']},
                                      'imageWidth':640,'imageHeight':480}]}
    data={'webapp.video-detail':{'statusCode':0,'itemInfo':{'itemStruct':post}}}
    monkeypatch.setattr(TiktokExtractor,'_extract_rehydration_data',lambda *a,**kw:copy.deepcopy(data))
    requested=[]
    def get(session,url,**kw):
        assert session.cookies.get('sessionid') is None
        requested.append(url)
        if url==TRACKS[0]['Url'] and failure:
            if failure=='request':raise requests.HTTPError('private-token must not enter diagnostics')
            return Response(b'' if failure=='empty' else b'x'*201)
        return Response(VIDEO if url.endswith('video.mp4') else jpeg() if url.endswith('photo.jpg')
                        else b'\xff\xfb\x90\x00'+b'\0'*1000 if url.endswith('sound.mp3') else PAYLOADS[url])
    monkeypatch.setattr(worker,'get',get)
    return requested


@pytest.mark.parametrize('enabled',[False,True])
def test_real_gallery_subtitles_are_optional_and_keep_original_files(tmp_path,monkeypatch,enabled):
    requested=extracted_post(monkeypatch)
    options={'include_subtitles':True} if enabled else {}
    result=worker.download(POST_URL,tmp_path,include_audio=False,compression={'mode':'none'},**options)
    assert result['ok'] and result['title']=='Post title' and result['subtitle_error'] is None
    assert config.get(('extractor','tiktok'),'subtitles')==('all' if enabled else False)
    video=result['media'][0]
    assert video['kind']=='video' and video['manual_audio']
    assert (tmp_path/video['file']).read_bytes()==VIDEO
    subtitles=[record for record in result['media'] if record['kind']=='subtitle']
    assert len(subtitles)==(3 if enabled else 0)
    assert requested==['https://cdn.example/video.mp4',*([track['Url'] for track in TRACKS] if enabled else [])]
    if enabled:
        assert [record['filename'] for record in subtitles]==[
            '1234567890_eng-US_ASR_1.vtt','1234567890_fa-IR_LC_2.json','1234567890_ara-SA_MT_1.srt']
        for record,track in zip(subtitles,TRACKS):
            assert (tmp_path/record['file']).read_bytes()==PAYLOADS[track['Url']]
            assert record['sha256']==hashlib.sha256(PAYLOADS[track['Url']]).hexdigest()
        assert len({record['subtitle_id'] for record in subtitles})==3


@pytest.mark.parametrize('mode',['no_tracks','photos','audio_only'])
def test_subtitles_absent_for_photos_and_manual_audio(tmp_path,monkeypatch,mode):
    requested=extracted_post(monkeypatch,tracks=[] if mode=='no_tracks' else None,photos=mode=='photos')
    result=worker.download(POST_URL,tmp_path,include_audio=False,include_subtitles=True,
                           audio_only=mode=='audio_only',compression={'mode':'none'})
    assert result['ok'] and not any(record['kind']=='subtitle' for record in result['media'])
    assert not any(url in PAYLOADS for url in requested)
    if mode=='photos':
        assert [record['kind'] for record in result['media']]==['image']
        assert result['media'][0]['manual_audio']
        assert 'https://cdn.example/sound.mp3' not in requested
    if mode=='audio_only':
        assert requested==['https://cdn.example/sound.mp3']
        assert config.get(('extractor','tiktok'),'subtitles') is False
        assert result['media'][0]['reply_to_source']


@pytest.mark.parametrize('failure',['request','empty','too_large'])
def test_optional_subtitle_failure_keeps_video_and_other_tracks(tmp_path,monkeypatch,failure):
    extracted_post(monkeypatch,failure=failure)
    monkeypatch.setattr(worker,'MAX_BYTES',200)
    worker.DIAGNOSTICS.clear()
    result=worker.download(POST_URL,tmp_path,include_audio=False,include_subtitles=True,compression={'mode':'none'})
    assert result['ok'] and result['media'][0]['kind']=='video'
    assert [record['kind'] for record in result['media']]==['video','subtitle','subtitle']
    assert result['subtitle_error']==('too_large' if failure=='too_large' else 'unavailable')
    assert not list(tmp_path.glob('*.part'))
    assert 'private-token' not in json.dumps(worker.DIAGNOSTICS)


def test_duplicate_subtitle_entries_are_uploaded_once(tmp_path,monkeypatch):
    extracted_post(monkeypatch,tracks=[TRACKS[0],TRACKS[0]])
    result=worker.download(POST_URL,tmp_path,include_audio=False,include_subtitles=True,compression={'mode':'none'})
    assert [record['kind'] for record in result['media']]==['video','subtitle']
    assert len(list(tmp_path.glob('*.vtt')))==1


@pytest.mark.asyncio
async def test_subtitle_and_language_settings_ownership_defaults_and_persistence(tmp_path):
    state,session,bot,r=setup(tmp_path)
    assert state.get('subtitles:1') is None
    assert r.settings_view(1)[1].inline_keyboard[-1][0].text=='Subtitles: Off'
    assert r.settings_view(1,'subtitles')[1].inline_keyboard[0][1].text=='✓ Off'
    async with bot.context():
        await r.handle(callback(bot,'settings:1:subtitles-on',user=2))
        assert state.get('subtitles:1') is None and not session.calls('editMessageText')
        await r.handle(callback(bot,'settings:1:subtitles-on'))
        assert state.get('subtitles:1')=='on'
        await r.handle(callback(bot,'settings:1:set-fa'))
        assert state.get('language:1')=='fa'
        assert session.calls('editMessageText')[-1]['fields']['text']=='تنظیمات'
        await r.handle(callback(bot,'settings:1:subtitles'))
        assert session.calls('editMessageText')[-1]['fields']['text']==TEXT['fa']['Send available subtitle files as replies to videos']
    state.close();state=State(tmp_path/'state.db');r.state=state
    assert state.get('subtitles:1')=='on' and state.get('language:1')=='fa'
    assert r.settings_view(1,'subtitles')[1].inline_keyboard[0][0].text=='✓ روشن'
    assert state.get('subtitles:2') is None
    assert any(button.callback_data=='settings:1:set-fa'
               for row in r.settings_view(1,'language')[1].inline_keyboard for button in row)
    state.close()


@pytest.mark.asyncio
async def test_subtitle_job_snapshot_survives_preferences_and_older_database(tmp_path,monkeypatch):
    state,session,bot,r=setup(tmp_path)
    jid,_=state.submit(1,1,77,None,POST_URL)
    state.db.execute('ALTER TABLE jobs DROP COLUMN subtitles')
    state.close();state=State(tmp_path/'state.db');r.state=state
    assert state.job(jid)['subtitles'] is None
    captured=[]
    async def start(*args,**kw):
        captured.append(next(arg for arg in args if arg.startswith('--subtitles=')))
        folder=Path(args[3]);(folder/'result.json').write_text('{"ok":true,"media":[]}')
        class Process:
            returncode=0
            async def wait(self):return 0
        return Process()
    monkeypatch.setattr(asyncio,'create_subprocess_exec',start)
    async with bot.context():
        await r.worker(state.job(jid),r.work/'one')
        state.set('subtitles:1','on')
        await r.worker(state.job(jid),r.work/'two')
        state.close();state=State(tmp_path/'state.db');r.state=state;state.recover()
        await r.worker(state.job(jid),r.work/'three')
        enabled,_=state.submit(1,1,78,None,POST_URL)
        await r.worker(state.job(enabled),r.work/'four')
        audio,_=state.submit(1,1,79,None,POST_URL,audio_only=True)
        await r.worker(state.job(audio),r.work/'five')
    assert captured==['--subtitles=off']*3+['--subtitles=on','--subtitles=off']
    assert state.job(enabled)['subtitles']==1 and state.job(audio)['subtitles']==0
    state.close()


@pytest.mark.asyncio
@pytest.mark.parametrize('fallback',[False,True])
async def test_native_subtitle_files_reply_to_video_with_only_attribution(tmp_path,fallback):
    state,session,bot,r=setup(tmp_path)
    jid,_=state.submit(1,-10,77,12,POST_URL)
    folder=r.work/'media';folder.mkdir()
    (folder/'video.mp4').write_bytes(VIDEO)
    (folder/'sound.mp3').write_bytes(b'sound')
    records=[{'file':'video.mp4','kind':'video','sha256':'video','manual_audio':True},
             {'file':'sound.mp3','kind':'audio','sha256':'audio'}]
    for index,(url,data) in enumerate(PAYLOADS.items()):
        suffix=('.vtt','.json','.srt')[index];name=f'subtitle-{index}{suffix}'
        (folder/name).write_bytes(data)
        records.append({'file':name,'filename':f'1234567890_track{index}{suffix}','kind':'subtitle',
                        'subtitle_id':f'track-{index}','sha256':hashlib.sha256(data).hexdigest()})
    if fallback:
        session.queue('sendVideo',status=400,description='Unsupported video')
        session.queue('sendDocument',message(-10,201))
    else:session.queue('sendVideo',message(-10,201))
    for index in range(3):session.queue('sendDocument',message(-10,301+index))
    async with bot.context():
        await r.deliver(jid,records,folder,'Post title','Account','tester')
        await r.deliver(jid,[*records[:2],*reversed(records[2:])],folder,'Post title','Account','tester')
    documents=session.calls('sendDocument')
    assert len(documents)==3+int(fallback)
    for request,record in zip(documents[int(fallback):],records[2:]):
        fields=request['fields']
        assert fields['caption']=='@TikTokdownloaderbestbot'
        assert json.loads(fields['reply_parameters'])['message_id']==201
        assert fields['chat_id']=='-10' and fields['message_thread_id']=='12'
        assert 'reply_markup' not in fields
        attachment=request['files'][fields['document'].removeprefix('attach://')]
        assert attachment=={'filename':record['filename'],'data':(folder/record['file']).read_bytes()}
    assert len(session.calls('sendAudio'))==1
    assert json.loads(session.calls('sendAudio')[0]['fields']['reply_parameters'])['message_id']==201
    assert state.job(jid)['reply_message']==201 and state.job(jid)['photo_reply_message'] is None
    assert len(json.loads(state.job(jid)['sent']))==5 and state.job(jid)['in_flight'] is None
    state.close()


@pytest.mark.asyncio
@pytest.mark.parametrize('ambiguous',[False,True])
async def test_native_subtitle_resume_skips_confirmed_video_and_tracks(tmp_path,ambiguous):
    state,session,bot,r=setup(tmp_path)
    jid,_=state.submit(1,-10,77,12,POST_URL)
    state.change(jid,status='running')
    async def download(row,folder):
        folder.mkdir();(folder/'video.mp4').write_bytes(VIDEO)
        records=[{'file':'video.mp4','kind':'video','sha256':'video'}]
        for index in range(2):
            name=f'track{index}.vtt';(folder/name).write_bytes(PAYLOADS[TRACKS[0]['Url']])
            records.append({'file':name,'kind':'subtitle','subtitle_id':str(index),'sha256':str(index)})
        return {'ok':True,'media':records}
    r.worker=download
    session.queue('sendVideo',message(-10,201))
    def first_document(method):
        if not ambiguous:r.stop.set()
        return {'ok':True,'result':message(-10,301)}
    session.responses['sendDocument'].append((200,first_document))
    if ambiguous:
        def interrupted(method):raise TelegramNetworkError(method=method,message='response interrupted')
        session.responses['sendDocument'].append((200,interrupted))
    async with bot.context():
        if ambiguous:await r.run_job(jid)
        else:
            with pytest.raises(asyncio.CancelledError):await r.run_job(jid)
        row=state.job(jid)
        assert row['reply_message']==201 and len(json.loads(row['sent']))==2
        assert bool(row['in_flight'])==ambiguous
        state.close();state=State(tmp_path/'state.db');r.state=state;state.recover();r.stop.clear()
        assert state.job(jid)['status']==('uncertain' if ambiguous else 'ready')
        if not ambiguous:
            session.queue('sendDocument',message(-10,401))
            await r.run_job(jid)
            assert state.job(jid)['status']=='done'
            assert state.job(jid)['reply_message']==201
            assert len(json.loads(state.job(jid)['sent']))==3
    assert len(session.calls('sendVideo'))==1 and len(session.calls('sendDocument'))==2
    assert all(json.loads(request['fields']['reply_parameters'])['message_id']==201
               and request['fields']['caption']=='@TikTokdownloaderbestbot'
               for request in session.calls('sendDocument'))
    state.close()


def test_persian_translation_coverage_and_language_command_removal():
    assert LANGUAGES['fa']=='فارسی'
    assert set(TEXT['en'])<=set(TEXT['fa'])
    for key in TEXT['en']:
        placeholders=lambda text:{name for _,name,_,_ in Formatter().parse(text) if name}
        assert placeholders(key)==placeholders(TEXT['fa'][key]),key
    assert TEXT['fa']['Subtitles']=='زیرنویس' and TEXT['fa']['Settings']=='تنظیمات'
    assert '/language' not in {f'/{name}' for name,_ in COMMANDS}
    assert all('/language' not in text for text in HELP.values())
    assert '/settings' in HELP['fa'] and '/broadcast' in OWNER_HELP['fa']
