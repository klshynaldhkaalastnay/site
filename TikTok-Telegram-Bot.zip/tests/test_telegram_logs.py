import pytest
import io
import os
from pathlib import Path
import subprocess
import sys
import threading

import telegram_logs as logs


def test_upload_destination_and_redaction(monkeypatch):
    monkeypatch.setenv('TELEGRAM_BOT_TOKEN', '123456789:abcdefghijklmnopqrstuvwxyz12345')
    monkeypatch.setenv('R2_SECRET_ACCESS_KEY', 'private-r2-key')
    calls = []
    def open_request(request, timeout):
        calls.append((request, timeout))
        return io.BytesIO(b'{"ok":true}')
    monkeypatch.setattr(logs.urllib.request, 'urlopen', open_request)
    assert logs.send_document(b'private-r2-key\nCookie: private-session\n', 'logs.txt', 'Hourly log')
    request, timeout = calls[0]
    assert request.full_url.endswith('/sendDocument')
    assert b'-1004434678187' in request.data
    assert b'private-r2-key' not in request.data
    assert b'private-session' not in request.data
    assert b'filename="logs.txt"' in request.data
    assert timeout == 30


def test_upload_failure_does_not_print_credentials(monkeypatch, capsys):
    monkeypatch.setenv('TELEGRAM_BOT_TOKEN', 'private-token')
    def fail(*args, **kwargs):
        raise OSError('https://api.telegram.org/botprivate-token/sendDocument')
    monkeypatch.setattr(logs.urllib.request, 'urlopen', fail)
    assert not logs.send_document(b'hello', 'logs.txt', 'Log')
    assert 'private-token' not in capsys.readouterr().err


def test_missing_token_does_not_attempt_network(monkeypatch):
    monkeypatch.delenv('TELEGRAM_BOT_TOKEN', raising=False)
    monkeypatch.setattr(logs.urllib.request, 'urlopen', lambda *a, **k: pytest.fail('Unexpected network'))
    assert not logs.send_document(b'hello', 'logs.txt', 'Log')


def test_snapshot_preserves_concurrent_entries_and_failed_upload(monkeypatch):
    buffer = logs.LogBuffer()
    buffer.append('old\n')
    def upload(*args):
        buffer.append('new\n')
        return True
    monkeypatch.setattr(logs, 'send_document', upload)
    logs.upload_logs(buffer)
    assert buffer.snapshot()[1] == b'new\n'
    monkeypatch.setattr(logs, 'send_document', lambda *args: False)
    logs.upload_logs(buffer)
    assert buffer.snapshot()[1] == b'new\n'


def test_buffer_bound_and_empty_hourly(monkeypatch):
    monkeypatch.setattr(logs, 'MAX_LOG_BYTES', 10)
    buffer = logs.LogBuffer()
    buffer.append('12345678')
    buffer.append('abcdef')
    assert buffer.size <= 10
    assert b'Older log entries omitted' in buffer.snapshot()[1]
    calls = []
    monkeypatch.setattr(logs, 'send_document', lambda *args: calls.append(args) or True)
    logs.upload_logs(logs.LogBuffer())
    assert b'No bot log entries' in calls[0][0]
    logs.upload_logs(logs.LogBuffer(), final=True)
    assert len(calls) == 1


def test_supervisor_hourly_final_and_exit_code(tmp_path, monkeypatch, capsys):
    script = tmp_path/'child.py'
    script.write_text('import time\nprint("first", flush=True)\ntime.sleep(.16)\nprint("last", flush=True)\nraise SystemExit(7)\n')
    calls = []
    monkeypatch.setattr(logs, 'send_document', lambda *args: calls.append(args) or True)
    assert logs.run_bot(str(script), interval=.05) == 7
    assert any('hourly' in entry[1] for entry in calls)
    # The periodic sender may acknowledge the last line just before final flush.
    uploads=[entry for entry in calls if 'hourly' in entry[1] or 'final' in entry[1]]
    assert sum(b'last' in entry[0] for entry in uploads)==1
    assert 'first' in capsys.readouterr().out
    assert not any(t.is_alive() and t.name.startswith('Thread') for t in threading.enumerate())


def test_supervisor_forwards_signal(tmp_path):
    script = tmp_path/'child.py'
    script.write_text('import signal,time\nsignal.signal(signal.SIGTERM, lambda *_: exit(0))\nprint("ready",flush=True)\ntime.sleep(20)\n')
    env = dict(os.environ, TELEGRAM_BOT_TOKEN='')
    process = subprocess.Popen([sys.executable, str(Path(logs.__file__)), 'run', str(script)], stdout=subprocess.PIPE, stderr=subprocess.PIPE, env=env)
    try:
        assert process.stdout.readline() == b'ready\n'
        process.terminate()
        stdout, stderr = process.communicate(timeout=5)
        assert process.returncode == 0
    finally:
        if process.poll() is None:
            process.kill()
            process.wait()


def test_dead_local_api_fails_session_even_when_bot_stops_cleanly(tmp_path,monkeypatch):
    marker=tmp_path/'ready'
    script=tmp_path/'child.py'
    script.write_text('import signal,time\nfrom pathlib import Path\n'
                      'signal.signal(signal.SIGTERM,lambda *_:exit(0))\n'
                      f'Path({str(marker)!r}).touch()\n'
                      'time.sleep(20)\n')
    monkeypatch.setenv('BOT_API_PID','1073741824')
    kill=logs.os.kill
    def probe(pid,signum):
        if pid==1073741824:
            if marker.exists():raise ProcessLookupError()
            return
        return kill(pid,signum)
    monkeypatch.setattr(logs.os,'kill',probe)
    reported=[]
    monkeypatch.setattr(logs,'send_document',lambda *args:True)
    monkeypatch.setattr(logs,'report_crash',lambda code,context,event:reported.append((code,event)))
    assert logs.run_bot(str(script),interval=.02)==1
    assert reported==[(1,{'title':'Local Bot API server stopped unexpectedly','details':''})]


def test_workflow_embeds_reporter_and_preserves_custom_settings():
    import yaml
    workflow = Path('.github/workflows/tik.yml').read_text()
    document = yaml.safe_load(workflow)
    assert document['env']['SESSION_SECONDS'] == '20400'
    assert 'secrets.TELE_ZIP' in workflow
    assert 'secrets.TELE_OWNER_ID || vars.TELE_OWNER_ID' in workflow
    assert 'actions/upload-artifact' not in workflow
    steps = document['jobs']['bot']['steps']
    supervisor = next(step for step in steps if step['name']=='Prepare Telegram log supervisor')
    source = supervisor['run'].split("python3 - <<'PYREPORT'\n", 1)[1].rsplit('PYREPORT', 1)[0]
    namespace = {}
    # Replace only the write destination to inspect the embedded source safely
    tree = __import__('ast').parse(source)
    literal = tree.body[-1].value.args[0]
    assert __import__('ast').literal_eval(literal) == Path(logs.__file__).read_text()
    reporting = next(step for step in steps if step['name']=='Send diagnostics to Telegram')
    assert reporting['if'] == 'always()'
    assert reporting['continue-on-error'] is True
