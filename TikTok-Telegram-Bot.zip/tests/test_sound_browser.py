import json
import copy
import time
from types import SimpleNamespace as NS
import pytest
import requests
import sound_browser
import worker
from test_audio import Response, jpeg


@pytest.fixture
def saved_cookie_file(tmp_path,monkeypatch):
    path=tmp_path/'cookies.txt'
    path.write_text('# Netscape HTTP Cookie File\n.tiktok.com\tTRUE\t/\tTRUE\t'
                    +str(int(time.time())+86400)+'\tsessionid\tsaved-login\n')
    monkeypatch.setenv('TIKTOK_COOKIE_FILE',str(path))
    return path


def assert_anonymous_session(session):
    prepared=session.prepare_request(requests.Request('GET','https://www.tiktok.com/'))
    assert 'saved-login' not in prepared.headers.get('Cookie','')
    assert session.cookies.get('sessionid') is None


def test_cookie_filtering_and_expiry():
    session=requests.Session()
    session.cookies.set('sessionid','private',domain='.tiktok.com',path='/',secure=True)
    session.cookies.set('expired','old',domain='.tiktok.com',expires=int(time.time())-10)
    session.cookies.set('other','secret',domain='.example.com')
    cookies=sound_browser.browser_cookies(session.cookies)
    assert len(cookies)==1 and cookies[0]['name']=='sessionid'
    assert cookies[0]['domain']=='.tiktok.com' and cookies[0]['secure']


@pytest.mark.asyncio
@pytest.mark.parametrize('cookie_state',['configured','unset','missing','invalid'])
async def test_browser_reads_page_data_keeps_cookies_isolated_and_closes(
        saved_cookie_file,monkeypatch,cookie_state):
    if cookie_state=='unset':
        monkeypatch.delenv('TIKTOK_COOKIE_FILE')
    elif cookie_state=='missing':
        saved_cookie_file.unlink()
    elif cookie_state=='invalid':
        saved_cookie_file.write_text('invalid saved-login cookie data')
    music={'id':'123','playUrl':'https://cdn.example/sound.mp3','title':'Sound'}
    events=[]
    added={};notes=[]
    class Page:
        url='https://www.tiktok.com/music/original-sound-123'
        def set_default_timeout(self,n):pass
        def on(self,*a):pass
        def remove_listener(self,*a):pass
        async def goto(self,*a,**kw):events.append('navigate')
        def locator(self,*a):return self
        async def all_text_contents(self):return [json.dumps({'musicInfo':{'music':music}})]
        async def evaluate(self,code,*a):return 'browser-UA'
    class Context:
        async def add_cookies(self,c):
            events.append('cookies')
            added.update({cookie['name']:cookie['value'] for cookie in c})
        async def new_page(self):return Page()
        async def route(self,*a):pass
        async def cookies(self):return [{'name':'sessionid','value':'fresh','domain':'.tiktok.com','path':'/'}]
    class Browser:
        async def new_context(self,**kw):assert kw['accept_downloads'] is False;return Context()
        async def close(self):events.append('closed')
    class Factory:
        async def __aenter__(self):return NS(chromium=self)
        async def __aexit__(self,*a):pass
        async def launch(self,**kw):assert kw['headless'];return Browser()
    session=requests.Session();session.cookies.set('sessionid','old',domain='.tiktok.com')
    def note(stage,reason,exc=None):notes.append((stage,reason,type(exc).__name__ if exc else None))
    result=await sound_browser.browse_sound(Page.url,'123',session,worker.music_from_page,note,factory=Factory)
    assert result==music and events==['cookies','navigate','closed']
    assert session.headers['User-Agent']=='browser-UA'
    assert added['sessionid']==('saved-login' if cookie_state=='configured' else 'old')
    assert session.cookies.get('sessionid')=='old'
    assert 'saved-login' not in str(notes)
    if cookie_state in ('missing','invalid'):
        assert any(reason=='cookie_file_unavailable' for _,reason,_ in notes)


@pytest.mark.parametrize('resolved',[
    'https://www.tiktok.com/@test/video/1234567890',
    'https://www.tiktok.com/music/title-12345'])
def test_short_link_resolution_does_not_load_saved_cookies(saved_cookie_file,monkeypatch,resolved):
    def forbidden_load(*a,**kw):raise AssertionError('Short links must not load saved cookies')
    monkeypatch.setattr(sound_browser.http.cookiejar.MozillaCookieJar,'load',forbidden_load)
    def get(session,url,**kwargs):
        assert_anonymous_session(session)
        assert kwargs['tiktok_only']
        response=Response(b'');response.url=resolved
        return response
    monkeypatch.setattr(worker,'get',get)
    assert worker.resolve('https://vt.tiktok.com/example/')==resolved


@pytest.mark.parametrize('photos,audio_only',[(False,False),(True,False),(False,True),(True,True)])
def test_post_downloads_and_audio_ignore_saved_cookies(
        tmp_path,saved_cookie_file,monkeypatch,photos,audio_only):
    from gallery_dl.extractor.tiktok import TiktokExtractor
    loads=[]
    def forbidden_load(*a,**kw):
        loads.append(True)
        raise AssertionError('Posts must not load saved cookies')
    monkeypatch.setattr(sound_browser.http.cookiejar.MozillaCookieJar,'load',forbidden_load)
    music={'id':'555','title':'Sound','playUrl':'https://cdn.example/sound.mp3',
           'coverLarge':'https://cdn.example/cover.jpg'}
    post={'id':'1234567890','author':{'uniqueId':'test'},'createTime':1,'desc':'Post','music':music}
    if photos:
        post['imagePost']={'images':[{'imageURL':{'urlList':['https://cdn.example/photo.jpg']},
                                     'imageWidth':640,'imageHeight':480}]}
    else:
        post['video']={'playAddr':'https://cdn.example/video.mp4','width':40,'height':60,'duration':3}
    data={'webapp.video-detail':{'statusCode':0,'itemInfo':{'itemStruct':post}}}
    def page(ex,*a,**kw):
        assert_anonymous_session(ex.session)
        return copy.deepcopy(data)
    monkeypatch.setattr(TiktokExtractor,'_extract_rehydration_data',page)
    requested=[]
    def get(session,url,**kwargs):
        assert_anonymous_session(session)
        requested.append(url)
        return Response(b'\xff\xfb\x90\x00'+b'\0'*2000 if url.endswith('.mp3')
                        else b'\0\0\0\x18ftypisom'+b'0'*100 if url.endswith('.mp4') else jpeg())
    monkeypatch.setattr(worker,'get',get)
    result=worker.download('https://www.tiktok.com/@test/video/1234567890',tmp_path,audio_only=audio_only,compression={'mode':'none'})
    assert result['ok'] and result['media'][-1]['kind']=='audio'
    assert not loads
    if audio_only:
        assert not any(url.endswith(('video.mp4','photo.jpg')) for url in requested)


@pytest.mark.parametrize('source',['page','detail'])
def test_normal_sound_extraction_ignores_saved_cookies(
        tmp_path,saved_cookie_file,monkeypatch,source):
    from gallery_dl.extractor.tiktok import TiktokExtractor
    loads=[]
    def forbidden_load(*a,**kw):
        loads.append(True)
        raise AssertionError('Normal sound requests must not load saved cookies')
    monkeypatch.setattr(sound_browser.http.cookiejar.MozillaCookieJar,'load',forbidden_load)
    music={'id':'123','title':'Sound','playUrl':'https://cdn.example/sound.mp3',
           'coverLarge':'https://cdn.example/cover.jpg'}
    data={'musicInfo':{'music':music}}
    def page(ex,*a,**kw):
        assert_anonymous_session(ex.session)
        return data if source=='page' else {}
    monkeypatch.setattr(TiktokExtractor,'_extract_rehydration_data',page)
    def browser(*a,**kw):raise AssertionError('Playable sound must not start Chromium')
    monkeypatch.setattr(sound_browser,'extract_sound',browser)
    def get(session,url,**kwargs):
        assert_anonymous_session(session)
        return Response(json.dumps(data).encode() if '/api/music/' in url
                        else b'\xff\xfb\x90\x00'+b'\0'*2000 if url.endswith('.mp3') else jpeg())
    monkeypatch.setattr(worker,'get',get)
    result=worker.download('https://www.tiktok.com/music/title-123',tmp_path)
    assert result['ok'] and result['media'][0]['kind']=='audio'
    assert not loads


def test_worker_browser_fallback_only_after_missing_metadata(tmp_path,saved_cookie_file,monkeypatch):
    from gallery_dl.extractor.tiktok import TiktokExtractor
    monkeypatch.setattr(TiktokExtractor,'_extract_rehydration_data',lambda *a,**kw:{})
    called=[]
    def browser(url,sid,*args):
        assert_anonymous_session(args[0])
        assert sound_browser.os.environ['TIKTOK_COOKIE_FILE']==str(saved_cookie_file)
        called.append((url,sid))
        return {'id':sid,'title':'Browser sound','playUrl':'https://cdn.example/sound'}
    monkeypatch.setattr(sound_browser,'extract_sound',browser)
    monkeypatch.setattr(worker,'get',lambda s,u,**k:Response(b'' if '/api/music/' in u else b'\xff\xfb\x90\x00'+b'\0'*2000))
    worker.DIAGNOSTICS.clear()
    result=worker.download('https://www.tiktok.com/music/title-123',tmp_path,include_audio=False)
    assert result['ok'] and result['media'][0]['reply_to_source']
    assert called==[('https://www.tiktok.com/music/title-123','123')]
    assert not any(d.get('exception')=='JSONDecodeError' for d in worker.DIAGNOSTICS)
    monkeypatch.setattr(sound_browser,'extract_sound',lambda *a:None)
    result=worker.download('https://www.tiktok.com/music/title-123',tmp_path)
    assert result['error']=='sound_unavailable'
