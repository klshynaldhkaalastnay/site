import json
import time
from types import SimpleNamespace as NS
import pytest
import requests
import sound_browser
import worker
from test_audio import Response


def test_cookie_filtering_and_expiry():
    session=requests.Session()
    session.cookies.set('sessionid','private',domain='.tiktok.com',path='/',secure=True)
    session.cookies.set('expired','old',domain='.tiktok.com',expires=int(time.time())-10)
    session.cookies.set('other','secret',domain='.example.com')
    cookies=sound_browser.browser_cookies(session.cookies)
    assert len(cookies)==1 and cookies[0]['name']=='sessionid'
    assert cookies[0]['domain']=='.tiktok.com' and cookies[0]['secure']


@pytest.mark.asyncio
async def test_browser_reads_page_data_reuses_session_and_closes():
    music={'id':'123','playUrl':'https://cdn.example/sound.mp3','title':'Sound'}
    events=[]
    class Page:
        url='https://www.tiktok.com/music/original-sound-123'
        def set_default_timeout(self,n):pass
        def on(self,*a):pass
        def remove_listener(self,*a):pass
        async def goto(self,*a,**kw):events.append('navigate')
        def locator(self,*a):return self
        async def all_text_contents(self):return [json.dumps({'musicInfo':{'music':music}})]
        async def evaluate(self,code,*a):return 'browser-UA'
    class Context:
        async def add_cookies(self,c):events.append('cookies')
        async def new_page(self):return Page()
        async def route(self,*a):pass
        async def cookies(self):return [{'name':'sessionid','value':'fresh','domain':'.tiktok.com','path':'/'}]
    class Browser:
        async def new_context(self,**kw):assert kw['accept_downloads'] is False;return Context()
        async def close(self):events.append('closed')
    class Factory:
        async def __aenter__(self):return NS(chromium=self)
        async def __aexit__(self,*a):pass
        async def launch(self,**kw):assert kw['headless'];return Browser()
    session=requests.Session();session.cookies.set('sessionid','old',domain='.tiktok.com')
    result=await sound_browser.browse_sound(Page.url,'123',session,worker.music_from_page,lambda *a,**kw:None,factory=Factory)
    assert result==music and events==['cookies','navigate','closed']
    assert session.headers['User-Agent']=='browser-UA'
    assert session.cookies.get('sessionid')=='fresh'


def test_worker_browser_fallback_only_after_missing_metadata(tmp_path,monkeypatch):
    from gallery_dl.extractor.tiktok import TiktokExtractor
    monkeypatch.setattr(TiktokExtractor,'_extract_rehydration_data',lambda *a,**kw:{})
    called=[]
    def browser(url,sid,*args):
        called.append((url,sid))
        return {'id':sid,'title':'Browser sound','playUrl':'https://cdn.example/sound'}
    monkeypatch.setattr(sound_browser,'extract_sound',browser)
    monkeypatch.setattr(worker,'get',lambda s,u,**k:Response(b'' if '/api/music/' in u else b'\xff\xfb\x90\x00'+b'\0'*2000))
    worker.DIAGNOSTICS.clear()
    result=worker.download('https://www.tiktok.com/music/title-123',tmp_path,include_audio=False)
    assert result['ok'] and result['media'][0]['reply_to_source']
    assert called==[('https://www.tiktok.com/music/title-123','123')]
    assert not any(d.get('exception')=='JSONDecodeError' for d in worker.DIAGNOSTICS)
    monkeypatch.setattr(sound_browser,'extract_sound',lambda *a:None)
    result=worker.download('https://www.tiktok.com/music/title-123',tmp_path)
    assert result['error']=='sound_unavailable'
