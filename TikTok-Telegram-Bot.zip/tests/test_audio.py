import asyncio
import copy
import io
import json
import sqlite3
from types import SimpleNamespace as NS

import pytest
from PIL import Image
from mutagen.id3 import ID3
from aiogram.exceptions import TelegramNetworkError
from aiogram.methods import SendAudio
from bot import Runner
from common import BOT_ATTRIBUTION
from state import State
import worker

class Response:
    headers = {}
    def __init__(self,data): self.data=data
    def iter_content(self,*args): yield self.data
    def __enter__(self): return self
    def __exit__(self,*args): pass

def jpeg():
    out=io.BytesIO(); Image.new('RGB',(640,480),'red').save(out,'JPEG'); return out.getvalue()

@pytest.mark.parametrize('photos',[False,True])
def test_extractor_audio_metadata_embedded(tmp_path,monkeypatch,photos):
    from gallery_dl.extractor.tiktok import TiktokExtractor
    import sound_browser
    def forbidden_browser(*a,**kw):raise AssertionError('Posts must never start a browser')
    monkeypatch.setattr(sound_browser,'extract_sound',forbidden_browser)
    mp3=b'\xff\xfb\x90\x00'+b'\0'*2000
    photo=jpeg(); video=b'\0\0\0\x18ftypisom'+b'0'*100
    music={'id':'555','title':'A sound','authorName':'Artist','album':'Album',
           'duration':12,'playUrl':'https://cdn.example/audio.mp3','coverLarge':'https://cdn.example/cover.jpg'}
    post={'id':'1234567890','author':{'uniqueId':'test','nickname':'Test'},'createTime':1,'desc':'Post title','music':music}
    if photos: post['imagePost']={'images':[{'imageURL':{'urlList':['https://cdn.example/photo.jpg']},'imageWidth':640,'imageHeight':480}]}
    else: post['video']={'playAddr':'https://cdn.example/video.mp4','width':40,'height':60,'duration':3}
    data={'webapp.video-detail':{'statusCode':0,'itemInfo':{'itemStruct':post}}}
    monkeypatch.setattr(TiktokExtractor,'_extract_rehydration_data',lambda *a,**kw:copy.deepcopy(data))
    def get(session,url,**kw):return Response(mp3 if url.endswith('.mp3') else video if url.endswith('.mp4') else photo)
    monkeypatch.setattr(worker,'get',get)
    result=worker.download('https://www.tiktok.com/@test/video/1234567890',tmp_path,compression={'mode':'none'})
    assert result['ok'] and result['audio_error'] is None
    assert result['title']=='Post title'
    record=result['media'][-1]
    assert record['filename']=='A sound.mp3' and record['kind']=='audio'
    tags=ID3(tmp_path/record['file'])
    assert str(tags['TIT2'])=='A sound' and str(tags['TPE1'])=='Artist'
    assert str(tags['TALB'])=='Album' and str(tags['TLEN'])=='12000'
    assert tags.getall('APIC')[0].data==photo
    with Image.open(io.BytesIO(tags.getall('APIC')[0].data)) as cover:assert cover.size==(640,480)
    assert str(tags['TXXX:TikTok Post ID'])=='1234567890'
    assert str(tags['TXXX:TikTok Sound ID'])=='555'
    assert (tmp_path/record['file']).read_bytes().endswith(mp3)
    with Image.open(tmp_path/record['thumbnail']) as img:assert max(img.size)<=320
    no_audio = tmp_path/'disabled'; no_audio.mkdir()
    def forbidden(*args,**kwargs): raise AssertionError('Sound download must be skipped')
    monkeypatch.setattr(worker,'download_sound',forbidden)
    muted=worker.download('https://www.tiktok.com/@test/video/1234567890',no_audio,include_audio=False,compression={'mode':'none'})
    assert muted['ok'] and muted['audio_error'] is None
    assert all(r['kind'] != 'audio' for r in muted['media'])
    assert muted['media'][0]['manual_audio'] is True


def test_fallback_missing_audio_and_size_limit(tmp_path,monkeypatch):
    assert worker.sound_name('', '123')=='123'
    assert worker.sound_name('...', '123')=='123'
    assert '/' not in worker.sound_name('../../test','123')
    assert worker.download_sound(None,None,'123',tmp_path)==(None,'unavailable')
    mp3=b'\xff\xfb\x90\x00'+b'\0'*2000
    monkeypatch.setattr(worker,'get',lambda *a,**kw:Response(mp3))
    record,error=worker.download_sound(None,{'playUrl':'https://cdn.example/a'},'123',tmp_path)
    assert not error and record['filename']=='123.mp3' and record['title']=='123'
    monkeypatch.setattr(worker,'MAX_BYTES',len(mp3))
    record,error=worker.download_sound(None,{'playUrl':'https://cdn.example/a'},'123',tmp_path)
    assert record is None and error=='too_large'
    assert not (tmp_path/'sound.mp3').exists()

class FakeBot:
    def __init__(self):self.media=[]; self.audios=[]
    async def send_message(self,*args,**kwargs):return NS(message_id=42)
    async def edit_message_text(self,*args,**kwargs): pass
    async def send_video(self,**kwargs):self.media.append(kwargs); return NS(message_id=100)
    async def send_media_group(self,**kwargs):self.media.append(kwargs);return [NS(message_id=100),NS(message_id=101)]
    async def send_audio(self,**kwargs):self.audios.append(kwargs);return NS(message_id=102)

@pytest.mark.asyncio
@pytest.mark.parametrize('album',[False,True])
async def test_audio_reply_and_resume_without_duplicate_media(tmp_path,album):
    state=State(tmp_path/'state.db');bot=FakeBot();r=Runner(state,bot,tmp_path,7,99)
    async def fast(chat,op):return await op()
    r.api=fast
    jid,_=state.submit(1,1,1,None,'https://www.tiktok.com/@test/video/123')
    folder=r.work/'files';folder.mkdir(); records=[]
    for i in range(2 if album else 1):
        file=f'{i}.jpg' if album else 'video.mp4';(folder/file).write_bytes(b'media')
        records.append({'file':file,'kind':'image' if album else 'video','sha256':str(i),'width':10,'height':10})
    await r.deliver(jid,records,folder)
    assert state.job(jid)['reply_message']==100
    assert bot.media[0]['reply_parameters'].message_id==1
    assert bot.media[0]['reply_parameters'].allow_sending_without_reply is True
    (folder/'sound.mp3').write_bytes(b'audio');(folder/'cover.jpg').write_bytes(jpeg())
    records.append({'file':'sound.mp3','kind':'audio','sha256':'sound','filename':'Song.mp3','title':'Song','performer':'Artist','duration':12,'thumbnail':'cover.jpg'})
    state.close();r.state=State(tmp_path/'state.db')
    await r.deliver(jid,records,folder)
    assert len(bot.media)==1 and len(bot.audios)==1
    sent=bot.audios[0]
    assert sent['reply_parameters'].message_id==100
    assert sent['caption']==BOT_ATTRIBUTION
    assert sent['audio'].filename=='Song.mp3' and sent['title']=='Song' and sent['performer']=='Artist'
    assert 'thumbnail' in sent
    await r.deliver(jid,records,folder)
    assert len(bot.audios)==1
    r.state.close()

@pytest.mark.asyncio
async def test_ambiguous_audio_preserves_delivery_intent(tmp_path):
    state=State(tmp_path/'state.db');bot=FakeBot();r=Runner(state,bot,tmp_path,7,99)
    async def fast(chat,op):return await op()
    async def fail(**kwargs):raise TelegramNetworkError(method=SendAudio(chat_id=1,audio=kwargs['audio']),message='unconfirmed')
    r.api=fast;bot.send_audio=fail
    jid,_=state.submit(1,1,1,None,'https://www.tiktok.com/@test/video/123')
    state.change(jid,status='running',reply_message=100)
    folder=r.work/'f';folder.mkdir();(folder/'sound.mp3').write_bytes(b'audio')
    with pytest.raises(TelegramNetworkError):await r.deliver(jid,[{'file':'sound.mp3','kind':'audio','sha256':'sound'}],folder)
    state.recover();assert state.job(jid)['status']=='uncertain'
    state.close()

def test_old_database_migrates_without_losing_queue(tmp_path):
    path=tmp_path/'state.db';state=State(path)
    jid,_=state.submit(1,1,1,None,'https://www.tiktok.com/@test/video/123')
    state.set('language:1','ar');state.close()
    with sqlite3.connect(path) as db: db.execute('ALTER TABLE jobs DROP COLUMN reply_message')
    state=State(path)
    assert state.job(jid)['status']=='ready' and state.job(jid)['reply_message'] is None
    assert state.get('language:1')=='ar';state.close()


@pytest.mark.parametrize('format_,mime',[('PNG','image/png'),('WEBP','image/png')])
def test_full_resolution_cover_and_separate_preview(tmp_path,monkeypatch,format_,mime):
    buf=io.BytesIO()
    Image.new('RGB',(1000,700),'blue').save(buf,format=format_)
    original=buf.getvalue()
    monkeypatch.setattr(worker,'get',lambda *a,**kw:Response(original))
    record=worker.sound_artwork(None,{'coverLarge':'https://cdn.example/cover'},tmp_path)
    assert record['cover_mime']==mime and record['cover']!=record['thumbnail']
    with Image.open(tmp_path/record['cover']) as cover:assert cover.size==(1000,700)
    with Image.open(tmp_path/record['thumbnail']) as preview:
        assert preview.format=='JPEG' and max(preview.size)<=320
    if format_=='PNG':assert (tmp_path/record['cover']).read_bytes()==original
    audio=tmp_path/'test.mp3';audio.write_bytes(b'\xff\xfb\x90\x00'+b'\0'*2000)
    worker.embed_sound_metadata(audio,{'title':'Test'},'123',record,'https://www.tiktok.com/@test/video/123')
    artwork=ID3(audio).getall('APIC')[0]
    assert artwork.mime==mime and artwork.data==(tmp_path/record['cover']).read_bytes()
