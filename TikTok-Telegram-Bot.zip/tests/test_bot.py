import asyncio
import hashlib
import json
import sqlite3
from pathlib import Path
from types import SimpleNamespace
import zipfile

import pytest
import yaml
from aiogram.exceptions import TelegramNetworkError
from aiogram.methods import SendVideo
from common import extract_links,normalize_url,TOO_LARGE
from state import State
from bot import Runner
import worker
import backup
from import_app import extract_project


@pytest.fixture
def state(tmp_path):
    obj = State(tmp_path/'state.db')
    yield obj
    obj.close()


def submit(s,user=1,index=1,privileged=False):
    return s.submit(user,1,index,None,f'https://www.tiktok.com/@x/video/{index}',privileged)[0]


def test_queue_limits_promote_and_independent_users(state):
    ids = [submit(state,index=i) for i in range(1,101)]
    assert all(ids)
    assert [r['status'] for r in state.outstanding(1)] == ['ready']*5+['queued']*10+['deferred']*85
    assert state.queue_position(ids[5])==1 and state.queue_position(ids[-1])==85
    assert submit(state,user=2,index=101)
    state.change(ids[0],status='done')
    state.promote()
    assert state.job(ids[5])['status']=='ready'
    assert submit(state,index=102)


def test_exempt_lane_and_replayed_update(state):
    ids = [submit(state,user=99,index=i,privileged=True) for i in range(1,14)]
    assert all(ids)
    assert len([r for r in state.ready() if r['user_id']==99]) == 5
    assert submit(state,user=99,index=1,privileged=True)==ids[0]
    assert len(state.outstanding())==13


@pytest.mark.parametrize('privileged',[False,True])
def test_waiting_requests_keep_their_place_when_new_links_arrive_and_after_restart(tmp_path,privileged):
    state=State(tmp_path/'state.db')
    ids=[submit(state,index=i,privileged=privileged) for i in range(1,18)]
    state.change(ids[0],status='done')
    newest=submit(state,index=18,privileged=privileged)
    assert state.job(ids[5])['status']=='ready'
    assert state.job(newest)['status']==('queued' if privileged else 'deferred')
    assert state.queue_position(newest)==(12 if privileged else 3)
    state.change(ids[1],status='cancelled')
    state.close()
    state=State(tmp_path/'state.db')
    state.recover()
    assert len(state.ready())==5
    assert state.job(ids[6])['status']=='ready'
    assert state.queue_position(newest)==(11 if privileged else 3)
    state.close()


def test_secondary_queue_waits_for_all_primary_work_and_releases_batches_after_restart(tmp_path):
    state=State(tmp_path/'state.db')
    ids=[submit(state,index=i) for i in range(1,46)]
    for jid in ids[:14]:state.change(jid,status='done')
    state.change(ids[14],status='running')
    state.promote()
    assert not state.ready()
    assert all(state.job(jid)['status']=='deferred' for jid in ids[15:])
    newest=submit(state,index=46)
    assert state.job(newest)['status']=='deferred'
    state.close()


    state=State(tmp_path/'state.db')
    state.recover()
    assert [row['id'] for row in state.ready()]==[ids[14]]
    assert state.job(ids[15])['status']=='deferred'
    state.change(ids[14],status='cancelled')
    state.promote()
    assert [row['id'] for row in state.ready()]==ids[15:20]
    assert [row['id'] for row in state.outstanding(1) if row['status']=='queued']==ids[20:30]
    assert all(state.job(jid)['status']=='deferred' for jid in ids[30:])
    for jid in ids[15:30]:state.change(jid,status='failed')
    state.promote()
    assert [row['id'] for row in state.ready()]==ids[30:35]
    assert state.job(newest)['status']=='deferred'
    state.close()


def test_owner_and_bypass_exemptions_refresh_saved_requests_without_losing_work(state):
    owner=[submit(state,user=7,index=100+i) for i in range(40)]
    former=[submit(state,user=88,index=200+i,privileged=True) for i in range(40)]
    state.queue_exemptions(7,99)
    state.promote()
    assert len(state.outstanding(7))==40 and len(state.outstanding(88))==40
    assert all(state.job(jid)['status']=='queued' for jid in owner[5:])
    assert all(state.job(jid)['status']=='queued' for jid in former[5:15])
    assert all(state.job(jid)['status']=='deferred' for jid in former[15:])


async def test_scheduler_runs_five_requests_per_user_and_replaces_finished_slots(tmp_path):
    state=State(tmp_path/'state.db')
    runner=Runner(state,FakeBot(),tmp_path,7,99)
    users=(1,2,99)
    ids={user:[submit(state,user=user,index=user*100+i,privileged=user==99)
               for i in range(8)] for user in users}
    started=set()
    releases={jid:asyncio.Event() for group in ids.values() for jid in group}
    first=asyncio.Event()
    promoted=asyncio.Event()
    async def job(jid):
        started.add(jid)
        assert state.job(jid)['status']=='running'
        for user in users:
            assert sum(row['status']=='running' for row in state.outstanding(user))<=5
        if len(started)==15:first.set()
        if len(started)==18:promoted.set()
        await releases[jid].wait()
        state.change(jid,status='done')
    runner.run_job=job
    scheduler=asyncio.create_task(runner.scheduler())
    try:
        await asyncio.wait_for(first.wait(),2)
        assert started=={jid for group in ids.values() for jid in group[:5]}
        for user in users:
            assert state.job(ids[user][5])['status']=='queued'
            releases[ids[user][0]].set()
        await asyncio.wait_for(promoted.wait(),2)
        for user in users:
            assert ids[user][5] in started
            assert state.job(ids[user][6])['status']=='queued'
    finally:
        runner.stop.set()
        scheduler.cancel()
        for task in runner.tasks.values():task.cancel()
        await asyncio.gather(scheduler,*runner.tasks.values(),return_exceptions=True)
        state.close()


def test_recovery_does_not_resend_ambiguous_upload(state):
    a,b = submit(state,index=1),submit(state,index=2)
    state.change(a,status='running',sent='["previous"]')
    state.change(b,status='running',in_flight='["unknown"]')
    state.recover()
    assert state.job(a)['status']=='ready'
    assert json.loads(state.job(a)['sent'])==['previous']
    assert state.job(b)['status']=='uncertain'


def test_links():
    urls,bad = extract_links('https://www.tiktok.com/@abc/photo/123?foo=bar https://vt.tiktok.com/ABC/ https://evil.example/x')
    assert len(urls)==2 and bad
    assert urls[0]=='https://www.tiktok.com/@abc/video/123'
    for url in ('https://tiktok.com.evil.test/@a/video/1','https://x@tiktok.com/@a/video/1','https://tiktok.com/@profile','file:///tmp/x','https://tiktok.com:999/@a/video/1'):
        with pytest.raises(ValueError):
            normalize_url(url)


class Response:
    headers = {}
    def __init__(self,chunks,headers=None):
        self.chunks=chunks
        self.headers=headers or {}
    def iter_content(self,*args):
        yield from self.chunks


def test_size_headers_and_streaming(tmp_path,monkeypatch):
    monkeypatch.setattr(worker,'MAX_BYTES',10)
    path=tmp_path/'x'
    with pytest.raises(worker.TooLarge):
        worker.save_response(Response([],{ 'Content-Length':'11'}),path)
    with pytest.raises(worker.TooLarge):
        worker.save_response(Response([b'123456',b'78901']),path)
    assert not path.exists()
    worker.save_response(Response([b'1234567890']),path)
    assert path.stat().st_size==10


def test_album_batching_preserves_all_images(tmp_path):
    records=[]
    for i in range(23):
        name=f'{i}.jpg'
        (tmp_path/name).write_bytes(b'test')
        records.append({'file':name,'kind':'image','sha256':str(i),'width':100,'height':100})
    groups=Runner.groups(records,tmp_path)
    assert [len(g[1]) for g in groups]==[10,10,3]
    assert all(g[0]=='photo' for g in groups)


class FakeBot:
    async def send_message(self,*args,**kwargs):
        return SimpleNamespace(message_id=1)
    async def edit_message_text(self,*args,**kwargs):
        return None
    async def send_video(self,*args,**kwargs):
        raise TelegramNetworkError(method=SendVideo(chat_id=1,video='file'),message='Unconfirmed upload')


async def test_owner_permission_and_cancel_ownership(state,tmp_path):
    runner=Runner(state,FakeBot(),tmp_path,owner=7,bypass=99)
    async def fast(chat,operation):
        return await operation()
    runner.api=fast
    msg=SimpleNamespace(chat=SimpleNamespace(id=1),message_thread_id=None)
    await runner.command(msg,1,'/shutdown',[])
    assert not runner.stop.is_set()
    jid=submit(state,user=2,index=1)
    await runner.command(msg,1,'/cancel',[str(jid)])
    assert state.job(jid)['status']=='ready'
    await runner.command(msg,7,'/shutdown',[])
    assert runner.stop.is_set() and runner.reason=='shutdown'


async def test_upload_timeout_records_uncertainty(state,tmp_path):
    runner=Runner(state,FakeBot(),tmp_path,7,99)
    async def fast(chat,operation):
        return await operation()
    runner.api=fast
    jid=submit(state)
    state.change(jid,status='running')
    folder=runner.work/'1'
    folder.mkdir()
    (folder/'1.mp4').write_bytes(b'video')
    record={'file':'1.mp4','kind':'video','sha256':'abc','width':1,'height':1}
    with pytest.raises(TelegramNetworkError):
        await runner.deliver(jid,[record],folder)
    state.recover()
    assert state.job(jid)['status']=='uncertain'


def test_safe_import_excludes_secrets_and_state(tmp_path):
    z=tmp_path/'source.zip'
    with zipfile.ZipFile(z,'w') as out:
        for name in ('bot.py','requirements.txt','state.db','cookies.txt','.env'):
            out.writestr('project/'+name,'x')
    dest=tmp_path/'app'
    extract_project(z,dest)
    assert sorted(x.name for x in dest.iterdir())==['bot.py','requirements.txt']
    with zipfile.ZipFile(z,'w') as out:
        out.writestr('../bad','x')
    with pytest.raises(ValueError):
        extract_project(z,dest)


class FakeS3:
    def __init__(self,broken=False):
        self.broken=broken
        self.deleted=[]
        self.data=b''
    def get_paginator(self,*args):
        return self
    def paginate(self,**kwargs):
        return [{'Contents':[{'Key':'scope/backup-1-old.zip','LastModified':1}]}]
    def upload_file(self,path,*args,**kwargs):
        self.data=Path(path).read_bytes()
    def get_object(self,**kwargs):
        data=b'broken' if self.broken else self.data
        return {'Body':SimpleNamespace(iter_chunks=lambda n:iter([data]),close=lambda:None)}
    def delete_object(self,**kwargs):
        self.deleted.append(kwargs['Key'])


def test_backup_verifies_before_deleting_and_excludes_credentials(state,tmp_path,monkeypatch):
    submit(state)
    source=tmp_path/'app'
    source.mkdir()
    for name in ('bot.py','requirements.txt','.env','cookies.txt'):
        (source/name).write_text('x')
    s3=FakeS3(broken=True)
    monkeypatch.setattr(backup,'connection',lambda:(s3,'bucket','scope/'))
    with pytest.raises(RuntimeError):
        backup.backup(tmp_path,source)
    assert s3.deleted==[]
    s3.broken=False
    backup.backup(tmp_path,source)
    assert s3.deleted==['scope/backup-1-old.zip']
    import io
    with zipfile.ZipFile(io.BytesIO(s3.data)) as z:
        assert set(z.namelist())=={'state/state.db','app/bot.py','app/requirements.txt'}


def test_workflow_main_and_shutdown_gate():
    text=(Path(__file__).parents[1]/'.github/workflows/tik.yml').read_text()
    workflow=yaml.safe_load(text)
    steps=workflow['jobs']['bot']['steps']
    assert all(s['uses'].endswith('@main') for s in steps if 'uses' in s)
    continuation=next(s for s in steps if s['name']=='Start next session')
    assert "reason != 'shutdown'" in continuation['if']
    assert "success()" in continuation['if']
    assert not any('secrets.' in s.get('if','') for s in steps)
    assert not any('/download' in c for c,_ in __import__('bot').COMMANDS)

@pytest.mark.parametrize('photos',[False,True])
def test_real_gallery_extractor_with_fixture_responses(tmp_path,monkeypatch,photos):
    import copy
    import io
    from PIL import Image
    from gallery_dl.extractor.tiktok import TiktokExtractor
    image=io.BytesIO()
    Image.new('RGB',(40,60),'red').save(image,format='JPEG')
    post={'id':'1234567890','author':{'uniqueId':'example','nickname':'Example Name'},'createTime':1,'desc':'Test post'}
    if photos:
        post['imagePost']={'images':[{'imageURL':{'urlList':[f'https://cdn.example/{i}.jpg']},
                                    'imageWidth':40,'imageHeight':60} for i in range(3)]}
    else:
        post['video']={'playAddr':'https://cdn.example/video.mp4','width':40,'height':60,'duration':3}
    data={'webapp.video-detail':{'statusCode':0,'itemInfo':{'itemStruct':post}}}
    monkeypatch.setattr(TiktokExtractor,'_extract_rehydration_data',lambda *a,**k:copy.deepcopy(data))
    class Media(Response):
        def __enter__(self):return self
        def __exit__(self,*args):pass
    content=image.getvalue() if photos else b'\x00\x00\x00\x18ftypisom'+b'0'*100
    monkeypatch.setattr(worker,'get',lambda *a,**k:Media([content]))
    result=worker.download('https://www.tiktok.com/@example/video/1234567890',tmp_path,compression={'mode':'none'})
    assert result['ok']
    assert result['account_name']=='Example Name'
    assert result['username']=='example'
    assert len(result['media'])==(3 if photos else 1)
    assert all(r['kind']==('image' if photos else 'video') for r in result['media'])
    assert all((tmp_path/r['file']).read_bytes()==content for r in result['media'])


async def test_recovery_skips_confirmed_album_batches(state,tmp_path):
    class Collect(FakeBot):
        batches=[]
        async def send_media_group(self,media,**kwargs):
            assert kwargs['reply_parameters'].message_id==1
            self.batches.append(len(media))
    fake=Collect()
    runner=Runner(state,fake,tmp_path,7,99)
    async def fast(chat,operation):return await operation()
    runner.api=fast
    jid=submit(state)
    folder=runner.work/'1'
    folder.mkdir()
    records=[]
    for i in range(13):
        (folder/f'{i}.jpg').write_bytes(b'jpg')
        records.append({'file':f'{i}.jpg','kind':'image','sha256':str(i),'width':40,'height':60})
    state.change(jid,sent=json.dumps([f'{i}:{i}' for i in range(10)]))
    await runner.deliver(jid,records,folder)
    assert fake.batches==[3]
    assert len(json.loads(state.job(jid)['sent']))==13


async def test_shutdown_saves_receipt_and_telegram_cursor(state,tmp_path):
    class Lifecycle(FakeBot):
        delivered=False
        async def get_me(self):return SimpleNamespace(username='testbot')
        async def delete_webhook(self,**kwargs):pass
        async def set_my_commands(self,*args):pass
        async def get_updates(self,**kwargs):
            if self.delivered:
                await asyncio.sleep(0.01)
                return []
            self.delivered=True
            message=SimpleNamespace(from_user=SimpleNamespace(id=7,is_bot=False),
                text='/shutdown',caption=None,chat=SimpleNamespace(id=7),message_thread_id=None)
            return [SimpleNamespace(update_id=42,message=message)]
    state.set('language:7','en')
    runner=Runner(state,Lifecycle(),tmp_path,7,99)
    await asyncio.wait_for(runner.run(),3)
    receipt=json.loads((tmp_path/'receipt.json').read_text())
    assert receipt['ok'] and receipt['reason']=='shutdown'
    assert state.get('offset')=='43'


async def test_video_rejected_as_video_falls_back_to_original_file(state,tmp_path):
    from aiogram.exceptions import TelegramBadRequest
    class Fallback(FakeBot):
        original=None
        async def send_video(self,video,**kwargs):
            assert kwargs['reply_parameters'].message_id==1
            assert b''.join([chunk async for chunk in video.read(self)])==b'original video bytes'
            raise TelegramBadRequest(method=SendVideo(chat_id=1,video=video),message='Unsupported video')
        async def send_document(self,document,**kwargs):
            assert kwargs['reply_parameters'].message_id==1
            self.original=b''.join([chunk async for chunk in document.read(self)])
    fake=Fallback()
    runner=Runner(state,fake,tmp_path,7,99)
    async def fast(chat,operation):return await operation()
    runner.api=fast
    jid=submit(state)
    folder=runner.work/'1'
    folder.mkdir()
    (folder/'1.mp4').write_bytes(b'original video bytes')
    await runner.deliver(jid,[{'file':'1.mp4','kind':'video','sha256':'abc','width':1,'height':1}],folder)
    assert fake.original==b'original video bytes'
    assert json.loads(state.job(jid)['sent'])==['0:abc']
    assert state.job(jid)['in_flight'] is None
