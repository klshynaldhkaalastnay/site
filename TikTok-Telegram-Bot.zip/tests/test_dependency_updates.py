"""Version baselines, exact Telegram notices and background service lifecycle."""
import asyncio
import json
from pathlib import Path
from types import SimpleNamespace as NS
import zipfile

import pytest

import backup
import dependency_updates as updates
from state import State
from test_aiogram import setup
from video_compression import DEFAULTS


def record(name,version):return {'name':name,'version':version}


def installed(monkeypatch,values):
    async def current():return values.copy()
    monkeypatch.setattr(updates,'current_versions',current)


async def test_native_message_matches_image_and_survives_restart(tmp_path,monkeypatch):
    state,session,bot,r=setup(tmp_path)
    old={'package:aiogram':record('aiogram','3.30.0')}
    installed(monkeypatch,old)
    async with bot.context():
        await r.dependency_updates.run()
        assert not session.calls('sendMessage')
        installed(monkeypatch,{'package:aiogram':record('aiogram','3.31.0')})
        await r.dependency_updates.run()
        request=session.calls('sendMessage')[0]
        assert request['fields']['chat_id']=='-1004434678187'
        assert request['fields']['text']=='#update\n\naiogram: 3.30.0 ➡️ 3.31.0'
        assert 'parse_mode' not in request['fields']
        assert 'reply_markup' not in request['fields']
        state.close();state=State(tmp_path/'state.db');r.state=state
        await r.dependency_updates.run()
        assert len(session.calls('sendMessage'))==1
    assert DEFAULTS['mode']=='all'
    state.close()


async def test_changes_in_same_check_post_together(tmp_path,monkeypatch):
    state,session,bot,r=setup(tmp_path)
    original={'package:aiogram':record('aiogram','3.31.0'),
              'package:aiohttp':record('aiohttp','3.14.4'),
              'tool:ffmpeg':record('FFmpeg','N-123-gabc'),
              'runtime:python':record('Python','3.14.7')}
    state.set(updates.STATE_KEY,json.dumps(original))
    installed(monkeypatch,dict(original,**{'package:aiohttp':record('aiohttp','3.14.5'),
        'runtime:python':record('Python','3.14.8'),'package:new':record('new','1.0')}))
    async with bot.context():await r.dependency_updates.run()
    texts=[request['fields']['text'] for request in session.calls('sendMessage')]
    assert texts==['#update\n\naiohttp: 3.14.4 ➡️ 3.14.5\nPython: 3.14.7 ➡️ 3.14.8']
    assert updates.saved_versions(state)['package:new']['version']=='1.0'
    state.close()


async def test_failed_notice_retries_next_session_without_repeating_success(tmp_path,monkeypatch,caplog):
    state,session,bot,r=setup(tmp_path)
    old={'package:aiogram':record('aiogram','3.30.0'),'package:boto3':record('boto3','1.43.110')}
    state.set(updates.STATE_KEY,json.dumps(old))
    installed(monkeypatch,{'package:aiogram':record('aiogram','3.31.0'),'package:boto3':record('boto3','1.43.111')})
    session.queue('sendMessage',status=403,description='PRIVATE_TOKEN must never enter logs')
    async with bot.context():
        await r.dependency_updates.run()
        saved=updates.saved_versions(state)
        assert saved['package:aiogram']['version']=='3.30.0'
        assert saved['package:boto3']['version']=='1.43.110'
        assert not r.stop.is_set()
        state.close();state=State(tmp_path/'state.db');r.state=state
        await r.dependency_updates.run()
        assert len(session.calls('sendMessage'))==2
        await r.dependency_updates.run()
        assert len(session.calls('sendMessage'))==2
    assert 'PRIVATE_TOKEN' not in caplog.text
    state.close()


async def test_collects_transitive_packages_and_available_system_tools(monkeypatch):
    monkeypatch.setattr(updates,'distributions',lambda:[
        NS(metadata={'Name':'gallery_dl'},version='1.32.16'),
        NS(metadata={'Name':'pydantic-core'},version='2.46.5'),
        NS(metadata={'Name':'unsafe\nmessage'},version='1.0')])
    async def report():
        return 'Python: 3.14.8\n\nPython packages\naiogram: 3.31.0\n\nSystem tools\nFFmpeg: N-123-gabc\nffprobe: Unavailable\nChromium: Timed out\nneofetch: 8.2.1'
    monkeypatch.setattr(updates,'read_dependencies',report)
    current=await updates.current_versions()
    assert current['package:gallery-dl']['name']=='gallery_dl'
    assert current['package:pydantic-core']['version']=='2.46.5'
    assert current['tool:ffmpeg']['version']=='N-123-gabc'
    assert current['tool:neofetch']['version']=='8.2.1'
    assert 'tool:ffprobe' not in current and 'tool:chromium' not in current
    assert len([key for key in current if key.startswith('package:')])==2


@pytest.mark.parametrize('saved',['{bad','[]','{"tool:ffmpeg":{"name":"FFmpeg","version":"Unavailable"}}'])
async def test_invalid_baseline_initializes_without_false_updates(tmp_path,monkeypatch,saved):
    state,session,bot,r=setup(tmp_path)
    state.set(updates.STATE_KEY,saved)
    installed(monkeypatch,{'package:aiogram':record('aiogram','3.31.0')})
    async with bot.context():await r.dependency_updates.run()
    assert not session.calls('sendMessage')
    assert updates.saved_versions(state)['package:aiogram']['version']=='3.31.0'
    state.close()


async def test_failed_probe_does_not_overwrite_previous_versions(tmp_path,monkeypatch,caplog):
    state,session,bot,r=setup(tmp_path)
    old={'package:aiogram':record('aiogram','3.30.0')}
    state.set(updates.STATE_KEY,json.dumps(old))
    async def failure():raise RuntimeError('PRIVATE_TOKEN')
    monkeypatch.setattr(updates,'current_versions',failure)
    await r.dependency_updates.run()
    assert updates.saved_versions(state)==old
    assert 'PRIVATE_TOKEN' not in caplog.text and not r.stop.is_set()
    state.close()


async def test_background_notices_do_not_stop_services_and_cancel_on_shutdown(tmp_path,monkeypatch):
    state,session,bot,r=setup(tmp_path)
    started=asyncio.Event();cancelled=asyncio.Event()
    async def notifications():
        started.set()
        try:await asyncio.Event().wait()
        finally:cancelled.set()
    r.dependency_updates.run=notifications
    async def poll():
        await started.wait()
        r.request_stop('shutdown')
    async def idle():await r.stop.wait()
    r.polling=poll;r.scheduler=idle;r.broadcasts.run=idle
    async with bot.context():await asyncio.wait_for(r.run(),3)
    assert cancelled.is_set()
    assert json.loads((tmp_path/'receipt.json').read_text())['ok'] is True
    state.close()


async def test_baseline_is_in_backups_and_stop_skips_pending_notices(tmp_path,monkeypatch):
    state,session,bot,r=setup(tmp_path)
    values={'package:aiogram':record('aiogram','3.31.0')}
    state.set(updates.STATE_KEY,json.dumps(values))
    source=tmp_path/'app';source.mkdir();(source/'bot.py').write_text('# source')
    archive=tmp_path/'backup.zip'
    backup.create_archive(tmp_path,source,archive)
    restored=tmp_path/'restored';restored.mkdir()
    with zipfile.ZipFile(archive) as packed:
        (restored/'state.db').write_bytes(packed.read('state/state.db'))
    copy=State(restored/'state.db')
    assert updates.saved_versions(copy)==values
    copy.close()
    installed(monkeypatch,{'package:aiogram':record('aiogram','3.32.0')})
    r.stop.set()
    await r.dependency_updates.run()
    assert not session.calls('sendMessage') and updates.saved_versions(state)==values
    state.close()


async def test_screenshot_changes_share_one_native_telegram_message(tmp_path,monkeypatch):
    state,session,bot,r=setup(tmp_path)
    previous={'package:playwright':record('playwright','1.63.0'),
              'package:pyee':record('pyee','13.0.1'),
              'tool:chromium':record('Chromium','153.0.8010.12')}
    state.set(updates.STATE_KEY,json.dumps(previous))
    installed(monkeypatch,{'package:playwright':record('playwright','1.64.0'),
        'package:pyee':record('pyee','14.0.0'),'tool:chromium':record('Chromium','156.0.8078.4')})
    async with bot.context():await r.dependency_updates.run()
    calls=session.calls('sendMessage')
    assert len(calls)==1
    assert calls[0]['fields']['chat_id']=='-1004434678187'
    assert calls[0]['fields']['text']=='#update\n\nplaywright: 1.63.0 ➡️ 1.64.0\npyee: 13.0.1 ➡️ 14.0.0\nChromium: 153.0.8010.12 ➡️ 156.0.8078.4'
    state.close()


async def test_long_batches_respect_limit_and_retry_only_failed_lines(tmp_path,monkeypatch):
    state,session,bot,r=setup(tmp_path)
    old={f'package:{index:02}':record('package'+str(index)+'x'*80,'1.'+'a'*140) for index in range(18)}
    current={key:record(value['name'],'2.'+'b'*140) for key,value in old.items()}
    state.set(updates.STATE_KEY,json.dumps(old));installed(monkeypatch,current)
    # Reject the first large message, accept the second
    session.queue('sendMessage',status=403,description='private token never logged')
    async with bot.context():
        await r.dependency_updates.run()
        first=list(session.calls('sendMessage'))
        assert len(first)==2
        for request in first:
            assert len(request['fields']['text'].encode('utf-16-le'))//2<=4096
            assert request['fields']['text'].startswith('#update\n\n')
        saved=updates.saved_versions(state)
        pending={key for key in old if saved[key]['version']==old[key]['version']}
        confirmed=set(old)-pending
        assert pending and confirmed
        await r.dependency_updates.run()
        assert len(session.calls('sendMessage'))==3
        retry=session.calls('sendMessage')[-1]['fields']['text']
        assert all(current[key]['name']+':' in retry for key in pending)
        assert all(current[key]['name']+':' not in retry for key in confirmed)
        assert updates.saved_versions(state)==current
        await r.dependency_updates.run()
        assert len(session.calls('sendMessage'))==3
    state.close()
