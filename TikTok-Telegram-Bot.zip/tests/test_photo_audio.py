"""Photo audio buttons use real aiogram albums and durable delivery receipts."""
import asyncio
import json

import pytest
from aiogram.exceptions import TelegramNetworkError

from state import State
from test_aiogram import callback, message, photo_records, setup


@pytest.mark.asyncio
@pytest.mark.parametrize('count',[1,2,10,11,23])
@pytest.mark.parametrize('document',[False,True])
async def test_photo_audio_off_button_and_owned_audio_reply(tmp_path,count,document):
    state,session,bot,r=setup(tmp_path)
    state.set('audio:1','off')
    state.set('language:1','en')
    jid,_=state.submit(1,-10,77,12,'https://www.tiktok.com/@x/photo/123')
    folder=r.work/'photos';folder.mkdir()
    records=photo_records(folder,count,document)
    for record in records:record['manual_audio']=True
    sizes=[min(10,count-offset) for offset in range(0,count,10)]
    first_ids=[201+100*index for index in range(len(sizes))]
    for size,mid in zip(sizes,first_ids):
        if size>1:
            session.queue('sendMediaGroup',[message(-10,mid+i) for i in range(size)])
        else:
            session.queue('sendDocument' if document else 'sendPhoto',message(-10,mid))
    async with bot.context():
        await r.deliver(jid,records,folder,'Post title','Account','user')
        await r.deliver(jid,records,folder,'Post title','Account','user')
        state.change(jid,status='done')
        row=state.job(jid)
        button_id=201+sizes[0]-1
        assert row['manual_audio'] and row['audio_button_message']==button_id
        assert row['reply_message']==201 and row['photo_reply_message']==first_ids[-1]
        assert not row['audio_button_pending'] and row['in_flight'] is None
        assert len(json.loads(row['sent']))==count
        uploads=[request for request in session.requests
                 if request['api'] in ('sendMediaGroup','sendPhoto','sendDocument')]
        assert [len(request['files']) for request in uploads]==sizes
        assert {file['data'] for request in uploads for file in request['files'].values()}=={
            f'image {index}'.encode() for index in range(count)}
        for index,request in enumerate(uploads):
            fields=request['fields']
            assert fields['message_thread_id']=='12'
            assert json.loads(fields['reply_parameters'])['message_id']==([77,*first_ids[:-1]][index])
            if request['api']=='sendMediaGroup':
                assert 'reply_markup' not in fields
                media=json.loads(fields['media'])
                assert all(item['type']==('document' if document else 'photo') for item in media)
                caption=media[0]['caption']
            else:
                caption=fields['caption']
                assert ('reply_markup' in fields)==(index==0)
            assert caption==(r.media_caption('Post title','Account','user') if index==0
                             else '@TikTokdownloaderbestbot')
        edits=session.calls('editMessageReplyMarkup')
        assert len(edits)==int(count>1)
        keyboard=edits[0]['fields'] if edits else uploads[0]['fields']
        if edits:assert keyboard['message_id']==str(button_id)
        assert json.loads(keyboard['reply_markup'])=={'inline_keyboard':[[{
            'text':'Extract audio','callback_data':f'extract:{jid}'}]]}
        assert not session.calls('sendAudio')
        state.close();state=State(tmp_path/'state.db');r.state=state
        for user,chat,mid in ((2,-10,button_id),(1,-20,button_id),(1,-10,button_id+1)):
            await r.handle(callback(bot,f'extract:{jid}',user=user,chat=chat,mid=mid))
            assert not state.outstanding(1) and not state.outstanding(2)
        if count>1:
            await r.handle(callback(bot,f'extract:{jid}',chat=-10,mid=201))
            assert not state.outstanding(1)
        query=callback(bot,f'extract:{jid}',chat=-10,mid=button_id)
        await r.handle(query);await r.handle(query)
        audio_job=state.outstanding(1)[0]
        assert len(state.outstanding(1))==1 and audio_job['audio_only']
        assert audio_job['message_id']==201 and audio_job['thread_id']==12
        (folder/'sound.mp3').write_bytes(b'TikTok soundtrack')
        await r.deliver(audio_job['id'],[{'file':'sound.mp3','kind':'audio','sha256':'audio',
                                       'reply_to_source':True}],folder)
        state.change(audio_job['id'],status='done')
        await r.handle(query)
        assert not state.outstanding(1)
        audio=session.calls('sendAudio')
        assert len(audio)==1 and audio[0]['fields']['message_thread_id']=='12'
        assert audio[0]['fields']['caption']=='@TikTokdownloaderbestbot'
        assert json.loads(audio[0]['fields']['reply_parameters'])['message_id']==201
    state.close()


@pytest.mark.asyncio
async def test_album_button_recovers_after_receipt_before_edit(tmp_path):
    state,session,bot,r=setup(tmp_path)
    jid,_=state.submit(1,-10,77,12,'https://www.tiktok.com/@x/photo/123')
    state.change(jid,status='running')
    folder=r.work/'photos';folder.mkdir()
    records=photo_records(folder,13)
    for record in records:record['manual_audio']=True
    def interrupted(method):
        r.stop.set()
        return {'ok':True,'result':[message(-10,201+i) for i in range(10)]}
    session.responses['sendMediaGroup'].append((200,interrupted))
    async with bot.context():
        with pytest.raises(asyncio.CancelledError):await r.deliver(jid,records,folder,'Post title')
        row=state.job(jid)
        assert len(json.loads(row['sent']))==10 and row['in_flight'] is None
        assert row['audio_button_pending'] and row['audio_button_message']==210
        assert not session.calls('editMessageReplyMarkup')
        state.close();state=State(tmp_path/'state.db');r.state=state
        state.recover();r.stop.clear()
        assert state.job(jid)['status']=='ready'
        session.queue('sendMediaGroup',[message(-10,301+i) for i in range(3)])
        await r.deliver(jid,records,folder,'Post title')
        assert len(session.calls('sendMediaGroup'))==2
        assert len(session.calls('editMessageReplyMarkup'))==1
        edit=session.calls('editMessageReplyMarkup')[0]
        assert edit['fields']['message_id']=='210'
        second=session.calls('sendMediaGroup')[1]['fields']
        assert json.loads(second['reply_parameters'])['message_id']==201
        assert json.loads(second['media'])[0]['caption']=='@TikTokdownloaderbestbot'
        row=state.job(jid)
        assert not row['audio_button_pending'] and len(json.loads(row['sent']))==13
        assert row['reply_message']==201 and row['photo_reply_message']==301
    state.close()


@pytest.mark.asyncio
@pytest.mark.parametrize('retry',['success','already_applied'])
async def test_unconfirmed_button_edit_keeps_confirmed_album(tmp_path,retry):
    state,session,bot,r=setup(tmp_path)
    jid,_=state.submit(1,-10,77,12,'https://www.tiktok.com/@x/photo/123')
    folder=r.work/'photos';folder.mkdir()
    records=photo_records(folder,2)
    for record in records:record['manual_audio']=True
    session.queue('sendMediaGroup',[message(-10,201),message(-10,202)])
    def interrupted(method):raise TelegramNetworkError(method=method,message='response interrupted')
    session.responses['editMessageReplyMarkup'].append((200,interrupted))
    async with bot.context():
        await r.deliver(jid,records,folder)
        row=state.job(jid)
        assert row['audio_button_pending'] and row['in_flight'] is None
        assert len(json.loads(row['sent']))==2 and row['audio_button_message']==202
        if retry=='already_applied':
            session.queue('editMessageReplyMarkup',status=400,description='Bad Request: message is not modified')
        await r.deliver(jid,records,folder)
        assert not state.job(jid)['audio_button_pending']
    assert len(session.calls('sendMediaGroup'))==1
    assert len(session.calls('editMessageReplyMarkup'))==2
    state.close()


@pytest.mark.asyncio
async def test_startup_repairs_completed_album_button(tmp_path):
    state,session,bot,r=setup(tmp_path)
    state.set('language:7','en')
    jid,_=state.submit(1,-10,77,12,'https://www.tiktok.com/@x/photo/123')
    state.change(jid,status='done',manual_audio=1,reply_message=201,
                 photo_reply_message=201,audio_button_message=210,audio_button_pending=1)
    session.queue('getUpdates',[{'update_id':43,'message':message(7,user=7,text='/shutdown')}])
    async def idle():await r.stop.wait()
    r.scheduler=idle
    async with bot.context():await asyncio.wait_for(r.run(),3)
    assert session.closed and not state.job(jid)['audio_button_pending']
    assert session.calls('editMessageReplyMarkup')[0]['fields']['message_id']=='210'
    assert not session.calls('sendMediaGroup') and not session.calls('sendPhoto')
    state.close()


@pytest.mark.asyncio
async def test_existing_database_and_video_button_remain_usable(tmp_path):
    state,session,bot,r=setup(tmp_path)
    jid,_=state.submit(1,-10,77,12,'https://www.tiktok.com/@x/video/123')
    state.change(jid,status='done',manual_audio=1,reply_message=88)
    state.set('language:1','fa');state.set('audio:1','off')
    state.db.execute('ALTER TABLE jobs DROP COLUMN audio_button_message')
    state.db.execute('ALTER TABLE jobs DROP COLUMN audio_button_pending')
    state.db.commit();state.close()
    state=State(tmp_path/'state.db');r.state=state
    row=state.job(jid)
    assert row['audio_button_message'] is None and row['audio_button_pending']==0
    assert row['manual_audio'] and row['reply_message']==88 and row['status']=='done'
    assert state.get('language:1')=='fa' and state.get('audio:1')=='off'
    async with bot.context():await r.handle(callback(bot,f'extract:{jid}',chat=-10,mid=88))
    audio=state.outstanding(1)[0]
    assert audio['audio_only'] and audio['message_id']==88 and audio['thread_id']==12
    state.close()
