"""Photo audio buttons use real aiogram albums and durable delivery receipts."""
import asyncio
import json

import pytest
from aiogram.exceptions import TelegramNetworkError

from bot import Runner
from state import State
from test_aiogram import callback, message, photo_records, setup


@pytest.mark.asyncio
@pytest.mark.parametrize('count',[1,2,10,11,23])
@pytest.mark.parametrize('document',[False,True])
async def test_photo_audio_off_button_and_owned_audio_reply(tmp_path,count,document):
    state,session,bot,r=setup(tmp_path)
    state.set('audio:1','off')
    state.set('language:1','en')
    jid,_=state.submit(1,-10,77,12,'https://www.tiktok.com/@x/photo/123')
    folder=r.work/'photos';folder.mkdir()
    records=photo_records(folder,count,document)
    for record in records:record['manual_audio']=True
    sizes=[min(10,count-offset) for offset in range(0,count,10)]
    first_ids=[201+100*index for index in range(len(sizes))]
    for size,mid in zip(sizes,first_ids):
        if size>1:
            session.queue('sendMediaGroup',[message(-10,mid+i) for i in range(size)])
        else:
            session.queue('sendDocument' if document else 'sendPhoto',message(-10,mid))
    session.queue('sendMessage',message(-10,90))
    if count>1:session.queue('sendMessage',message(-10,900))
    async with bot.context():
        await r.deliver(jid,records,folder,'Post title','Account','user')
        await r.deliver(jid,records,folder,'Post title','Account','user')
        state.change(jid,status='done')
        row=state.job(jid)
        button_id=900 if count>1 else 201
        assert row['manual_audio'] and row['audio_button_message']==button_id
        assert row['reply_message']==201 and row['photo_reply_message']==first_ids[-1]
        assert not row['audio_button_pending'] and row['in_flight'] is None
        assert len(json.loads(row['sent']))==count
        uploads=[request for request in session.requests
                 if request['api'] in ('sendMediaGroup','sendPhoto','sendDocument')]
        assert [len(request['files']) for request in uploads]==sizes
        assert {file['data'] for request in uploads for file in request['files'].values()}=={
            f'image {index}'.encode() for index in range(count)}
        for index,request in enumerate(uploads):
            fields=request['fields']
            assert fields['message_thread_id']=='12'
            assert json.loads(fields['reply_parameters'])['message_id']==([77,*first_ids[:-1]][index])
            if request['api']=='sendMediaGroup':
                assert 'reply_markup' not in fields
                media=json.loads(fields['media'])
                assert all(item['type']==('document' if document else 'photo') for item in media)
                caption=media[0]['caption']
            else:
                caption=fields['caption']
                assert ('reply_markup' in fields)==(index==0)
            assert caption==(r.media_caption('Post title','Account','user') if index==0
                             else '@TikTokdownloaderbestbot')
        assert not session.calls('editMessageReplyMarkup')
        controls=[request for request in session.calls('sendMessage')
                  if 'reply_markup' in request['fields']]
        assert len(controls)==int(count>1)
        keyboard=controls[0]['fields'] if controls else uploads[0]['fields']
        if controls:
            assert keyboard['text']=='@TikTokdownloaderbestbot'
            assert keyboard['chat_id']=='-10' and keyboard['message_thread_id']=='12'
            assert json.loads(keyboard['reply_parameters'])=={
                'message_id':201,'allow_sending_without_reply':True}
        assert json.loads(keyboard['reply_markup'])=={'inline_keyboard':[[{
            'text':'Extract audio','callback_data':f'extract:{jid}'}]]}
        assert not session.calls('sendAudio')
        state.close();state=State(tmp_path/'state.db');r.state=state
        for user,chat,mid in ((2,-10,button_id),(1,-20,button_id),(1,-10,button_id+1)):
            await r.handle(callback(bot,f'extract:{jid}',user=user,chat=chat,mid=mid))
            assert not state.outstanding(1) and not state.outstanding(2)
        if count>1:
            await r.handle(callback(bot,f'extract:{jid}',chat=-10,mid=201))
            assert not state.outstanding(1)
        query=callback(bot,f'extract:{jid}',chat=-10,mid=button_id)
        await r.handle(query);await r.handle(query)
        audio_job=state.outstanding(1)[0]
        assert len(state.outstanding(1))==1 and audio_job['audio_only']
        assert audio_job['message_id']==201 and audio_job['thread_id']==12
        (folder/'sound.mp3').write_bytes(b'TikTok soundtrack')
        await r.deliver(audio_job['id'],[{'file':'sound.mp3','kind':'audio','sha256':'audio',
                                       'reply_to_source':True}],folder)
        state.change(audio_job['id'],status='done')
        await r.handle(query)
        assert not state.outstanding(1)
        audio=session.calls('sendAudio')
        assert len(audio)==1 and audio[0]['fields']['message_thread_id']=='12'
        assert audio[0]['fields']['caption']=='@TikTokdownloaderbestbot'
        assert json.loads(audio[0]['fields']['reply_parameters'])['message_id']==201
    state.close()


@pytest.mark.asyncio
async def test_album_button_recovers_after_receipt_before_reply(tmp_path):
    state,session,bot,r=setup(tmp_path)
    jid,_=state.submit(1,-10,77,12,'https://www.tiktok.com/@x/photo/123')
    state.change(jid,status='running')
    folder=r.work/'photos';folder.mkdir()
    records=photo_records(folder,13)
    for record in records:record['manual_audio']=True
    def interrupted(method):
        r.stop.set()
        return {'ok':True,'result':[message(-10,201+i) for i in range(10)]}
    session.responses['sendMediaGroup'].append((200,interrupted))
    async with bot.context():
        with pytest.raises(asyncio.CancelledError):await r.deliver(jid,records,folder,'Post title')
        row=state.job(jid)
        assert len(json.loads(row['sent']))==10 and row['in_flight'] is None
        assert row['audio_button_pending'] and row['audio_button_message'] is None
        assert not row['audio_button_in_flight']
        assert not session.calls('editMessageReplyMarkup')
        state.close();state=State(tmp_path/'state.db');r.state=state
        state.recover();r.stop.clear()
        assert state.job(jid)['status']=='ready'
        session.queue('sendMediaGroup',[message(-10,301+i) for i in range(3)])
        session.queue('sendMessage',message(-10,900))
        await r.deliver(jid,records,folder,'Post title')
        assert len(session.calls('sendMediaGroup'))==2
        assert not session.calls('editMessageReplyMarkup')
        controls=[request for request in session.calls('sendMessage')
                  if 'reply_markup' in request['fields']]
        assert len(controls)==1 and state.job(jid)['audio_button_message']==900
        second=session.calls('sendMediaGroup')[1]['fields']
        assert json.loads(second['reply_parameters'])['message_id']==201
        assert json.loads(second['media'])[0]['caption']=='@TikTokdownloaderbestbot'
        row=state.job(jid)
        assert not row['audio_button_pending'] and len(json.loads(row['sent']))==13
        assert row['reply_message']==201 and row['photo_reply_message']==301
    state.close()


@pytest.mark.asyncio
@pytest.mark.parametrize('status',[400,403,413])
async def test_rejected_button_reply_retries_without_resending_album(tmp_path,status):
    state,session,bot,r=setup(tmp_path)
    jid,_=state.submit(1,-10,77,12,'https://www.tiktok.com/@x/photo/123')
    state.change(jid,status_message=90)
    folder=r.work/'photos';folder.mkdir()
    records=photo_records(folder,2)
    for record in records:record['manual_audio']=True
    session.queue('sendMediaGroup',[message(-10,201),message(-10,202)])
    session.queue('sendMessage',status=status,description='controlled rejection')
    async with bot.context():
        await r.deliver(jid,records,folder)
        row=state.job(jid)
        assert row['audio_button_pending'] and row['in_flight'] is None
        assert len(json.loads(row['sent']))==2 and row['audio_button_message'] is None
        assert not row['audio_button_in_flight']
        session.queue('sendMessage',message(-10,900))
        await r.deliver(jid,records,folder)
        assert not state.job(jid)['audio_button_pending']
        assert state.job(jid)['audio_button_message']==900
    assert len(session.calls('sendMediaGroup'))==1
    assert len(session.calls('sendMessage'))==2 and not session.calls('editMessageReplyMarkup')
    state.close()


@pytest.mark.asyncio
@pytest.mark.parametrize('failure',['network','server','decode'])
async def test_unconfirmed_button_reply_is_not_repeated_and_click_confirms_it(tmp_path,failure):
    state,session,bot,r=setup(tmp_path)
    state.set('language:1','en')
    jid,_=state.submit(1,-10,77,12,'https://www.tiktok.com/@x/photo/123')
    state.change(jid,status_message=90)
    folder=r.work/'photos';folder.mkdir()
    records=photo_records(folder,2)
    for record in records:record['manual_audio']=True
    session.queue('sendMediaGroup',[message(-10,201),message(-10,202)])
    if failure=='network':
        def interrupted(method):raise TelegramNetworkError(method=method,message='response interrupted')
        session.responses['sendMessage'].append((200,interrupted))
    elif failure=='server':
        session.queue('sendMessage',status=500,description='Internal Server Error')
    else:
        session.responses['sendMessage'].append((200,'response interrupted'))
    async with bot.context():
        await r.deliver(jid,records,folder)
        state.change(jid,status='done')
        row=state.job(jid)
        assert row['audio_button_pending'] and row['audio_button_in_flight']
        assert row['in_flight'] is None and len(json.loads(row['sent']))==2
        state.close();state=State(tmp_path/'state.db');r.state=state
        state.recover()
        await r.deliver(jid,records,folder)
        assert len(session.calls('sendMessage'))==1 and len(session.calls('sendMediaGroup'))==1
        for values in ({'user':2},{'chat':-20},{'thread':13},{'anchor':202}):
            await r.handle(callback(bot,f'extract:{jid}',user=values.get('user',1),
                chat=values.get('chat',-10),mid=900,
                message_thread_id=values.get('thread',12),
                reply_to_message=message(-10,values.get('anchor',201))))
            assert not state.outstanding(1) and not state.outstanding(2)
            assert state.job(jid)['audio_button_in_flight']
        query=callback(bot,f'extract:{jid}',chat=-10,mid=900,message_thread_id=12,
                       reply_to_message=message(-10,201))
        await r.handle(query);await r.handle(query)
        row=state.job(jid)
        assert row['audio_button_message']==900
        assert not row['audio_button_pending'] and not row['audio_button_in_flight']
        audio=state.outstanding(1)
        assert len(audio)==1 and audio[0]['audio_only'] and audio[0]['message_id']==201
    state.close()


@pytest.mark.asyncio
@pytest.mark.parametrize('pending',[0,1])
async def test_startup_repairs_older_completed_album_button(tmp_path,pending):
    state,session,bot,r=setup(tmp_path)
    state.set('language:7','en')
    jid,_=state.submit(1,-10,77,12,'https://www.tiktok.com/@x/photo/123')
    state.change(jid,status='done',manual_audio=1,reply_message=201,
                 photo_reply_message=201,audio_button_message=210,audio_button_pending=pending)
    state.db.execute('ALTER TABLE jobs DROP COLUMN audio_button_in_flight')
    state.db.commit();state.close()
    state=State(tmp_path/'state.db');r.state=state
    assert state.job(jid)['audio_button_pending'] and state.job(jid)['audio_button_message'] is None
    restored=Runner(state,bot,tmp_path,7,99)
    restored.api=r.api;r=restored
    session.queue('sendMessage',message(-10,900))
    session.queue('getUpdates',[{'update_id':43,'message':message(7,user=7,text='/shutdown')}])
    async def idle():await r.stop.wait()
    r.scheduler=idle
    async with bot.context():await asyncio.wait_for(r.run(),3)
    assert session.closed and not state.job(jid)['audio_button_pending']
    assert state.job(jid)['audio_button_message']==900
    controls=[request for request in session.calls('sendMessage') if 'reply_markup' in request['fields']]
    assert len(controls)==1 and json.loads(controls[0]['fields']['reply_parameters'])['message_id']==201
    assert not session.calls('editMessageReplyMarkup')
    assert not session.calls('sendMediaGroup') and not session.calls('sendPhoto')
    state.close()


@pytest.mark.asyncio
@pytest.mark.parametrize('phase',['pacing','rate_limit'])
async def test_button_cancel_before_send_or_after_rate_rejection_can_retry(tmp_path,phase,monkeypatch):
    state,session,bot,r=setup(tmp_path)
    jid,_=state.submit(1,-10,77,12,'https://www.tiktok.com/@x/photo/123')
    state.change(jid,status='done',manual_audio=1,reply_message=201,audio_button_pending=1)
    if phase=='pacing':
        async def paced(chat,operation):raise asyncio.CancelledError()
        r.api=paced
    else:
        r.api=Runner.api.__get__(r)
        session.queue('sendMessage',status=429,description='Too Many Requests',parameters={'retry_after':2})
        async def interrupted_sleep(seconds):
            if seconds:raise asyncio.CancelledError()
        monkeypatch.setattr(asyncio,'sleep',interrupted_sleep)
    async with bot.context():
        with pytest.raises(asyncio.CancelledError):await r.install_audio_button(jid)
        row=state.job(jid)
        assert row['audio_button_pending'] and not row['audio_button_in_flight']
        assert len(session.calls('sendMessage'))==int(phase=='rate_limit')
        async def fast(chat,operation):return await operation()
        r.api=fast
        session.queue('sendMessage',message(-10,900))
        await r.install_audio_button(jid)
        assert state.job(jid)['audio_button_message']==900
        assert not state.job(jid)['audio_button_pending']
    state.close()


@pytest.mark.asyncio
@pytest.mark.parametrize('failure',['rejected','unconfirmed'])
async def test_button_failure_keeps_media_done_and_shows_notice(tmp_path,failure):
    state,session,bot,r=setup(tmp_path)
    state.set('language:1','en')
    jid,_=state.submit(1,-10,77,12,'https://www.tiktok.com/@x/photo/123')
    state.change(jid,status='running')
    async def download(row,folder):
        folder.mkdir()
        records=photo_records(folder,2)
        for record in records:record['manual_audio']=True
        return {'ok':True,'media':records}
    r.worker=download
    session.queue('sendMessage',message(-10,90))
    if failure=='rejected':
        session.queue('sendMessage',status=400,description='controlled rejection')
    else:
        def interrupted(method):raise TelegramNetworkError(method=method,message='response interrupted')
        session.responses['sendMessage'].append((200,interrupted))
    async with bot.context():await r.run_job(jid)
    row=state.job(jid)
    assert row['status']=='done' and row['in_flight'] is None and len(json.loads(row['sent']))==2
    assert not session.calls('deleteMessage')
    notice=session.calls('editMessageText')[-1]['fields']['text']
    assert notice==('Could not add the audio button yet, it will be retried after restart'
                    if failure=='rejected' else
                    'Telegram did not confirm the audio button, check the chat before sending the link again')
    state.close()


@pytest.mark.asyncio
async def test_existing_database_and_video_button_remain_usable(tmp_path):
    state,session,bot,r=setup(tmp_path)
    jid,_=state.submit(1,-10,77,12,'https://www.tiktok.com/@x/video/123')
    state.change(jid,status='done',manual_audio=1,reply_message=88)
    state.set('language:1','fa');state.set('audio:1','off')
    state.db.execute('ALTER TABLE jobs DROP COLUMN audio_button_message')
    state.db.execute('ALTER TABLE jobs DROP COLUMN audio_button_pending')
    state.db.commit();state.close()
    state=State(tmp_path/'state.db');r.state=state
    row=state.job(jid)
    assert row['audio_button_message'] is None and row['audio_button_pending']==0
    assert row['manual_audio'] and row['reply_message']==88 and row['status']=='done'
    assert state.get('language:1')=='fa' and state.get('audio:1')=='off'
    async with bot.context():await r.handle(callback(bot,f'extract:{jid}',chat=-10,mid=88))
    audio=state.outstanding(1)[0]
    assert audio['audio_only'] and audio['message_id']==88 and audio['thread_id']==12
    state.close()
