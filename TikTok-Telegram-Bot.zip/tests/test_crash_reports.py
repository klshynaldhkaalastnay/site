import io
import json
import logging
import os
from pathlib import Path
import subprocess
import sys
import threading

import pytest
import yaml
from aiogram.exceptions import TelegramConflictError
from aiogram.methods import GetUpdates

import crash_reports as reports
import telegram_logs as logs

PROJECT = Path(reports.__file__).parent


def test_exception_locations_exclude_message_source_locals_and_method_data(monkeypatch):
    monkeypatch.setenv('TELEGRAM_BOT_TOKEN', '123456789:abcdefghijklmnopqrstuvwxyz12345')
    private_local = 'never-log-this-local-or-message'
    try:
        raise ValueError(private_local)
    except ValueError:
        try:
            raise TelegramConflictError(method=GetUpdates(offset=1234), message=private_local)
        except TelegramConflictError as exc:
            details = reports.exception_details(exc)
    assert 'TelegramConflictError' in details and 'ValueError' in details
    assert 'test_crash_reports.py:' in details
    assert 'Another application is polling' in details
    assert private_local not in details
    assert '1234' not in details
    assert 'raise TelegramConflictError(' not in details


def test_redacts_captions_urls_headers_and_credentials(monkeypatch):
    monkeypatch.setenv('TELEGRAM_BOT_TOKEN', '123456789:abcdefghijklmnopqrstuvwxyz12345')
    monkeypatch.setenv('APP_ZIP_URL', 'https://files.example/bot.zip?access=private')
    calls = []
    monkeypatch.setattr(logs.urllib.request, 'urlopen',
                        lambda request, **kwargs: calls.append(request) or io.BytesIO(b'{"ok":true}'))
    private = ('https://api.telegram.org/bot123456789:abcdefghijklmnopqrstuvwxyz12345/sendMessage\n'
               'Cookie: session=hidden-cookie\nAuthorization: Bearer private-auth\n'
               'https://user:private-pass@example.test/a?X-Amz-Signature=hidden-signature&key=private-key\n'
               'https://files.example/bot.zip?access=private')
    assert logs.send_document(private.encode(), 'crash.txt', private)
    for secret in ('hidden-cookie', 'private-auth', 'private-pass', 'hidden-signature',
                   'private-key', 'access=private', 'abcdefghijklmnopqrstuvwxyz12345'):
        assert secret.encode() not in calls[0].data


def test_native_bot_entrypoint_conflict_reports_crash_and_preserves_failure(tmp_path, monkeypatch):
    monkeypatch.setenv('PYTHONPATH', str(PROJECT))
    monkeypatch.setenv('RUNNER_TEMP', str(tmp_path))
    monkeypatch.setenv('GITHUB_RUN_ID', '123')
    monkeypatch.setenv('GITHUB_RUN_ATTEMPT', '2')
    monkeypatch.setenv('GITHUB_REPOSITORY', 'owner/repo')
    monkeypatch.setenv('TELEGRAM_BOT_TOKEN', '123456789:abcdefghijklmnopqrstuvwxyz12345')
    child = tmp_path/'conflict.py'
    child.write_text(
        "import asyncio, runpy\n"
        "from aiogram.exceptions import TelegramConflictError\n"
        "from aiogram.methods import GetUpdates\n"
        "def fail(coro):\n"
        "    coro.close()\n"
        "    raise TelegramConflictError(method=GetUpdates(), message='private-response-body')\n"
        "asyncio.run=fail\n"
        f"runpy.run_path({str(PROJECT/'bot.py')!r}, run_name='__main__')\n")
    sent = []
    monkeypatch.setattr(logs, 'send_document', lambda *args: sent.append(args) or True)
    assert logs.run_bot(str(child)) == 1
    crashes = [call for call in sent if call[2].startswith('#crash')]
    assert len(crashes) == 1
    data, filename, caption = crashes[0]
    assert 'TelegramConflictError' in caption and 'Exit code: 1' in caption
    assert b'Another application is polling' in data
    assert b'bot.py:' in data and b'conflict.py:' in data
    assert b'private-response-body' not in data
    assert 'https://github.com/owner/repo/actions/runs/123' in caption
    assert logs.crash_reported()
    assert not (tmp_path/'receipt.json').exists()
    # The final workflow step does not post a duplicate alert for this session.
    monkeypatch.setenv('WORKFLOW_STATUS', 'failure')
    monkeypatch.setenv('WORKFLOW_STEPS', json.dumps({'session': {'outcome': 'failure'}}))
    logs.report_workflow(b'diagnostics')
    assert len([call for call in sent if call[2].startswith(('#crash', '#error'))]) == 1


def test_runtime_errors_upload_before_exit_without_blocking_child(tmp_path, monkeypatch):
    monkeypatch.setenv('PYTHONPATH', str(PROJECT))
    monkeypatch.setattr(logs, 'ERROR_INTERVAL_SECONDS', .02)
    child = tmp_path/'runtime.py'
    child.write_text(
        "import logging,time\nfrom crash_reports import configure_logging\n"
        "configure_logging()\nprint('started',flush=True)\n"
        "logging.error('Job 123 could not finish')\nlogging.error('Job 456 could not finish')\n"
        "time.sleep(.2)\nprint('finished',flush=True)\n")
    sent = []
    monkeypatch.setattr(logs, 'send_document',
                        lambda *args: sent.append((args, threading.current_thread().name)) or True)
    assert logs.run_bot(str(child)) == 0
    alerts = [(call, thread) for call, thread in sent if call[2].startswith('#error')]
    assert len(alerts) == 1
    (data, _, caption), thread = alerts[0]
    assert '×2' in caption and b'Occurrences: 2' in data
    assert b'finished' not in data
    assert thread != threading.current_thread().name
    assert not any(call[2].startswith('#crash') for call, _ in sent)


def test_crash_context_survives_hourly_acknowledgement(tmp_path, monkeypatch):
    child = tmp_path/'late.py'
    child.write_text("import time\nprint('startup-context',flush=True)\ntime.sleep(.16)\nraise SystemExit(7)\n")
    sent = []
    monkeypatch.setattr(logs, 'send_document', lambda *args: sent.append(args) or True)
    assert logs.run_bot(str(child), interval=.04) == 7
    assert any('hourly' in call[1] and b'startup-context' in call[0] for call in sent)
    crash = next(call for call in sent if call[2].startswith('#crash'))
    assert b'startup-context' in crash[0]
    assert 'Exit code: 7' in crash[2]


def test_failed_report_does_not_hide_original_exit_or_mark_delivered(tmp_path, monkeypatch):
    monkeypatch.setenv('RUNNER_TEMP', str(tmp_path))
    child = tmp_path/'failure.py'
    child.write_text('raise SystemExit(9)\n')
    monkeypatch.setattr(logs, 'send_document', lambda *args: False)
    assert logs.run_bot(str(child)) == 9
    assert not logs.crash_reported()


def test_crash_does_not_wait_for_in_progress_hourly_upload(tmp_path, monkeypatch):
    child = tmp_path/'crash_during_upload.py'
    child.write_text("import time\nprint('started',flush=True)\ntime.sleep(.12)\nraise SystemExit(8)\n")
    hourly_started, crash_sent = threading.Event(), threading.Event()
    failures = []
    def upload(data, filename, caption):
        if 'hourly' in filename:
            hourly_started.set()
            if not crash_sent.wait(2):
                failures.append('Hourly upload delayed the crash report')
        elif caption.startswith('#crash'):
            crash_sent.set()
        return True
    monkeypatch.setattr(logs, 'send_document', upload)
    assert logs.run_bot(str(child), interval=.02) == 8
    assert hourly_started.is_set() and crash_sent.is_set()
    assert not failures


def test_killed_process_reports_signal_exit_code(tmp_path, monkeypatch):
    child = tmp_path/'killed.py'
    child.write_text('import os,signal\nos.kill(os.getpid(),signal.SIGKILL)\n')
    sent = []
    monkeypatch.setattr(logs, 'send_document', lambda *args: sent.append(args) or True)
    assert logs.run_bot(str(child)) == 137
    assert 'Exit code: 137' in sent[0][2]


def test_spawn_failure_reports_safely_and_returns_failure(monkeypatch):
    def fail(*args, **kwargs):
        raise OSError(13, 'private-spawn-message')
    sent = []
    monkeypatch.setattr(logs.subprocess, 'Popen', fail)
    monkeypatch.setattr(logs, 'send_document', lambda *args: sent.append(args) or True)
    assert logs.run_bot('unused.py') == 1
    assert b'PermissionError' in sent[0][0] and b'OS error number: 13' in sent[0][0]
    assert b'private-spawn-message' not in sent[0][0]


def test_normal_exit_has_no_crash_report(tmp_path, monkeypatch):
    child = tmp_path/'shutdown.py'
    child.write_text("print('Progress saved, session ended with shutdown')\n")
    sent = []
    monkeypatch.setattr(logs, 'send_document', lambda *args: sent.append(args) or True)
    assert logs.run_bot(str(child)) == 0
    assert not any(call[2].startswith(('#crash', '#error')) for call in sent)


def test_error_group_retries_throttles_and_keeps_concurrent_entries(monkeypatch):
    context = logs.LogBuffer()
    issues = logs.IssueBuffer(context)
    event = {'title': 'Job 1 ended unexpectedly', 'kind': 'error', 'details': 'ValueError'}
    issues.append(event)
    sent = []
    monkeypatch.setattr(logs.time, 'monotonic', lambda: 1000)
    monkeypatch.setattr(logs, 'send_document', lambda *args: False)
    issues.flush()
    assert len(issues.pending) == 1 and not issues.sent
    def upload(*args):
        issues.append(dict(event, title='Job 2 ended unexpectedly'))
        sent.append(args)
        return True
    monkeypatch.setattr(logs, 'send_document', upload)
    issues.flush()
    assert next(iter(issues.pending.values()))['count'] == 1
    issues.flush()
    assert len(sent) == 1
    monkeypatch.setattr(logs, 'send_document', lambda *args: sent.append(args) or True)
    issues.flush(final=True)
    assert len(sent) == 2 and not issues.pending


def test_runtime_error_groups_are_bounded():
    issues = logs.IssueBuffer(logs.LogBuffer())
    for i in range(200):
        issues.append({'title': f'failure {i}', 'details': '', 'kind': 'error'})
    assert len(issues.pending) <= 41
    assert sum(value['count'] for value in issues.pending.values()) == 200


def test_setup_failure_and_cancellation_ignore_step_outputs(monkeypatch):
    monkeypatch.setenv('GITHUB_REPOSITORY', 'owner/repo')
    monkeypatch.setenv('GITHUB_RUN_ID', '42')
    monkeypatch.setenv('WORKFLOW_STATUS', 'failure')
    monkeypatch.setenv('WORKFLOW_STEPS', json.dumps({
        'dependencies': {'outcome': 'failure', 'outputs': {'credential': 'never-copy-this-value'}},
        'session': {'outcome': 'skipped'},
    }))
    sent = []
    monkeypatch.setattr(logs, 'send_document', lambda *args: sent.append(args) or True)
    logs.report_workflow(b'aiogram: not installed\n')
    assert sent[0][2].startswith('#error')
    assert 'dependencies: failure' in sent[0][2]
    assert b'never-copy-this-value' not in sent[0][0]
    assert b'aiogram: not installed' in sent[0][0]
    monkeypatch.setenv('WORKFLOW_STATUS', 'cancelled')
    monkeypatch.setenv('WORKFLOW_STEPS', '{"session":{"outcome":"cancelled"}}')
    logs.report_workflow(b'diagnostics')
    assert sent[-1][2].startswith('#warning')


def test_workflow_reports_later_failure_even_after_confirmed_crash(tmp_path, monkeypatch):
    monkeypatch.setenv('RUNNER_TEMP', str(tmp_path))
    monkeypatch.setenv('WORKFLOW_STATUS', 'failure')
    monkeypatch.setenv('WORKFLOW_STEPS', '{"session":{"outcome":"failure"},"write_sanitized_diagnostics":{"outcome":"failure"}}')
    sent = []
    monkeypatch.setattr(logs, 'send_document', lambda *args: sent.append(args) or True)
    logs.report_crash(1, logs.LogBuffer())
    logs.report_workflow(b'diagnostics')
    assert len(sent) == 2
    assert b'write_sanitized_diagnostics: failure' in sent[-1][0]


def test_diagnostics_failure_still_reports_workflow_failure(tmp_path, monkeypatch):
    monkeypatch.setenv('WORKFLOW_STATUS', 'failure')
    monkeypatch.setenv('WORKFLOW_STEPS', '{"write_sanitized_diagnostics":{"outcome":"failure"}}')
    monkeypatch.setattr(sys, 'argv', ['telegram_logs.py', 'diagnostics', str(tmp_path/'missing.txt')])
    sent = []
    monkeypatch.setattr(logs, 'send_document', lambda *args: sent.append(args) or True)
    logs.main()
    assert sent[0][2].startswith('#error')
    assert b'Diagnostics file was unavailable' in sent[0][0]


def test_embedded_reporters_run_without_site_packages_and_cover_all_steps(tmp_path):
    steps = yaml.safe_load((PROJECT/'.github/workflows/tik.yml').read_text())['jobs']['bot']['steps']
    assert all(step.get('id') for step in steps)
    env = dict(os.environ, RUNNER_TEMP=str(tmp_path))
    subprocess.run(['bash', '-e', '-c', steps[0]['run']], check=True, env=env)
    for name in ('crash_reports.py', 'telegram_logs.py'):
        assert (tmp_path/name).read_bytes() == (PROJECT/name).read_bytes()
    output = subprocess.check_output([sys.executable, '-S', '-c',
                                      'import telegram_logs; print(telegram_logs.CHAT_ID)'],
                                     cwd=tmp_path, env=dict(env, PYTHONPATH=''))
    assert output.strip() == b'-1004434678187'
    assert steps[-1]['env']['WORKFLOW_STATUS'] == '${{ job.status }}'
    assert steps[-1]['env']['WORKFLOW_STEPS'] == '${{ toJSON(steps) }}'
    assert steps[-1]['if'] == 'always()' and steps[-1]['continue-on-error'] is True
