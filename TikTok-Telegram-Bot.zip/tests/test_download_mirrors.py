import asyncio
import base64
from hashlib import sha256
from html import unescape
import json
import re

import aiohttp
from aiohttp import web
import pytest

from common import BOT_ATTRIBUTION
import download_mirrors as mirrors
from test_aiogram import callback, message, photo_records, setup
from test_send_files import video_record


POST_ID = '1234567890'
URL = 'https://www.tiktok.com/@tester/video/'+POST_ID
ONLY = 'https://onlyfiles.com/Test'


def visible(caption):
    return unescape(re.sub(r'<[^>]+>','',caption))


@pytest.mark.asyncio
@pytest.mark.parametrize('kind,photo_count',[('video',0),('photo',1),('photo',11)])
async def test_opt_in_sends_all_telegram_files_before_editing_each_caption(tmp_path,monkeypatch,kind,photo_count):
    state,session,bot,r = setup(tmp_path)
    state.set('language:1','en')
    assert r.settings_view(1,'mirrors')[1].inline_keyboard[1][0].text=='✓ Off with no button'
    async with bot.context():
        await r.handle(callback(bot,'settings:1:mirrors-on',user=2))
        assert state.get('mirrors:1') is None
        await r.handle(callback(bot,'settings:1:mirrors-on'))
        assert r.settings_view(1,'mirrors')[1].inline_keyboard[0][0].text=='✓ On'
        state.set('caption:1','on')
        state.set('metadata:1','on')
        state.set('files:1','off_no_button')
        jid,_ = state.submit(1,-10,77,12,URL)
        folder = r.work/'fixture'; folder.mkdir()
        audio = {'kind':'audio','file':'sound.mp3','sha256':'audio'}
        (folder/'sound.mp3').write_bytes(b'audio')
        if kind=='video':
            video = dict(video_record(folder),manual_audio=True,manual_subtitles=True)
            (folder/'subtitle-0001.srt').write_bytes(b'first line')
            subtitle = {'kind':'subtitle','file':'subtitle-0001.srt','filename':POST_ID+'_en_auto_1.srt',
                        'sha256':'subtitle'}
            records = [video,subtitle]
            primary_name = POST_ID+'.mp4'
            primary = 'sendVideo'
        else:
            records = [*photo_records(folder,photo_count),audio]
            primary = 'sendPhoto' if photo_count==1 else 'sendMediaGroup'
            photo_names = [POST_ID+'.jpg'] if photo_count==1 else [
                f'{POST_ID}_{n:02}.jpg' for n in range(1,photo_count+1)]
        source_names = []
        async def publish(job,target,sources):
            assert job==jid and target==kind+'/'+POST_ID
            # Both automatic documents have been acknowledged before any mirror request.
            assert session.calls(primary) and len(session.calls('sendDocument'))==(3 if kind=='video' else 2)
            if photo_count==11:
                assert len(session.calls('sendMediaGroup'))==len(session.calls('sendPhoto'))==1
            assert not session.calls('editMessageCaption')
            source_names.extend(name for name,path in sources.values())
            assert all(path.is_file() for name,path in sources.values())
            return {key:(ONLY+str(i),mirrors.CDN+target+'/'+name)
                    for i,(key,(name,path)) in enumerate(sources.items(),1)}
        monkeypatch.setattr(r.mirrors,'publish',publish)
        await r.deliver(jid,records,folder,'🚀'*600,'Creator','tester',POST_ID,{'description':'fixture'})
    assert source_names==([
        primary_name,POST_ID+'_en_auto_1.srt',POST_ID+'.txt',POST_ID+'.metadata.json'
    ] if kind=='video' else [
        *photo_names,POST_ID+'.audio.mp3',POST_ID+'.txt',POST_ID+'.metadata.json'
    ])
    edits = [call['fields'] for call in session.calls('editMessageCaption')]
    batches = ([list(enumerate(source_names[:10],1)),
                *[[(n,name)] for n,name in enumerate(source_names[10:],11)]]
               if photo_count==11 else [[(n,name)] for n,name in enumerate(source_names,1)])
    assert len(edits)==len(batches)
    initial_call = session.calls(primary)[0]['fields']
    if primary=='sendMediaGroup':
        original_album = json.loads(initial_call['media'])
        assert 'Download link' not in original_album[0]['caption'] and 'caption' not in original_album[1]
        assert int(edits[0]['message_id'])==state.job(jid)['reply_message']
    else:
        assert 'Download link' not in initial_call['caption']
    if kind=='video':
        assert json.loads(edits[0]['reply_markup'])==json.loads(initial_call['reply_markup'])
    for edit,batch in zip(edits,batches,strict=True):
        caption = edit['caption']
        expected = []
        for n,name in batch:
            photo_label = f' photo {n}' if 1<photo_count and n<=photo_count else ''
            expected.extend((f'<a href="{mirrors.CDN}{kind}/{POST_ID}/{name}">Download link 1{photo_label}</a>',
                             f'<a href="{ONLY}{n}">Download link 2{photo_label}</a>'))
        assert caption.endswith('\n'.join(expected)+'\n\n'+BOT_ATTRIBUTION)
        assert len(visible(caption).encode('utf-16-le'))//2<=1024
    assert '<blockquote>' in edits[0]['caption'] and not state.pending_mirror_edits(jid)
    state.close()


@pytest.mark.asyncio
async def test_disabled_and_failed_mirrors_never_block_telegram_sends(tmp_path,monkeypatch):
    state,session,bot,r = setup(tmp_path)
    targets = []
    async def unavailable(jid,target,sources):
        assert len(session.calls('sendVideo'))==2
        targets.append(target)
        return {}
    monkeypatch.setattr(r.mirrors,'publish',unavailable)
    folder = r.work/'fixture'; folder.mkdir()
    record = video_record(folder)
    async with bot.context():
        jid,_ = state.submit(1,1,77,None,URL)
        await r.deliver(jid,[record],folder)
        assert not targets
        state.set('mirrors:1','on')
        jid,_ = state.submit(1,1,78,None,URL)
        await r.deliver(jid,[record],folder)
    assert targets==['video/'+POST_ID]
    assert not session.calls('editMessageCaption')
    assert state.job(jid)['in_flight'] is None
    state.close()


@pytest.mark.asyncio
async def test_manual_audio_keeps_its_source_folder_and_telegram_reply(tmp_path,monkeypatch):
    state,session,bot,r = setup(tmp_path)
    state.set('mirrors:1','on')
    source,_ = state.submit(1,-10,77,12,URL)
    r.mirrors.bind(source,'video',POST_ID)
    state.change(source,status='done',manual_audio=1,reply_message=82)
    async with bot.context():
        await r.handle(callback(bot,f'extract:{source}',chat=-10,mid=82,message_thread_id=12))
        row, = state.outstanding(1)
        folder = r.work/'manual'; folder.mkdir()
        (folder/'track.m4a').write_bytes(b'track')
        async def publish(jid,target,sources):
            assert jid==row['id'] and target=='video/'+POST_ID
            request, = session.calls('sendAudio')
            assert json.loads(request['fields']['reply_parameters'])['message_id']==82
            assert sources['track.m4a'][0]==POST_ID+'.audio.m4a'
            return {'track.m4a':(ONLY,None)}
        monkeypatch.setattr(r.mirrors,'publish',publish)
        await r.deliver(row['id'],[{'kind':'audio','file':'track.m4a','sha256':'track','reply_to_source':True}],folder)
    fields = session.calls('editMessageCaption')[0]['fields']
    assert fields['caption']==f'<a href="{ONLY}">Download link 2</a>\n\n'+BOT_ATTRIBUTION
    state.close()


@pytest.mark.asyncio
@pytest.mark.parametrize('partial',[False,True])
async def test_off_offers_owner_only_public_links_after_delivery(tmp_path,monkeypatch,partial):
    state,session,bot,r = setup(tmp_path)
    state.set('language:1','en')
    state.set('caption:1','on')
    state.set('files:1','off_no_button')
    state.set('mirrors:1','off')  # previous version: Off meant no button
    description,keyboard = r.settings_view(1,'mirrors')
    assert 'public links' in description and 'OnlyFiles' not in description and 'GitHub' not in description
    assert keyboard.inline_keyboard[1][0].text=='✓ Off with no button'
    jid,_ = state.submit(1,-10,77,12,URL)
    folder = r.work/'album'; folder.mkdir()
    records = photo_records(folder,2)
    text = '🎬'*700
    payloads = {'photo-1':b'Telegram first image','photo-2':b'Telegram second image','caption':text.encode()}
    published = []
    first_attempt = True
    async def publish(job,target,sources):
        nonlocal first_attempt
        assert job==jid and target=='photo/'+POST_ID
        if partial and first_attempt:
            sources = {key:source for key,source in sources.items() if key!='502'}
        first_attempt = False
        published.extend((name,path.read_bytes()) for name,path in sources.values())
        return {key:(ONLY+key,mirrors.CDN+target+'/'+name) for key,(name,path) in sources.items()}
    async def download(path,destination,timeout):
        destination.write_bytes(payloads[path])
    monkeypatch.setattr(r.mirrors,'publish',publish)
    monkeypatch.setattr(bot,'download_file',download)
    async with bot.context():
        await r.handle(callback(bot,'settings:1:mirrors-off'))
        assert r.settings_view(1,'mirrors')[1].inline_keyboard[0][1].text=='✓ Off'
        session.queue('sendMediaGroup',[
            message(-10,501,photo=[{'file_id':'small','file_unique_id':'small','width':1,'height':1},
                                    {'file_id':'photo-1','file_unique_id':'photo-1','width':40,'height':60}]),
            message(-10,502,photo=[{'file_id':'photo-2','file_unique_id':'photo-2','width':40,'height':60}])])
        session.queue('sendDocument',message(-10,503,document={'file_id':'caption','file_unique_id':'caption'}))
        await r.deliver(jid,records,folder,text,'Creator','tester',POST_ID)
        button = state.job(jid)['links_button_message']
        assert button and len(state.public_link_files(jid))==3 and published==[]
        assert len(session.calls('sendMediaGroup'))==1
        controls = session.calls('sendMessage')[-1]['fields']
        assert json.loads(controls['reply_markup'])['inline_keyboard'][0][0]['text']=='Get public links'
        assert json.loads(controls['reply_parameters'])['message_id']==501
        for path in folder.iterdir():
            path.unlink()
        await r.handle(callback(bot,f'public_links:{jid}',user=2,chat=-10,mid=button,message_thread_id=12))
        assert not r.mirrors.requests and not session.calls('getFile')
        assert session.calls('answerCallbackQuery')[-1]['fields']['text']=='This button belongs to the original requester'
        for key,data in payloads.items():
            session.queue('getFile',{'file_id':key,'file_unique_id':key,'file_path':key,'file_size':len(data)})
        await r.handle(callback(bot,f'public_links:{jid}',chat=-10,mid=button,message_thread_id=12))
        assert session.calls('answerCallbackQuery')[-1]['fields']['text']=='Creating public links...'
        await asyncio.wait_for(r.mirrors.requests[jid],2)
        assert [call['fields']['file_id'] for call in session.calls('getFile')]==list(payloads)
        assert len(session.calls('sendMediaGroup'))==1
        edits = [call['fields'] for call in session.calls('editMessageCaption')]
        assert [edit['message_id'] for edit in edits]==['501','503']
        assert '<blockquote>' in edits[0]['caption']
        assert f'<a href="{mirrors.CDN}photo/{POST_ID}/{POST_ID}_01.jpg">Download link 1 photo 1</a>' in edits[0]['caption']
        assert ('>Download link 2 photo 2</a>' in edits[0]['caption'])!=partial
        assert '>Download link 1</a>' in edits[1]['caption']
        assert all(edit['caption'].endswith('\n\n'+BOT_ATTRIBUTION) for edit in edits)
        assert all(len(visible(edit['caption']).encode('utf-16-le'))//2<=1024 for edit in edits)
        if partial:
            assert [item['message_id'] for item in state.public_link_files(jid)]==[501,502]
            with state.db:
                state.db.execute("UPDATE button_presses SET created=0 WHERE source_job=? AND kind='public_links'",(jid,))
            session.queue('getFile',{'file_id':'photo-2','file_unique_id':'photo-2',
                                     'file_path':'photo-2','file_size':len(payloads['photo-2'])})
            await r.handle(callback(bot,f'public_links:{jid}',chat=-10,mid=button,message_thread_id=12))
            await asyncio.wait_for(r.mirrors.requests[jid],2)
            retry = session.calls('editMessageCaption')[-1]['fields']
            assert retry['message_id']=='501'
            assert '>Download link 1 photo 1</a>' in retry['caption']
            assert f'<a href="{ONLY}502">Download link 2 photo 2</a>' in retry['caption']
            assert '<blockquote>' in retry['caption']
            assert [call['fields']['file_id'] for call in session.calls('getFile')]==[*payloads,'photo-2']
        assert not state.public_link_files(jid)
    assert sorted(published)==sorted([(POST_ID+'_01.jpg',payloads['photo-1']),
                                      (POST_ID+'_02.jpg',payloads['photo-2']),
                                      (POST_ID+'.txt',payloads['caption'])])
    state.close()


@pytest.mark.asyncio
async def test_caption_button_returns_before_background_mirrors_finish(tmp_path,monkeypatch):
    state,session,bot,r = setup(tmp_path)
    jid,_ = state.submit(1,-10,77,12,URL)
    state.set('mirrors:1','on')
    target = r.mirrors.bind(jid,'photo',POST_ID)
    state.change(jid,status='done',reply_message=88,caption_button_message=89,
                 caption_text='Full caption',caption_post_id=POST_ID)
    release = asyncio.Event()
    async def publish(job,actual,sources):
        assert job==jid and actual==target
        await release.wait()
        name,path = sources['@caption']
        assert name==POST_ID+'.txt' and path.read_bytes()==b'Full caption'
        return {'@caption':(ONLY,None)}
    monkeypatch.setattr(r.mirrors,'publish',publish)
    async with bot.context():
        await asyncio.wait_for(r.handle(callback(bot,f'caption:{jid}',chat=-10,mid=89,message_thread_id=12)),1)
        assert session.calls('sendDocument') and not session.calls('editMessageCaption')
        tasks = list(r.mirrors.documents)
        assert len(tasks)==1
        release.set()
        await asyncio.wait_for(asyncio.gather(*tasks),2)
    assert session.calls('editMessageCaption')[0]['fields']['caption'].startswith(
        f'<a href="{ONLY}">Download link 2</a>')
    state.close()


@pytest.mark.asyncio
async def test_onlyfiles_streams_individual_file_with_forever_and_skips_over_limit(tmp_path,monkeypatch):
    seen = []
    async def upload(request):
        multipart = await request.multipart()
        expire = await multipart.next()
        assert expire.name=='expire' and await expire.text()=='0'
        file = await multipart.next()
        seen.append((file.filename,bytes(await file.read())))
        return web.json_response({'status':True,'data':{'file':{'url':{'short':ONLY}}}})
    app = web.Application()
    app.router.add_post('/v1/upload',upload)
    server = web.AppRunner(app)
    await server.setup()
    site = web.TCPSite(server,'127.0.0.1',0)
    await site.start()
    port = server.addresses[0][1]
    monkeypatch.setattr(mirrors,'ONLYFILES_API',f'http://127.0.0.1:{port}/v1/upload')
    monkeypatch.setattr(mirrors,'ONLYFILES_LIMIT',9)
    monkeypatch.delenv('TIKCDN_TOKEN',raising=False)
    state,session,bot,r = setup(tmp_path)
    try:
        state.set('mirrors:1','on')
        jid,_ = state.submit(1,1,77,None,URL)
        target = r.mirrors.bind(jid,'video',POST_ID)
        small = tmp_path/'a.mp4'; small.write_bytes(b'video')
        large = tmp_path/'b.mp4'; large.write_bytes(b'x'*10)
        files = {'small':('a.mp4',small),'large':('b.mp4',large)}
        for _ in range(2):
            assert await r.mirrors.publish(jid,target,files)=={'small':(ONLY,None)}
        assert seen==[('a.mp4',b'video')]
    finally:
        state.close()
        await bot.session.close()
        await server.cleanup()


@pytest.mark.asyncio
async def test_github_batches_blob_and_release_redirect_without_force_push(tmp_path,monkeypatch):
    small = tmp_path/'a.jpg'; small.write_bytes(b'foto')
    large = tmp_path/'b.mp4'; large.write_bytes(b'video-file')
    a,b = (mirrors.File.read(p.name,p.name,p) for p in (small,large))
    assert mirrors.GIT_FILE_LIMIT==100*1024**2
    monkeypatch.setattr(mirrors,'GIT_FILE_LIMIT',5)
    target = 'photo/'+POST_ID
    small_hash = sha256(b'foto').hexdigest()[:16]
    large_hash = sha256(b'video-file').hexdigest()[:16]
    photo_path = f'{target}/{small_hash}/a.jpg'
    redirect_path = f'{target}/{large_hash}/b.mp4.html'
    clean_path = f'{target}/{large_hash}/b.mp4/'
    asset_name = f'b-{large_hash}.mp4'
    tree_entries,patches = [],[]
    async def api(method,path,**opts):
        if path=='':
            return {'size':0,'private':False}
        if path=='/git/blobs':
            assert base64.b64decode(opts['json']['content'])==b'foto'
            return {'sha':'a'*40}
        if path.startswith('/releases/tags/'):
            assert opts['missing']
            return None
        if path=='/releases':
            assert opts['json']['make_latest']=='false'
            return {'id':34,'assets':[]}
        if path=='/git/ref/heads/main':
            return {'object':{'sha':'b'*40}}
        if path=='/git/commits/'+'b'*40:
            return {'tree':{'sha':'c'*40}}
        if path=='/git/trees':
            assert opts['json']['base_tree']=='c'*40
            tree_entries.extend(opts['json']['tree'])
            return {'sha':'d'*40}
        if path=='/git/commits':
            return {'sha':'e'*40}
        if path=='/git/refs/heads/main':
            patches.append(opts['json'])
            if len(patches)==1:
                raise mirrors.MirrorError(422)
            return {}
        raise AssertionError(path)
    async def upload(session,method,url,**opts):
        assert url.endswith('/34/assets') and opts['params']=={'name':asset_name}
        assert opts['data'].read()==b'video-file'
        return {'name':asset_name,'state':'uploaded','size':b.size}
    monkeypatch.setattr(mirrors,'request_json',upload)
    git = mirrors.GitHub(None,'main',asyncio.Lock())
    monkeypatch.setattr(git,'api',api)
    links = await git.publish(target,[a,b])
    assert links=={'a.jpg':mirrors.CDN+photo_path,'b.mp4':mirrors.CDN+clean_path}
    assert patches==[{'sha':'e'*40,'force':False}]*2
    assert tree_entries[0]['path']==photo_path and tree_entries[0]['sha']=='a'*40
    assert tree_entries[1]['path']==redirect_path
    assert tree_entries[2]['path']==clean_path+'index.html'
    assert tree_entries[1]['content']==tree_entries[2]['content']
    assert f'/releases/download/tiktok-photo-{POST_ID}/{asset_name}' in tree_entries[1]['content']
    assert 'get("view")==="true"' in tree_entries[1]['content'] and '<video controls' in tree_entries[1]['content']
