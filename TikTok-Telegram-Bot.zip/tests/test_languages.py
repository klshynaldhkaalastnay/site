from types import SimpleNamespace as NS
import pytest
from bot import Runner
from state import State
from i18n import LANGUAGES, HELP, OWNER_HELP

class Bot:
    def __init__(self): self.messages=[]; self.edits=[]
    async def send_message(self,chat,text,**kwargs):
        self.messages.append((text,kwargs))
        return NS(message_id=42)
    async def edit_message_text(self,text,**kwargs): self.edits.append(text)

@pytest.mark.asyncio
async def test_language_onboarding_persistence_and_callback_ownership(tmp_path):
    state=State(tmp_path/'state.db'); bot=Bot(); runner=Runner(state,bot,tmp_path,7,99)
    async def fast(chat,operation): return await operation()
    runner.api=fast
    msg=NS(from_user=NS(id=1,is_bot=False),chat=NS(id=1),message_thread_id=None,text='/start',caption=None)
    await runner.handle(NS(message=msg))
    buttons=bot.messages[-1][1]['reply_markup'].inline_keyboard
    assert sum(len(row) for row in buttons)==5
    class Query:
        data='lang:1:ar'; from_user=NS(id=2); message=NS(chat=NS(id=1),message_id=42)
        async def answer(self): pass
    q=Query()
    await runner.select_language(q)
    assert state.get('language:1') is None
    q.from_user=NS(id=1)
    await runner.select_language(q)
    assert state.get('language:1')=='ar'
    assert bot.edits[-1]=='أرسل رابط فيديو أو صور أو صوت من تيك توك'
    state.close(); restored=State(tmp_path/'state.db')
    assert restored.get('language:1')=='ar'
    restored.close()

@pytest.mark.asyncio
async def test_all_languages_help_start_status_and_ping(tmp_path):
    state=State(tmp_path/'state.db'); bot=Bot(); runner=Runner(state,bot,tmp_path,7,99)
    async def fast(chat,operation): return await operation()
    runner.api=fast
    msg=NS(chat=NS(id=1),message_thread_id=None)
    for lang in LANGUAGES:
        for user in (1,7):
            state.set(f'language:{user}',lang)
            await runner.command(msg,user,'/start',[])
            assert '/queue' not in bot.messages[-1][0]
            await runner.command(msg,user,'/help',[])
            text=bot.messages[-1][0]
            assert ('/shutdown' in text)==(user==7)
            assert '—' not in text
            assert HELP[lang] in text
        jid,_=state.submit(1,1,len(bot.messages),None,'https://www.tiktok.com/@a/video/1')
        await runner.status(jid,'Downloading...')
        assert bot.messages[-1][0]==runner.tr(1,'Downloading...')
        state.change(jid,status='done')
    await runner.command(msg,1,'/ping',[])
    assert bot.edits[-1].startswith('Pong! ') and bot.edits[-1].endswith('ms')
    state.close()
