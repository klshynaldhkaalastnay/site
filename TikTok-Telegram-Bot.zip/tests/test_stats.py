import json
from pathlib import Path
import sqlite3
import time

import pytest
from aiogram.types import Update

from bot import COMMANDS, Runner
from i18n import HELP, LANGUAGES, OWNER_HELP, STATS_REPORT, TEXT
from state import State
from test_aiogram import setup, message


@pytest.mark.parametrize('chat',[7,-10])
async def test_owner_stats_before_language_selection_replies_to_command(tmp_path,monkeypatch,chat):
    state,session,bot,r=setup(tmp_path)
    r.username='testbot'
    # Statistics never invoke dependency probes or external executables.
    import bot as bot_module
    async def forbidden():pytest.fail('Stats started an external probe')
    monkeypatch.setattr(bot_module,'read_specs',forbidden)
    monkeypatch.setattr(bot_module,'read_dependencies',forbidden)
    update=Update.model_validate({'update_id':42,'message':message(chat,user=7,
        text='/StAtS@testbot',message_thread_id=12 if chat<0 else None)},context={'bot':bot})
    async with bot.context():
        await r.handle(update)
    fields=session.calls('sendMessage')[0]['fields']
    assert fields['text'].startswith('<pre>Bot statistics\nSession uptime: 0d 0h 0m')
    assert 'Saved requests: 0' in fields['text'] and 'Running: 0' in fields['text']
    assert 'Requests: 0\nRequesters: 0' in fields['text']
    assert fields['parse_mode']=='HTML' and fields['chat_id']==str(chat)
    assert json.loads(fields['reply_parameters'])=={'message_id':77,'allow_sending_without_reply':True}
    assert fields.get('message_thread_id')==('12' if chat<0 else None)
    assert state.get('language:7') is None
    assert not state.outstanding() and not r.stop.is_set()
    state.close()


@pytest.mark.parametrize('user',[1,99])
@pytest.mark.parametrize('chat',[1,-10])
@pytest.mark.parametrize('language',[None,'ar'])
async def test_stats_denied_to_other_users_including_queue_bypass(tmp_path,monkeypatch,user,chat,language):
    state,session,bot,r=setup(tmp_path)
    def forbidden():pytest.fail('Non-owner accessed statistics')
    monkeypatch.setattr(r,'stats_report',forbidden)
    if language:state.set(f'language:{user}',language)
    update=Update.model_validate({'update_id':42,'message':message(chat,user=user,text='/stats')},
                                 context={'bot':bot})
    async with bot.context():
        await r.handle(update)
    calls=session.calls('sendMessage')
    assert len(calls)==1
    assert calls[0]['fields']['text']==TEXT[language or 'en']['Only the bot owner can use this command']
    assert 'reply_markup' not in calls[0]['fields']
    assert not r.stop.is_set()
    state.close()


async def test_stats_for_another_bot_are_ignored(tmp_path,monkeypatch):
    state,session,bot,r=setup(tmp_path)
    r.username='testbot'
    def forbidden():pytest.fail('Another bot was addressed')
    monkeypatch.setattr(r,'stats_report',forbidden)
    update=Update.model_validate({'update_id':42,'message':message(user=7,text='/stats@otherbot')},
                                 context={'bot':bot})
    async with bot.context():await r.handle(update)
    assert not session.calls('sendMessage')
    state.close()


def test_stats_counts_saved_history_queue_recent_users_and_no_private_data(tmp_path):
    state,session,bot,r=setup(tmp_path)
    statuses=('done','failed','cancelled','uncertain','running','ready','queued')
    for index,status in enumerate(statuses):
        user=1 if index%2==0 else 2
        jid,_=state.submit(user,1 if user==1 else -10,index+1,None,
                           f'https://www.tiktok.com/@private-user/video/{1234567890+index}',
                           audio_only=index==0,subtitles_only=index==1)
        assert jid is not None
        state.change(jid,status=status,metadata_data=b'private metadata never included')
        if index<2:
            with state.db:state.db.execute('UPDATE jobs SET created=? WHERE id=?',(time.time()-90000,jid))
    r.broadcasts.track(1,'private')
    r.broadcasts.track(-10,'supergroup',False)
    r.broadcasts.track(7,'private')
    state.set('language:3','fa')
    state.set('language:1','en')  # Same user must not be counted twice.
    state.set('language:bad','private-settings')
    state.set('language:0','en')
    r.started_at=time.monotonic()-90061
    before=state.db.total_changes
    report=r.stats_report()
    assert state.db.total_changes==before
    for line in ('Session uptime: 1d 1h 1m','Recorded users: 4','Recorded chats: 3',
                 'Active chat records: 2','Saved requests: 7','Completed: 1','Failed: 1',
                 'Cancelled: 1','Unconfirmed: 1','Running: 1','Ready: 1','Waiting: 1',
                 'Requests: 5','Requesters: 2'):
        assert line in report
    assert 'private' not in report and '1234567890' not in report and 'https://' not in report
    assert '-10' not in report
    state.close()


async def test_stats_owner_help_and_report_are_translated(tmp_path):
    import string
    fields={name for _,name,_,_ in string.Formatter().parse(STATS_REPORT) if name}
    assert 'stats' not in dict(COMMANDS)
    state,session,bot,r=setup(tmp_path)
    for language in LANGUAGES:
        assert '/stats' not in HELP[language]
        assert '/stats - ' in OWNER_HELP[language]
        assert STATS_REPORT in TEXT[language]
        assert {name for _,name,_,_ in string.Formatter().parse(TEXT[language][STATS_REPORT]) if name}==fields
        state.set('language:7',language)
        report=r.stats_report()
        assert '{' not in report and '}' not in report
        assert report.startswith(TEXT[language][STATS_REPORT].split('\n')[0])
    state.set('language:7','fr')
    update=Update.model_validate({'update_id':42,'message':message(user=7,text='/stats')},context={'bot':bot})
    async with bot.context():await r.handle(update)
    assert session.calls('sendMessage')[0]['fields']['text'].startswith('<pre>Statistiques du bot\n')
    state.close()


async def test_stats_report_failure_has_appropriate_reply_and_no_stop(tmp_path,monkeypatch):
    state,session,bot,r=setup(tmp_path)
    state.set('language:7','ar')
    def unavailable():raise ValueError('private failure details')
    monkeypatch.setattr(r,'stats_report',unavailable)
    update=Update.model_validate({'update_id':42,'message':message(user=7,text='/stats')},context={'bot':bot})
    async with bot.context():await r.handle(update)
    text=session.calls('sendMessage')[0]['fields']['text']
    assert text==TEXT['ar']['Could not read bot statistics, please try again later']
    assert 'private failure' not in text and not r.stop.is_set()
    state.close()


def test_stats_history_survives_sqlite_backup_and_session_restart(tmp_path):
    state,session,bot,r=setup(tmp_path)
    jid,_=state.submit(1,-10,77,None,'https://www.tiktok.com/@a/video/123')
    state.change(jid,status='done')
    r.broadcasts.track(-10,'supergroup',False)
    state.set('language:2','ja')
    original=r.stats_report().splitlines()[2:]
    snapshot=tmp_path/'snapshot.db'
    with sqlite3.connect(snapshot) as target:state.db.backup(target)
    state.close()
    restored=State(snapshot)
    directory=tmp_path/'restored'
    directory.mkdir()
    new=Runner(restored,bot,directory,7,99)
    assert new.stats_report().splitlines()[2:]==original
    assert 'Session uptime: 0d 0h 0m' in new.stats_report()
    restored.close()
