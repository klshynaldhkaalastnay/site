"""Language coverage, owner-bound restart decisions and one-session ZIP imports."""
import asyncio
import json
from string import Formatter

import pytest
from aiogram.exceptions import TelegramNetworkError

from bot import Runner
from i18n import LANGUAGES, TEXT, HELP, OWNER_HELP
from state import State
from test_aiogram import setup, message, callback
import backup
import workflow_tools

ADDED=('ja','pt','fr','de')


def restart_button(session,mode):
    request=session.calls('sendMessage')[-1]
    buttons=json.loads(request['fields']['reply_markup'])['inline_keyboard']
    return next(button for row in buttons for button in row if button['callback_data'].endswith(':'+mode))


def owner_message(bot,**values):
    return callback(bot,'unused',user=7,chat=-10,mid=77,message_thread_id=12,**values).callback_query.message


@pytest.mark.parametrize('language',ADDED)
def test_added_languages_cover_all_labels_and_format_fields(language):
    assert len(LANGUAGES)==10 and 'hi' not in LANGUAGES and 'ur' not in LANGUAGES
    assert set(TEXT[language])==set(TEXT['en'])
    fields=lambda text:{name for _,name,_,_ in Formatter().parse(text) if name}
    for key,value in TEXT[language].items():
        assert value.strip() and fields(value)==fields(key),(language,key)
    for command in ('/queue','/cancel','/ping','/id','/settings'):
        assert command in HELP[language]
    for command in ('/jobs','/restart','/upload','/shutdown','/broadcast'):
        assert command in OWNER_HELP[language] and command not in HELP[language]
    assert '/language' not in HELP[language]+OWNER_HELP[language]


@pytest.mark.asyncio
@pytest.mark.parametrize('language',ADDED)
async def test_native_language_selection_settings_help_and_restart_translation(tmp_path,language):
    state,session,bot,r=setup(tmp_path)
    async with bot.context():
        msg=owner_message(bot,text='/start')
        await r.language_menu(msg,7)
        chooser=json.loads(session.calls('sendMessage')[-1]['fields']['reply_markup'])['inline_keyboard']
        assert len(chooser)==5 and all(len(row)==2 for row in chooser)
        assert {button['callback_data'].rsplit(':',1)[1] for row in chooser for button in row}==set(LANGUAGES)
        await r.handle(callback(bot,f'lang:7:{language}',user=2))
        assert state.get('language:7') is None
        await r.handle(callback(bot,f'lang:7:{language}',user=7))
        assert state.get('language:7')==language
        assert session.calls('editMessageText')[-1]['fields']['text']==TEXT[language]['Send a TikTok video or photo link']
        keyboard=r.settings_view(7,'language')[1].inline_keyboard
        assert len(keyboard)==6 and len(keyboard[-1])==1
        await r.handle(callback(bot,f'settings:7:set-{language}',user=7))
        assert session.calls('editMessageText')[-1]['fields']['text']==TEXT[language]['Settings']
        for page in ('audio','subtitles','caption','compression','compress-advanced'):
            text,buttons=r.settings_view(7,page)
            assert text and buttons.inline_keyboard
        await r.command(msg,7,'/help',[])
        assert session.calls('sendMessage')[-1]['fields']['text']==HELP[language]+'\n\n'+OWNER_HELP[language]
        await r.command(msg,7,'/restart',[])
        assert not r.stop.is_set()
        assert session.calls('sendMessage')[-1]['fields']['text']==TEXT[language]['Reimport the ZIP when restarting?']
        assert restart_button(session,'reimport')['text']==TEXT[language]['Restart and reimport ZIP']
        assert restart_button(session,'keep')['text']==TEXT[language]['Restart without reimport']
        await r.handle(callback(bot,restart_button(session,'cancel')['callback_data'],user=7,chat=-10,
                                mid=r.pending_restart['message'],message_thread_id=12))
        assert session.calls('editMessageText')[-1]['fields']['text']==TEXT[language]['Restart cancelled']
        assert not r.stop.is_set()
    state.close();state=State(tmp_path/'state.db')
    assert state.get('language:7')==language
    state.close()


@pytest.mark.asyncio
@pytest.mark.parametrize('mode',['reimport','keep','cancel'])
async def test_restart_waits_for_choice_and_consumes_buttons(tmp_path,mode):
    state,session,bot,r=setup(tmp_path)
    queued,_=state.submit(1,1,1,None,'https://www.tiktok.com/@x/video/123')
    async with bot.context():
        await r.command(owner_message(bot),7,'/restart',[])
        assert not r.stop.is_set() and not r.force_reimport
        request=session.calls('sendMessage')[-1]['fields']
        assert request['chat_id']=='-10' and request['message_thread_id']=='12'
        assert json.loads(request['reply_parameters'])['message_id']==77
        choice=restart_button(session,mode)
        assert len(choice['callback_data'].encode())<=64
        query=callback(bot,choice['callback_data'],user=7,chat=-10,mid=r.pending_restart['message'],message_thread_id=12)
        await r.handle(query)
        assert r.stop.is_set()==(mode!='cancel')
        assert r.force_reimport==(mode=='reimport')
        assert r.pending_restart is None and state.job(queued)['status']=='ready'
        await r.handle(query)
        assert len(session.calls('editMessageText'))==1
        assert 'no longer active' in session.calls('answerCallbackQuery')[-1]['fields']['text']
        assert r.force_reimport==(mode=='reimport')
    state.close()


@pytest.mark.asyncio
async def test_restart_rejects_nonowner_wrong_binding_old_prompt_and_shutdown(tmp_path):
    state,session,bot,r=setup(tmp_path)
    async with bot.context():
        await r.command(owner_message(bot),1,'/restart',[])
        assert r.pending_restart is None and 'Only the bot owner' in session.calls('sendMessage')[-1]['fields']['text']
        await r.command(owner_message(bot),7,'/restart',[])
        data=restart_button(session,'reimport')['callback_data'];mid=r.pending_restart['message']
        for changes in ({'user':2},{'chat':-20},{'mid':mid+1},{'message_thread_id':13}):
            values={'user':7,'chat':-10,'mid':mid,'message_thread_id':12};values.update(changes)
            await r.handle(callback(bot,data,**values))
            assert not r.stop.is_set() and not r.force_reimport and r.pending_restart
        await r.command(owner_message(bot),7,'/restart',[])
        await r.handle(callback(bot,data,user=7,chat=-10,mid=mid,message_thread_id=12))
        assert not r.stop.is_set() and r.pending_restart
        current=restart_button(session,'reimport')['callback_data'];mid=r.pending_restart['message']
        r.request_stop('shutdown')
        await r.handle(callback(bot,current,user=7,chat=-10,mid=mid,message_thread_id=12))
        assert r.reason=='shutdown' and not r.force_reimport
    state.close()


@pytest.mark.asyncio
async def test_restart_choice_survives_failed_telegram_acknowledgement(tmp_path):
    state,session,bot,r=setup(tmp_path)
    async with bot.context():
        await r.command(owner_message(bot),7,'/restart',[])
        data=restart_button(session,'reimport')['callback_data'];mid=r.pending_restart['message']
        session.responses['answerCallbackQuery'].append((200,lambda method:TelegramNetworkError(method=method,message='lost')))
        session.queue('editMessageText',status=400,description='message deleted')
        await r.handle(callback(bot,data,user=7,chat=-10,mid=mid,message_thread_id=12))
        assert r.reason=='restart' and r.stop.is_set() and r.force_reimport and r.pending_restart is None
    state.close()


@pytest.mark.asyncio
async def test_uncertain_prompt_can_only_bind_to_the_correct_owner_reply(tmp_path):
    state,session,bot,r=setup(tmp_path)
    async with bot.context():
        session.responses['sendMessage'].append((200,lambda method:TelegramNetworkError(method=method,message='lost')))
        with pytest.raises(TelegramNetworkError):await r.command(owner_message(bot),7,'/restart',[])
        assert r.pending_restart['message'] is None
        data=restart_button(session,'reimport')['callback_data']
        await r.handle(callback(bot,data,user=7,chat=-10,mid=401,message_thread_id=12,reply_to_message=message(-10,999)))
        assert not r.stop.is_set()
        await r.handle(callback(bot,data,user=7,chat=-10,mid=401,message_thread_id=12,reply_to_message=message(-10,77)))
        assert r.stop.is_set() and r.force_reimport
    state.close()


def configure_dispatch(monkeypatch,tmp_path):
    for key,value in {'GITHUB_REPOSITORY':'test/bot','GITHUB_REF_NAME':'main','GITHUB_RUN_ID':'123',
                      'RUNNER_TEMP':str(tmp_path),'BOT_DATA_DIR':str(tmp_path),'CONTINUE_SESSIONS':'false'}.items():
        monkeypatch.setenv(key,value)
    calls=[]
    def gh(*args):
        calls.append(args)
        if '--method' in args:
            assert '/workflows/789/dispatches' in args[args.index('POST')+1]
            return ''
        return '{"workflow_id":789}'
    monkeypatch.setattr(workflow_tools,'gh',gh)
    return calls


@pytest.mark.asyncio
@pytest.mark.parametrize('mode',['reimport','keep'])
async def test_native_lifecycle_receipt_backup_gate_and_next_dispatch(tmp_path,monkeypatch,mode):
    state,session,bot,r=setup(tmp_path)
    state.set('language:7','ja')
    job,_=state.submit(1,1,1,None,'https://www.tiktok.com/@x/video/123')
    session.queue('getUpdates',[{'update_id':42,'message':message(-10,77,user=7,text='/restart',message_thread_id=12)}])
    def select(method):
        assert method.offset==43 and not r.stop.is_set()
        data=restart_button(session,mode)['callback_data']
        update=callback(bot,data,user=7,chat=-10,mid=r.pending_restart['message'],message_thread_id=12)
        return {'ok':True,'result':[update.model_dump(mode='json',exclude_none=True)]}
    session.responses['getUpdates'].append((200,select))
    async def idle():await r.stop.wait()
    r.scheduler=idle;r.broadcasts.run=idle
    async with bot.context():await asyncio.wait_for(r.run(),3)
    receipt=json.loads((tmp_path/'receipt.json').read_text())
    assert receipt['reason']=='restart' and receipt['ok'] and receipt['force_reimport']==(mode=='reimport')
    assert state.get('offset')=='102' and state.job(job)['status']=='ready'
    monkeypatch.setenv('GITHUB_OUTPUT',str(tmp_path/'outputs.txt'))
    backup.receipt(tmp_path)
    assert (tmp_path/'outputs.txt').read_text()=='reason=restart\nok=true\n'
    calls=configure_dispatch(monkeypatch,tmp_path)
    workflow_tools.dispatch()
    payload=json.loads((tmp_path/'tiktok-next-session.json').read_text())
    assert payload=={'ref':'main','inputs':{'continue':'false','force_reimport':'true' if mode=='reimport' else 'false'}}
    assert len(calls)==2
    # A fresh session invalidates old prompts and cannot inherit the reimport flag.
    restored=Runner(state,bot,tmp_path,7,99)
    assert restored.pending_restart is None and not restored.force_reimport
    state.close()


@pytest.mark.parametrize('receipt',[None,{'ok':True,'reason':'restart'},
    {'ok':True,'reason':'time-limit','force_reimport':True},
    {'ok':True,'reason':'upload','force_reimport':True},
    {'ok':True,'reason':'shutdown','force_reimport':True},
    {'ok':False,'reason':'restart','force_reimport':True},
    {'ok':True,'reason':'restart','force_reimport':'true'}])
def test_dispatch_only_reimports_for_an_explicit_clean_restart(tmp_path,monkeypatch,receipt):
    if receipt is not None:(tmp_path/'receipt.json').write_text(json.dumps(receipt))
    configure_dispatch(monkeypatch,tmp_path)
    workflow_tools.dispatch()
    payload=json.loads((tmp_path/'tiktok-next-session.json').read_text())
    assert payload['inputs']=={'continue':'false','force_reimport':'false'}
