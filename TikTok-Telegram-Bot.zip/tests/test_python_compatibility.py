"""Startup and source-cache regressions for Python's compression namespace."""
import io
from pathlib import Path
import subprocess
import sys
import urllib.request
import zipfile

import pytest
import yaml

import import_app

ROOT = Path(__file__).resolve().parents[1]


def importer(workflow):
    if not workflow:
        return import_app.main
    steps = yaml.safe_load((ROOT/'.github/workflows/tik.yml').read_text())['jobs']['bot']['steps']
    run = next(step['run'] for step in steps if step['name']=='Import application from ZIP or reuse cache')
    source = run.split("python - <<'PY'\n", 1)[1].rsplit('\nPY', 1)[0]
    namespace = {'__name__':'importer_test'}
    exec(compile(source, 'workflow-importer', 'exec'), namespace)
    return namespace['main']


def source_zip(legacy=False):
    output = io.BytesIO()
    with zipfile.ZipFile(output, 'w', zipfile.ZIP_DEFLATED) as archive:
        for file in ROOT.glob('*.py'):
            if legacy and file.name=='video_compression.py':
                archive.writestr('compression.py',file.read_bytes())
            else:
                archive.writestr(file.name,file.read_bytes())
        archive.write(ROOT/'requirements.txt','requirements.txt')
    return output.getvalue()


def test_fresh_process_imports_and_archive_roundtrips():
    source = '''
import backup, boto3, bot, worker, video_compression
import bz2, gzip, lzma, io, zipfile, sys
from pathlib import Path
payload = b'Bot backup startup regression'
for module in (gzip, bz2, lzma):
    assert module.decompress(module.compress(payload)) == payload
output = io.BytesIO()
with zipfile.ZipFile(output, 'w', zipfile.ZIP_DEFLATED) as archive:
    archive.writestr('state.txt', payload)
with zipfile.ZipFile(io.BytesIO(output.getvalue())) as archive:
    assert archive.read('state.txt') == payload
if sys.version_info >= (3,14):
    import compression._common, compression.gzip
    assert 'site-packages' not in str(compression.__file__)
assert not (Path.cwd()/'compression.py').exists()
print('Startup and archives passed')
'''
    process = subprocess.run([sys.executable, '-c', source], cwd=ROOT, capture_output=True, text=True, timeout=30)
    assert process.returncode==0,process.stderr


@pytest.mark.parametrize('workflow',[False,True])
@pytest.mark.parametrize('cache',['legacy','stray','before_crash_reporting','current'])
def test_importer_refreshes_legacy_source_preserving_state(tmp_path,monkeypatch,workflow,cache):
    app=tmp_path/'app';app.mkdir()
    for file in ROOT.glob('*.py'):
        if cache=='legacy' and file.name=='video_compression.py':
            continue
        if cache=='before_crash_reporting' and file.name=='crash_reports.py':
            continue
        (app/file.name).write_bytes(file.read_bytes())
    (app/'requirements.txt').write_bytes((ROOT/'requirements.txt').read_bytes())
    (app/'worker.py').write_text('# cached worker\n')
    if cache in ('legacy','stray'):
        (app/'compression.py').write_text('# old video compressor\n')
    state=tmp_path/'state';state.mkdir()
    (state/'state.db').write_bytes(b'saved queue and preferences')
    calls=[]
    body=source_zip()
    class Response(io.BytesIO):
        def geturl(self):return 'https://example.invalid/bot.zip'
    def fetch(url,timeout):
        calls.append(url)
        return Response(body)
    monkeypatch.setattr(urllib.request,'urlopen',fetch)
    monkeypatch.chdir(tmp_path)
    monkeypatch.setenv('APP_ZIP_URL','https://example.invalid/bot.zip')
    monkeypatch.setenv('FORCE_REIMPORT','false')
    monkeypatch.setenv('GITHUB_ENV',str(tmp_path/'github-env'))
    monkeypatch.delenv('GITHUB_WORKFLOW_REF',raising=False)
    importer(workflow)()
    assert (state/'state.db').read_bytes()==b'saved queue and preferences'
    assert (app/'video_compression.py').is_file()
    assert not (app/'compression.py').exists()
    assert (tmp_path/'github-env').read_text()=='BOT_SOURCE_DIR='+str(app)+'\n'
    assert len(calls)==(0 if cache=='current' else 1)
    assert (app/'worker.py').read_text()==('# cached worker\n' if cache=='current' else (ROOT/'worker.py').read_text())


@pytest.mark.parametrize('workflow',[False,True])
def test_importer_rejects_outdated_hosted_zip(tmp_path,monkeypatch,workflow):
    class Response(io.BytesIO):
        def geturl(self):return 'https://example.invalid/bot.zip'
    monkeypatch.setattr(urllib.request,'urlopen',lambda *a,**k:Response(source_zip(legacy=True)))
    monkeypatch.chdir(tmp_path)
    monkeypatch.setenv('APP_ZIP_URL','https://example.invalid/bot.zip')
    monkeypatch.setenv('FORCE_REIMPORT','true')
    monkeypatch.setenv('GITHUB_ENV',str(tmp_path/'github-env'))
    monkeypatch.delenv('GITHUB_WORKFLOW_REF',raising=False)
    with pytest.raises((ValueError,SystemExit),match='video_compression.py'):
        importer(workflow)()
    assert not (tmp_path/'github-env').exists()
