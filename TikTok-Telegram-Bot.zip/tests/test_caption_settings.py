"""Full-caption preferences, original-file auto replies, snapshots and recovery."""
import asyncio
import json
from pathlib import Path

import pytest
from aiogram.exceptions import TelegramNetworkError

from bot import Runner
from common import MEDIA_CHOICES, BOT_ATTRIBUTION
from i18n import LANGUAGES, TEXT
from state import State
from test_aiogram import setup, callback
from test_caption_files import POST_ID, POST_URL, FULL_TEXT, caption_buttons, caption_documents


@pytest.mark.asyncio
@pytest.mark.parametrize('mode',MEDIA_CHOICES)
@pytest.mark.parametrize('long',[False,True])
@pytest.mark.parametrize('media',['video','video_document','photo','photo_document','album','album_documents'])
async def test_three_modes_only_apply_to_long_captions(tmp_path,mode,long,media):
    state,session,bot,r=setup(tmp_path)
    state.set('caption:1',mode)
    jid,_=state.submit(1,-10,77,12,POST_URL)
    folder=r.work/'files';folder.mkdir()
    photo=media.startswith(('photo','album'))
    count=11 if media.startswith('album') else 1
    document=media in ('photo_document','album_documents')
    records=[]
    for index in range(count):
        name=f'{index}.jpg' if photo else 'video.mp4'
        (folder/name).write_bytes(b'original media')
        records.append({'file':name,'kind':'image' if photo else 'video','sha256':str(index),
                        'width':12000 if document else 40,'height':60})
    if media=='video_document':session.queue('sendVideo',status=400,description='Unsupported video')
    title=FULL_TEXT if long else 'Short caption'
    async with bot.context():
        await r.deliver(jid,records,folder,title,'Account','tester',POST_ID)
        await r.deliver(jid,records,folder,title,'Account','tester',POST_ID)
    assert len(caption_buttons(session))==int(long and mode=='off')
    assert len(caption_documents(session))==int(long and mode=='on')
    row=state.job(jid)
    assert row['caption_mode']==mode
    if mode=='on' and long:
        request=caption_documents(session)[0]
        assert next(iter(request['files'].values()))=={'filename':POST_ID+'.txt','data':FULL_TEXT.encode('utf-8')}
        assert request['fields']['caption']==BOT_ATTRIBUTION and request['fields']['parse_mode']=='HTML'
        assert request['fields']['chat_id']=='-10' and request['fields']['message_thread_id']=='12'
        assert json.loads(request['fields']['reply_parameters'])['message_id']==row['reply_message']
        assert row['caption_file_message'] and not row['caption_file_in_flight']
    if mode=='off_no_button':
        assert row['caption_text']=='' and not row['caption_button_pending']
    state.close()


@pytest.mark.asyncio
async def test_caption_settings_ownership_default_checkmarks_translations_and_persistence(tmp_path):
    state,session,bot,r=setup(tmp_path)
    assert r.settings_view(1)[1].inline_keyboard[4][0].text=='Full caption: Off'
    assert r.settings_view(1,'caption')[1].inline_keyboard[0][1].text=='✓ Off'
    async with bot.context():
        await r.handle(callback(bot,'settings:1:caption-on',user=2))
        await r.handle(callback(bot,'settings:1:caption-unknown'))
        assert state.get('caption:1') is None
        for language in LANGUAGES:
            state.set('language:1',language)
            await r.handle(callback(bot,'settings:1:caption'))
            assert session.calls('editMessageText')[-1]['fields']['text']==TEXT[language][
                'Automatically send full captions as text files when too long, Off shows a text-file button']
            for mode,label in MEDIA_CHOICES.items():
                await r.handle(callback(bot,'settings:1:caption-'+mode))
                assert state.get('caption:1')==mode
                keyboard=r.settings_view(1,'caption')[1].inline_keyboard
                selected=keyboard[0][0 if mode=='on' else 1] if mode!='off_no_button' else keyboard[1][0]
                assert selected.text=='✓ '+TEXT[language][label]
                assert r.settings_view(1)[1].inline_keyboard[4][0].text==TEXT[language]['Full caption']+': '+TEXT[language][label]
            await r.handle(callback(bot,'settings:1:main'))
    state.close();state=State(tmp_path/'state.db');r.state=state
    assert state.get('caption:1')=='off_no_button' and state.get('caption:2') is None
    state.close()


@pytest.mark.asyncio
async def test_caption_snapshot_is_taken_by_worker_and_survives_preference_changes(tmp_path,monkeypatch):
    state,session,bot,r=setup(tmp_path)
    state.set('caption:1','on')
    jid,_=state.submit(1,-10,77,12,POST_URL)
    async def start(*args,**values):
        folder=Path(args[3]);(folder/'result.json').write_text('{"ok":true,"media":[]}')
        class Process:
            returncode=0
            async def wait(self):return 0
        return Process()
    monkeypatch.setattr(asyncio,'create_subprocess_exec',start)
    async with bot.context():
        await r.worker(state.job(jid),r.work/'first')
        state.set('caption:1','off_no_button')
        await r.worker(state.job(jid),r.work/'retry')
        state.close();state=State(tmp_path/'state.db')
        restored=Runner(state,bot,tmp_path,7,99);restored.api=r.api;r=restored
        await r.worker(state.job(jid),r.work/'after-restart')
        assert state.job(jid)['caption_mode']=='on'
        fresh,_=state.submit(1,-10,88,12,POST_URL)
        await r.worker(state.job(fresh),r.work/'new')
        assert state.job(fresh)['caption_mode']=='off_no_button'
        folder=r.work/'files';folder.mkdir();(folder/'video.mp4').write_bytes(b'media')
        await r.deliver(jid,[{'file':'video.mp4','kind':'video','sha256':'video'}],folder,FULL_TEXT)
        assert len(caption_documents(session))==1 and not caption_buttons(session)
    state.close()


@pytest.mark.asyncio
async def test_older_caption_button_jobs_keep_their_original_mode(tmp_path):
    state,session,bot,r=setup(tmp_path)
    jid,_=state.submit(1,-10,77,12,POST_URL)
    r.caption_files.remember(jid,FULL_TEXT,None,True)
    state.change(jid,status='done',reply_message=301)
    state.db.execute('ALTER TABLE jobs DROP COLUMN caption_mode');state.close()
    state=State(tmp_path/'state.db');state.set('caption:1','on')
    restored=Runner(state,bot,tmp_path,7,99);restored.api=r.api;r=restored
    async with bot.context():
        await r.caption_files.install(jid)
        await r.caption_files.automatic(jid)
    assert state.job(jid)['caption_mode']=='off' and state.job(jid)['caption_text']==FULL_TEXT
    assert len(caption_buttons(session))==1 and not caption_documents(session)
    state.close()


@pytest.mark.asyncio
@pytest.mark.parametrize('failure',[400,413,'network'])
async def test_automatic_caption_recovery_uses_saved_text_and_delivery_receipts(tmp_path,monkeypatch,failure):
    state,session,bot,r=setup(tmp_path)
    state.set('caption:1','on')
    jid,_=state.submit(1,-10,77,12,POST_URL)
    r.caption_files.remember(jid,FULL_TEXT,None,True)
    state.change(jid,status='done',reply_message=301)
    if failure=='network':
        session.responses['sendDocument'].append((200,lambda method:TelegramNetworkError(method=method,message='lost acknowledgement')))
    else:session.queue('sendDocument',status=failure,description='Rejected file')
    async with bot.context():
        await r.caption_files.automatic(jid)
        assert not state.job(jid)['caption_file_message']
        assert bool(state.job(jid)['caption_file_in_flight'])==(failure=='network')
        state.close();state=State(tmp_path/'state.db');state.set('caption:1','off_no_button')
        restored=Runner(state,bot,tmp_path,7,99);restored.api=r.api;r=restored
        async def idle():await r.stop.wait()
        r.polling=idle;r.scheduler=idle;r.broadcasts.run=idle
        monkeypatch.setenv('SESSION_SECONDS','0')
        await r.run()
        assert len(caption_documents(session))==(1 if failure=='network' else 2)
        assert bool(state.job(jid)['caption_file_message'])==(failure!='network')
        assert not caption_buttons(session)
        assert not session.calls('sendVideo') and not session.calls('sendMediaGroup')
    state.close()


@pytest.mark.asyncio
@pytest.mark.parametrize('blocked',['stopping','cancelled'])
async def test_automatic_caption_respects_shutdown_and_cancellation(tmp_path,blocked):
    state,session,bot,r=setup(tmp_path);state.set('caption:1','on')
    jid,_=state.submit(1,-10,77,12,POST_URL)
    r.caption_files.remember(jid,FULL_TEXT,None,True)
    state.change(jid,reply_message=301)
    if blocked=='stopping':r.stop.set()
    else:state.change(jid,status='cancelled')
    async with bot.context():await r.caption_files.automatic(jid)
    assert not caption_documents(session) and not state.job(jid)['caption_file_in_flight']
    state.close()
