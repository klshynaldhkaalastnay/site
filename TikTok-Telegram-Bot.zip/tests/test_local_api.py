import io
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time
from types import SimpleNamespace
import urllib.error
import zipfile

import pytest
import yaml
from cryptography.fernet import InvalidToken

import backup
import local_api
import telegram_api
import telegram_logs
from state import State

ROOT=Path(__file__).resolve().parents[1]


def api_responses(monkeypatch,*responses):
    pending=iter(responses)
    calls=[]
    def request(req,timeout):
        calls.append(req.full_url)
        response=next(pending)
        if isinstance(response,Exception):raise response
        status,payload=response
        body=io.BytesIO(json.dumps(payload).encode())
        if status>=400:raise urllib.error.HTTPError(req.full_url,status,'Private response',{},body)
        return body
    monkeypatch.setattr(local_api.urllib.request,'build_opener',lambda *args:SimpleNamespace(open=request))
    return calls


def fast_clock(monkeypatch):
    current=[0]
    sleeps=[]
    monkeypatch.setattr(local_api.time,'monotonic',lambda:current[0])
    def sleep(seconds):
        sleeps.append(seconds)
        current[0]+=seconds
    monkeypatch.setattr(local_api.time,'sleep',sleep)
    return sleeps


@pytest.fixture
def credentials(tmp_path,monkeypatch):
    monkeypatch.setenv('TELEGRAM_API_ID','12345')
    monkeypatch.setenv('TELEGRAM_API_HASH','a'*32)
    monkeypatch.setenv('TELEGRAM_BOT_TOKEN','123456:LOCAL_TEST_ONLY')
    monkeypatch.setenv('RUNNER_TEMP',str(tmp_path/'runner'))
    monkeypatch.setenv('BOT_DATA_DIR',str(tmp_path/'data'))
    monkeypatch.setenv('GITHUB_ENV',str(tmp_path/'github-env'))
    return tmp_path


def test_local_limits_keep_fifty_mb_compression_threshold(tmp_path):
    script=r'''
from pathlib import Path
from aiogram.client.session.aiohttp import AiohttpSession
from aiogram.client.telegram import TelegramAPIServer
import common,video_compression,i18n,telegram_api,bot
assert common.MAX_BYTES==2_000_000_000
assert telegram_api.UPLOAD_TIMEOUT==3600
assert video_compression.MAX_VIDEO_INPUT_BYTES==2_000_000_000
assert video_compression.DEFAULTS['mode']=='all'
assert video_compression.CHOICES['mode']['large']=='Over 50 MB'
settings=video_compression.options({'mode':'large'})
assert not video_compression.should_compress(50_000_000,settings)
assert video_compression.should_compress(50_000_001,settings)
assert not video_compression.should_compress(100_000_000,{'mode':'none'})
key='This video is too large, the maximum size is 50 MB'
assert '2 GBs' in i18n.translate('en',key)
assert '2 غيغابايت' in i18n.translate('ar',key)
assert i18n.translate('en','Over 50 MB')=='Over 50 MB'
assert all('2' in text and '5' in text and '2000' not in text for text in i18n.HELP.values())
session=AiohttpSession(api=TelegramAPIServer.from_base(telegram_api.api_base(),is_local=True))
assert session.api.api_url('123456:LOCAL_TEST_ONLY','getMe')=='http://127.0.0.1:8081/bot123456:LOCAL_TEST_ONLY/getMe'
path=Path('large.mp4')
with path.open('wb') as out:out.truncate(50_000_001)
records=[{'file':'large.mp4','kind':'video','sha256':'hash'}]
assert bot.Runner.groups(records,Path.cwd())
print('Local upload and compression limits passed')
'''
    result=subprocess.run([sys.executable,'-c',script],cwd=tmp_path,
                          env=dict(os.environ,TELEGRAM_API_BASE=telegram_api.LOCAL_API,PYTHONPATH=str(ROOT)),
                          capture_output=True,text=True,timeout=30)
    assert result.returncode==0,result.stderr


@pytest.mark.parametrize('base',['https://evil.test','http://user:pass@127.0.0.1:8081',
                                  'http://127.0.0.1:8081/path','http://127.0.0.1:9999'])
def test_endpoint_rejects_unapproved_hosts_or_paths(monkeypatch,base):
    monkeypatch.setenv('TELEGRAM_API_BASE',base)
    with pytest.raises(ValueError):telegram_api.api_base()


@pytest.mark.parametrize('status,payload,logged_out,delay',[
    (400,{'ok':False,'description':'Logged out'},True,None),
    (400,{'ok':False,'description':'Bad Request: the bot is already logged out'},True,None),
    (400,{'ok':False,'description':'Bad Request: invalid request'},False,None),
    (429,{'ok':False,'parameters':{'retry_after':125}},False,125),
    (429,{'ok':False,'parameters':{'retry_after':True}},False,None),
    (401,{'ok':False,'description':'123456:LOCAL_TEST_ONLY '+('a'*32)},False,None),
])
def test_control_http_errors_keep_only_safe_status_and_retry_fields(credentials,monkeypatch,status,payload,logged_out,delay):
    from crash_reports import exception_details
    api_responses(monkeypatch,(status,payload))
    with pytest.raises(local_api.TelegramRPCError) as caught:local_api.rpc('logOut',telegram_api.CLOUD_API)
    error=caught.value
    assert error.status==status and error.logged_out==logged_out and error.retry_after==delay
    assert f'HTTP {status}' in str(error)
    assert '123456:LOCAL_TEST_ONLY' not in str(error)+exception_details(error)
    assert 'a'*32 not in str(error)+exception_details(error)


@pytest.mark.parametrize('ending',[True,False])
def test_cloud_logout_honors_cooldown_then_accepts_success_or_logged_out(credentials,monkeypatch,ending):
    calls=api_responses(monkeypatch,
        (429,{'ok':False,'parameters':{'retry_after':125}}),
        (200,{'ok':True,'result':True}) if ending else (400,{'ok':False,'description':'Logged out'}))
    sleeps=fast_clock(monkeypatch)
    local_api.cloud_logout()
    assert sleeps==[60,60,5]
    assert len(calls)==2 and all(url.endswith('/logOut') for url in calls)


def test_repeated_migration_starts_locally_when_cloud_already_logged_out(credentials,monkeypatch):
    api_responses(monkeypatch,(400,{'ok':False,'description':'Logged out'}))
    binary=credentials/'api'
    binary.write_text('unused')
    binary.chmod(0o700)
    monkeypatch.setenv('BOT_API_BINARY',str(binary))
    launched=[]
    monkeypatch.setattr(local_api,'launch',lambda *args:launched.append(args) or 12345)
    local_api.start()
    assert len(launched)==1
    assert 'BOT_API_PID=12345' in (credentials/'github-env').read_text()


def test_invalid_token_fails_before_local_launch_with_useful_safe_status(credentials,monkeypatch,capsys):
    api_responses(monkeypatch,(401,{'ok':False,'description':'Unauthorized 123456:LOCAL_TEST_ONLY'}))
    binary=credentials/'api'
    binary.write_text('unused')
    binary.chmod(0o700)
    monkeypatch.setenv('BOT_API_BINARY',str(binary))
    monkeypatch.setattr(local_api,'launch',lambda *args:pytest.fail('Ignored a rejected bot token'))
    monkeypatch.setattr(sys,'argv',['local_api.py','start'])
    with pytest.raises(SystemExit):local_api.main()
    error=capsys.readouterr().err
    assert 'HTTP 401' in error and 'TELEGRAM_BOT_TOKEN' in error
    assert '123456:LOCAL_TEST_ONLY' not in error and 'https://' not in error


def test_cloud_logout_does_not_wait_indefinitely(credentials,monkeypatch):
    api_responses(monkeypatch,(429,{'ok':False,'parameters':{'retry_after':86400}}))
    sleeps=fast_clock(monkeypatch)
    with pytest.raises(local_api.TelegramRPCError,match='86400'):local_api.cloud_logout()
    assert not sleeps


def test_cloud_logout_retries_transient_transport_and_server_errors(credentials,monkeypatch):
    calls=api_responses(monkeypatch,urllib.error.URLError('PRIVATE'),
                        (503,{'ok':False,'description':'PRIVATE'}),(200,{'ok':True,'result':True}))
    sleeps=fast_clock(monkeypatch)
    local_api.cloud_logout()
    assert sleeps==[1,2] and len(calls)==3


def test_control_errors_inside_json_success_status_are_still_errors(credentials,monkeypatch):
    api_responses(monkeypatch,(200,{'ok':False,'error_code':401,'description':'Unauthorized: invalid api-id/api-hash'}))
    with pytest.raises(local_api.TelegramRPCError,match='TELEGRAM_API_ID and TELEGRAM_API_HASH'):
        local_api.rpc('getMe')


def test_local_authorization_rejection_stops_server_without_polling_until_timeout(credentials,monkeypatch):
    _,runtime,_=local_api.paths()
    binary=credentials/'api'
    binary.write_text('unused')
    binary.chmod(0o700)
    monkeypatch.setattr(local_api.subprocess,'Popen',lambda *a,**k:SimpleNamespace(pid=12345,poll=lambda:None))
    stopped=[]
    monkeypatch.setattr(local_api,'stop_server',lambda *a:stopped.append(a))
    def rejected(*args,**kwargs):
        raise local_api.TelegramRPCError('getMe',telegram_api.LOCAL_API,401,
                                        {'description':'Unauthorized: invalid api-id/api-hash'})
    monkeypatch.setattr(local_api,'rpc',rejected)
    sleeps=fast_clock(monkeypatch)
    with pytest.raises(local_api.TelegramRPCError,match='TELEGRAM_API_ID and TELEGRAM_API_HASH'):
        local_api.launch(runtime,binary)
    assert stopped==[(runtime,binary)] and not sleeps


@pytest.mark.parametrize('delay',[125,86400])
def test_local_authorization_respects_retry_after_with_a_bounded_wait(credentials,monkeypatch,delay):
    _,runtime,_=local_api.paths()
    binary=credentials/'api'
    binary.write_text('unused')
    binary.chmod(0o700)
    monkeypatch.setattr(local_api.subprocess,'Popen',lambda *a,**k:SimpleNamespace(pid=12345,poll=lambda:None))
    stopped=[]
    monkeypatch.setattr(local_api,'stop_server',lambda *args:stopped.append(args))
    attempts=[]
    def request(*args,**kwargs):
        attempts.append(True)
        if len(attempts)==1:
            raise local_api.TelegramRPCError('getMe',telegram_api.LOCAL_API,429,
                                            {'parameters':{'retry_after':delay}})
        return {'id':123456}
    monkeypatch.setattr(local_api,'rpc',request)
    sleeps=fast_clock(monkeypatch)
    if delay==86400:
        with pytest.raises(local_api.TelegramRPCError,match='86400'):local_api.launch(runtime,binary)
        assert not sleeps and len(stopped)==1 and len(attempts)==1
    else:
        assert local_api.launch(runtime,binary)==12345
        assert sleeps==[60,60,5] and not stopped and len(attempts)==2


def test_reports_use_selected_local_endpoint_without_exposing_api_hash(credentials,monkeypatch):
    monkeypatch.setenv('TELEGRAM_API_BASE',telegram_api.LOCAL_API)
    sent=[]
    monkeypatch.setattr(telegram_logs.urllib.request,'urlopen',
                        lambda request,timeout: sent.append(request) or io.BytesIO(b'{"ok":true}'))
    assert telegram_logs.send_document(('key='+'a'*32).encode(),'report.txt','Report')
    assert sent[0].full_url.startswith(telegram_api.LOCAL_API+'/bot')
    assert ('a'*32).encode() not in sent[0].data


def test_encrypted_state_roundtrip_tamper_and_token_rotation(credentials,monkeypatch):
    folder=credentials/'native'
    folder.mkdir()
    (folder/'td.binlog').write_bytes(b'private bot authorization state')
    destination=credentials/'state.enc'
    local_api.save_state(folder,destination)
    assert b'private bot authorization state' not in destination.read_bytes()
    assert destination.stat().st_mode & 0o777==0o600
    monkeypatch.setenv('TELEGRAM_BOT_TOKEN','123456:ROTATED_TEST_ONLY')
    restored=credentials/'restored'
    local_api.restore_state(destination,restored)
    assert (restored/'td.binlog').read_bytes()==b'private bot authorization state'
    damaged=bytearray(destination.read_bytes())
    damaged[len(damaged)//2]^=1
    destination.write_bytes(damaged)
    with pytest.raises(InvalidToken):local_api.restore_state(destination,restored)
    assert (restored/'td.binlog').read_bytes()==b'private bot authorization state'


def test_state_cannot_be_decrypted_with_another_api_hash(credentials,monkeypatch):
    source=credentials/'source'
    source.mkdir()
    (source/'state').write_text('private')
    encrypted=credentials/'state.enc'
    local_api.save_state(source,encrypted)
    monkeypatch.setenv('TELEGRAM_API_HASH','b'*32)
    with pytest.raises(InvalidToken):local_api.restore_state(encrypted,credentials/'restored')


def test_restore_rejects_unsafe_paths_before_writing(credentials):
    output=io.BytesIO()
    with zipfile.ZipFile(output,'w') as archive:archive.writestr('../escape','private')
    encrypted=credentials/'state.enc'
    encrypted.write_bytes(local_api.cipher().encrypt(output.getvalue()))
    with pytest.raises(local_api.SetupError):local_api.restore_state(encrypted,credentials/'restore')
    assert not (credentials/'escape').exists()


def test_state_is_in_r2_backups_but_excluded_from_owner_zip(credentials):
    data=credentials/'data'
    data.mkdir()
    state=State(data/'state.db')
    state.set(local_api.REQUIRED_KEY,'1')
    state.close()
    native=credentials/'native'
    native.mkdir()
    (native/'authorization').write_text('private-native-auth')
    local_api.save_state(native,data/local_api.STATE_NAME)
    r2_archive=credentials/'r2.zip'
    backup.create_archive(data,ROOT,r2_archive,include_api=True)
    with zipfile.ZipFile(r2_archive) as archive:
        assert archive.read('state/telegram-api.enc')==(data/local_api.STATE_NAME).read_bytes()
        assert not any('authorization' in name for name in archive.namelist())
    owner_archive=credentials/'owner.zip'
    backup.create_archive(data,ROOT,owner_archive)
    with zipfile.ZipFile(owner_archive) as archive:
        assert 'state/telegram-api.enc' not in archive.namelist()


@pytest.mark.parametrize('complete',[False,True])
def test_r2_restore_requires_and_restores_the_matching_encrypted_state(credentials,monkeypatch,complete):
    import hashlib
    from types import SimpleNamespace
    data=credentials/'data'
    data.mkdir()
    state=State(data/'state.db')
    state.set(local_api.REQUIRED_KEY,'1')
    jid,_=state.submit(1,1,77,None,'https://www.tiktok.com/@x/video/123')
    state.close()
    (data/local_api.STATE_NAME).write_bytes(b'encrypted-native-session')
    archive=credentials/'r2.zip'
    backup.create_archive(data,ROOT,archive,include_api=complete)
    payload=archive.read_bytes()
    client=SimpleNamespace(get_object=lambda **kwargs:{
        'Metadata':{'sha256':hashlib.sha256(payload).hexdigest()},
        'Body':SimpleNamespace(iter_chunks=lambda size:iter([payload]),close=lambda:None)})
    monkeypatch.setattr(backup,'connection',lambda:(client,'bucket','scope/'))
    monkeypatch.setattr(backup,'managed',lambda *args:[{'Key':'scope/backup-1-test.zip'}])
    destination=credentials/'restored'
    if not complete:
        with pytest.raises(RuntimeError,match='matching local Bot API state'):backup.restore(destination)
        assert not (destination/'state.db').exists()
        return
    backup.restore(destination)
    assert (destination/local_api.STATE_NAME).read_bytes()==b'encrypted-native-session'
    restored=State(destination/'state.db')
    assert restored.job(jid)['status']=='ready' and local_api.required_state(destination)
    restored.close()


def test_stop_refuses_a_pid_that_belongs_to_another_process(credentials,monkeypatch):
    _,runtime,binary=local_api.paths()
    (runtime/'pid').write_text('12345')
    monkeypatch.setattr(local_api,'process_alive',lambda pid:True)
    monkeypatch.setattr(local_api,'owns_server',lambda *args:False)
    monkeypatch.setattr(local_api.os,'kill',lambda *args:pytest.fail('Signalled an unrelated process'))
    with pytest.raises(local_api.SetupError,match='identity changed'):local_api.stop_server(runtime,binary)


def test_lifecycle_stops_encrypts_restarts_and_restores(credentials,monkeypatch):
    data=credentials/'data'
    data.mkdir()
    state=State(data/'state.db')
    state.close()
    binary=credentials/'fake-bot-api'
    binary.write_text(f'#!{sys.executable}\n'+r'''
from pathlib import Path
from http.server import HTTPServer,BaseHTTPRequestHandler
import json,sys,os
directory=Path(next(arg.split('=',1)[1] for arg in sys.argv if arg.startswith('--dir=')))
# Native realpath checks require the supplied files directory to exist.
for name in ('--dir=','--files-dir=','--temp-dir='):
    path=Path(next(arg.split('=',1)[1] for arg in sys.argv if arg.startswith(name)))
    path.resolve(strict=True)
    assert path.is_dir() and path.stat().st_mode & 0o777==0o700
assert os.environ['TELEGRAM_API_ID']==os.environ['TELEGRAM_API_ID'].strip()
assert os.environ['TELEGRAM_API_HASH']==os.environ['TELEGRAM_API_HASH'].strip()
(directory/'td.binlog').write_text('private-native-auth')
class Handler(BaseHTTPRequestHandler):
    def do_POST(self):
        self.rfile.read(int(self.headers.get('Content-Length',0)))
        data=json.dumps({'ok':True,'result':{'id':123456,'is_bot':True,'first_name':'Test'}}).encode()
        self.send_response(200);self.send_header('Content-Length',str(len(data)));self.end_headers();self.wfile.write(data)
    def log_message(self,*args):pass
HTTPServer(('127.0.0.1',8081),Handler).serve_forever()
''')
    binary.chmod(0o700)
    monkeypatch.setenv('BOT_API_BINARY',str(binary))
    monkeypatch.setenv('TELEGRAM_API_ID',' 12345 ')
    monkeypatch.setenv('TELEGRAM_API_HASH',' '+('a'*32)+' ')
    rpc=local_api.rpc
    cloud=[]
    def call(method,base=telegram_api.LOCAL_API,timeout=5):
        if base==telegram_api.CLOUD_API:
            assert method=='logOut'
            cloud.append(method)
            return True
        return rpc(method,base,timeout)
    monkeypatch.setattr(local_api,'rpc',call)
    # This test environment has a host-mounted /proc that does not share child
    # PID namespaces. Track the actual child objects for these two OS probes.
    spawn=local_api.subprocess.Popen
    children={}
    def create(*args,**kwargs):
        child=spawn(*args,**kwargs)
        children[child.pid]=child
        return child
    monkeypatch.setattr(local_api.subprocess,'Popen',create)
    monkeypatch.setattr(local_api,'process_alive',lambda pid:pid in children and children[pid].poll() is None)
    monkeypatch.setattr(local_api,'owns_server',lambda pid,runtime,binary:
                        pid in children and children[pid].args[0]==str(binary)
                        and '--dir='+str(runtime/'db') in children[pid].args)
    try:
        local_api.start()
        _,runtime,_=local_api.paths()
        first=local_api.server_pid(runtime)
        assert local_api.process_alive(first) and cloud==['logOut']
        local_api.checkpoint()
        second=local_api.server_pid(runtime)
        assert second!=first and local_api.process_alive(second)
        assert (data/local_api.STATE_NAME).is_file()
        assert local_api.required_state(data)
        local_api.stop_server(runtime,binary)
        import shutil
        shutil.rmtree(runtime/'db')
        local_api.start()
        assert cloud==['logOut']  # Restored local sessions do not re-register the cloud API.
        assert (runtime/'db/td.binlog').read_text()=='private-native-auth'
    finally:
        _,runtime,_=local_api.paths()
        local_api.stop_server(runtime,binary)


def test_startup_exit_includes_safe_diagnostics_and_clears_dead_pid(credentials,monkeypatch,capsys):
    binary=credentials/'failed-api'
    binary.write_text(f'#!{sys.executable}\n'+r'''
import os,sys
print('Fatal: unable to bind local server',file=sys.stderr)
print(os.environ['TELEGRAM_API_HASH'],file=sys.stderr)
print('https://api.telegram.org/bot'+os.environ['TELEGRAM_BOT_TOKEN']+'/getMe',file=sys.stderr)
sys.exit(23)
''')
    binary.chmod(0o700)
    monkeypatch.setenv('TELEGRAM_API_HASH',' '+('a'*32)+' ')
    monkeypatch.setenv('BOT_API_BINARY',str(binary))
    def unavailable(method,base=telegram_api.LOCAL_API,timeout=5):
        if base==telegram_api.CLOUD_API:return True
        raise ConnectionRefusedError()
    monkeypatch.setattr(local_api,'rpc',unavailable)
    monkeypatch.setattr(sys,'argv',['local_api.py','start'])
    with pytest.raises(SystemExit):local_api.main()
    error=capsys.readouterr().err
    assert 'unable to bind local server' in error and 'exit code 23' in error
    assert '[redacted]' in error
    assert 'a'*32 not in error and '123456:LOCAL_TEST_ONLY' not in error
    _,runtime,_=local_api.paths()
    assert not (runtime/'pid').exists()
    assert (runtime/'startup.log').stat().st_mode & 0o777==0o600


def test_startup_diagnostic_tail_is_bounded_and_drops_partial_secret_lines(credentials,capsys):
    _,runtime,_=local_api.paths()
    (runtime/'startup.log').write_bytes(b'A'*100000+b'\n'+b'123456:LOCAL_TEST_ONLY\n'*1000+b'last safe error\n')
    local_api.startup_diagnostics(runtime)
    error=capsys.readouterr().err
    assert len(error)<6100 and error.endswith('last safe error\n')
    assert 'A' not in error.split('\n',1)[1] and '123456:LOCAL_TEST_ONLY' not in error


def test_startup_rejects_symlinked_runtime_directories(credentials,monkeypatch):
    _,runtime,_=local_api.paths()
    private=credentials/'other'
    private.mkdir()
    (runtime/'files').symlink_to(private,target_is_directory=True)
    binary=credentials/'unused-api'
    binary.write_text('unused')
    binary.chmod(0o700)
    monkeypatch.setattr(local_api.subprocess,'Popen',lambda *a,**k:pytest.fail('Started with a symlinked directory'))
    with pytest.raises(local_api.SetupError,match='Unexpected link'):local_api.launch(runtime,binary)


def test_missing_required_state_does_not_reconnect_from_scratch(credentials,monkeypatch):
    data=credentials/'data'
    data.mkdir()
    state=State(data/'state.db')
    state.set(local_api.REQUIRED_KEY,'1')
    state.close()
    binary=credentials/'fake-api'
    binary.write_text('unused')
    binary.chmod(0o700)
    monkeypatch.setenv('BOT_API_BINARY',str(binary))
    monkeypatch.setattr(local_api,'rpc',lambda *a,**k:pytest.fail('Missing auth state triggered a network request'))
    with pytest.raises(local_api.SetupError,match='matching queue database'):local_api.start()


def test_bad_credentials_show_names_without_values(credentials,monkeypatch,capsys):
    monkeypatch.setenv('TELEGRAM_API_HASH','invalid-private-hash')
    monkeypatch.setattr(sys,'argv',['local_api.py','start'])
    with pytest.raises(SystemExit):local_api.main()
    error=capsys.readouterr().err
    assert 'TELEGRAM_API_HASH' in error and 'invalid-private-hash' not in error


def test_workflow_cache_state_and_loopback_reporting_order():
    workflow=yaml.safe_load((ROOT/'.github/workflows/tik.yml').read_text())
    steps=workflow['jobs']['bot']['steps']
    names=[step['name'] for step in steps]
    assert names.index('Start local Telegram Bot API')<names.index('Run bot')
    assert names.index('Checkpoint encrypted local API state')<names.index('Back up to R2 and verify before pruning')
    assert names.index('Send diagnostics to Telegram')<names.index('Stop local Telegram Bot API')
    for step in steps:
        if 'run' in step:assert len(step['run'])<=21000
    source=next(step for step in steps if step['id']=='api_source')
    assert 'https://github.com/tdlib/telegram-bot-api.git' in source['run']
    cache=next(step for step in steps if step['id']=='api_binary')
    assert cache['with']['path']=='~/.telegram-bot-api'
    assert 'api_source.outputs.sha' in cache['with']['key'] and 'api_source.outputs.platform' in cache['with']['key']
    for name in ('Restore queue cache','Save queue cache'):
        paths=next(step for step in steps if step['name']==name)['with']['path']
        assert 'state/state.db' in paths and 'state/telegram-api.enc' in paths
        assert 'tiktok-local-api' not in paths
