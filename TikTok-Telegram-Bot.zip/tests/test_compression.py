import asyncio
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
from types import SimpleNamespace as NS

import pytest
import requests
from gallery_dl.extractor.common import Message
from bot import Runner
from state import State
from i18n import LANGUAGES, TEXT
from test_audio import FakeBot, Response
import compression
import worker


@pytest.mark.asyncio
async def test_compression_settings_ownership_options_reset_and_restart(tmp_path):
    state=State(tmp_path/'state.db');r=Runner(state,FakeBot(),tmp_path,7,99)
    async def fast(chat,op):return await op()
    r.api=fast
    class Query:
        from_user=NS(id=2);message=NS(chat=NS(id=1),message_id=42);data='settings:1:compress-mode-none'
        async def answer(self):pass
    q=Query();await r.settings_callback(q)
    assert state.get('compression:1') is None
    assert compression.options(state.get('compression:1'))['mode']=='all'
    q.from_user=NS(id=1)
    chosen={'mode':'large','fps':'30','resolution':'720','quality':'small','preset':'slow','audio':'64'}
    for key,value in chosen.items():
        q.data=f'settings:1:compress-{key}-{value}'
        await r.settings_callback(q)
    assert json.loads(state.get('compression:1'))==chosen
    q.data='settings:1:compress-fps-500';await r.settings_callback(q)
    assert json.loads(state.get('compression:1'))==chosen
    state.close();r.state=state=State(tmp_path/'state.db')
    assert compression.options(state.get('compression:1'))==chosen
    assert compression.options(state.get('compression:2'))==compression.DEFAULTS
    for lang in LANGUAGES:
        state.set('language:1',lang)
        for page in ('compression','compress-advanced',*('compress-'+key for key in compression.LABELS)):
            text,markup=r.settings_view(1,page)
            assert text in TEXT[lang].values()
            for row in markup.inline_keyboard:
                for button in row:
                    assert len(button.callback_data.encode())<=64
    q.data='settings:1:compress-reset';await r.settings_callback(q)
    assert compression.options(state.get('compression:1'))==dict(compression.DEFAULTS,mode='large')
    state.close()


@pytest.mark.asyncio
async def test_job_snapshots_options_for_retries_and_recovery(tmp_path,monkeypatch):
    state=State(tmp_path/'state.db');r=Runner(state,FakeBot(),tmp_path,7,99)
    jid,_=state.submit(1,1,1,None,'https://www.tiktok.com/@x/video/123')
    state.set('compression:1',json.dumps({'fps':'30','quality':'high'}))
    captured=[]
    async def start(*args,**kw):
        assert kw['start_new_session']
        captured.append(json.loads(next(a.split('=',1)[1] for a in args if a.startswith('--compression='))))
        folder=Path(args[3]);(folder/'result.json').write_text('{"ok":true,"media":[]}')
        class Process:
            returncode=0
            async def wait(self):return 0
        return Process()
    monkeypatch.setattr(asyncio,'create_subprocess_exec',start)
    stale=state.job(jid)
    await r.worker(stale,r.work/'one')
    state.set('compression:1',json.dumps({'mode':'none','fps':'24'}))
    await r.worker(stale,r.work/'two')
    state.close();r.state=state=State(tmp_path/'state.db');state.recover()
    await r.worker(state.job(jid),r.work/'three')
    assert captured==[dict(compression.DEFAULTS,fps='30',quality='high')]*3
    state.close()


@pytest.mark.asyncio
async def test_encoded_video_receipt_survives_changed_bytes(tmp_path):
    state=State(tmp_path/'state.db');bot=FakeBot();r=Runner(state,bot,tmp_path,7,99)
    async def fast(chat,op):return await op()
    r.api=fast
    jid,_=state.submit(1,-1,77,12,'https://www.tiktok.com/@x/video/123')
    folder=r.work/'media';folder.mkdir();(folder/'video.mp4').write_bytes(b'encoded')
    record={'file':'video.mp4','kind':'video','sha256':'encoded-one','source_sha256':'source',
            'width':480,'height':852,'duration':3,'supports_streaming':True,'manual_audio':True}
    await r.deliver(jid,[record],folder)
    assert bot.media[0]['supports_streaming'] and bot.media[0]['width']==480
    assert bot.media[0]['reply_parameters'].message_id==77
    assert bot.media[0]['reply_markup'].inline_keyboard[0][0].text=='Extract audio'
    state.close();r.state=state=State(tmp_path/'state.db')
    await r.deliver(jid,[dict(record,sha256='encoded-two')],folder)
    assert len(bot.media)==1
    state.close()


@pytest.mark.parametrize('mode,size,encode',[
    ('all',100,True),('all',101,True),('large',100,False),('large',101,True),
    ('none',100,False),('none',101,False)])
def test_worker_compression_modes_and_exact_upload_boundary(tmp_path,monkeypatch,mode,size,encode):
    monkeypatch.setattr(worker,'MAX_BYTES',100);monkeypatch.setattr(compression,'MAX_BYTES',100)
    class Extractor:
        category='tiktok';subcategory='post';session=requests.Session()
        def __iter__(self):yield Message.Url,'https://cdn.example/video',{'type':'video'}
    monkeypatch.setattr(worker.extractor,'find',lambda url:Extractor())
    payload=b'\0\0\0\x18ftypisom'+b'0'*(size-12)
    monkeypatch.setattr(worker,'get',lambda *a,**kw:Response(payload))
    calls=[]
    def compressed(path,settings,note):
        calls.append(settings)
        return path,{'width':40,'height':60,'duration':2}
    monkeypatch.setattr(worker,'compress_video',compressed)
    if mode=='none' and size>100:
        with pytest.raises(worker.TooLarge):
            worker.download('https://www.tiktok.com/@x/video/123',tmp_path,include_audio=False,compression={'mode':mode})
    else:
        result=worker.download('https://www.tiktok.com/@x/video/123',tmp_path,include_audio=False,compression={'mode':mode})
        assert result['ok'] and result['media'][0]['manual_audio']
        assert bool(result['media'][0].get('source_sha256'))==encode
    assert bool(calls)==encode


def test_larger_download_bound_applies_only_to_videos(tmp_path,monkeypatch):
    monkeypatch.setattr(worker,'MAX_BYTES',100);monkeypatch.setattr(worker,'MAX_VIDEO_INPUT_BYTES',200)
    class Extractor:
        category='tiktok';subcategory='post';session=requests.Session()
        kind='video'
        def __iter__(self):yield Message.Url,'https://cdn.example/media',{'type':self.kind}
    monkeypatch.setattr(worker.extractor,'find',lambda url:Extractor())
    monkeypatch.setattr(worker,'get',lambda *a,**kw:Response(b'x'*201))
    with pytest.raises(worker.VideoInputTooLarge):
        worker.download('https://www.tiktok.com/@x/video/123',tmp_path)
    Extractor.kind='image'
    with pytest.raises(worker.TooLarge) as caught:
        worker.download('https://www.tiktok.com/@x/video/123',tmp_path)
    assert not isinstance(caught.value,worker.VideoInputTooLarge)


@pytest.fixture(scope='module')
def real_video(tmp_path_factory):
    if not shutil.which('ffmpeg') or not shutil.which('ffprobe'):
        pytest.fail('FFmpeg and ffprobe are required for compression validation')
    path=tmp_path_factory.mktemp('real-video')/'source.mp4'
    subprocess.run(['ffmpeg','-v','error','-y','-threads','2','-filter_threads','1',
                    '-f','lavfi','-i','testsrc2=size=960x540:rate=60',
                    '-f','lavfi','-i','sine=frequency=440:sample_rate=48000',
                    '-t','3','-c:v','libx264','-preset','ultrafast','-crf','10','-pix_fmt','yuv420p',
                    '-threads','2','-c:a','aac','-b:a','192k',str(path)],check=True,timeout=30,capture_output=True)
    return path


def assert_complete_mp4(path,duration=3):
    info=compression.probe(path)
    assert info['codec']=='h264' and info['pix_fmt']=='yuv420p' and info['audio_codec']=='aac'
    assert abs(info['duration']-duration)<0.2
    data=path.read_bytes()
    assert data.index(b'moov')<data.index(b'mdat')
    subprocess.run(['ffmpeg','-v','error','-i',str(path),'-f','null','-'],check=True,timeout=30,capture_output=True)
    return info


def test_real_quality_encode_preserves_60fps_and_audio(real_video,tmp_path):
    source=tmp_path/'source.mp4';shutil.copy2(real_video,source)
    before=source.stat().st_size
    encoded,info=compression.compress_video(source,compression.DEFAULTS)
    assert encoded.stat().st_size<before and info['fps']==60
    assert info['width']==960 and info['height']==540
    assert_complete_mp4(encoded)
    assert not source.exists() and not list(tmp_path.glob('encode-*'))


def test_real_advanced_frame_rate_resolution_and_quality(real_video,tmp_path):
    source=tmp_path/'source.mp4';shutil.copy2(real_video,source)
    encoded,info=compression.compress_video(source,{'fps':'30','resolution':'480','quality':'small','preset':'medium','audio':'64'})
    assert info['fps']==30 and info['height']<=480 and info['width']<=854
    assert_complete_mp4(encoded)


def test_real_two_pass_fits_limit_without_truncation(real_video,tmp_path,monkeypatch):
    source=tmp_path/'source.mp4';shutil.copy2(real_video,source)
    monkeypatch.setattr(compression,'MAX_BYTES',140000)
    notes=[]
    encoded,info=compression.compress_video(source,{'quality':'high'},lambda stage,reason:notes.append(reason))
    assert 'size_fitting' in notes
    assert encoded.stat().st_size<=140000 and info['fps']==60
    assert_complete_mp4(encoded)
    assert not list(tmp_path.glob('encode-*'))


def test_failed_encode_keeps_source_and_cleans_temporary_files(real_video,tmp_path,monkeypatch):
    source=tmp_path/'source.mp4';shutil.copy2(real_video,source)
    digest=hashlib.sha256(source.read_bytes()).hexdigest()
    def failed(*a,**kw):raise compression.CompressionError('failed')
    monkeypatch.setattr(compression,'run_encoder',failed)
    with pytest.raises(compression.CompressionError):compression.compress_video(source,compression.DEFAULTS)
    assert hashlib.sha256(source.read_bytes()).hexdigest()==digest
    assert not list(tmp_path.glob('encode-*'))


@pytest.mark.parametrize('kind',['silent_portrait','variable_fps','rotated','hdr'])
def test_real_video_compatibility_cases(tmp_path,kind):
    source=tmp_path/'source.mp4'
    vf=['-vf',"select='if(lt(n,30),1,not(mod(n,2)))'"] if kind=='variable_fps' else []
    color=['-color_trc','smpte2084','-color_primaries','bt2020','-colorspace','bt2020nc'] if kind=='hdr' else []
    subprocess.run(['ffmpeg','-v','error','-y','-filter_threads','1','-f','lavfi','-i',
                    'testsrc2=size='+('540x960' if kind=='silent_portrait' else '640x360')+':rate=30',
                    '-t','2',*vf,'-fps_mode','vfr','-c:v','libx264','-preset','ultrafast','-crf','10',
                    '-threads','2','-pix_fmt','yuv420p10le' if kind=='hdr' else 'yuv420p',*color,str(source)],
                   check=True,timeout=30,capture_output=True)
    if kind=='rotated':
        rotated=tmp_path/'rotated.mp4'
        subprocess.run(['ffmpeg','-v','error','-y','-display_rotation:v:0','90','-i',str(source),
                        '-c','copy',str(rotated)],check=True,timeout=30,capture_output=True)
        source=rotated
    def frames(path):
        result=subprocess.run(['ffprobe','-v','error','-select_streams','v:0','-count_frames',
                               '-show_entries','stream=nb_read_frames','-of','json',str(path)],
                              check=True,timeout=30,capture_output=True)
        return int(json.loads(result.stdout)['streams'][0]['nb_read_frames'])
    before=frames(source)
    if kind=='variable_fps':
        saved=tmp_path/'vfr-copy.mp4';shutil.copy2(source,saved)
    encoded,info=compression.compress_video(source,{'quality':'high','resolution':'480'})
    assert info['codec']=='h264' and info['pix_fmt']=='yuv420p' and not info['has_audio']
    assert abs(info['duration']-2)<0.2
    assert frames(encoded)==before
    if kind in ('silent_portrait','rotated'):
        assert info['height']>info['width'] and info['width']<=480
    if kind=='hdr':
        assert info['transfer']=='bt709' and info['primaries']=='bt709'
    subprocess.run(['ffmpeg','-v','error','-i',str(encoded),'-f','null','-'],
                   check=True,timeout=30,capture_output=True)
    if kind=='variable_fps':
        capped,capped_info=compression.compress_video(saved,{'fps':'24','quality':'high'})
        assert abs(capped_info['fps']-24)<0.1


def test_option_validation_rejects_arbitrary_encoder_arguments():
    assert compression.options('{bad')==compression.DEFAULTS
    assert compression.options({'fps':'10000','preset':'-i http://example','audio':['128']})==compression.DEFAULTS
