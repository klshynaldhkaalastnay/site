"""Check template editing and the actual aiogram captions and standard filenames."""
import asyncio
from html import unescape
import json
import re

from aiogram.types import Update
import pytest

from bot import Runner
from common import BOT_ATTRIBUTION
from i18n import LANGUAGES, TEXT
import media_templates as templates
from state import State
from template_settings import EDIT_PROMPT, EDIT_SECONDS, TemplateSettings
from test_aiogram import callback, message, photo_records, setup
from test_send_files import POST_ID, uploaded_files, video_record
from test_subtitles import POST_URL, VIDEO


def store(state, field, template, user=1):
    state.set(TemplateSettings.key(user,field),template)


def inbound(bot, text, *, user=1, mid=77, chat=-10, topic=12, reply=None, **extra):
    values = message(chat,mid,user,text=text,message_thread_id=topic,**extra)
    if reply:
        values['reply_to_message'] = reply
    return Update.model_validate({'update_id':800,'message':values},context={'bot':bot})


@pytest.mark.asyncio
async def test_templates_edit_is_owned_and_scoped_with_validation_preview_and_reset(tmp_path):
    state,session,bot,r = setup(tmp_path)
    state.set('language:1','en');state.set('language:2','en')
    data = '{{.Username}} {{ .PhotoCount }}'
    def tap(action, user=1):
        return callback(bot,'settings:1:'+action,user=user,chat=-10,message_thread_id=12)
    async with bot.context():
        await r.handle(inbound(bot,'/settings'))
        keyboard = json.loads(session.calls('sendMessage')[-1]['fields']['reply_markup'])
        assert keyboard['inline_keyboard'][-1][0]['callback_data']=='settings:1:templates'
        await r.handle(tap('templates'))
        fields = session.calls('editMessageText')[-1]['fields']
        names = [row[0]['text'] for row in json.loads(fields['reply_markup'])['inline_keyboard']]
        assert names==['Video caption','Photo caption','Back']
        await r.handle(tap('tpl-edit-photo_caption',user=2))
        await r.handle(tap('tpl-edit-video_filename'))
        await r.handle(tap('tpl-edit-audio_filename'))
        assert len(session.calls('sendMessage'))==1
        await r.handle(tap('tpl-photo_caption'))
        assert '<blockquote>A sample TikTok caption</blockquote>' in session.calls('editMessageText')[-1]['fields']['text']
        await r.handle(tap('tpl-edit-photo_caption'))
        send = session.calls('sendMessage')[-1]['fields']
        assert json.loads(send['reply_markup'])=={'force_reply':True,'selective':True}
        assert send['message_thread_id']=='12' and 'tg://user?id=1' in send['text']
        prompt = message(-10,session.next_message,bot.id,text=EDIT_PROMPT,message_thread_id=12)
        prompt['from']['is_bot'] = True
        for sender,chat,topic in ((2,-10,12),(1,-10,13),(1,-11,12)):
            await r.handle(inbound(bot,POST_URL,user=sender,chat=chat,topic=topic,reply=prompt))
        assert not state.outstanding() and not state.get(TemplateSettings.key(1,'photo_caption'))
        await r.handle(inbound(bot,'{{.DoesNotExist}}',mid=78,reply=prompt))
        assert 'Use only placeholders' in session.calls('sendMessage')[-1]['fields']['text']
        assert not r.templates.preference(1,'photo_caption')
        await r.handle(inbound(bot,data,mid=79,reply=prompt))
        saved = session.calls('sendMessage')[-1]['fields']['text']
        assert 'Template saved' in saved and 'creator 3' in saved
        assert r.templates.preference(1,'photo_caption')==data
        assert not state.outstanding()
    state.close()
    state = State(tmp_path/'state.db')
    rebuilt = Runner(state,bot,tmp_path,7,99);rebuilt.api = r.api
    assert rebuilt.templates.preference(1,'photo_caption')==data
    assert rebuilt.templates.panel(1)[1].inline_keyboard[1][0].text=='✓ Photo caption'
    async with bot.context():
        await rebuilt.handle(tap('tpl-reset-photo_caption'))
    assert rebuilt.templates.preference(1,'photo_caption') is None
    assert '<blockquote>A sample TikTok caption</blockquote>' in session.calls('editMessageText')[-1]['fields']['text']
    state.close()


@pytest.mark.asyncio
@pytest.mark.parametrize('close_edit',['cancel','expire','restart'])
async def test_cancelled_expired_or_stale_editor_does_not_save_or_queue_a_reply(tmp_path,monkeypatch,close_edit):
    state,session,bot,r = setup(tmp_path)
    state.set('language:1','en')
    prev = 'before {{.Title}}'
    store(state,'video_caption',prev)
    async with bot.context():
        await r.handle(callback(bot,'settings:1:tpl-edit-video_caption',chat=-10,message_thread_id=12))
        prompt = message(-10,session.next_message,bot.id,text=EDIT_PROMPT,message_thread_id=12)
        prompt['from']['is_bot'] = True
        if close_edit=='cancel':
            await r.handle(inbound(bot,'/cancel',reply=prompt))
            assert 'Template edit cancelled' in session.calls('sendMessage')[-1]['fields']['text']
        elif close_edit=='expire':
            edit = r.templates.pending[(1,-10,12)]
            with monkeypatch.context() as patch:
                patch.setattr('template_settings.time.monotonic',lambda:edit.expires+EDIT_SECONDS)
                await r.handle(inbound(bot,'expire {{.Title}}',reply=prompt))
            assert 'Template edit expired' in session.calls('sendMessage')[-1]['fields']['text']
        else:
            rebuilt=Runner(state,bot,tmp_path,7,99);rebuilt.api=r.api;r=rebuilt
        await r.handle(inbound(bot,POST_URL,mid=78,reply=prompt))
        assert not state.outstanding() and r.templates.preference(1,'video_caption')==prev
        await r.handle(inbound(bot,POST_URL,mid=79))
        assert len(state.outstanding(1))==1
    state.close()


@pytest.mark.asyncio
@pytest.mark.parametrize('mode',['on','both','off_no_button'])
async def test_custom_video_caption_ignores_legacy_filename_settings(tmp_path,mode):
    state,session,bot,r = setup(tmp_path)
    state.set('files:1',mode)
    custom_caption = '@{{.Username}} | {{.DurationSeconds}}s\n{{.Caption}}\n{{.URL}}'
    store(state,'video_caption',custom_caption)
    store(state,'video_filename','{{.Author}}-{{.PostID}}.{{.Ext}}')
    store(state,'audio_filename','{{.PostID}}_{{.SoundID}}_{{.SoundArtist}}.{{.Ext}}')
    short = 'https://vt.tiktok.com/example/'
    jid,_ = state.submit(1,-10,77,12,short)
    if mode=='both':
        state.change(jid,media_templates=json.dumps({
            'video_caption':custom_caption,'video_filename':'ignored','audio_filename':'ignored'}))
    assert r.templates.snapshot(jid)=={'video_caption':custom_caption}
    folder = r.work/'video';folder.mkdir()
    video = video_record(folder)
    (folder/'sound.m4a').write_bytes(b'unchanged audio')
    audio = {'kind':'audio','file':'sound.m4a','filename':'Original title.m4a','title':'Original title',
             'performer':'Artist','sound_id':'555','sha256':'sound','duration':4}
    async with bot.context():
        await r.deliver(jid,[video,audio],folder,'<b>raw & title</b> {{.PostID}}','A/B','@user',POST_ID)
    video_request = session.calls('sendDocument' if mode=='on' else 'sendVideo')[0]
    assert uploaded_files(video_request)==[((POST_ID if mode=='on' else '123')+'.mp4',VIDEO)]
    assert video_request['fields']['caption']==(
        f'@user | 3s\n&lt;b&gt;raw &amp; title&lt;/b&gt; {{{{.PostID}}}}\n{short}\n\n'+BOT_ATTRIBUTION)
    assert json.loads(video_request['fields']['reply_parameters'])['message_id']==77
    documents = session.calls('sendDocument')
    assert len(documents)==int(mode in ('both','on'))
    if mode=='both':
        assert uploaded_files(documents[0])==[(POST_ID+'.mp4',VIDEO)]
        assert documents[0]['fields']['caption']==BOT_ATTRIBUTION
    sound, = session.calls('sendAudio')
    assert uploaded_files(sound)==[('Original title.m4a',b'unchanged audio')]
    assert sound['fields']['title']=='Original title' and sound['fields']['performer']=='Artist'
    assert json.loads(sound['fields']['reply_parameters'])['message_id']==state.job(jid)['reply_message']
    assert (folder/'123.mp4').is_file() and (folder/'sound.m4a').is_file()
    state.close()


@pytest.mark.asyncio
@pytest.mark.parametrize('count',[1,11])
async def test_photo_template_preserves_single_filename_and_numbered_album_replies(tmp_path,count):
    state,session,bot,r = setup(tmp_path)
    state.set('files:1','on')
    store(state,'photo_filename','ignored')
    store(state,'photo_caption','{{.PhotoCount}} by {{.Author}}')
    store(state,'video_caption','wrong caption field')
    jid,_ = state.submit(1,-10,77,12,POST_URL)
    folder = r.work/'photos';folder.mkdir()
    records = photo_records(folder,count,document=True)
    async with bot.context():
        await r.deliver(jid,records,folder,'Post title','Account')
    last, = session.calls('sendDocument')
    if count==1:
        assert uploaded_files(last)==[(POST_ID+'.webp',b'image 0')]
        assert last['fields']['caption']=='1 by Account\n\n'+BOT_ATTRIBUTION
        assert not session.calls('sendMediaGroup')
    else:
        first, = session.calls('sendMediaGroup')
        assert json.loads(first['fields']['media'])[0]['caption']=='11 by Account\n\n'+BOT_ATTRIBUTION
        assert uploaded_files(first)+uploaded_files(last)==[
            (f'{POST_ID}_{i+1:02d}.webp',f'image {i}'.encode()) for i in range(count)]
        assert last['fields']['caption']==BOT_ATTRIBUTION
        assert json.loads(last['fields']['reply_parameters'])['message_id']==state.job(jid)['reply_message']
    state.close()


@pytest.mark.asyncio
async def test_caption_limit_keeps_attribution_and_full_caption_file(tmp_path):
    state,session,bot,r = setup(tmp_path)
    state.set('caption:1','on')
    store(state,'video_caption','{{.Title}}\n{{.Title}}')
    title = '🎞️ & <title> ' * 50
    jid,_ = state.submit(1,1,77,None,POST_URL)
    folder = r.work/'video';folder.mkdir()
    async with bot.context():
        await r.deliver(jid,[video_record(folder)],folder,title)
    caption = session.calls('sendVideo')[0]['fields']['caption']
    assert caption.endswith(BOT_ATTRIBUTION) and '…\n\n' in caption
    assert templates.utf16_units(unescape(re.sub(r'<[^>]+>','',caption)))<=1024
    document, = session.calls('sendDocument')
    assert uploaded_files(document)==[(POST_ID+'.txt',title.encode())]
    state.close()


@pytest.mark.asyncio
async def test_in_progress_post_keeps_its_template_snapshot_after_restart(tmp_path,monkeypatch):
    state,session,bot,r = setup(tmp_path)
    state.set('files:1','on')
    store(state,'photo_caption','old {{.PostID}}')
    jid,_ = state.submit(1,-10,77,12,POST_URL)
    state.change(jid,status='running')
    folder = r.work/'album';folder.mkdir()
    status = r.status
    async def stop_after_batch(jid,text):
        if session.calls('sendMediaGroup'):
            raise asyncio.CancelledError()
        await status(jid,text)
    monkeypatch.setattr(r,'status',stop_after_batch)
    async with bot.context():
        with pytest.raises(asyncio.CancelledError):
            await r.deliver(jid,photo_records(folder,11),folder)
        store(state,'photo_caption','changed')
        state.close();state=State(tmp_path/'state.db');state.recover()
        rebuilt=Runner(state,bot,tmp_path,7,99);rebuilt.api=r.api
        assert rebuilt.templates.snapshot(jid)=={'photo_caption':'old {{.PostID}}'}
        folder=rebuilt.work/'album';folder.mkdir()
        await rebuilt.deliver(jid,photo_records(folder,11),folder)
    last,=session.calls('sendDocument')
    assert len(session.calls('sendMediaGroup'))==1
    assert uploaded_files(last)==[(f'{POST_ID}_11.jpg',b'image 10')]
    assert last['fields']['caption']==BOT_ATTRIBUTION
    state.close()


def test_templates_migrate_as_additive_state_and_preserve_old_receipts(tmp_path):
    state = State(tmp_path/'state.db')
    jid,_ = state.submit(1,1,77,None,POST_URL)
    state.change(jid,status='running',sent='["0:old"]',reply_message=201)
    store(state,'video_caption','custom')
    state.db.execute('ALTER TABLE jobs DROP COLUMN media_templates')
    before = dict(state.job(jid))
    state.close()
    state = State(tmp_path/'state.db')
    assert dict(state.job(jid))==dict(before,media_templates=None)
    assert state.get(TemplateSettings.key(1,'video_caption'))=='custom'
    r = Runner(state,None,tmp_path,7,99)
    assert r.templates.snapshot(jid)=={}
    state.recover()
    assert state.job(jid)['status']=='ready' and state.job(jid)['sent']=='["0:old"]'
    state.close()


@pytest.mark.parametrize('bad',['{{.Unknown}}','{{if .Title}}','{{.Title','x}}','a\0b','🎞'*513])
def test_invalid_templates_are_rejected(bad):
    with pytest.raises(templates.TemplateError):
        templates.validate('video_caption',bad)


def test_translations_and_callback_size_for_each_field(tmp_path):
    state,session,bot,r = setup(tmp_path)
    user = 1234567890123456789
    for language in LANGUAGES:
        state.set(f'language:{user}',language)
        assert TEXT[language][EDIT_PROMPT]
        for field, label in templates.FIELDS.items():
            store(state,field,templates.EXAMPLES[field],user)
            panel, keyboard = r.templates.panel(user,field)
            assert TEXT[language][label] in panel and '<code>{{.PostID}}</code>' in panel
            assert all(len(button.callback_data.encode())<=64 for line in keyboard.inline_keyboard for button in line)
    state.close()
