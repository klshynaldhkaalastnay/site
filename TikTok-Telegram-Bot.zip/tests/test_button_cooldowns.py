"""Durable 100-second action timers, repeat requests and old-database migration."""
import asyncio
import json

import pytest

from bot import Runner
from common import BOT_ATTRIBUTION
from i18n import LANGUAGES, TEXT
from state import State
from test_aiogram import setup, callback
from test_caption_files import source, FULL_TEXT, POST_ID, caption_documents
from test_subtitles import POST_URL, extracted_post
import worker


@pytest.fixture
def clock(monkeypatch):
    now=[2000000000.0]
    monkeypatch.setattr('state.time.time',lambda:now[0])
    return now


def action(bot,state,jid,kind,**overrides):
    row=state.job(jid)
    prefix={'audio':'extract','subtitles':'extract_subtitles','caption':'caption'}[kind]
    values={'chat':row['chat_id'],'mid':row['caption_button_message'] if kind=='caption' else row['reply_message'],
            'message_thread_id':row['thread_id']}
    values.update(overrides)
    return callback(bot,f'{prefix}:{jid}',**values)


def controls(state,r):
    jid=source(state,r)
    state.change(jid,manual_audio=1,manual_subtitles=1,audio_button_message=301,subtitle_button_message=301)
    return jid


@pytest.mark.asyncio
@pytest.mark.parametrize('kind',['audio','subtitles'])
async def test_extraction_repeats_at_boundary_with_new_job_and_original_reply(tmp_path,monkeypatch,clock,kind):
    requested=extracted_post(monkeypatch)
    state,session,bot,r=setup(tmp_path);jid=controls(state,r)
    async with bot.context():
        first=action(bot,state,jid,kind)
        await r.handle(first)
        old=state.outstanding(1)[0]
        folder=r.work/str(old['id']);folder.mkdir()
        result=worker.download(POST_URL,folder,audio_only=kind=='audio',subtitles_only=kind=='subtitles')
        assert result['ok']
        await r.deliver(old['id'],result['media'],folder)
        state.change(old['id'],status='done')
        receipt=state.job(old['id'])['sent']
        assert receipt!='[]'
        clock[0]+=99
        await r.handle(action(bot,state,jid,kind))
        assert not state.outstanding(1)
        assert session.calls('answerCallbackQuery')[-1]['fields']['text']=='Try this button again in 0:01 (min:sec)'
        assert state.button_remaining(jid,kind)==1
        # Reload with no retained downloaded files. The last tap does not reset time.
        state.close();state=State(tmp_path/'state.db')
        restored=Runner(state,bot,tmp_path,7,99);restored.api=r.api;r=restored
        assert not folder.exists() and state.button_remaining(jid,kind)==1
        clock[0]+=1
        second=action(bot,state,jid,kind);await r.handle(second)
        new=state.outstanding(1)[0]
        assert new['id']!=old['id'] and new['request_token']==second.callback_query.id
        assert new['message_id']==301 and new['thread_id']==12
        assert state.job(old['id'])['sent']==receipt
        assert state.button_remaining(jid,kind)==100
        folder=r.work/str(new['id']);folder.mkdir()
        result=worker.download(POST_URL,folder,audio_only=kind=='audio',subtitles_only=kind=='subtitles')
        await r.deliver(new['id'],result['media'],folder)
        await r.deliver(new['id'],result['media'],folder)
        state.change(new['id'],status='done')
        uploads=session.calls('sendAudio' if kind=='audio' else 'sendDocument')
        assert len(uploads)==(2 if kind=='audio' else 6)
        assert all(json.loads(upload['fields']['reply_parameters'])['message_id']==301 for upload in uploads)
        assert all(upload['fields']['caption']==BOT_ATTRIBUTION for upload in uploads)
        assert not session.calls('sendVideo') and not session.calls('sendPhoto')
        assert all('video.mp4' not in url and 'photo.jpg' not in url for url in requested)
        # Replaying an earlier Telegram callback never creates another request.
        clock[0]+=100
        await r.handle(first);await r.handle(second)
        assert not state.outstanding(1)
        assert 'already received' in session.calls('answerCallbackQuery')[-1]['fields']['text']
    state.close()


@pytest.mark.asyncio
async def test_caption_repeats_after_restart_and_retains_each_receipt(tmp_path,clock):
    state,session,bot,r=setup(tmp_path);jid=controls(state,r)
    async with bot.context():
        await r.caption_files.install(jid)
        first=action(bot,state,jid,'caption');await r.handle(first)
        old_message=state.job(jid)['caption_file_message']
        assert state.button_press(first.callback_query.id)['file_message']==old_message
        await r.handle(action(bot,state,jid,'caption'))
        assert len(caption_documents(session))==1
        assert session.calls('answerCallbackQuery')[-1]['fields']['text']=='Try this button again in 1:40 (min:sec)'
        clock[0]+=99
        state.close();state=State(tmp_path/'state.db')
        restored=Runner(state,bot,tmp_path,7,99);restored.api=r.api;r=restored
        await r.handle(action(bot,state,jid,'caption'))
        assert len(caption_documents(session))==1 and state.button_remaining(jid,'caption')==1
        clock[0]+=1
        second=action(bot,state,jid,'caption');await r.handle(second)
        documents=caption_documents(session)
        assert len(documents)==2
        for document in documents:
            assert next(iter(document['files'].values()))=={'filename':POST_ID+'.txt','data':FULL_TEXT.encode('utf-8')}
            assert document['fields']['caption']==BOT_ATTRIBUTION and document['fields']['message_thread_id']=='12'
            assert json.loads(document['fields']['reply_parameters'])['message_id']==301
        assert state.button_press(first.callback_query.id)['file_message']==old_message
        assert state.button_press(second.callback_query.id)['file_message']!=old_message
        assert state.job(jid)['caption_file_message']==state.button_press(second.callback_query.id)['file_message']
    state.close()


@pytest.mark.asyncio
async def test_three_actions_and_other_messages_have_separate_timers_and_settings_still_work(tmp_path,clock):
    state,session,bot,r=setup(tmp_path);jid=controls(state,r)
    other,_=state.submit(1,-10,78,12,POST_URL)
    state.change(other,status='done',reply_message=302,manual_audio=1,audio_button_message=302)
    async with bot.context():
        await r.caption_files.install(jid)
        for kind in ('audio','subtitles','caption'):
            await r.handle(action(bot,state,jid,kind))
            assert state.button_remaining(jid,kind)==100
        assert len(state.outstanding(1))==2 and len(caption_documents(session))==1
        await r.handle(action(bot,state,other,'audio'))
        assert len(state.outstanding(1))==3
        for choice in ('on','off_no_button','off'):
            await r.handle(callback(bot,'settings:1:caption-'+choice))
            assert state.get('caption:1')==choice
        assert state.db.execute('SELECT COUNT(*) FROM button_presses').fetchone()[0]==4
    state.close()


@pytest.mark.asyncio
@pytest.mark.parametrize('kind',['audio','subtitles','caption'])
async def test_invalid_owner_or_restart_does_not_start_a_timer(tmp_path,clock,kind):
    state,session,bot,r=setup(tmp_path);jid=controls(state,r)
    async with bot.context():
        await r.caption_files.install(jid)
        for overrides in ({'user':2},{'chat':-20},{'mid':999}):
            await r.handle(action(bot,state,jid,kind,**overrides))
            assert state.button_remaining(jid,kind)==0
        r.stop.set();await r.handle(action(bot,state,jid,kind))
        assert state.button_remaining(jid,kind)==0
        assert not state.outstanding(1) and not caption_documents(session)
    state.close()


@pytest.mark.asyncio
@pytest.mark.parametrize('kind',['audio','subtitles'])
async def test_full_queue_does_not_start_timer_but_queued_admission_does(tmp_path,clock,kind):
    state,session,bot,r=setup(tmp_path);jid=controls(state,r)
    for i in range(8):state.submit(1,1,100+i,None,POST_URL+str(i))
    async with bot.context():
        first=action(bot,state,jid,kind);await r.handle(first)
        assert state.button_remaining(jid,kind)==0 and not state.button_press(first.callback_query.id)
        assert 'queue is full' in session.calls('answerCallbackQuery')[-1]['fields']['text']
        queued=[row for row in state.outstanding(1) if row['status']=='queued']
        state.change(queued[0]['id'],status='cancelled')
        await r.handle(first)
        assert state.button_remaining(jid,kind)==100
        new=state.outstanding(1)[-1]
        assert new['status']=='queued' and new['request_token']==first.callback_query.id
    state.close()


@pytest.mark.asyncio
async def test_late_caption_acknowledgement_preserves_the_latest_request(tmp_path,clock):
    state,session,bot,r=setup(tmp_path);jid=controls(state,r)
    async with bot.context():
        await r.caption_files.install(jid)
        entered=asyncio.Event();release=asyncio.Event();fast=r.api
        async def delayed(chat,operation):
            entered.set();await release.wait();return await operation()
        r.api=delayed
        first=action(bot,state,jid,'caption')
        task=asyncio.create_task(r.handle(first));await asyncio.wait_for(entered.wait(),1)
        clock[0]+=100;r.api=fast
        second=action(bot,state,jid,'caption');await r.handle(second)
        latest_message=state.job(jid)['caption_file_message']
        release.set();await task
        assert len(caption_documents(session))==2
        assert state.job(jid)['caption_request_token']==second.callback_query.id
        assert state.job(jid)['caption_file_message']==latest_message
        assert state.button_press(first.callback_query.id)['file_message']!=latest_message
    state.close()


@pytest.mark.parametrize('constraint',['UNIQUE(chat_id,message_id,url)',
                                       'UNIQUE(chat_id,message_id,url,audio_only,subtitles_only)'])
def test_migration_preserves_old_jobs_receipts_and_cooldowns(tmp_path,clock,constraint):
    state=State(tmp_path/'state.db')
    jid,_=state.submit(1,-10,77,12,POST_URL)
    state.change(jid,status='done',reply_message=301,manual_audio=1,manual_subtitles=1,
                 caption_mode='off',caption_text=FULL_TEXT,caption_post_id=POST_ID,caption_file_message=501)
    audio,_=state.submit(1,-10,301,12,POST_URL,audio_only=True)
    state.change(audio,status='done',sent='["audio:receipt"]')
    state.set('language:1','fa')
    before=[dict(row) for row in state.db.execute('SELECT * FROM jobs ORDER BY id')]
    definition=state.db.execute("SELECT sql FROM sqlite_master WHERE name='jobs'").fetchone()[0]
    legacy=definition.replace('UNIQUE(chat_id,message_id,url,audio_only,subtitles_only,request_token)',constraint)
    legacy=legacy.replace('CREATE TABLE jobs','CREATE TABLE legacy_jobs',1)
    with state.db:
        state.db.execute(legacy);state.db.execute('INSERT INTO legacy_jobs SELECT * FROM jobs')
        state.db.execute('DROP TABLE jobs');state.db.execute('ALTER TABLE legacy_jobs RENAME TO jobs')
        state.db.execute('ALTER TABLE jobs DROP COLUMN request_token')
        state.db.execute('ALTER TABLE jobs DROP COLUMN caption_request_token')
        state.db.execute('DROP TABLE button_presses')
    clock[0]+=60
    state.close();state=State(tmp_path/'state.db')
    assert before==[dict(row) for row in state.db.execute('SELECT * FROM jobs ORDER BY id')]
    assert state.get('language:1')=='fa'
    assert state.button_remaining(jid,'audio')==40
    assert state.button_remaining(jid,'caption')==100
    assert state.button_remaining(jid,'subtitles')==0
    clock[0]+=60
    state.close();state=State(tmp_path/'state.db')
    assert state.button_remaining(jid,'caption')==40
    clock[0]+=40
    new,fresh=state.submit(1,-10,301,12,POST_URL,audio_only=True,request_token='new-click',button_source=jid)
    assert fresh and new!=audio and state.job(audio)['sent']=='["audio:receipt"]'
    assert state.submit(1,-10,77,12,POST_URL)==(jid,False)
    assert state.submit(1,-10,301,12,POST_URL,audio_only=True,request_token='new-click',button_source=jid)==(new,False)
    state.close()


@pytest.mark.asyncio
@pytest.mark.parametrize('language',LANGUAGES)
async def test_cooldown_alert_is_translated_and_does_not_extend_timer(tmp_path,clock,language):
    state,session,bot,r=setup(tmp_path);jid=controls(state,r)
    state.set('language:1',language)
    async with bot.context():
        await r.handle(action(bot,state,jid,'audio'))
        clock[0]+=65
        await r.handle(action(bot,state,jid,'audio'))
        answer=session.calls('answerCallbackQuery')[-1]['fields']
        assert answer['text']==TEXT[language]['Try this button again in {time} (min:sec)'].format(time='0:35')
        assert json.loads(answer['show_alert']) and state.button_remaining(jid,'audio')==35
    state.close()
