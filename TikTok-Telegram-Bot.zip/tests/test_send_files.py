"""Document delivery, owned file requests and their durable admission/receipts."""
import asyncio
import json
from pathlib import Path

import pytest

from bot import Runner
from common import FILES_CHOICES, MEDIA_CHOICES, BOT_ATTRIBUTION
from i18n import LANGUAGES, TEXT
from state import State
from test_aiogram import setup, callback, message, photo_records
from test_subtitles import POST_URL, extracted_post, VIDEO
from video_compression import options
import worker

POST_ID = '1234567890'


def video_record(folder):
    (folder/'123.mp4').write_bytes(VIDEO)
    return {'file':'123.mp4','kind':'video','sha256':'video','width':40,'height':60,'duration':3}


def controls(session):
    return [request for request in session.calls('sendMessage') if 'reply_markup' in request['fields']]


def uploaded_files(request):
    return [(file['filename'],file['data']) for file in request['files'].values()]


async def source(state,session,runner,mode='off',photos=0):
    state.set('files:1',mode)
    jid,_=state.submit(1,-10,77,12,POST_URL)
    state.change(jid,status_message=66,compression=json.dumps({'mode':'none','fps':'24'}))
    folder=runner.work/'source';folder.mkdir(exist_ok=True)
    records=photo_records(folder,photos) if photos else [video_record(folder)]
    for index,group in enumerate(range(0,len(records),10)):
        count=min(10,len(records)-group)
        mid=201+index*200
        if count>1:
            session.queue('sendMediaGroup',[message(-10,mid+i) for i in range(count)])
        else:
            session.queue('sendDocument' if mode=='on' else 'sendPhoto' if photos else 'sendVideo',message(-10,mid))
    await runner.deliver(jid,records,folder,'Post title','Account','tester')
    state.change(jid,status='done')
    return jid,records


@pytest.mark.asyncio
@pytest.mark.parametrize('mode',MEDIA_CHOICES)
@pytest.mark.parametrize('photos',[0,1,23])
async def test_all_modes_upload_the_correct_unchanged_bytes_and_chain_ten_file_batches(tmp_path,mode,photos):
    state,session,bot,runner=setup(tmp_path)
    async with bot.context():
        jid,records=await source(state,session,runner,mode,photos)
        uploads=[request for request in session.requests if request['api'] in
                 ('sendDocument','sendVideo','sendPhoto','sendMediaGroup')]
        assert [len(request['files']) for request in uploads]==([10,10,3] if photos==23 else [1])
        expected={f'image {i}'.encode() for i in range(photos)} if photos else {VIDEO}
        assert {file['data'] for request in uploads for file in request['files'].values()}==expected
        if mode=='on':
            names=[file['filename'] for request in uploads for file in request['files'].values()]
            assert names==([f'{POST_ID}_{i:02d}.jpg' for i in range(1,24)] if photos==23 else
                           [f'{POST_ID}.jpg' if photos else f'{POST_ID}.mp4'])
        for index,request in enumerate(uploads):
            fields=request['fields']
            assert fields['message_thread_id']=='12'
            assert json.loads(fields['reply_parameters'])['message_id']==([77,201,401][index])
            if request['api']=='sendMediaGroup':
                media=json.loads(fields['media'])
                assert all(item['type']==('document' if mode=='on' else 'photo') for item in media)
                if mode=='on':assert all(item['disable_content_type_detection'] for item in media)
                caption=media[0]['caption']
            else:
                assert request['api']==('sendDocument' if mode=='on' else 'sendPhoto' if photos else 'sendVideo')
                if mode=='on':assert json.loads(fields['disable_content_type_detection'])
                caption=fields['caption']
            assert caption==(runner.media_caption('Post title','Account','tester') if index==0 else BOT_ATTRIBUTION)
        buttons=controls(session)
        assert len(buttons)==int(mode=='off')
        if buttons:
            fields=buttons[0]['fields']
            assert fields['text']==BOT_ATTRIBUTION
            assert json.loads(fields['reply_parameters'])['message_id']==201
            assert fields['message_thread_id']=='12'
            assert json.loads(fields['link_preview_options'])['is_disabled']
            assert json.loads(fields['reply_markup'])=={'inline_keyboard':[[{
                'text':'Send as files','callback_data':f'files:{jid}'}]]}
        before=len(uploads)
        state.set('files:1','on' if mode!='on' else 'off')
        await runner.deliver(jid,records,runner.work/'source')
        assert sum(request['api'] in ('sendDocument','sendVideo','sendPhoto','sendMediaGroup')
                   for request in session.requests)==before
        assert len(controls(session))==int(mode=='off')
        assert state.job(jid)['files_mode']==mode
    state.close()


@pytest.mark.asyncio
async def test_setting_defaults_ownership_all_languages_and_persistence(tmp_path):
    state,session,bot,runner=setup(tmp_path)
    assert runner.settings_view(1,'files')[1].inline_keyboard[1][0].text=='✓ Off with no button'
    async with bot.context():
        await runner.handle(callback(bot,'settings:1:files-both',user=2))
        assert state.get('files:1') is None
        for setting in ('audio','subtitles','caption','metadata'):
            await runner.handle(callback(bot,f'settings:1:{setting}-both'))
            assert state.get(f'{setting}:1') is None
        for language in LANGUAGES:
            state.set('language:1',language)
            for mode in FILES_CHOICES:
                await runner.handle(callback(bot,f'settings:1:files-{mode}'))
                assert state.get('files:1')==mode
                fields=session.calls('editMessageText')[-1]['fields']
                keyboard=json.loads(fields['reply_markup'])['inline_keyboard']
                marked=[button['text'] for row in keyboard for button in row if button['text'].startswith('✓ ')]
                assert marked==['✓ '+TEXT[language][FILES_CHOICES[mode]]]
                assert all(len(button['callback_data'].encode())<=64 for row in keyboard for button in row)
                label=next(button.text for row in runner.settings_view(1)[1].inline_keyboard for button in row
                           if button.callback_data.endswith(':files'))
                assert label==TEXT[language]['Send as files']+': '+TEXT[language][FILES_CHOICES[mode]]
        await runner.handle(callback(bot,'settings:1:files-unknown'))
        assert state.get('files:1')=='both'
    state.close();state=State(tmp_path/'state.db')
    assert state.get('files:1')=='both'
    state.close()


@pytest.mark.asyncio
async def test_both_delivers_the_same_video_with_one_download_and_one_set_of_extras(tmp_path,monkeypatch):
    state,session,bot,runner=setup(tmp_path)
    for setting,value in (('files','both'),('audio','on'),('subtitles','on'),('caption','on'),('metadata','on')):
        state.set(f'{setting}:1',value)
    jid,_=state.submit(1,-10,77,12,'https://vt.tiktok.com/example/')
    state.change(jid,status='running')
    downloads=[]
    title='Long caption '*100
    async def download(row,folder):
        downloads.append(row['url'])
        folder.mkdir()
        video=dict(video_record(folder),file='0001.compressed.mp4')
        (folder/'123.mp4').rename(folder/video['file'])
        (folder/'sound.mp3').write_bytes(b'audio')
        (folder/'subtitle.vtt').write_bytes(b'WEBVTT\n')
        return {'ok':True,'post_id':POST_ID,'title':title,'full_metadata':{'id':POST_ID},
                'media':[video,{'kind':'audio','file':'sound.mp3','sha256':'audio'},
                         {'kind':'subtitle','file':'subtitle.vtt','sha256':'subtitle'}]}
    monkeypatch.setattr(runner,'worker',download)
    session.queue('sendVideo',message(-10,201))
    async with bot.context():
        await runner.run_job(jid)
    video,=session.calls('sendVideo')
    document,subtitle,caption,metadata=session.calls('sendDocument')
    audio,=session.calls('sendAudio')
    assert uploaded_files(video)==[('0001.compressed.mp4',VIDEO)]
    assert uploaded_files(document)==[(POST_ID+'.mp4',VIDEO)]
    assert json.loads(video['fields']['reply_parameters'])['message_id']==77
    assert uploaded_files(subtitle)==[('subtitle.vtt',b'WEBVTT\n')]
    assert uploaded_files(audio)==[('sound.mp3',b'audio')]
    assert uploaded_files(caption)==[(POST_ID+'.txt',title.encode())]
    assert uploaded_files(metadata)[0][0]==POST_ID+'.metadata.json'
    for request in (document,subtitle,caption,metadata,audio):
        assert request['fields']['caption']==BOT_ATTRIBUTION
        assert request['fields']['message_thread_id']=='12'
        assert json.loads(request['fields']['reply_parameters'])['message_id']==201
    assert downloads==['https://vt.tiktok.com/example/'] and state.job(jid)['status']=='done'
    assert not controls(session) and not state.outstanding(1)
    state.close()


@pytest.mark.asyncio
@pytest.mark.parametrize('file_batches',[0,2])
async def test_both_album_copies_resume_in_order_with_the_original_names(tmp_path,monkeypatch,file_batches):
    state,session,bot,runner=setup(tmp_path)
    state.set('files:1','both')
    jid,_=state.submit(1,-10,77,12,POST_URL)
    state.change(jid,status='running')
    for mid in (201,401,801,1001):
        session.queue('sendMediaGroup',[message(-10,mid+i) for i in range(10)])
    session.queue('sendPhoto',message(-10,601))
    session.queue('sendDocument',message(-10,1201))
    def uploads():
        return [r for r in session.requests if r['api'] in ('sendMediaGroup','sendPhoto','sendDocument')]
    status=runner.status
    async def interrupted(jid,text):
        if len(uploads())==3+file_batches:
            raise asyncio.CancelledError()
        await status(jid,text)
    monkeypatch.setattr(runner,'status',interrupted)
    async with bot.context():
        folder=runner.work/'album';folder.mkdir()
        with pytest.raises(asyncio.CancelledError):
            await runner.deliver(jid,photo_records(folder,21),folder,'Post title')
        row=state.job(jid)
        assert row['files_mode']=='both' and row['reply_message']==201
        assert row['photo_reply_message']==601 and row['in_flight'] is None
        assert row['files_photo_reply_message']==(1001 if file_batches else None)
        state.set('files:1','off_no_button')
        state.close()
        state=State(tmp_path/'state.db');state.recover()
        assert state.job(jid)['status']=='ready'
        restored=Runner(state,bot,tmp_path,7,99);restored.api=runner.api
        folder=restored.work/'album';folder.mkdir()
        records=photo_records(folder,21)
        await restored.deliver(jid,records,folder,'Post title')
        await restored.deliver(jid,records,folder,'Post title')
    regular,copies=uploads()[:3],uploads()[3:]
    assert [len(r['files']) for r in regular]==[10,10,1]
    assert [len(r['files']) for r in copies]==[10,10,1]
    assert [json.loads(r['fields']['reply_parameters'])['message_id'] for r in uploads()]==[77,201,401,201,801,1001]
    for request in copies[:2]:
        media=json.loads(request['fields']['media'])
        assert all(item['type']=='document' and item['disable_content_type_detection'] for item in media)
        assert media[0]['caption']==BOT_ATTRIBUTION
    assert copies[-1]['fields']['caption']==BOT_ATTRIBUTION
    assert [item for request in copies for item in uploaded_files(request)]==[
        (f'{POST_ID}_{i+1:02d}.jpg',f'image {i}'.encode()) for i in range(21)]
    assert state.job(jid)['photo_reply_message']==601 and state.job(jid)['files_photo_reply_message']==1201
    assert not controls(session)
    state.close()


@pytest.mark.asyncio
@pytest.mark.parametrize('extension',['jpg','png','webp'])
async def test_both_single_photo_keeps_the_post_id_without_a_number(tmp_path,extension):
    state,session,bot,runner=setup(tmp_path)
    state.set('files:1','both')
    jid,_=state.submit(1,-10,77,12,POST_URL)
    folder=runner.work/'photo';folder.mkdir()
    name='download.'+extension
    (folder/name).write_bytes(b'photo bytes')
    record={'file':name,'kind':'image','width':40,'height':60,'sha256':'photo'}
    async with bot.context():
        await runner.deliver(jid,[record],folder,'Post title')
    assert len(session.calls('sendPhoto'))==int(extension!='webp')
    document,=session.calls('sendDocument')
    assert uploaded_files(document)==[(POST_ID+'.'+extension,b'photo bytes')]
    assert json.loads(document['fields']['disable_content_type_detection'])
    state.close()


@pytest.mark.asyncio
@pytest.mark.parametrize('case',['video_rejected','document_unconfirmed'])
async def test_both_upload_handles_video_fallback_and_unconfirmed_documents(tmp_path,monkeypatch,case):
    state,session,bot,runner=setup(tmp_path)
    state.set('files:1','both')
    jid,_=state.submit(1,-10,77,12,POST_URL)
    state.change(jid,status='running')
    if case=='video_rejected':
        session.queue('sendVideo',status=400,description='Unsupported video')
    else:
        session.queue('sendDocument',status=500)
    async def download(row,folder):
        folder.mkdir()
        return {'ok':True,'media':[video_record(folder)]}
    monkeypatch.setattr(runner,'worker',download)
    async with bot.context():
        await runner.run_job(jid)
    assert len(session.calls('sendVideo'))==1
    document,=session.calls('sendDocument')
    assert uploaded_files(document)==[(POST_ID+'.mp4',VIDEO)]
    row=state.job(jid)
    if case=='video_rejected':
        assert row['status']=='done' and len(json.loads(row['sent']))==2 and row['in_flight'] is None
    else:
        assert row['status']=='uncertain' and row['in_flight']
        assert len(json.loads(row['sent']))==1
    state.recover()
    assert not state.ready() and not (runner.work/str(jid)).exists()
    state.close()


@pytest.mark.asyncio
@pytest.mark.parametrize('photos',[False,True])
async def test_file_taps_redownload_only_media_reply_to_source_and_repeat_after_restart(tmp_path,monkeypatch,photos):
    now=[2000000000.0]
    monkeypatch.setattr('state.time.time',lambda:now[0])
    requested=extracted_post(monkeypatch,photos=photos)
    state,session,bot,runner=setup(tmp_path)
    async with bot.context():
        jid,_=await source(state,session,runner,photos=int(photos))
        binding=state.job(jid)['files_button_message']
        def tap():return callback(bot,f'files:{jid}',chat=-10,mid=binding,message_thread_id=12)
        first=tap();await runner.handle(first)
        child=state.outstanding(1)[0]
        assert child['files_only'] and not child['audio_only'] and not child['subtitles_only']
        assert child['message_id']==201 and child['thread_id']==12
        assert child['compression']==state.job(jid)['compression']
        assert all(child[field]=='off_no_button' for field in ('audio_mode','subtitle_mode','caption_mode','metadata_mode'))
        state.set('audio:1','on');state.set('subtitles:1','on')
        state.set('caption:1','on');state.set('metadata:1','on')
        async def download(row,folder):
            folder.mkdir(parents=True,exist_ok=True)
            return worker.download(row['url'],folder,include_audio=False,audio_button=False,
                include_subtitles=False,subtitle_button=False,include_metadata=False,compression={'mode':'none'})
        runner.worker=download
        await runner.run_job(child['id'])
        assert state.job(child['id'])['status']=='done' and not (runner.work/str(child['id'])).exists()
        receipt=state.job(child['id'])['sent']
        assert receipt!='[]' and state.button_remaining(jid,'files')==100
        assert state.button_remaining(jid,'audio')==state.button_remaining(jid,'subtitles')==0
        now[0]+=99
        await runner.handle(tap())
        assert not state.outstanding(1)
        assert session.calls('answerCallbackQuery')[-1]['fields']['text']=='Try this button again in 0:01 (min:sec)'
        state.close();state=State(tmp_path/'state.db')
        runner=Runner(state,bot,tmp_path,7,99)
        async def fast(chat,operation):return await operation()
        runner.api=fast;runner.worker=download
        assert state.button_remaining(jid,'files')==1
        now[0]+=1
        second=tap();await runner.handle(second)
        next_child=state.outstanding(1)[0]
        assert next_child['id']!=child['id']
        await runner.run_job(next_child['id'])
        assert state.job(child['id'])['sent']==receipt
        uploads=session.calls('sendDocument')
        assert len(uploads)==2
        assert all(json.loads(request['fields']['reply_parameters'])['message_id']==201 for request in uploads)
        assert all(request['fields']['caption']==BOT_ATTRIBUTION for request in uploads)
        assert all(next(iter(request['files'].values()))['filename']==POST_ID+('.jpg' if photos else '.mp4')
                   for request in uploads)
        assert len(requested)==2 and all(url.endswith('photo.jpg' if photos else 'video.mp4') for url in requested)
        assert not session.calls('sendAudio')
        assert len(controls(session))==1
        now[0]+=100
        await runner.handle(first);await runner.handle(second)
        assert not state.outstanding(1)
    state.close()


@pytest.mark.asyncio
@pytest.mark.parametrize('invalid',['user','chat','message','topic','cancelled','stopping'])
async def test_invalid_file_taps_never_admit_work_or_start_the_timer(tmp_path,invalid):
    state,session,bot,runner=setup(tmp_path)
    async with bot.context():
        jid,_=await source(state,session,runner)
        values={'chat':-10,'mid':state.job(jid)['files_button_message'],'message_thread_id':12}
        if invalid=='user':values['user']=2
        if invalid=='chat':values['chat']=-20
        if invalid=='message':values['mid']+=1
        if invalid=='topic':values['message_thread_id']=13
        if invalid=='cancelled':state.change(jid,status='cancelled')
        if invalid=='stopping':runner.stop.set()
        await runner.handle(callback(bot,f'files:{jid}',**values))
        assert not state.outstanding() and state.button_remaining(jid,'files')==0
    state.close()


@pytest.mark.asyncio
@pytest.mark.parametrize('status',[400,413,500])
async def test_file_button_rejection_retries_but_lost_ack_requires_an_owned_click(tmp_path,status):
    state,session,bot,runner=setup(tmp_path)
    session.queue('sendMessage',status=status)
    async with bot.context():
        jid,_=await source(state,session,runner)
        row=state.job(jid)
        assert row['files_button_pending'] and not row['files_button_message']
        assert bool(row['files_button_in_flight'])==(status==500)
        state.close();state=State(tmp_path/'state.db');runner.state=state
        await runner.install_files_button(jid)
        assert len(controls(session))==(1 if status==500 else 2)
        if status==500:
            await runner.handle(callback(bot,f'files:{jid}',chat=-10,mid=909,message_thread_id=12,
                reply_to_message=message(-10,999)))
            assert not state.outstanding()
            await runner.handle(callback(bot,f'files:{jid}',chat=-10,mid=909,message_thread_id=12,
                reply_to_message=message(-10,201)))
            assert state.job(jid)['files_button_message']==909
            assert not state.job(jid)['files_button_pending'] and not state.job(jid)['files_button_in_flight']
            assert len(state.outstanding(1))==1
        else:
            assert state.job(jid)['files_button_message']
            assert not state.job(jid)['files_button_pending']
        assert len(session.calls('sendVideo'))==1
    state.close()


@pytest.mark.asyncio
@pytest.mark.parametrize('user',[1,7,99])
async def test_file_requests_obey_selected_concurrency_and_waiting_exemptions(tmp_path,user):
    state,session,bot,runner=setup(tmp_path)
    async with bot.context():
        jid,_=await source(state,session,runner)
        # Rebind this post to its owner to exercise the same callback as normal users.
        with state.db:state.db.execute('UPDATE jobs SET user_id=? WHERE id=?',(user,jid))
        state.set_queue_mode(user,'sequential')
        for index in range(20):
            state.submit(user,-10,100+index,12,f'https://www.tiktok.com/@x/video/{100+index}',user!=1)
        await runner.handle(callback(bot,f'files:{jid}',user=user,chat=-10,
            mid=state.job(jid)['files_button_message'],message_thread_id=12))
        child=state.outstanding(user)[-1]
        assert child['files_only'] and child['status']==('deferred' if user==1 else 'queued')
        assert sum(row['status']=='ready' for row in state.outstanding(user))==1
    state.close()


@pytest.mark.asyncio
async def test_file_worker_uses_source_compression_and_omits_auxiliary_downloads(tmp_path,monkeypatch):
    state,session,bot,runner=setup(tmp_path)
    async with bot.context():
        jid,_=await source(state,session,runner)
        await runner.handle(callback(bot,f'files:{jid}',chat=-10,
            mid=state.job(jid)['files_button_message'],message_thread_id=12))
    child=state.outstanding(1)[0]
    captured=[]
    async def start(*args,**kwargs):
        captured.append(args)
        (Path(args[3])/'result.json').write_text('{"ok":true,"media":[]}')
        class Process:
            returncode=0
            async def wait(self):return 0
        return Process()
    monkeypatch.setattr(asyncio,'create_subprocess_exec',start)
    for key in ('audio','subtitles','caption','metadata'):state.set(f'{key}:1','on')
    state.set('compression:1',json.dumps({'mode':'all','fps':'60'}))
    await runner.worker(child,runner.work/'files')
    args=captured[0]
    assert '--audio=off_no_button' in args and '--subtitles=off_no_button' in args and '--metadata=off_no_button' in args
    compression=json.loads(next(arg.split('=',1)[1] for arg in args if arg.startswith('--compression=')))
    assert compression==options(child['compression'])
    assert compression['mode']=='none' and compression['fps']=='24'
    assert '--audio-only' not in args and '--subtitles-only' not in args
    state.close()


@pytest.mark.asyncio
@pytest.mark.parametrize('mode',['on','both'])
async def test_file_modes_keep_one_set_of_controls_and_do_not_affect_sound_posts(tmp_path,monkeypatch,mode):
    extracted_post(monkeypatch)
    state,session,bot,runner=setup(tmp_path)
    state.set('files:1',mode)
    jid,_=state.submit(1,-10,77,12,POST_URL)
    folder=runner.work/'media';folder.mkdir()
    result=worker.download(POST_URL,folder,include_audio=False,include_subtitles=False,
                           audio_button=True,subtitle_button=True,compression={'mode':'none'})
    async with bot.context():
        await runner.deliver(jid,result['media'],folder)
        fields=session.calls('sendDocument' if mode=='on' else 'sendVideo')[0]['fields']
        assert [button['text'] for row in json.loads(fields['reply_markup'])['inline_keyboard'] for button in row]==[
            'Extract audio','Extract subtitles']
        if mode=='both':
            assert 'reply_markup' not in session.calls('sendDocument')[0]['fields']
        sound,_=state.submit(1,-10,78,12,'https://www.tiktok.com/music/sound-555')
        (folder/'sound.mp3').write_bytes(b'audio')
        await runner.deliver(sound,[{'file':'sound.mp3','kind':'audio','sha256':'audio','reply_to_source':True}],folder)
        assert len(session.calls('sendAudio'))==1 and len(session.calls('sendDocument'))==1
        assert not controls(session)
    state.close()


def test_old_database_adds_file_fields_without_changing_existing_jobs_or_preferences(tmp_path):
    state=State(tmp_path/'state.db')
    jid,_=state.submit(1,1,1,None,POST_URL)
    state.change(jid,status='done',sent='["old-receipt"]',reply_message=201)
    state.set('queue_mode:1','sequential');state.set('audio:1','off')
    columns=('files_mode','files_only','files_photo_reply_message',
             'files_button_message','files_button_pending','files_button_in_flight')
    with state.db:
        for column in columns:state.db.execute('ALTER TABLE jobs DROP COLUMN '+column)
    before=dict(state.job(jid));state.close()
    state=State(tmp_path/'state.db')
    after=dict(state.job(jid))
    assert {key:value for key,value in after.items() if key not in columns}==before
    assert after['files_mode'] is None and after['files_only']==0 and after['files_button_message'] is None
    assert after['files_photo_reply_message'] is None
    assert state.get('audio:1')=='off' and state.queue_mode(1)=='sequential'
    state.close()


@pytest.mark.asyncio
@pytest.mark.parametrize('status',[400,500])
async def test_file_upload_rejections_and_unconfirmed_sends_retain_correct_recovery_state(tmp_path,status):
    state,session,bot,runner=setup(tmp_path)
    async with bot.context():
        jid,_=await source(state,session,runner)
        await runner.handle(callback(bot,f'files:{jid}',chat=-10,
            mid=state.job(jid)['files_button_message'],message_thread_id=12))
        child=state.outstanding(1)[0]
        async def download(row,folder):
            folder.mkdir(parents=True,exist_ok=True)
            return {'ok':True,'media':[video_record(folder)]}
        runner.worker=download
        session.queue('sendDocument',status=status)
        await runner.run_job(child['id'])
        row=state.job(child['id'])
        assert row['status']==('uncertain' if status==500 else 'failed')
        assert bool(row['in_flight'])==(status==500)
        assert row['sent']=='[]' and not (runner.work/str(child['id'])).exists()
        state.recover()
        assert not state.ready() and len(session.calls('sendDocument'))==1
        assert state.button_remaining(jid,'files')>0
    state.close()
