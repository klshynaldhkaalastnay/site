import asyncio
from types import SimpleNamespace as NS
import pytest
from aiogram.exceptions import TelegramForbiddenError
from aiogram.methods import CopyMessage
from bot import Runner
from state import State

class Bot:
    def __init__(self):self.copies=[];self.messages=[];self.error={};self.edits=[]
    async def copy_message(self,**kwargs):
        self.copies.append(kwargs)
        if kwargs['chat_id'] in self.error:raise self.error[kwargs['chat_id']]
        return NS(message_id=900+len(self.copies))
    async def send_message(self,chat,text,**kwargs):
        self.messages.append((chat,text,kwargs));return NS(message_id=50)
    async def edit_message_text(self,text,**kwargs):self.edits.append(text)

class Query:
    def __init__(self,bid,action='send',user=7):
        self.data=f'broadcast:{bid}:{action}';self.from_user=NS(id=user);self.message=NS(chat=NS(id=7),message_id=50)
    async def answer(self):pass

def setup(tmp_path):
    state=State(tmp_path/'state.db');bot=Bot();r=Runner(state,bot,tmp_path,7,99)
    async def fast(chat,op):return await op()
    r.api=fast
    return state,bot,r

def message():return NS(chat=NS(id=7),message_id=22,message_thread_id=None,reply_to_message=NS(message_id=11))

@pytest.mark.asyncio
async def test_owner_preview_confirm_and_duplicate_click(tmp_path):
    state,bot,r=setup(tmp_path)
    r.broadcasts.track(1);r.broadcasts.track(-20,'supergroup');r.broadcasts.track(2,active=False)
    await r.broadcasts.command(message(),1)
    assert not bot.copies
    await r.broadcasts.command(message(),7)
    assert bot.copies==[{'chat_id':7,'from_chat_id':7,'message_id':11}]
    assert '2 chats' in bot.messages[-1][1]
    await r.broadcasts.callback(Query(1,user=1))
    await r.broadcasts.step();assert len(bot.copies)==1
    await r.broadcasts.callback(Query(1));await r.broadcasts.callback(Query(1))
    for _ in range(4):await r.broadcasts.step()
    assert [m['chat_id'] for m in bot.copies]==[7,-20,1]
    assert all(m['message_id']==901 for m in bot.copies[1:])
    assert 'Sent: 2' in bot.messages[-1][1]
    await r.broadcasts.command(message(),7);assert len(bot.copies)==3
    state.close()

@pytest.mark.asyncio
async def test_cancel_resume_and_blocked_recipient(tmp_path):
    state,bot,r=setup(tmp_path)
    for c in (1,2,3):r.broadcasts.track(c)
    await r.broadcasts.command(message(),7)
    await r.broadcasts.callback(Query(1,'cancel'))
    await r.broadcasts.step();assert len(bot.copies)==1
    m=message();m.message_id=23
    await r.broadcasts.command(m,7);await r.broadcasts.callback(Query(2))
    await r.broadcasts.step() # user 1 confirmed
    r.broadcasts.receipt(2,2,'sending') # process interruption
    state.close()
    state,bot,r=setup(tmp_path);r.broadcasts.recover()
    bot.error[3]=TelegramForbiddenError(method=CopyMessage(chat_id=3,from_chat_id=7,message_id=902),message='blocked')
    for _ in range(3):await r.broadcasts.step()
    assert [m['chat_id'] for m in bot.copies]==[3]
    assert r.broadcasts.db.execute('SELECT active FROM known_chats WHERE chat_id=3').fetchone()[0]==0
    assert 'Sent: 1' in bot.messages[-1][1] and 'Unconfirmed: 1' in bot.messages[-1][1]
    state.close()

@pytest.mark.asyncio
async def test_new_chat_and_membership_tracking(tmp_path):
    state,bot,r=setup(tmp_path)
    msg=NS(from_user=NS(id=5,is_bot=False),chat=NS(id=5),message_id=1,message_thread_id=None,text='/start',caption=None)
    await r.handle(NS(message=msg))
    assert r.broadcasts.db.execute('SELECT active FROM known_chats WHERE chat_id=5').fetchone()[0]==1
    await r.handle(NS(my_chat_member=NS(chat=NS(id=-20,type='supergroup'),new_chat_member=NS(status='administrator'))))
    await r.handle(NS(my_chat_member=NS(chat=NS(id=-20,type='supergroup'),new_chat_member=NS(status='left'))))
    assert r.broadcasts.db.execute('SELECT active FROM known_chats WHERE chat_id=-20').fetchone()[0]==0
    state.close()
