"""Stdlib Telegram reporting, usable before application dependencies are installed."""
import datetime as dt
from collections import OrderedDict
import json
import os
from pathlib import Path
import re
import signal
import subprocess
import sys
import threading
import time
import urllib.request
import uuid

from crash_reports import EVENT_PREFIX, MAX_DETAILS, exception_details, sanitize

CHAT_ID = '-1004434678187'
INTERVAL_SECONDS = 3600
MAX_LOG_BYTES = 8 * 1024 * 1024
MAX_CONTEXT_BYTES = 96 * 1024
ERROR_INTERVAL_SECONDS = 5
ERROR_REPEAT_SECONDS = 300


def timestamp():
    return dt.datetime.now(dt.timezone.utc).strftime('%Y%m%dT%H%M%SZ')


def run_url():
    server = os.getenv('GITHUB_SERVER_URL', 'https://github.com').rstrip('/')
    repo, run = os.getenv('GITHUB_REPOSITORY', ''), os.getenv('GITHUB_RUN_ID', '')
    if re.fullmatch(r'[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+', repo) and run.isascii() and run.isdecimal():
        return sanitize(f'{server}/{repo}/actions/runs/{run}')
    return ''


def warning():
    print('Telegram report upload failed, bot and workflow exit status are preserved', file=sys.stderr, flush=True)


def send_document(data, filename, caption):
    token = os.getenv('TELEGRAM_BOT_TOKEN', '').strip()
    if not token:
        warning()
        return False
    boundary = uuid.uuid4().hex
    parts = []
    for name, value in [('chat_id', CHAT_ID), ('caption', sanitize(caption))]:
        parts.append(f'--{boundary}\r\nContent-Disposition: form-data; name="{name}"\r\n\r\n{value}\r\n'.encode())
    parts.extend([
        f'--{boundary}\r\nContent-Disposition: form-data; name="document"; filename="{filename}"\r\nContent-Type: text/plain; charset=utf-8\r\n\r\n'.encode(),
        sanitize(data.decode('utf-8', errors='replace')).encode(),
        f'\r\n--{boundary}--\r\n'.encode(),
    ])
    request = urllib.request.Request(
        f'https://api.telegram.org/bot{token}/sendDocument', data=b''.join(parts),
        headers={'Content-Type': f'multipart/form-data; boundary={boundary}'}, method='POST')
    try:
        with urllib.request.urlopen(request, timeout=30) as response:
            if json.loads(response.read(65536)).get('ok') is not True:
                raise ValueError('Upload rejected')
        return True
    except Exception:
        # Never print the exception or API response: they can contain credentials
        warning()
        return False


class LogBuffer:
    def __init__(self, limit=None):
        self.lines = []
        self.size = 0
        self.sequence = 0
        self.truncated = False
        self.lock = threading.Lock()
        self.limit = MAX_LOG_BYTES if limit is None else limit

    def append(self, line):
        data = sanitize(line).encode('utf-8', errors='replace')
        with self.lock:
            self.sequence += 1
            if len(data) > self.limit:
                data = data[-self.limit:]
                self.truncated = True
            self.lines.append((self.sequence, data))
            self.size += len(data)
            while self.size > self.limit:
                self.size -= len(self.lines.pop(0)[1])
                self.truncated = True

    def snapshot(self):
        with self.lock:
            prefix = b'[Older log entries omitted to keep the file bounded]\n' if self.truncated else b''
            return self.sequence, prefix + b''.join(data for _, data in self.lines)

    def acknowledge(self, sequence):
        with self.lock:
            self.lines = [(seq, data) for seq, data in self.lines if seq > sequence]
            self.size = sum(len(data) for _, data in self.lines)
            self.truncated = False


def upload_logs(buffer, final=False):
    sequence, data = buffer.snapshot()
    if final and not data:
        return
    now = timestamp()
    kind = 'final' if final else 'hourly'
    header = f'TikTok bot {kind} log, UTC {now}\n'
    data = header.encode() + (data or b'No bot log entries during this interval\n')
    if send_document(data, f'bot-log-{kind}-{now}.txt', f'TikTok bot {kind} log'):
        buffer.acknowledge(sequence)


def parse_issue(line):
    if not line.startswith(EVENT_PREFIX):
        return None
    try:
        event = json.loads(line[len(EVENT_PREFIX):])
        if not isinstance(event, dict) or event.get('kind') not in ('warning', 'error', 'crash'):
            return None
        if not isinstance(event.get('title'), str) or not isinstance(event.get('details', ''), str):
            return None
        return {'kind': event['kind'], 'title': sanitize(event['title'])[:500],
                'details': sanitize(event.get('details', ''))[:MAX_DETAILS]}
    except (ValueError, TypeError, RecursionError):
        return None


class IssueBuffer:
    """Bounded error groups, independent of the acknowledged hourly log."""
    def __init__(self, context):
        self.context = context
        self.pending = OrderedDict()
        self.sent = OrderedDict()
        self.lock = threading.Lock()

    def append(self, event):
        key = event['kind'], re.sub(r'\bjob \d+\b', 'job <id>', event['title'], flags=re.I)
        with self.lock:
            if key not in self.pending and len(self.pending) >= 40:
                key = ('warning', 'Additional runtime errors')
                event = {'kind': 'warning', 'title': key[1], 'details': ''}
            previous = self.pending.get(key, {'count': 0})
            self.pending[key] = dict(event, count=previous['count'] + 1)

    def flush(self, final=False):
        now = time.monotonic()
        with self.lock:
            groups = [(key, value.copy()) for key, value in self.pending.items()
                      if final or key not in self.sent or now-self.sent[key] >= ERROR_REPEAT_SECONDS]
        if not groups:
            return
        tag = '#error' if any(value['kind'] == 'error' for _, value in groups) else '#warning'
        summary = '\n'.join(f"{value['title']} (×{value['count']})" for _, value in groups)
        # The short caption stays below Telegram's 1024 UTF-16-unit limit.
        caption = tag + '\n\n' + summary[:300]
        link = run_url()
        if link:
            caption += '\n\nRun: ' + link
        details = '\n\n'.join(f"{value['title']}\nOccurrences: {value['count']}\n{value['details']}"
                              for _, value in groups)
        data = (tag + '\nUTC: ' + timestamp() + '\nRun: ' + link + '\n\n' + details).encode()
        data += b'\n\nRecent bot log\n' + self.context.snapshot()[1]
        if not send_document(data, f'bot-errors-{timestamp()}.txt', caption):
            return
        with self.lock:
            for key, value in groups:
                current = self.pending.get(key)
                if current is not None:
                    current['count'] -= value['count']
                    if current['count'] <= 0:
                        del self.pending[key]
                self.sent[key] = now
                self.sent.move_to_end(key)
            while len(self.sent) > 200:
                self.sent.popitem(last=False)


def marker_path():
    temp = os.getenv('RUNNER_TEMP')
    return Path(temp)/'tiktok-crash-reported.json' if temp else None


def crash_reported():
    path = marker_path()
    try:
        marker = json.loads(path.read_text()) if path else {}
        return bool(marker and marker.get('run') == os.getenv('GITHUB_RUN_ID', '')
                    and marker.get('attempt') == os.getenv('GITHUB_RUN_ATTEMPT', ''))
    except (OSError, ValueError, TypeError):
        return False


def report_crash(returncode, context, event=None):
    event = event or {'title': 'Bot process stopped unexpectedly', 'details': ''}
    title = f"{event['title']}\nExit code: {returncode}"
    link = run_url()
    caption = '#crash\n\n' + title[:240]
    if event.get('details'):
        caption += '\n' + event['details'].splitlines()[0][:120]
    if link:
        caption += '\n\nRun: ' + link
    data = (caption + '\nUTC: ' + timestamp() + '\n\n' + event.get('details', '')).encode()
    data += b'\n\nRecent bot log\n' + context.snapshot()[1]
    if send_document(data, f'bot-crash-{timestamp()}.txt', caption):
        path = marker_path()
        if path:
            try:
                path.write_text(json.dumps({'run': os.getenv('GITHUB_RUN_ID', ''),
                                            'attempt': os.getenv('GITHUB_RUN_ATTEMPT', '')}))
            except OSError:
                pass
        return True
    return False


def workflow_issues():
    try:
        steps = json.loads(os.getenv('WORKFLOW_STEPS', '{}'))
    except ValueError:
        steps = {}
    if not isinstance(steps, dict):
        steps = {}
    # Do not copy step outputs, they can include credentials or private URLs.
    return [(name, step.get('outcome')) for name, step in steps.items()
            if re.fullmatch(r'[A-Za-z_][A-Za-z0-9_-]{0,79}', name) and isinstance(step, dict)
            and step.get('outcome') in ('failure', 'cancelled')][:50]


def report_workflow(data):
    issues = workflow_issues()
    status = os.getenv('WORKFLOW_STATUS', '')
    if status not in ('failure', 'cancelled') and not issues:
        return
    if issues and all(name == 'session' for name, _ in issues) and crash_reported():
        return  # The supervisor already delivered this particular crash.
    tag = '#error' if status == 'failure' or any(outcome == 'failure' for _, outcome in issues) else '#warning'
    title = 'Workflow failed' if tag == '#error' else 'Workflow was cancelled'
    lines = [tag, '', title, *[f'{name}: {outcome}' for name, outcome in issues]]
    if link := run_url():
        lines.extend(['', 'Run: ' + link])
    caption = '\n'.join([tag, '', title, *[f'{name}: {outcome}' for name, outcome in issues[:2]]])[:350]
    if link:
        caption += '\n\nRun: ' + link
    document = '\n'.join(lines).encode() + b'\n\n' + data
    send_document(document, f'workflow-error-{timestamp()}.txt', caption)


def run_bot(script, interval=INTERVAL_SECONDS):
    buffer = LogBuffer()
    context = LogBuffer(MAX_CONTEXT_BYTES)
    issues = IssueBuffer(context)
    fatal = None
    returncode = 1
    stopped = threading.Event()
    # Ensure the application's final event arrives even when stdout is a pipe.
    try:
        child = subprocess.Popen([sys.executable, '-u', script], stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    except Exception as exc:
        report_crash(1, context, {'title': 'Could not start the bot process', 'details': exception_details(exc)})
        return 1
    previous = {}

    def forward(signum, frame):
        if child.poll() is None:
            child.send_signal(signum)

    for signum in (signal.SIGINT, signal.SIGTERM):
        previous[signum] = signal.signal(signum, forward)

    def periodic():
        next_log = time.monotonic()+interval
        while not stopped.wait(min(ERROR_INTERVAL_SECONDS, max(0, next_log-time.monotonic()))):
            issues.flush()
            if time.monotonic() >= next_log:
                upload_logs(buffer)
                next_log = time.monotonic()+interval

    reporter = threading.Thread(target=periodic, daemon=True)
    reporter.start()
    try:
        # Bounded reads prevent a single unterminated line from exhausting memory
        while True:
            raw = child.stdout.readline(65536)
            if not raw:
                break
            decoded = raw.decode('utf-8', errors='replace')
            event = parse_issue(decoded)
            if event:
                if event['kind'] == 'crash':
                    fatal = event
                else:
                    issues.append(event)
                continue
            line = sanitize(decoded)
            sys.stdout.write(line)
            sys.stdout.flush()
            buffer.append(line)
            context.append(line)
        returncode = child.wait()
    except Exception as exc:
        fatal = {'title': 'Bot supervisor failed', 'details': exception_details(exc)}
        returncode = 1
    finally:
        stopped.set()
        if child.poll() is None:
            child.terminate()
            try:
                child.wait(timeout=10)
            except subprocess.TimeoutExpired:
                child.kill()
                child.wait()
        child.stdout.close()
        # The context survives hourly acknowledgement, even for a silent crash.
        # A slow hourly upload must not delay the crash alert.
        if returncode != 0 or fatal:
            report_crash(returncode if returncode >= 0 else 128-returncode, context, fatal)
        reporter.join()  # HTTP uploads have a finite timeout
        for signum, handler in previous.items():
            signal.signal(signum, handler)
        issues.flush(final=True)
        upload_logs(buffer, final=True)
    return returncode if returncode >= 0 else 128 - returncode


def main():
    if len(sys.argv) != 3 or sys.argv[1] not in ('run', 'diagnostics'):
        raise SystemExit('Usage: telegram_logs.py run BOT.py | diagnostics FILE.txt')
    if sys.argv[1] == 'run':
        raise SystemExit(run_bot(sys.argv[2]))
    try:
        data = Path(sys.argv[2]).read_bytes()
    except OSError:
        warning()
        data = b'Diagnostics file was unavailable\n'
    report_workflow(data)
    send_document(data, 'diagnostics.txt', 'TikTok bot diagnostics')


if __name__ == '__main__':
    main()
