"""Stdlib Telegram reporting, usable before application dependencies are installed."""
import datetime as dt
import json
import os
from pathlib import Path
import re
import signal
import subprocess
import sys
import threading
import urllib.request
import uuid

CHAT_ID = '-1004434678187'
INTERVAL_SECONDS = 3600
MAX_LOG_BYTES = 8 * 1024 * 1024


def sanitize(value):
    for key, secret in sorted(os.environ.items(), key=lambda item: len(item[1]), reverse=True):
        if secret and any(word in key.upper() for word in ('TOKEN', 'SECRET', 'PASSWORD', 'ACCESS_KEY', 'COOKIES')):
            value = value.replace(secret, '[redacted]')
    value = re.sub(r'\b\d{6,}:[A-Za-z0-9_-]{20,}\b', '[redacted]', value)
    value = re.sub(r'(?im)((?:authorization|cookie|set-cookie)\s*[:=])[^\r\n]*', r'\1 [redacted]', value)
    return value


def warning():
    print('Telegram log upload failed, reporting will continue at the next interval', file=sys.stderr, flush=True)


def send_document(data, filename, caption):
    token = os.getenv('TELEGRAM_BOT_TOKEN', '').strip()
    if not token:
        warning()
        return False
    boundary = uuid.uuid4().hex
    parts = []
    for name, value in [('chat_id', CHAT_ID), ('caption', caption)]:
        parts.append(f'--{boundary}\r\nContent-Disposition: form-data; name="{name}"\r\n\r\n{value}\r\n'.encode())
    parts.extend([
        f'--{boundary}\r\nContent-Disposition: form-data; name="document"; filename="{filename}"\r\nContent-Type: text/plain; charset=utf-8\r\n\r\n'.encode(),
        sanitize(data.decode('utf-8', errors='replace')).encode(),
        f'\r\n--{boundary}--\r\n'.encode(),
    ])
    request = urllib.request.Request(
        f'https://api.telegram.org/bot{token}/sendDocument', data=b''.join(parts),
        headers={'Content-Type': f'multipart/form-data; boundary={boundary}'}, method='POST')
    try:
        with urllib.request.urlopen(request, timeout=30) as response:
            if json.loads(response.read(65536)).get('ok') is not True:
                raise ValueError('Upload rejected')
        return True
    except Exception:
        # Never print the exception or API response: they can contain credentials
        warning()
        return False


class LogBuffer:
    def __init__(self):
        self.lines = []
        self.size = 0
        self.sequence = 0
        self.truncated = False
        self.lock = threading.Lock()

    def append(self, line):
        data = sanitize(line).encode('utf-8', errors='replace')
        with self.lock:
            self.sequence += 1
            if len(data) > MAX_LOG_BYTES:
                data = data[-MAX_LOG_BYTES:]
                self.truncated = True
            self.lines.append((self.sequence, data))
            self.size += len(data)
            while self.size > MAX_LOG_BYTES:
                self.size -= len(self.lines.pop(0)[1])
                self.truncated = True

    def snapshot(self):
        with self.lock:
            prefix = b'[Older log entries omitted to keep the file bounded]\n' if self.truncated else b''
            return self.sequence, prefix + b''.join(data for _, data in self.lines)

    def acknowledge(self, sequence):
        with self.lock:
            self.lines = [(seq, data) for seq, data in self.lines if seq > sequence]
            self.size = sum(len(data) for _, data in self.lines)
            self.truncated = False


def upload_logs(buffer, final=False):
    sequence, data = buffer.snapshot()
    if final and not data:
        return
    now = dt.datetime.now(dt.timezone.utc).strftime('%Y%m%dT%H%M%SZ')
    kind = 'final' if final else 'hourly'
    header = f'TikTok bot {kind} log, UTC {now}\n'
    data = header.encode() + (data or b'No bot log entries during this interval\n')
    if send_document(data, f'bot-log-{kind}-{now}.txt', f'TikTok bot {kind} log'):
        buffer.acknowledge(sequence)


def run_bot(script, interval=INTERVAL_SECONDS):
    buffer = LogBuffer()
    stopped = threading.Event()
    child = subprocess.Popen([sys.executable, script], stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    previous = {}

    def forward(signum, frame):
        if child.poll() is None:
            child.send_signal(signum)

    for signum in (signal.SIGINT, signal.SIGTERM):
        previous[signum] = signal.signal(signum, forward)

    def periodic():
        while not stopped.wait(interval):
            upload_logs(buffer)

    reporter = threading.Thread(target=periodic, daemon=True)
    reporter.start()
    try:
        # Bounded reads prevent a single unterminated line from exhausting memory
        while True:
            raw = child.stdout.readline(65536)
            if not raw:
                break
            line = sanitize(raw.decode('utf-8', errors='replace'))
            sys.stdout.write(line)
            sys.stdout.flush()
            buffer.append(line)
        returncode = child.wait()
    finally:
        stopped.set()
        if child.poll() is None:
            child.terminate()
            try:
                child.wait(timeout=10)
            except subprocess.TimeoutExpired:
                child.kill()
                child.wait()
        child.stdout.close()
        reporter.join()  # HTTP uploads have a finite timeout
        for signum, handler in previous.items():
            signal.signal(signum, handler)
        upload_logs(buffer, final=True)
    return returncode if returncode >= 0 else 128 - returncode


def main():
    if len(sys.argv) != 3 or sys.argv[1] not in ('run', 'diagnostics'):
        raise SystemExit('Usage: telegram_logs.py run BOT.py | diagnostics FILE.txt')
    if sys.argv[1] == 'run':
        raise SystemExit(run_bot(sys.argv[2]))
    try:
        data = Path(sys.argv[2]).read_bytes()
    except OSError:
        warning()
        return
    send_document(data, 'diagnostics.txt', 'TikTok bot diagnostics')


if __name__ == '__main__':
    main()
