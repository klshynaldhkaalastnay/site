"""Browser fallback for direct sound pages, isolated from post downloads."""
import asyncio
from contextlib import contextmanager
import fcntl
import http.cookiejar
import json
import os
from pathlib import Path
import tempfile
import time
from urllib.parse import urlsplit

MAX_METADATA = 2_000_000
BROWSER_DOMAINS = ('tiktok.com', 'tiktokcdn.com', 'tiktokcdn-us.com', 'tiktokv.com',
                   'tiktokv.us', 'tiktokw.us', 'ttwstatic.com', 'ttwstatic-us.com',
                   'byteoversea.com', 'ibyteimg.com', 'ibytedtos.com', 'byteimg.com')


def tiktok_domain(host):
    return host == 'tiktok.com' or host.endswith('.tiktok.com')


def browser_cookies(jar):
    result = []
    now = time.time()
    for cookie in jar:
        if not tiktok_domain(cookie.domain.lstrip('.')):
            continue
        if cookie.expires is not None and cookie.expires <= now:
            continue
        item = {'name':cookie.name, 'value':cookie.value, 'domain':cookie.domain,
                'path':cookie.path or '/', 'secure':cookie.secure,
                'httpOnly':cookie.has_nonstandard_attr('HttpOnly')}
        if cookie.expires is not None:
            item['expires'] = cookie.expires
        result.append(item)
    return result


@contextmanager
def browser_slot():
    # All download workers share one slot, preventing several Chromium instances
    # from exhausting the runner. The OS releases the lock on worker exit.
    path = Path(tempfile.gettempdir())/'tiktok-sound-browser.lock'
    with path.open('a') as lock:
        deadline = time.monotonic()+300
        while True:
            try:
                fcntl.flock(lock,fcntl.LOCK_EX | fcntl.LOCK_NB)
                break
            except BlockingIOError:
                if time.monotonic() >= deadline:
                    raise TimeoutError('Browser slot timeout')
                time.sleep(0.25)
        try:
            yield
        finally:
            fcntl.flock(lock,fcntl.LOCK_UN)


async def browse_sound(url, sound_id, session, find_music, note, factory=None):
    if factory is None:
        from playwright.async_api import async_playwright
        factory = async_playwright
    async with factory() as pw:
        browser = await pw.chromium.launch(headless=True,channel='chromium',timeout=20000)
        try:
            context = await browser.new_context(locale='en-US',accept_downloads=False,
                                                service_workers='block')
            cookies = browser_cookies(session.cookies)
            cookie_file = os.environ.get('TIKTOK_COOKIE_FILE')
            note('sound_browser','cookie_file_configured' if cookie_file else 'no_cookie_file_configured')
            if cookie_file:
                jar = http.cookiejar.MozillaCookieJar(cookie_file)
                try:
                    jar.load(ignore_discard=True)
                except OSError as exc:
                    note('sound_browser','cookie_file_unavailable',exc)
                else:
                    cookies.extend(browser_cookies(jar))
            if cookies:
                await context.add_cookies(cookies)
            note('sound_browser','cookies_added' if cookies else 'no_valid_cookies')
            page = await context.new_page()
            page.set_default_timeout(10000)
            found = None
            pending = set()

            def consume(data):
                nonlocal found
                if found is None:
                    found = find_music(data,sound_id)

            async def inspect_response(response):
                try:
                    p = urlsplit(response.url)
                    if not tiktok_domain(p.hostname or '') or p.path not in (
                            '/api/music/detail/', '/api/music/item_list/'):
                        return
                    size = int(response.headers.get('content-length','0'))
                    if size > MAX_METADATA:
                        return
                    body = await asyncio.wait_for(response.body(),10)
                    if body and len(body) <= MAX_METADATA:
                        consume(json.loads(body))
                except Exception:
                    # Other responses and empty/blocked endpoints are expected.
                    pass

            def observed(response):
                task = asyncio.create_task(inspect_response(response))
                pending.add(task)
                task.add_done_callback(pending.discard)

            async def filter_request(route):
                p = urlsplit(route.request.url)
                host = p.hostname or ''
                allowed = p.scheme == 'https' and any(host == d or host.endswith('.'+d) for d in BROWSER_DOMAINS)
                if not allowed or route.request.resource_type in ('image','media','font'):
                    await route.abort()
                else:
                    await route.continue_()

            await context.route('**/*',filter_request)
            page.on('response',observed)
            try:
                try:
                    await page.goto(url,wait_until='domcontentloaded',timeout=30000)
                except Exception as exc:
                    note('sound_browser','navigation_incomplete',exc)
                if not tiktok_domain(urlsplit(page.url).hostname or ''):
                    return None
                deadline = time.monotonic()+25
                fetched = False
                while time.monotonic() < deadline and found is None:
                    scripts = await page.locator(
                        'script#__UNIVERSAL_DATA_FOR_REHYDRATION__,script#SIGI_STATE').all_text_contents()
                    for script in scripts:
                        if len(script) <= MAX_METADATA:
                            try:
                                consume(json.loads(script))
                            except ValueError:
                                pass
                    if not fetched and time.monotonic() >= deadline-18 and found is None:
                        fetched = True
                        # Use the page's own SDK when available. No third-party
                        # service receives cookies or sound metadata.
                        token = next((c['value'] for c in await context.cookies()
                                      if c['name']=='msToken' and tiktok_domain(c['domain'].lstrip('.'))),'')
                        data = await page.evaluate('''async ({id, token}) => {
                            const params = new URLSearchParams({aid:'1988', app_name:'tiktok_web', musicId:id});
                            if (token) params.set('msToken',token);
                            let url = location.origin+'/api/music/detail/?'+params;
                            try {
                                const sdk = window.byted_acrawler;
                                if (sdk && typeof sdk.frontierSign === 'function') {
                                    const signed = await sdk.frontierSign(url);
                                    if (signed && signed['X-Bogus']) url += '&X-Bogus='+encodeURIComponent(signed['X-Bogus']);
                                }
                                const r = await fetch(url,{credentials:'include',signal:AbortSignal.timeout(8000)});
                                const body = await r.text();
                                return body.length <= 2000000 && body ? JSON.parse(body) : null;
                            } catch (_) { return null; }
                        }''',{'id':sound_id,'token':token})
                        consume(data)
                    if found is None:
                        await asyncio.sleep(0.5)
                if found:
                    # Reuse browser headers for the bounded downloader. Saved
                    # login cookies stay inside this temporary browser context.
                    session.headers['User-Agent'] = await page.evaluate('navigator.userAgent')
                    session.headers['Referer'] = url
                note('sound_browser','play_url_found' if found else 'no_play_url_for_requested_sound')
                return found
            finally:
                page.remove_listener('response',observed)
                for task in list(pending):
                    task.cancel()
                if pending:
                    await asyncio.gather(*list(pending),return_exceptions=True)
        finally:
            await browser.close()


def extract_sound(url, sound_id, session, find_music, note):
    note('sound_browser','waiting_for_slot')
    try:
        with browser_slot():
            note('sound_browser','starting')
            async def run():
                return await asyncio.wait_for(browse_sound(url,sound_id,session,find_music,note),80)
            return asyncio.run(run())
    except Exception as exc:
        note('sound_browser','failed',exc)
        return None
